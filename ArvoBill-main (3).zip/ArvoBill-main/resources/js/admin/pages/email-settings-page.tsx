import { useEffect, useState } from 'react';
import { getEmailSettings, sendEmailTest, updateEmailSettings } from '@/lib/affiliate-api';
import type { EmailSettingsPayload } from '@/types/affiliate';

export function EmailSettingsPage() {
    const [settings, setSettings] = useState<EmailSettingsPayload | null>(null);
    const [password, setPassword] = useState('');
    const [testEmail, setTestEmail] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [isTesting, setIsTesting] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    async function load() {
        try {
            setIsLoading(true);
            const payload = await getEmailSettings();
            setSettings(payload);
            setTestEmail(payload.from_address ?? '');
            setError(null);
        } catch (loadError) {
            setError(loadError instanceof Error ? loadError.message : 'Failed to load email settings.');
        } finally {
            setIsLoading(false);
        }
    }

    useEffect(() => {
        void load();
    }, []);

    async function save() {
        if (!settings) return;

        try {
            setIsSaving(true);
            await updateEmailSettings({
                host: settings.host,
                port: settings.port,
                username: settings.username,
                password: password || null,
                encryption: settings.encryption,
                from_address: settings.from_address,
                from_name: settings.from_name,
                enabled: settings.enabled,
            });
            setPassword('');
            setMessage('Email settings saved.');
            setError(null);
            await load();
        } catch (saveError) {
            setError(saveError instanceof Error ? saveError.message : 'Failed to save email settings.');
        } finally {
            setIsSaving(false);
        }
    }

    async function sendTest() {
        if (!testEmail) return;

        try {
            setIsTesting(true);
            await sendEmailTest(testEmail);
            setMessage('Test email queued. Check email logs/queue worker.');
            setError(null);
        } catch (testError) {
            setError(testError instanceof Error ? testError.message : 'Failed to send test email.');
        } finally {
            setIsTesting(false);
        }
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold">Email Settings</h2>
                <p className="mt-1 text-sm text-white/70">
                    Configure transactional SMTP delivery and queue test messages.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            {message ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-900/20 dark:text-emerald-300">
                    {message}
                </div>
            ) : null}

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                {isLoading || !settings ? (
                    <p className="text-sm text-white/70">Loading settings...</p>
                ) : (
                    <div className="grid gap-4 md:grid-cols-2">
                        <label className="space-y-1 text-sm">
                            <span className="font-medium">SMTP Host</span>
                            <input
                                type="text"
                                value={settings.host ?? ''}
                                onChange={(event) => setSettings({ ...settings, host: event.target.value || null })}
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                            />
                        </label>

                        <label className="space-y-1 text-sm">
                            <span className="font-medium">Port</span>
                            <input
                                type="number"
                                min={1}
                                max={65535}
                                value={settings.port}
                                onChange={(event) => setSettings({ ...settings, port: Number(event.target.value) })}
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                            />
                        </label>

                        <label className="space-y-1 text-sm">
                            <span className="font-medium">Username</span>
                            <input
                                type="text"
                                value={settings.username ?? ''}
                                onChange={(event) => setSettings({ ...settings, username: event.target.value || null })}
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                            />
                        </label>

                        <label className="space-y-1 text-sm">
                            <span className="font-medium">Password</span>
                            <input
                                type="password"
                                value={password}
                                onChange={(event) => setPassword(event.target.value)}
                                placeholder={settings.password_masked ?? 'Not set'}
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                            />
                        </label>

                        <label className="space-y-1 text-sm">
                            <span className="font-medium">Encryption</span>
                            <select
                                value={settings.encryption ?? 'tls'}
                                onChange={(event) =>
                                    setSettings({
                                        ...settings,
                                        encryption: event.target.value as 'tls' | 'ssl' | 'starttls',
                                    })
                                }
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                            >
                                <option value="tls">TLS</option>
                                <option value="ssl">SSL</option>
                                <option value="starttls">STARTTLS</option>
                            </select>
                        </label>

                        <label className="space-y-1 text-sm">
                            <span className="font-medium">From Address</span>
                            <input
                                type="email"
                                value={settings.from_address ?? ''}
                                onChange={(event) => setSettings({ ...settings, from_address: event.target.value || null })}
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                            />
                        </label>

                        <label className="space-y-1 text-sm">
                            <span className="font-medium">From Name</span>
                            <input
                                type="text"
                                value={settings.from_name ?? ''}
                                onChange={(event) => setSettings({ ...settings, from_name: event.target.value || null })}
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                            />
                        </label>

                        <label className="flex items-center gap-3 pt-6 text-sm">
                            <input
                                type="checkbox"
                                checked={settings.enabled}
                                onChange={(event) => setSettings({ ...settings, enabled: event.target.checked })}
                            />
                            <span>Enable email sending</span>
                        </label>
                    </div>
                )}

                <div className="mt-4 flex flex-wrap gap-2">
                    <button
                        type="button"
                        onClick={() => void save()}
                        disabled={isSaving || isLoading || !settings}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                    >
                        {isSaving ? 'Saving...' : 'Save Settings'}
                    </button>
                </div>
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="text-lg font-semibold">Send Test Email</h3>
                <div className="mt-3 flex flex-col gap-2 sm:flex-row">
                    <input
                        type="email"
                        value={testEmail}
                        onChange={(event) => setTestEmail(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        placeholder="admin@example.com"
                    />
                    <button
                        type="button"
                        onClick={() => void sendTest()}
                        disabled={isTesting || !testEmail}
                        className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10 disabled:opacity-60"
                    >
                        {isTesting ? 'Queueing...' : 'Send Test'}
                    </button>
                </div>
            </article>
        </section>
    );
}