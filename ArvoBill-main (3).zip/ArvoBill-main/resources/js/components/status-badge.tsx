import type { InvoiceStatus, OrderStatus, PaymentStatus } from '@/types/billing';
import type { ServiceStatus } from '@/types/service';
import type { TicketStatus } from '@/types/support';

type StatusValue = OrderStatus | InvoiceStatus | PaymentStatus | TicketStatus | ServiceStatus;

type StatusBadgeProps = {
    status: StatusValue;
};

const classMap: Record<StatusValue, string> = {
    pending: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
    unpaid: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
    provisioning: 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300',
    active: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    suspended: 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300',
    completed: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    paid: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    cancelled: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300',
    open: 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300',
    answered: 'bg-violet-100 text-violet-700 dark:bg-violet-900/30 dark:text-violet-300',
    closed: 'bg-zinc-200 text-zinc-700 dark:bg-zinc-800 dark:text-zinc-300',
    failed: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300',
};

export function StatusBadge({ status }: StatusBadgeProps) {
    return (
        <span
            className={`rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${classMap[status]}`}
        >
            {status}
        </span>
    );
}
