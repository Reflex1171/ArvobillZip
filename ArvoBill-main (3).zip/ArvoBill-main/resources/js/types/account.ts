export type AccountOverview = {
    active_services_count: number;
    open_tickets_count: number;
};

export type AccountProfile = {
    id: number;
    name: string;
    email: string;
    role: 'user' | 'staff' | 'admin' | 'superuser';
    created_at: string | null;
    overview: AccountOverview;
};

export type AdminPermission = {
    key: string;
    description: string;
};

export type AdminUserLinkedItem = {
    id: number;
    status?: string;
    subject?: string;
    priority?: string;
    total?: number;
    created_at?: string | null;
    updated_at?: string | null;
    product?: {
        id: number;
        name: string;
    } | null;
};

export type AdminUserDetail = {
    id: number;
    name: string;
    email: string;
    role: 'user' | 'staff' | 'admin' | 'superuser';
    permissions: string[];
    pterodactyl_user_id: number | null;
    pterodactyl_panel_url: string | null;
    created_at: string | null;
    last_login_at: string | null;
    available_permissions: AdminPermission[];
    services: AdminUserLinkedItem[];
    orders: AdminUserLinkedItem[];
    invoices: AdminUserLinkedItem[];
    tickets: AdminUserLinkedItem[];
};
