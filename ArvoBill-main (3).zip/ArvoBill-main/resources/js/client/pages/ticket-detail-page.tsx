import { FormEvent, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusBadge } from '@/components/status-badge';
import { getClientTicket, replyClientTicket } from '@/lib/support-api';
import type { TicketSummary } from '@/types/support';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
}

export function TicketDetailPage() {
    const { id = '' } = useParams();
    const [ticket, setTicket] = useState<TicketSummary | null>(null);
    const [reply, setReply] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadTicket() {
            try {
                setIsLoading(true);
                const data = await getClientTicket(id);
                setTicket(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load ticket.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadTicket();
    }, [id]);

    async function handleReply(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        try {
            setIsSubmitting(true);
            const updated = await replyClientTicket(id, reply);
            setTicket(updated);
            setReply('');
            setError(null);
        } catch (replyError) {
            setError(
                replyError instanceof Error
                    ? replyError.message
                    : 'Failed to submit reply.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    if (isLoading) {
        return <div className="text-sm text-white/70">Loading ticket...</div>;
    }

    if (!ticket) {
        return <div className="text-sm text-white/70">Ticket not found.</div>;
    }

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">
                        Ticket #{ticket.id}: {ticket.subject}
                    </h2>
                    <p className="mt-1 text-sm text-white/70">
                        Created {formatDate(ticket.created_at)}
                    </p>
                </div>
                <Link
                    to="/client/support"
                    className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
                >
                    Back to tickets
                </Link>
            </div>

            <div className="flex flex-wrap items-center gap-3 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4">
                <StatusBadge status={ticket.status} />
                <PriorityBadge priority={ticket.priority} />
                <span className="text-xs text-white/70">
                    Last updated: {formatDate(ticket.updated_at)}
                </span>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="space-y-3">
                {(ticket.messages ?? []).map((message) => (
                    <article
                        key={message.id}
                        className={`rounded-xl border p-4 ${
                            message.is_admin
                                ? 'border-[var(--panel-primary)]/40 bg-[var(--panel-primary)]/10'
                                : 'border-white/10 bg-[var(--panel-surface)]'
                        }`}
                    >
                        <div className="mb-2 flex items-center justify-between gap-4 text-xs text-white/70">
                            <span>
                                {message.is_admin
                                    ? `Admin${message.user ? ` (${message.user.name})` : ''}`
                                    : 'You'}
                            </span>
                            <span>{formatDate(message.created_at)}</span>
                        </div>
                        <p className="whitespace-pre-wrap text-sm text-[var(--panel-text)]">
                            {message.message}
                        </p>
                    </article>
                ))}
            </div>

            <form
                onSubmit={(event) => void handleReply(event)}
                className="space-y-3 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4"
            >
                <label className="block text-sm font-medium">Reply</label>
                <textarea
                    value={reply}
                    onChange={(event) => setReply(event.target.value)}
                    required
                    rows={5}
                    disabled={ticket.status === 'closed' || isSubmitting}
                    className="w-full rounded-lg border border-white/20 bg-transparent px-3 py-2 text-sm disabled:cursor-not-allowed disabled:opacity-60"
                />
                <button
                    type="submit"
                    disabled={ticket.status === 'closed' || isSubmitting}
                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-60"
                >
                    {ticket.status === 'closed'
                        ? 'Ticket closed'
                        : isSubmitting
                          ? 'Sending...'
                          : 'Send Reply'}
                </button>
            </form>
        </section>
    );
}

