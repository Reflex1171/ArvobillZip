import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { StatusBadge } from '@/components/status-badge';
import {
    cancelClientService,
    getClientService,
    updateClientServiceAutoRenew,
    updateClientServiceDefaultPaymentMethod,
    upgradeClientService,
} from '@/lib/services-api';
import { getClientBillingData } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import type { ServiceSummary } from '@/types/service';
import type { ClientBillingPaymentMethod } from '@/types/client-billing';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function ServiceDetailPage() {
    const { id = '' } = useParams();
    const [service, setService] = useState<ServiceSummary | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isUpdatingRenewal, setIsUpdatingRenewal] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [paymentMethods, setPaymentMethods] = useState<ClientBillingPaymentMethod[]>([]);
    const [selectedMethodId, setSelectedMethodId] = useState<string>('');
    const [showCancelModal, setShowCancelModal] = useState(false);
    const [cancelReason, setCancelReason] = useState('');
    const [cancelType, setCancelType] = useState<'immediate' | 'end_of_cycle'>('end_of_cycle');

    useEffect(() => {
        async function loadService() {
            try {
                const [data, billingData] = await Promise.all([
                    getClientService(id),
                    getClientBillingData().catch(() => null),
                ]);
                setService(data);
                const methods = billingData?.payment_methods ?? [];
                setPaymentMethods(methods);
                setSelectedMethodId(
                    data.default_payment_method
                        ? String(data.default_payment_method.id)
                        : '',
                );
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load service.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadService();
    }, [id]);

    async function handleUpgrade() {
        if (!service || service.status === 'cancelled') return;

        try {
            setIsSubmitting(true);
            const updated = await upgradeClientService(String(service.id));
            setService(updated);
            setMessage('Upgrade request placeholder triggered.');
            setError(null);
        } catch (upgradeError) {
            setError(
                upgradeError instanceof Error
                    ? upgradeError.message
                    : 'Failed to request upgrade.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleCancel() {
        if (!service || service.status === 'cancelled') return;

        try {
            setIsSubmitting(true);
            const updated = await cancelClientService(String(service.id), {
                reason: cancelReason.trim() || null,
                cancel_type: cancelType,
            });
            setService(updated);
            setMessage(
                cancelType === 'end_of_cycle'
                    ? 'Cancellation scheduled for the end of the billing cycle.'
                    : 'Service cancelled immediately.',
            );
            setError(null);
            setShowCancelModal(false);
            setCancelReason('');
            setCancelType('end_of_cycle');
        } catch (cancelError) {
            setError(
                cancelError instanceof Error
                    ? cancelError.message
                    : 'Failed to cancel service.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleToggleAutoRenew(nextValue: boolean) {
        if (!service) return;

        try {
            setIsUpdatingRenewal(true);
            const updated = await updateClientServiceAutoRenew(String(service.id), nextValue);
            setService(updated);
            setMessage(`Auto-renew ${nextValue ? 'enabled' : 'disabled'}.`);
            setError(null);
        } catch (renewError) {
            setError(
                renewError instanceof Error
                    ? renewError.message
                    : 'Failed to update auto-renew setting.',
            );
        } finally {
            setIsUpdatingRenewal(false);
        }
    }

    async function handleDefaultPaymentMethodSave() {
        if (!service) return;

        try {
            setIsUpdatingRenewal(true);
            const updated = await updateClientServiceDefaultPaymentMethod(
                String(service.id),
                selectedMethodId ? Number(selectedMethodId) : null,
            );
            setService(updated);
            setMessage('Default payment method updated.');
            setError(null);
        } catch (methodError) {
            setError(
                methodError instanceof Error
                    ? methodError.message
                    : 'Failed to update default payment method.',
            );
        } finally {
            setIsUpdatingRenewal(false);
        }
    }

    if (isLoading) {
        return <div className="text-sm text-white/70">Loading service...</div>;
    }

    if (!service) {
        return <div className="text-sm text-white/70">Service not found.</div>;
    }

    const isCancelled = service.status === 'cancelled';
    const isProvisioned = Boolean(service.pterodactyl_server_id);
    const panelLink = service.pterodactyl_panel_url && service.pterodactyl_identifier
        ? `${service.pterodactyl_panel_url}/server/${service.pterodactyl_identifier}`
        : null;

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">
                        Service #{service.id}
                    </h2>
                    <p className="mt-1 text-sm text-white/70">
                        Product: {service.product?.name ?? '-'}
                    </p>
                </div>
                <Link
                    to="/client/services"
                    className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
                >
                    Back to services
                </Link>
            </div>

            {message ? (
                <div className="rounded-lg border border-[var(--panel-accent)]/40 bg-[var(--panel-accent)]/15 p-4 text-sm text-[var(--panel-text)]">
                    {message}
                </div>
            ) : null}

            {service.status === 'provisioning' ? (
                <div className="rounded-lg border border-sky-300/40 bg-sky-500/10 p-4 text-sm text-sky-100">
                    Your server is being provisioned. This usually takes a few moments.
                </div>
            ) : null}

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            {service.provisioning_error ? (
                <div className="rounded-lg border border-rose-300/40 bg-rose-500/10 p-4 text-sm text-rose-100">
                    {service.provisioning_error}
                </div>
            ) : null}

            <div className="grid gap-4 md:grid-cols-2">
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                    <h3 className="font-semibold">Service Details</h3>
                    <dl className="mt-4 space-y-3 text-sm">
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Status</dt>
                            <dd>
                                <StatusBadge status={service.status} />
                            </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Billing Cycle</dt>
                            <dd>{service.billing_summary}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Next Due Date</dt>
                            <dd>{formatDate(service.next_due_at ?? service.next_due_date)}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Auto Renew</dt>
                            <dd>{service.auto_renew ? 'Enabled' : 'Disabled'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Cancellation</dt>
                            <dd>
                                {service.status === 'cancelled'
                                    ? 'Cancelled'
                                    : service.cancel_at_period_end
                                        ? 'Scheduled'
                                        : 'Active'}
                            </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Renewal Failures</dt>
                            <dd>{service.renewal_failure_count}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Pterodactyl Server ID</dt>
                            <dd>{service.pterodactyl_server_id ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Node</dt>
                            <dd>{service.pterodactyl_node_name ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Server Status</dt>
                            <dd>{service.pterodactyl_server_status ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Resource Limits</dt>
                            <dd>
                                {service.provisioning_limits
                                    ? `${service.provisioning_limits.memory}MB / ${service.provisioning_limits.cpu}% / ${service.provisioning_limits.disk}MB`
                                    : '-'}
                            </dd>
                        </div>
                    </dl>
                </article>

                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                    <h3 className="font-semibold">Billing Links</h3>
                    <dl className="mt-4 space-y-3 text-sm">
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Order</dt>
                            <dd>{service.order ? `#${service.order.id}` : '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Invoice</dt>
                            <dd>
                                {service.invoice ? (
                                    <Link
                                        to={`/client/invoices/${service.invoice.id}`}
                                        className="text-[var(--panel-primary)] hover:underline"
                                    >
                                        #{service.invoice.id}
                                    </Link>
                                ) : (
                                    '-'
                                )}
                            </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Invoice Total</dt>
                            <dd>
                                {service.invoice
                                    ? formatCurrency(service.invoice.total)
                                    : '-'}
                            </dd>
                        </div>
                    </dl>
                </article>
            </div>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="font-semibold">Subscription</h3>
                <div className="mt-4 space-y-4">
                    {service.billing_type !== 'recurring' ? (
                        <p className="text-sm text-white/70">
                            This service is billed one-time and does not renew automatically.
                        </p>
                    ) : (
                        <>
                            <div className="flex flex-wrap gap-2">
                                <button
                                    type="button"
                                    onClick={() => void handleToggleAutoRenew(true)}
                                    disabled={isUpdatingRenewal || service.status === 'cancelled'}
                                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                                >
                                    Enable Auto-Renew
                                </button>
                                <button
                                    type="button"
                                    onClick={() => void handleToggleAutoRenew(false)}
                                    disabled={isUpdatingRenewal || service.status === 'cancelled'}
                                    className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10 disabled:opacity-60"
                                >
                                    Disable Auto-Renew
                                </button>
                            </div>
                            <div className="grid gap-3 md:grid-cols-[1fr_auto] md:items-end">
                                <div>
                                    <label className="mb-1 block text-sm font-medium">
                                        Default renewal payment method
                                    </label>
                                    <select
                                        value={selectedMethodId}
                                        onChange={(event) => setSelectedMethodId(event.target.value)}
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                                        disabled={isUpdatingRenewal}
                                    >
                                        <option value="">None</option>
                                        {paymentMethods.map((method) => (
                                            <option key={method.id} value={method.id}>
                                                {method.label} ({method.masked_details})
                                            </option>
                                        ))}
                                    </select>
                                </div>
                                <button
                                    type="button"
                                    onClick={() => void handleDefaultPaymentMethodSave()}
                                    disabled={isUpdatingRenewal || service.status === 'cancelled'}
                                    className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10 disabled:opacity-60"
                                >
                                    Save Method
                                </button>
                            </div>
                        </>
                    )}
                </div>
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="font-semibold">Actions</h3>
                <div className="mt-4 flex flex-wrap gap-3">
                    {isProvisioned ? (
                        <a
                            href={panelLink ?? '#'}
                            target="_blank"
                            rel="noreferrer"
                            className={[
                                'rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10',
                                panelLink ? '' : 'pointer-events-none cursor-not-allowed opacity-50',
                            ].join(' ')}
                        >
                            Go to Game Panel
                        </a>
                    ) : (
                        <button
                            type="button"
                            disabled
                            className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold opacity-50"
                        >
                            Not Provisioned Yet
                        </button>
                    )}
                    <button
                        type="button"
                        disabled={isCancelled || isSubmitting}
                        onClick={() => void handleUpgrade()}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Upgrade Plan
                    </button>
                    <button
                        type="button"
                        disabled={isCancelled || isSubmitting}
                        onClick={() => setShowCancelModal(true)}
                        className="rounded-lg border border-rose-400/40 bg-rose-500/20 px-4 py-2 text-sm font-semibold text-rose-100 hover:bg-rose-500/30 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Cancel Service
                    </button>
                </div>
            </article>

            {showCancelModal ? (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                    <div className="w-full max-w-lg rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-xl">
                        <h3 className="text-lg font-semibold">Cancel Service</h3>
                        <p className="mt-2 text-sm text-white/70">
                            Choose when to cancel and optionally include a reason.
                        </p>

                        <div className="mt-4 space-y-4">
                            <div className="space-y-2 text-sm">
                                <label className="flex items-center gap-2">
                                    <input
                                        type="radio"
                                        name="cancel-type"
                                        value="end_of_cycle"
                                        checked={cancelType === 'end_of_cycle'}
                                        onChange={() => setCancelType('end_of_cycle')}
                                    />
                                    <span>Cancel at end of billing cycle</span>
                                </label>
                                <label className="flex items-center gap-2">
                                    <input
                                        type="radio"
                                        name="cancel-type"
                                        value="immediate"
                                        checked={cancelType === 'immediate'}
                                        onChange={() => setCancelType('immediate')}
                                    />
                                    <span>Cancel immediately</span>
                                </label>
                            </div>

                            <div>
                                <label className="mb-1 block text-sm font-medium">Reason (optional)</label>
                                <textarea
                                    value={cancelReason}
                                    onChange={(event) => setCancelReason(event.target.value)}
                                    rows={4}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                                    placeholder="Let us know why you're cancelling..."
                                />
                            </div>
                        </div>

                        <div className="mt-6 flex flex-wrap justify-end gap-3">
                            <button
                                type="button"
                                onClick={() => {
                                    setShowCancelModal(false);
                                    setCancelReason('');
                                    setCancelType('end_of_cycle');
                                }}
                                className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10"
                            >
                                Keep Service
                            </button>
                            <button
                                type="button"
                                disabled={isSubmitting}
                                onClick={() => void handleCancel()}
                                className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-700 disabled:opacity-60"
                            >
                                Confirm Cancellation
                            </button>
                        </div>
                    </div>
                </div>
            ) : null}
        </section>
    );
}
