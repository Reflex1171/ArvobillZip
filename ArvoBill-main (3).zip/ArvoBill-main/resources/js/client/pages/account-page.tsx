import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import {
    getAccountProfile,
    updateAccountPassword,
    updateAccountProfile,
} from '@/lib/account-api';
import type { AccountProfile } from '@/types/account';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function AccountPage() {
    const [account, setAccount] = useState<AccountProfile | null>(null);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [passwordConfirmation, setPasswordConfirmation] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSavingProfile, setIsSavingProfile] = useState(false);
    const [isSavingPassword, setIsSavingPassword] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadAccount() {
            try {
                const data = await getAccountProfile();
                setAccount(data);
                setName(data.name);
                setEmail(data.email);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load account settings.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadAccount();
    }, []);

    async function handleProfileSave(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        try {
            setIsSavingProfile(true);
            await updateAccountProfile({ name, email });
            const refreshed = await getAccountProfile();
            setAccount(refreshed);
            setMessage('Profile updated successfully.');
            setError(null);
        } catch (saveError) {
            setError(
                saveError instanceof Error
                    ? saveError.message
                    : 'Failed to update profile.',
            );
        } finally {
            setIsSavingProfile(false);
        }
    }

    async function handlePasswordSave(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        try {
            setIsSavingPassword(true);
            await updateAccountPassword({
                current_password: currentPassword,
                password: newPassword,
                password_confirmation: passwordConfirmation,
            });
            setCurrentPassword('');
            setNewPassword('');
            setPasswordConfirmation('');
            setMessage('Password updated successfully.');
            setError(null);
        } catch (saveError) {
            setError(
                saveError instanceof Error
                    ? saveError.message
                    : 'Failed to update password.',
            );
        } finally {
            setIsSavingPassword(false);
        }
    }

    if (isLoading) {
        return <div className="text-sm text-white/70">Loading account settings...</div>;
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Account Settings</h2>
                <p className="mt-1 text-sm text-white/70">
                    Manage your profile and security settings.
                </p>
            </div>

            {message ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-900/20 dark:text-emerald-300">
                    {message}
                </div>
            ) : null}

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <form
                onSubmit={(event) => void handleProfileSave(event)}
                className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm"
            >
                <h3 className="text-lg font-semibold">Profile</h3>
                <label className="block space-y-1 text-sm">
                    <span className="font-medium">Name</span>
                    <input
                        value={name}
                        onChange={(event) => setName(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                    />
                </label>
                <label className="block space-y-1 text-sm">
                    <span className="font-medium">Email</span>
                    <input
                        value={email}
                        onChange={(event) => setEmail(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                    />
                    <span className="text-xs text-white/70">
                        Email confirmation flow will be connected next.
                    </span>
                </label>
                <button
                    type="submit"
                    disabled={isSavingProfile}
                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                >
                    {isSavingProfile ? 'Saving...' : 'Save Profile'}
                </button>
            </form>

            <form
                onSubmit={(event) => void handlePasswordSave(event)}
                className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm"
            >
                <h3 className="text-lg font-semibold">Security</h3>
                <label className="block space-y-1 text-sm">
                    <span className="font-medium">Current Password</span>
                    <input
                        type="password"
                        value={currentPassword}
                        onChange={(event) => setCurrentPassword(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                    />
                </label>
                <label className="block space-y-1 text-sm">
                    <span className="font-medium">New Password</span>
                    <input
                        type="password"
                        value={newPassword}
                        onChange={(event) => setNewPassword(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                    />
                </label>
                <label className="block space-y-1 text-sm">
                    <span className="font-medium">Confirm New Password</span>
                    <input
                        type="password"
                        value={passwordConfirmation}
                        onChange={(event) => setPasswordConfirmation(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                    />
                </label>
                <button
                    type="submit"
                    disabled={isSavingPassword}
                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                >
                    {isSavingPassword ? 'Updating...' : 'Change Password'}
                </button>
            </form>

            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="text-lg font-semibold">Account Overview</h3>
                <dl className="mt-3 grid gap-2 text-sm md:grid-cols-2">
                    <div className="flex justify-between gap-4">
                        <dt className="text-white/70">Created</dt>
                        <dd>{formatDate(account?.created_at ?? null)}</dd>
                    </div>
                    <div className="flex justify-between gap-4">
                        <dt className="text-white/70">Active Services</dt>
                        <dd>{account?.overview.active_services_count ?? 0}</dd>
                    </div>
                    <div className="flex justify-between gap-4">
                        <dt className="text-white/70">Open Tickets</dt>
                        <dd>{account?.overview.open_tickets_count ?? 0}</dd>
                    </div>
                </dl>
            </div>
        </section>
    );
}
