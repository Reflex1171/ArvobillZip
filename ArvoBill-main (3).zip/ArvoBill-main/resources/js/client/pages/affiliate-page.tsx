import { useEffect, useState } from 'react';
import { getClientAffiliateData } from '@/lib/affiliate-api';
import type { AffiliateClientPayload } from '@/types/affiliate';
import { formatCurrency } from '@/lib/billing-api';

function formatDate(value: string | null): string {
    if (!value) return '-';

    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function AffiliatePage() {
    const [data, setData] = useState<AffiliateClientPayload | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function load() {
            try {
                setIsLoading(true);
                const payload = await getClientAffiliateData();
                setData(payload);
                setError(null);
            } catch (loadError) {
                setError(loadError instanceof Error ? loadError.message : 'Failed to load affiliate data.');
            } finally {
                setIsLoading(false);
            }
        }

        void load();
    }, []);

    async function copyReferralLink() {
        if (!data?.referral_link) return;

        try {
            await navigator.clipboard.writeText(data.referral_link);
        } catch {
            // clipboard may be blocked
        }
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Affiliate Program</h2>
                <p className="mt-1 text-sm text-white/70">
                    Share your referral link, track signups, and monitor commissions.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="text-lg font-semibold">Referral Link</h3>
                <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
                    <input
                        type="text"
                        readOnly
                        value={data?.referral_link ?? ''}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                    />
                    <button
                        type="button"
                        onClick={() => void copyReferralLink()}
                        disabled={!data?.referral_link}
                        className="rounded-lg bg-[var(--panel-primary)] px-3 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                    >
                        Copy
                    </button>
                </div>
            </article>

            <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-5">
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4">
                    <p className="text-xs uppercase tracking-wide text-white/60">Clicks</p>
                    <p className="mt-2 text-2xl font-semibold">{isLoading ? '-' : data?.stats.clicks ?? 0}</p>
                </article>
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4">
                    <p className="text-xs uppercase tracking-wide text-white/60">Signups</p>
                    <p className="mt-2 text-2xl font-semibold">{isLoading ? '-' : data?.stats.signups ?? 0}</p>
                </article>
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4">
                    <p className="text-xs uppercase tracking-wide text-white/60">Pending</p>
                    <p className="mt-2 text-2xl font-semibold">{isLoading ? '-' : formatCurrency(data?.stats.pending_earnings ?? 0)}</p>
                </article>
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4">
                    <p className="text-xs uppercase tracking-wide text-white/60">Approved</p>
                    <p className="mt-2 text-2xl font-semibold">{isLoading ? '-' : formatCurrency(data?.stats.approved_earnings ?? 0)}</p>
                </article>
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4">
                    <p className="text-xs uppercase tracking-wide text-white/60">Affiliate Balance</p>
                    <p className="mt-2 text-2xl font-semibold">{isLoading ? '-' : formatCurrency(data?.stats.affiliate_balance ?? 0)}</p>
                </article>
            </div>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="mb-4 text-lg font-semibold">Earnings</h3>
                <div className="overflow-x-auto rounded-lg border border-white/10">
                    <table className="min-w-full text-left text-sm">
                        <thead className="bg-white/5 text-white/70">
                            <tr>
                                <th className="px-4 py-3 font-medium">ID</th>
                                <th className="px-4 py-3 font-medium">Invoice</th>
                                <th className="px-4 py-3 font-medium">Amount</th>
                                <th className="px-4 py-3 font-medium">Status</th>
                                <th className="px-4 py-3 font-medium">Eligible</th>
                                <th className="px-4 py-3 font-medium">Created</th>
                            </tr>
                        </thead>
                        <tbody>
                            {isLoading ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={6}>Loading earnings...</td>
                                </tr>
                            ) : (data?.earnings.length ?? 0) === 0 ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={6}>No affiliate earnings yet.</td>
                                </tr>
                            ) : (
                                data?.earnings.map((earning) => (
                                    <tr key={earning.id} className="border-t border-white/10">
                                        <td className="px-4 py-3">#{earning.id}</td>
                                        <td className="px-4 py-3">#{earning.invoice_id}</td>
                                        <td className="px-4 py-3">{formatCurrency(earning.amount)}</td>
                                        <td className="px-4 py-3 capitalize">{earning.status}</td>
                                        <td className="px-4 py-3">{formatDate(earning.eligible_at)}</td>
                                        <td className="px-4 py-3">{formatDate(earning.created_at)}</td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </article>
        </section>
    );
}