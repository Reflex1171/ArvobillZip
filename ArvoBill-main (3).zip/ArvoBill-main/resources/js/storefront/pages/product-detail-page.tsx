import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { formatCurrency, getClientProductBySlug } from '@/lib/products-api';
import type { Product } from '@/types/product';

export function ProductDetailPage() {
    const { category, slug } = useParams<{ category: string; slug: string }>();
    const [product, setProduct] = useState<Product | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadProduct() {
            if (!slug) {
                setError('Missing product slug.');
                setIsLoading(false);

                return;
            }

            try {
                const data = await getClientProductBySlug(slug);
                setProduct(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load product details.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadProduct();
    }, [slug]);

    if (isLoading) {
        return (
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                Loading product...
            </div>
        );
    }

    if (error || !product) {
        return (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                {error ?? 'Product not found.'}
            </div>
        );
    }

    return (
        <div className="space-y-6">
            <section className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <div className="mb-3 flex items-center gap-3">
                    {product.category ? (
                        <span className="rounded-full bg-cyan-100 px-2.5 py-1 text-xs font-semibold uppercase tracking-wide text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-300">
                            {product.category.name}
                        </span>
                    ) : null}
                </div>
                <h1 className="text-2xl font-semibold">{product.name}</h1>
                <p className="mt-2 max-w-3xl text-sm text-white/80">
                    {product.description}
                </p>
            </section>

            <section className="grid gap-6 xl:grid-cols-2">
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                    <h2 className="text-lg font-semibold">Pricing Summary</h2>
                    <div className="mt-4 space-y-2 text-sm">
                        <div className="flex items-center justify-between">
                            <span className="text-white/70">
                                Billing
                            </span>
                            <span className="font-semibold">
                                {product.billing_summary}
                            </span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-white/70">
                                Charge amount
                            </span>
                            <span className="font-semibold">
                                {formatCurrency(product.price_monthly)}
                            </span>
                        </div>
                        <div className="flex items-center justify-between">
                            <span className="text-white/70">
                                Setup fee
                            </span>
                            <span className="font-semibold">
                                {formatCurrency(product.setup_fee ?? 0)}
                            </span>
                        </div>
                    </div>
                </article>

                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                    <h2 className="text-lg font-semibold">What&apos;s Included</h2>
                    <ul className="mt-4 list-disc space-y-2 pl-5 text-sm text-white/80">
                        <li>Datacenter-grade infrastructure baseline</li>
                        <li>Service monitoring and uptime checks</li>
                        <li>Standard support coverage</li>
                        <li>Future-ready checkout integration</li>
                    </ul>
                </article>
            </section>

            <section>
                <a
                    href={`/products/${category ?? 'uncategorized'}/${product.slug}/configure`}
                    className="inline-flex rounded-lg bg-cyan-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-cyan-700"
                >
                    Configure
                </a>
            </section>
        </div>
    );
}
