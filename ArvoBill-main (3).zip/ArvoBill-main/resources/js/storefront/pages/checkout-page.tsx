import { useEffect, useMemo, useState } from 'react';
import { createOrder, validatePromoCode, type PromoValidationResult } from '@/lib/billing-api';
import { useParams, useSearchParams } from 'react-router-dom';
import {
    formatCurrency,
    getClientProductBySlug,
    listProductConfigurationsBySlug,
} from '@/lib/products-api';
import type { ProductConfiguration } from '@/types/product-configuration';
import type { Product } from '@/types/product';

const requiredPterodactylKeys = ['ram', 'disk', 'cpu'];

async function isAuthenticated(): Promise<boolean> {
    try {
        const response = await fetch('/api/me', {
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json',
            },
        });

        if (!response.ok) {
            return false;
        }

        const payload = (await response.json()) as { data?: unknown };
        return Boolean(payload?.data);
    } catch {
        return false;
    }
}

export function ProductCheckoutPage() {
    const { slug } = useParams<{ slug: string }>();
    const [searchParams] = useSearchParams();
    const cfgFromQuery = searchParams.get('cfg');
    const autoCreateFromQuery = searchParams.get('auto_create') === '1';
    const [product, setProduct] = useState<Product | null>(null);
    const [configurations, setConfigurations] = useState<ProductConfiguration[]>([]);
    const [selectedConfigurations, setSelectedConfigurations] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [hasAutoCreateAttempted, setHasAutoCreateAttempted] = useState(false);
    const [promoInput, setPromoInput] = useState('');
    const [appliedPromo, setAppliedPromo] = useState<PromoValidationResult | null>(null);
    const [isApplyingPromo, setIsApplyingPromo] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadCheckoutProduct() {
            if (!slug) {
                setError('Missing product slug.');
                setIsLoading(false);

                return;
            }

            try {
                const [productData, configurationData] = await Promise.all([
                    getClientProductBySlug(slug),
                    listProductConfigurationsBySlug(slug),
                ]);
                setProduct(productData);
                setConfigurations(configurationData);
                let parsedSelections: Record<string, string> = {};

                if (cfgFromQuery) {
                    try {
                        parsedSelections = JSON.parse(cfgFromQuery) as Record<string, string>;
                    } catch {
                        parsedSelections = {};
                    }
                }

                const defaultSelections: Record<string, string> = {};
                configurationData.forEach((configuration) => {
                    const options = Array.isArray(configuration.options)
                        ? configuration.options
                        : [];
                    const defaultOption = options.find(
                        (option) => option.is_default,
                    );
                    if (defaultOption) {
                        defaultSelections[configuration.key] = defaultOption.value;
                    }
                });

                setSelectedConfigurations({
                    ...defaultSelections,
                    ...parsedSelections,
                });
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load checkout data.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadCheckoutProduct();
    }, [slug, cfgFromQuery]);

    const selectedSummary = useMemo(
        () =>
            configurations
                .map((configuration) => {
                    const selectedValue = selectedConfigurations[configuration.key];
                    if (!selectedValue) return null;

                    const options = Array.isArray(configuration.options)
                        ? configuration.options
                        : [];
                    const selectedOption = options.find(
                        (option) => option.value === selectedValue,
                    );

                    if (!selectedOption) return null;

                    return {
                        configurationName: configuration.name,
                        label: selectedOption.label,
                        priceModifier: selectedOption.price_modifier ?? 0,
                    };
                })
                .filter((item): item is NonNullable<typeof item> => item !== null),
        [configurations, selectedConfigurations],
    );

    const total = product ? product.price_monthly + (product.setup_fee ?? 0) : 0;
    const requiredKeys = configurations
        .filter((configuration) => configuration.required)
        .map((configuration) => configuration.key);
    const missingRequired = requiredKeys.filter(
        (key) => !selectedConfigurations[key],
    );
    const isPterodactylProduct = product?.infrastructure_type === 'pterodactyl';
    const missingPterodactylKeys = isPterodactylProduct
        ? requiredPterodactylKeys.filter(
              (key) => !configurations.some((configuration) => configuration.key === key),
          )
        : [];
    const missingPterodactylSelections = isPterodactylProduct
        ? requiredPterodactylKeys.filter((key) => !selectedConfigurations[key])
        : [];

    const selectedOptionPriceModifier = configurations.reduce((sum, configuration) => {
        const selectedValue = selectedConfigurations[configuration.key];
        if (!selectedValue) return sum;

        const options = Array.isArray(configuration.options)
            ? configuration.options
            : [];
        const selectedOption = options.find(
            (option) => option.value === selectedValue,
        );

        return sum + (selectedOption?.price_modifier ?? 0);
    }, 0);
    const adjustedTotal = total + selectedOptionPriceModifier;
    const finalTotal = appliedPromo ? appliedPromo.final_total : adjustedTotal;

    useEffect(() => {
        setAppliedPromo(null);
    }, [slug, selectedConfigurations, adjustedTotal]);

    async function handleApplyPromoCode() {
        if (!product) {
            return;
        }

        const code = promoInput.trim();
        if (code === '') {
            setAppliedPromo(null);
            return;
        }

        try {
            setIsApplyingPromo(true);
            setError(null);
            const validatedPromo = await validatePromoCode({
                code,
                product_slug: product.slug,
                configurations: selectedConfigurations,
            });
            setAppliedPromo(validatedPromo);
            setPromoInput(validatedPromo.code ?? code.toUpperCase());
        } catch (promoError) {
            setAppliedPromo(null);
            setError(
                promoError instanceof Error
                    ? promoError.message
                    : 'Failed to apply promo code.',
            );
        } finally {
            setIsApplyingPromo(false);
        }
    }

    async function handleConfirmOrder() {
        if (!product) {
            return;
        }

        if (missingPterodactylKeys.length > 0) {
            setError('Product is missing required RAM/Disk/CPU configuration definitions.');
            return;
        }

        if (missingRequired.length > 0 || missingPterodactylSelections.length > 0) {
            setError('Please select all required configuration options.');
            return;
        }

        const authenticated = await isAuthenticated();
        if (!authenticated) {
            const params = new URLSearchParams({
                cfg: JSON.stringify(selectedConfigurations),
                auto_create: '1',
            });
            window.location.assign(
                `/register?redirect=${encodeURIComponent(`/checkout/product/${product.slug}?${params.toString()}`)}`,
            );
            return;
        }

        try {
            setIsSubmitting(true);
            setError(null);
            const order = await createOrder(
                product.slug,
                selectedConfigurations,
                appliedPromo?.code ?? null,
            );
            const invoiceId = order.invoice?.id;

            if (invoiceId) {
                window.location.assign(`/checkout/${invoiceId}`);
            } else {
                window.location.assign('/client/orders');
            }
        } catch (createError) {
            const message = createError instanceof Error
                ? createError.message
                : 'Failed to create order.';

            const lower = message.toLowerCase();
            if (lower.includes('unauthenticated') || lower.includes('request failed: 401')) {
                const params = new URLSearchParams({
                    cfg: JSON.stringify(selectedConfigurations),
                    auto_create: '1',
                });
                window.location.assign(
                    `/register?redirect=${encodeURIComponent(`/checkout/product/${product.slug}?${params.toString()}`)}`,
                );
                return;
            }

            setError(
                message,
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    useEffect(() => {
        if (
            !autoCreateFromQuery ||
            hasAutoCreateAttempted ||
            isLoading ||
            !product
        ) {
            return;
        }

        setHasAutoCreateAttempted(true);
        void handleConfirmOrder();
    }, [
        autoCreateFromQuery,
        hasAutoCreateAttempted,
        isLoading,
        product,
    ]);

    if (isLoading) {
        return (
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                Loading checkout...
            </div>
        );
    }

    if (error || !product) {
        return (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                {error ?? 'Product not found.'}
            </div>
        );
    }

    return (
        <section className="space-y-6">
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <h1 className="text-xl font-semibold">Checkout</h1>
                <p className="mt-1 text-sm text-white/70">
                    Selected product: {product.name}
                </p>
            </div>
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <h2 className="text-lg font-semibold">Selected Configuration</h2>
                <div className="mt-4 space-y-2 text-sm">
                    {selectedSummary.length > 0 ? (
                        selectedSummary.map((item) => (
                            <div
                                key={item.configurationName}
                                className="flex justify-between gap-4"
                            >
                                <span className="text-white/70">
                                    {item.configurationName}
                                </span>
                                <span>
                                    {item.label}{' '}
                                    {item.priceModifier !== 0
                                        ? `(${item.priceModifier > 0 ? '+' : ''}${formatCurrency(item.priceModifier)})`
                                        : ''}
                                </span>
                            </div>
                        ))
                    ) : (
                        <p className="text-white/70">No configuration options selected.</p>
                    )}
                </div>
            </div>
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <h2 className="text-lg font-semibold">Price Breakdown</h2>
                <div className="mt-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span className="text-white/70">
                            Billing
                        </span>
                        <span>{product.billing_summary}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">
                            Base charge
                        </span>
                        <span>{formatCurrency(product.price_monthly)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">
                            Setup fee
                        </span>
                        <span>{formatCurrency(product.setup_fee ?? 0)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">
                            Configuration modifiers
                        </span>
                        <span>{formatCurrency(selectedOptionPriceModifier)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">
                            Promo discount
                        </span>
                        <span>{formatCurrency(0 - (appliedPromo?.discount_amount ?? 0))}</span>
                    </div>
                    <div className="flex justify-between border-t border-white/10 pt-2 font-semibold">
                        <span>{product.billing_type === 'one_time' ? 'Total' : 'First billing total'}</span>
                        <span>{formatCurrency(finalTotal)}</span>
                    </div>
                </div>
            </div>
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <h2 className="text-lg font-semibold">Promo Code</h2>
                <p className="mt-1 text-sm text-white/70">
                    Apply one promo code to this order before checkout.
                </p>
                <div className="mt-4 flex flex-wrap gap-3">
                    <input
                        type="text"
                        value={promoInput}
                        onChange={(event) => setPromoInput(event.target.value.toUpperCase())}
                        placeholder="Enter promo code"
                        className="w-full max-w-xs rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm text-[var(--panel-text)] outline-none focus:border-[var(--panel-primary)]"
                    />
                    <button
                        type="button"
                        onClick={() => void handleApplyPromoCode()}
                        disabled={isApplyingPromo || promoInput.trim() === ''}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                    >
                        {isApplyingPromo ? 'Applying...' : 'Apply Code'}
                    </button>
                    {appliedPromo ? (
                        <button
                            type="button"
                            onClick={() => {
                                setAppliedPromo(null);
                                setPromoInput('');
                            }}
                            className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10"
                        >
                            Remove
                        </button>
                    ) : null}
                </div>
                {appliedPromo ? (
                    <p className="mt-3 text-sm text-emerald-300">
                        Code {appliedPromo.code} applied. You saved {formatCurrency(appliedPromo.discount_amount)}.
                    </p>
                ) : null}
            </div>
            <div className="rounded-xl border border-cyan-200 bg-cyan-50 p-4 text-sm text-cyan-800 dark:border-cyan-900/40 dark:bg-cyan-900/20 dark:text-cyan-300">
                Checkout confirms product, selected configuration values, and
                total. Configuration changes happen on the configure page.
            </div>

            <div>
                <button
                    type="button"
                    onClick={() => void handleConfirmOrder()}
                    disabled={
                        isSubmitting ||
                        missingRequired.length > 0 ||
                        missingPterodactylSelections.length > 0 ||
                        missingPterodactylKeys.length > 0
                    }
                    className="rounded-lg bg-cyan-600 px-5 py-2.5 text-sm font-semibold text-white hover:bg-cyan-700 disabled:opacity-60"
                >
                    {isSubmitting ? 'Creating Order...' : 'Confirm Order'}
                </button>
            </div>
        </section>
    );
}
