import { Navigate, Route, Routes } from 'react-router-dom';
import { StorefrontLayout } from './layout/storefront-layout';
import { ProductCheckoutPage } from './pages/checkout-page';
import { InvoiceCheckoutPage } from './pages/invoice-checkout-page';
import { ProductConfigurePage } from './pages/product-configure-page';
import { ProductDetailPage } from './pages/product-detail-page';
import { ProductsPage } from './pages/products-page';

export function StorefrontApp() {
    return (
        <Routes>
            <Route element={<StorefrontLayout />}>
                <Route path="/products" element={<ProductsPage />} />
                <Route path="/products/:category" element={<ProductsPage />} />
                <Route
                    path="/products/:category/:slug"
                    element={<ProductDetailPage />}
                />
                <Route
                    path="/products/:category/:slug/configure"
                    element={<ProductConfigurePage />}
                />
                <Route path="/checkout/:invoiceId" element={<InvoiceCheckoutPage />} />
                <Route path="/checkout/product/:slug" element={<ProductCheckoutPage />} />
            </Route>
            <Route path="*" element={<Navigate to="/products" replace />} />
        </Routes>
    );
}
