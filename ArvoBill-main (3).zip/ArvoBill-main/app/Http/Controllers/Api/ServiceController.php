<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Support\BillingCycle;
use App\Services\Infrastructure\PterodactylService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $services = Service::query()
            ->with(['product', 'order', 'invoice', 'defaultPaymentMethod'])
            ->where('user_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Service $service) => $this->transformService($service))
            ->values();

        return response()->json([
            'data' => $services,
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $service = Service::query()
            ->with(['product', 'order.configurations', 'invoice', 'defaultPaymentMethod'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformService($service, true),
        ]);
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        $service = Service::query()
            ->with('product')
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        $validated = $request->validate([
            'reason' => ['nullable', 'string', 'max:1000'],
            'cancel_type' => ['nullable', 'in:immediate,end_of_cycle'],
        ]);

        if ($service->status === 'cancelled') {
            return response()->json([
                'message' => 'Service is already cancelled.',
                'data' => $this->transformService($service->load(['product', 'order', 'invoice', 'defaultPaymentMethod']), true),
            ]);
        }

        $cancelType = $validated['cancel_type'] ?? 'immediate';
        $reason = $validated['reason'] ?? null;

        $service->cancellation_reason = $reason;
        $service->auto_renew = false;

        if ($cancelType === 'end_of_cycle') {
            $service->cancel_at_period_end = true;
            $service->cancel_requested_at = now();
            $service->save();

            return response()->json([
                'message' => 'Cancellation scheduled for end of billing cycle.',
                'data' => $this->transformService($service->fresh()->load(['product', 'order', 'invoice', 'defaultPaymentMethod']), true),
            ]);
        }

        if ($service->pterodactyl_server_id && $service->product?->infrastructure_type === 'pterodactyl') {
            app(PterodactylService::class)->deleteServer($service->pterodactyl_server_id);
            $service->pterodactyl_server_id = null;
            $service->pterodactyl_node_id = null;
            $service->pterodactyl_egg_id = null;
            $service->pterodactyl_allocation_id = null;
        }

        $service->status = 'cancelled';
        $service->cancel_at_period_end = false;
        $service->cancelled_at = now();
        $service->save();

        return response()->json([
            'message' => 'Service cancellation requested.',
            'data' => $this->transformService($service->fresh()->load(['product', 'order', 'invoice', 'defaultPaymentMethod']), true),
        ]);
    }

    public function upgrade(Request $request, int $id): JsonResponse
    {
        $service = Service::query()
            ->with(['product', 'order', 'invoice', 'defaultPaymentMethod'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json([
            'message' => 'Upgrade flow coming soon.',
            'data' => $this->transformService($service, true),
        ]);
    }

    public function updateAutoRenew(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'auto_renew' => ['required', 'boolean'],
        ]);

        $service = Service::query()
            ->with(['product', 'order', 'invoice', 'defaultPaymentMethod'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        $service->auto_renew = (bool) $validated['auto_renew'];
        $service->save();

        return response()->json([
            'message' => 'Auto-renew preference updated.',
            'data' => $this->transformService($service->fresh()->load(['product', 'order', 'invoice', 'defaultPaymentMethod']), true),
        ]);
    }

    public function updateDefaultPaymentMethod(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'payment_method_id' => ['nullable', 'integer'],
        ]);

        $service = Service::query()
            ->with(['product', 'order', 'invoice', 'defaultPaymentMethod'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        $methodId = $validated['payment_method_id'] ?? null;
        if ($methodId !== null) {
            $method = $request->user()->paymentMethods()
                ->where('is_active', true)
                ->findOrFail($methodId);
            $service->default_payment_method_id = $method->id;
        } else {
            $service->default_payment_method_id = null;
        }

        $service->save();

        return response()->json([
            'message' => 'Default payment method updated for service renewals.',
            'data' => $this->transformService($service->fresh()->load(['product', 'order', 'invoice', 'defaultPaymentMethod']), true),
        ]);
    }

    private function transformService(Service $service, bool $withRelations = false): array
    {
        $panelUrl = app(PterodactylService::class)->panelUrl();
        $serverInfo = null;

        if ($withRelations && $service->pterodactyl_server_id) {
            try {
                $serverInfo = app(PterodactylService::class)->fetchServer($service->pterodactyl_server_id);
            } catch (\Throwable) {
                $serverInfo = null;
            }
        }

        return [
            'id' => $service->id,
            'status' => $service->status,
            'billing_cycle' => $this->billingCycleText($service),
            'billing_type' => $this->billingType($service),
            'billing_interval' => $this->billingInterval($service),
            'billing_period' => $this->billingPeriod($service),
            'billing_summary' => $this->billingSummary($service),
            'auto_renew' => (bool) $service->auto_renew,
            'renewal_failure_count' => (int) $service->renewal_failure_count,
            'next_due_at' => ($service->next_due_at ?? $service->next_due_date)?->toDateString(),
            'next_due_date' => ($service->next_due_at ?? $service->next_due_date)?->toDateString(),
            'cancel_at_period_end' => (bool) $service->cancel_at_period_end,
            'cancellation_reason' => $service->cancellation_reason,
            'cancel_requested_at' => $service->cancel_requested_at?->toISOString(),
            'cancelled_at' => $service->cancelled_at?->toISOString(),
            'pterodactyl_server_id' => $service->pterodactyl_server_id,
            'pterodactyl_node_id' => $service->pterodactyl_node_id,
            'pterodactyl_egg_id' => $service->pterodactyl_egg_id,
            'pterodactyl_allocation_id' => $service->pterodactyl_allocation_id,
            'pterodactyl_identifier' => is_array($serverInfo) ? ($serverInfo['identifier'] ?? null) : null,
            'pterodactyl_server_status' => is_array($serverInfo) ? ($serverInfo['status'] ?? null) : null,
            'pterodactyl_node_name' => is_array($serverInfo)
                ? ($serverInfo['relationships']['node']['attributes']['name'] ?? null)
                : null,
            'pterodactyl_panel_url' => $panelUrl,
            'provisioning_limits' => $withRelations ? $this->resolveProvisioningLimits($service) : null,
            'provisioning_error' => $service->provisioning_error,
            'created_at' => $service->created_at?->toISOString(),
            'updated_at' => $service->updated_at?->toISOString(),
            'product' => $service->product ? [
                'id' => $service->product->id,
                'name' => $service->product->name,
                'slug' => $service->product->slug,
            ] : null,
            'order' => $withRelations && $service->order ? [
                'id' => $service->order->id,
                'status' => $service->order->status,
            ] : null,
            'invoice' => $withRelations && $service->invoice ? [
                'id' => $service->invoice->id,
                'status' => $service->invoice->status,
                'total' => (float) $service->invoice->total,
                'due_date' => $service->invoice->due_date?->toDateString(),
            ] : null,
            'default_payment_method' => $withRelations && $service->defaultPaymentMethod ? [
                'id' => $service->defaultPaymentMethod->id,
                'provider' => $service->defaultPaymentMethod->provider,
                'label' => $service->defaultPaymentMethod->label,
                'masked_details' => $service->defaultPaymentMethod->masked_details,
            ] : null,
        ];
    }

    private function billingType(Service $service): string
    {
        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];

        return BillingCycle::normalizeBillingType((string) ($snapshot['billing_type'] ?? 'recurring'));
    }

    private function billingInterval(Service $service): ?int
    {
        if ($this->billingType($service) === 'one_time') {
            return null;
        }

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];

        return BillingCycle::resolveInterval($snapshot['billing_interval'] ?? 1);
    }

    private function billingPeriod(Service $service): ?string
    {
        if ($this->billingType($service) === 'one_time') {
            return null;
        }

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];

        return BillingCycle::normalizePeriod((string) ($snapshot['billing_period'] ?? 'month'));
    }

    private function billingSummary(Service $service): string
    {
        $type = $this->billingType($service);
        $interval = $this->billingInterval($service) ?? 1;
        $period = $this->billingPeriod($service) ?? 'month';

        return BillingCycle::billingSummary($type, $interval, $period);
    }

    private function billingCycleText(Service $service): string
    {
        $interval = $this->billingInterval($service);
        $period = $this->billingPeriod($service);

        if ($interval === null || $period === null) {
            return 'one-time';
        }

        return BillingCycle::intervalSummary($interval, $period);
    }

    /**
     * @return array{memory:int,cpu:int,disk:int}
     */
    private function resolveProvisioningLimits(Service $service): array
    {
        $limits = [
            'memory' => 2048,
            'cpu' => 100,
            'disk' => 10240,
        ];

        $order = $service->relationLoaded('order') ? $service->order : $service->order()->with('configurations')->first();
        if (! $order || ! $order->relationLoaded('configurations')) {
            return $limits;
        }

        foreach ($order->configurations as $configuration) {
            $key = strtolower((string) $configuration->configuration_key);
            $value = (int) $configuration->selected_value;
            if ($value <= 0) {
                continue;
            }

            if (in_array($key, ['ram', 'memory'], true)) {
                $limits['memory'] = $value;
            } elseif ($key === 'cpu') {
                $limits['cpu'] = $value;
            } elseif (in_array($key, ['disk', 'storage'], true)) {
                $limits['disk'] = $value;
            }
        }

        return $limits;
    }
}
