<?php

namespace App\Http\Controllers\Api\Admin\Settings;

use App\Http\Controllers\Controller;
use App\Services\Email\EmailNotificationService;
use App\Services\Email\EmailSettingsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class EmailSettingsController extends Controller
{
    public function show(EmailSettingsService $settingsService): JsonResponse
    {
        $settings = $settingsService->get();

        return response()->json([
            'data' => [
                'host' => $settings->host,
                'port' => (int) $settings->port,
                'username' => $settings->username,
                'password_masked' => $this->mask((string) ($settings->password ?? '')),
                'encryption' => $settings->encryption,
                'from_address' => $settings->from_address,
                'from_name' => $settings->from_name,
                'enabled' => (bool) $settings->enabled,
            ],
        ]);
    }

    public function update(Request $request, EmailSettingsService $settingsService): JsonResponse
    {
        $validated = $request->validate([
            'host' => ['nullable', 'string', 'max:255'],
            'port' => ['required', 'integer', 'min:1', 'max:65535'],
            'username' => ['nullable', 'string', 'max:255'],
            'password' => ['nullable', 'string', 'max:255'],
            'encryption' => ['nullable', 'in:tls,ssl,starttls'],
            'from_address' => ['nullable', 'email', 'max:255'],
            'from_name' => ['nullable', 'string', 'max:255'],
            'enabled' => ['required', 'boolean'],
        ]);

        $settings = $settingsService->get();
        $settings->host = $validated['host'] ?? null;
        $settings->port = (int) $validated['port'];
        $settings->username = $validated['username'] ?? null;
        if (isset($validated['password']) && $validated['password'] !== '') {
            $settings->password = $validated['password'];
        }
        $settings->encryption = $validated['encryption'] ?? null;
        $settings->from_address = $validated['from_address'] ?? null;
        $settings->from_name = $validated['from_name'] ?? null;
        $settings->enabled = (bool) $validated['enabled'];
        $settings->save();

        $settingsService->clearCache();

        return $this->show($settingsService);
    }

    public function sendTest(Request $request, EmailNotificationService $emailNotificationService): JsonResponse
    {
        $validated = $request->validate([
            'email' => ['required', 'email', 'max:255'],
        ]);

        $emailNotificationService->queueToAddress(
            $validated['email'],
            'ArvoBill SMTP test email',
            'SMTP connection test',
            [
                'Your SMTP settings are being used to send this test email.',
                'If this reaches your inbox, email delivery is configured correctly.',
            ],
            templateKey: 'smtp_test_recipient',
        );

        return response()->json([
            'message' => 'Test email queued successfully.',
        ]);
    }

    private function mask(string $value): ?string
    {
        if ($value === '') {
            return null;
        }

        $length = strlen($value);
        if ($length <= 4) {
            return str_repeat('*', $length);
        }

        return str_repeat('*', $length - 4).substr($value, -4);
    }
}
