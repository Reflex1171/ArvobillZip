<?php

namespace App\Http\Controllers\Api\Admin\Settings;

use App\Http\Controllers\Controller;
use App\Models\SocialProviderSetting;
use App\Services\SocialProviderSettingsService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class SocialProviderSettingsController extends Controller
{
    public function show(SocialProviderSettingsService $settingsService): JsonResponse
    {
        $settings = $settingsService->getAll();

        return response()->json([
            'data' => [
                'google' => $this->formatSetting($settings->get('google')),
                'apple' => $this->formatSetting($settings->get('apple')),
            ],
        ]);
    }

    public function update(
        Request $request,
        string $provider,
        SocialProviderSettingsService $settingsService,
    ): JsonResponse {
        if (! in_array($provider, ['google', 'apple'], true)) {
            abort(404);
        }

        $validated = $request->validate([
            'enabled' => ['required', 'boolean'],
            'client_id' => ['nullable', 'string', 'max:255'],
            'client_secret' => ['nullable', 'string', 'max:4096'],
            'redirect_uri' => ['nullable', 'url', 'max:255'],
            'team_id' => ['nullable', 'string', 'max:255'],
            'key_id' => ['nullable', 'string', 'max:255'],
            'private_key' => ['nullable', 'string', 'max:10000'],
        ]);

        /** @var SocialProviderSetting $setting */
        $setting = $settingsService->getProvider($provider);

        $setting->client_id = $validated['client_id'] ?? $setting->client_id;
        $setting->redirect_uri = $validated['redirect_uri'] ?? $setting->redirect_uri;
        $setting->enabled = (bool) $validated['enabled'];

        if (isset($validated['client_secret']) && $validated['client_secret'] !== '') {
            $setting->client_secret = $validated['client_secret'];
        }

        if ($provider === 'apple') {
            $setting->team_id = $validated['team_id'] ?? $setting->team_id;
            $setting->key_id = $validated['key_id'] ?? $setting->key_id;
            if (isset($validated['private_key']) && $validated['private_key'] !== '') {
                $setting->private_key = $validated['private_key'];
            }
        }

        $this->ensureRequiredFields($setting, $provider);

        $setting->save();
        $settingsService->clearCache();

        return $this->show($settingsService);
    }

    public function test(
        Request $request,
        string $provider,
        SocialProviderSettingsService $settingsService,
    ): JsonResponse {
        if (! in_array($provider, ['google', 'apple'], true)) {
            abort(404);
        }

        $setting = $settingsService->getProvider($provider);
        $this->ensureRequiredFields($setting, $provider);

        $authUrl = $this->buildAuthUrl($request, $provider, $setting);

        return response()->json([
            'data' => [
                'auth_url' => $authUrl,
            ],
        ]);
    }

    private function ensureRequiredFields(SocialProviderSetting $setting, string $provider): void
    {
        if (! $setting->enabled) {
            return;
        }

        $missing = [];
        if (! $setting->client_id) {
            $missing[] = 'client_id';
        }
        if (! $setting->client_secret) {
            $missing[] = 'client_secret';
        }
        if (! $setting->redirect_uri) {
            $missing[] = 'redirect_uri';
        }

        if ($provider === 'apple') {
            if (! $setting->team_id) {
                $missing[] = 'team_id';
            }
            if (! $setting->key_id) {
                $missing[] = 'key_id';
            }
            if (! $setting->private_key) {
                $missing[] = 'private_key';
            }
        }

        if ($missing !== []) {
            abort(422, 'Missing required fields: '.implode(', ', $missing));
        }
    }

    private function formatSetting(?SocialProviderSetting $setting): array
    {
        if (! $setting) {
            return [
                'enabled' => false,
                'client_id' => null,
                'client_secret_masked' => null,
                'redirect_uri' => null,
                'team_id' => null,
                'key_id' => null,
                'private_key_masked' => null,
            ];
        }

        return [
            'enabled' => (bool) $setting->enabled,
            'client_id' => $setting->client_id,
            'client_secret_masked' => $this->mask((string) ($setting->client_secret ?? '')),
            'redirect_uri' => $setting->redirect_uri,
            'team_id' => $setting->team_id,
            'key_id' => $setting->key_id,
            'private_key_masked' => $this->mask((string) ($setting->private_key ?? '')),
        ];
    }

    private function mask(string $value): ?string
    {
        if ($value === '') {
            return null;
        }

        $length = strlen($value);
        if ($length <= 4) {
            return str_repeat('*', $length);
        }

        return str_repeat('*', $length - 4).substr($value, -4);
    }

    private function buildAuthUrl(Request $request, string $provider, SocialProviderSetting $setting): string
    {
        $state = bin2hex(random_bytes(20));
        $request->session()->put("oauth_state_{$provider}", $state);

        if ($provider === 'google') {
            $query = http_build_query([
                'client_id' => $setting->client_id,
                'redirect_uri' => $setting->redirect_uri,
                'response_type' => 'code',
                'scope' => 'openid email profile',
                'state' => $state,
                'prompt' => 'select_account',
                'access_type' => 'offline',
                'include_granted_scopes' => 'true',
            ]);

            return 'https://accounts.google.com/o/oauth2/v2/auth?'.$query;
        }

        $query = http_build_query([
            'client_id' => $setting->client_id,
            'redirect_uri' => $setting->redirect_uri,
            'response_type' => 'code id_token',
            'response_mode' => 'form_post',
            'scope' => 'name email',
            'state' => $state,
        ]);

        return 'https://appleid.apple.com/auth/authorize?'.$query;
    }
}
