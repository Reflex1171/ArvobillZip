<?php

namespace App\Http\Controllers\Api\Admin\Infrastructure;

use App\Http\Controllers\Controller;
use App\Models\PterodactylSetting;
use App\Services\Infrastructure\PterodactylService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class PterodactylSettingsController extends Controller
{
    public function show(): JsonResponse
    {
        $setting = PterodactylSetting::query()->first();

        return response()->json([
            'data' => [
                'panel_url' => $setting?->panel_url,
                'enabled' => (bool) ($setting?->enabled ?? false),
                'api_key_masked' => $this->mask((string) ($setting?->api_key ?? '')),
                'has_api_key' => trim((string) ($setting?->api_key ?? '')) !== '',
            ],
        ]);
    }

    public function update(Request $request): JsonResponse
    {
        $this->ensureAdminOrSuperuser($request);

        $validated = $request->validate([
            'panel_url' => ['nullable', 'url'],
            'api_key' => ['nullable', 'string'],
            'enabled' => ['required', 'boolean'],
        ]);

        $setting = PterodactylSetting::query()->firstOrCreate([], [
            'panel_url' => null,
            'api_key' => null,
            'enabled' => false,
        ]);

        $setting->panel_url = $validated['panel_url'] ?? null;

        if (array_key_exists('api_key', $validated)) {
            $providedKey = trim((string) $validated['api_key']);
            if ($providedKey !== '') {
                $setting->api_key = $providedKey;
            }
        }

        $isEnabling = (bool) $validated['enabled'];
        if ($isEnabling) {
            if (trim((string) $setting->panel_url) === '' || trim((string) ($setting->api_key ?? '')) === '') {
                throw ValidationException::withMessages([
                    'enabled' => 'Panel URL and API key are required to enable Pterodactyl.',
                ]);
            }
        }

        $setting->enabled = $isEnabling;
        $setting->save();

        return response()->json([
            'message' => 'Pterodactyl settings updated successfully.',
            'data' => [
                'panel_url' => $setting->panel_url,
                'enabled' => $setting->enabled,
                'api_key_masked' => $this->mask((string) ($setting->api_key ?? '')),
                'has_api_key' => trim((string) ($setting->api_key ?? '')) !== '',
            ],
        ]);
    }

    public function testConnection(
        Request $request,
        PterodactylService $pterodactylService,
    ): JsonResponse {
        $this->ensureAdminOrSuperuser($request);

        $pterodactylService->testConnection();

        return response()->json([
            'message' => 'Connection successful.',
            'data' => [
                'connected' => true,
            ],
        ]);
    }

    private function ensureAdminOrSuperuser(Request $request): void
    {
        $role = (string) $request->user()->role;
        if (! in_array($role, ['admin', 'superuser'], true)) {
            abort(403, 'Only admins can manage Pterodactyl settings.');
        }
    }

    private function mask(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        if (strlen($value) <= 4) {
            return str_repeat('*', strlen($value));
        }

        return str_repeat('*', strlen($value) - 4).substr($value, -4);
    }
}
