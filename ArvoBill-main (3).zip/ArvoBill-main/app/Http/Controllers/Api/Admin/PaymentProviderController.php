<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Services\Payments\PaymentProviderManager;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentProviderController extends Controller
{
    public function index(PaymentProviderManager $manager): JsonResponse
    {
        return response()->json([
            'data' => $manager->getAdminSettings(),
        ]);
    }

    public function update(
        Request $request,
        string $provider,
        PaymentProviderManager $manager,
    ): JsonResponse {
        $validated = $request->validate([
            'mode' => ['required', 'in:test,live'],
            'enabled' => ['required', 'boolean'],
            'public_key' => ['nullable', 'string'],
            'secret_key' => ['nullable', 'string'],
            'webhook_secret' => ['nullable', 'string'],
            'confirm_overwrite' => ['nullable', 'boolean'],
        ]);

        if (
            ! empty($validated['secret_key']) &&
            ! ($validated['confirm_overwrite'] ?? false)
        ) {
            return response()->json([
                'message' => 'Confirm overwrite before replacing secret keys.',
            ], 422);
        }

        $result = $manager->updateProvider($provider, $validated);

        return response()->json([
            'message' => 'Payment provider settings updated successfully.',
            'data' => $result,
        ]);
    }
}
