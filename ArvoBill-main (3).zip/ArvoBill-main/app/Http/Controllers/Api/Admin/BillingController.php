<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\AccountTransaction;
use App\Models\User;
use App\Services\Billing\BalanceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class BillingController extends Controller
{
    public function userTransactions(int $id): JsonResponse
    {
        $user = User::query()->findOrFail($id);

        $transactions = AccountTransaction::query()
            ->where('user_id', $user->id)
            ->latest('id')
            ->limit(50)
            ->get()
            ->map(fn (AccountTransaction $transaction) => [
                'id' => $transaction->id,
                'type' => $transaction->type,
                'amount' => (float) $transaction->amount,
                'method' => $transaction->method,
                'reference' => $transaction->reference,
                'description' => $transaction->description,
                'created_at' => $transaction->created_at?->toISOString(),
            ])->values();

        return response()->json([
            'data' => $transactions,
        ]);
    }

    public function adjustBalance(
        Request $request,
        int $id,
        BalanceService $balanceService,
    ): JsonResponse {
        $user = User::query()->findOrFail($id);

        $validated = $request->validate([
            'type' => ['required', 'in:credit,debit'],
            'amount' => ['required', 'numeric', 'min:0.01'],
            'description' => ['nullable', 'string', 'max:255'],
        ]);

        $amount = (float) $validated['amount'];
        if ($validated['type'] === 'debit' && (float) $user->balance < $amount) {
            throw ValidationException::withMessages([
                'amount' => 'Cannot debit more than current balance.',
            ]);
        }

        if ($validated['type'] === 'credit') {
            $balanceService->credit(
                $user,
                $amount,
                'admin_credit',
                null,
                'admin',
                'admin:'.$request->user()->id,
                $validated['description'] ?? 'Admin credit adjustment',
            );
        } else {
            $balanceService->debit(
                $user,
                $amount,
                'admin_debit',
                null,
                'admin',
                'admin:'.$request->user()->id,
                $validated['description'] ?? 'Admin debit adjustment',
            );
        }

        return response()->json([
            'message' => 'Balance adjusted successfully.',
            'data' => [
                'user_id' => $user->id,
                'balance' => (float) $user->fresh()->balance,
            ],
        ]);
    }
}

