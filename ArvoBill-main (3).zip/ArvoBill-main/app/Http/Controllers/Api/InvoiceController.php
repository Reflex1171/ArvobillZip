<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class InvoiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $invoices = Invoice::query()
            ->with(['order.product'])
            ->where('user_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Invoice $invoice) => $this->transformInvoice($invoice));

        return response()->json([
            'data' => $invoices,
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $invoice = Invoice::query()
            ->with(['order.product', 'items'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformInvoice($invoice, true),
        ]);
    }

    private function transformInvoice(Invoice $invoice, bool $withItems = false): array
    {
        return [
            'id' => $invoice->id,
            'status' => $invoice->status,
            'subtotal' => (float) $invoice->subtotal,
            'promo_code' => $invoice->promo_code_code,
            'discount_amount' => (float) ($invoice->discount_amount ?? 0),
            'tax' => $invoice->tax !== null ? (float) $invoice->tax : null,
            'total' => (float) $invoice->total,
            'due_date' => $invoice->due_date?->toDateString(),
            'created_at' => $invoice->created_at?->toISOString(),
            'order' => $invoice->order ? [
                'id' => $invoice->order->id,
                'status' => $invoice->order->status,
                'product' => $invoice->order->product ? [
                    'id' => $invoice->order->product->id,
                    'name' => $invoice->order->product->name,
                    'slug' => $invoice->order->product->slug,
                ] : null,
            ] : null,
            'items' => $withItems
                ? $invoice->items->map(fn ($item) => [
                    'id' => $item->id,
                    'description' => $item->description,
                    'amount' => (float) $item->amount,
                ])->values()
                : null,
        ];
    }
}
