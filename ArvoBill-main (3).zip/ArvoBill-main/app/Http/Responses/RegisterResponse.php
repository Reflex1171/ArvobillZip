<?php

namespace App\Http\Responses;

use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Laravel\Fortify\Contracts\RegisterResponse as RegisterResponseContract;
use Symfony\Component\HttpFoundation\Response;

class RegisterResponse implements RegisterResponseContract
{
    public function toResponse($request): Response|JsonResponse
    {
        /** @var Request $request */
        $intended = $request->session()->pull('url.intended');
        $target = is_string($intended) && str_starts_with($intended, '/')
            ? $intended
            : '/client/dashboard';

        if ($request->is('api/*')) {
            return response()->json([
                'two_factor' => false,
                'redirect' => $target,
            ], 201);
        }

        return Inertia::location($target);
    }
}
