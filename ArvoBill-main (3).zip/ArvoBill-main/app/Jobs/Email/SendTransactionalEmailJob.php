<?php

namespace App\Jobs\Email;

use App\Mail\TransactionalMail;
use App\Models\EmailLog;
use App\Services\Email\EmailSettingsService;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Mail;
use Throwable;

class SendTransactionalEmailJob implements ShouldQueue
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public int $tries = 2;

    /**
     * @param  list<string>  $lines
     * @param  array<string, mixed>  $context
     */
    public function __construct(
        public readonly string $recipient,
        public readonly string $subjectLine,
        public readonly string $heading,
        public readonly array $lines,
        public readonly ?string $ctaLabel,
        public readonly ?string $ctaUrl,
        public readonly ?string $templateKey,
        public readonly array $context = [],
    ) {
        $this->onConnection('database');
        $this->onQueue('emails');
    }

    public function handle(EmailSettingsService $settingsService): void
    {
        $log = EmailLog::query()->create([
            'recipient' => $this->recipient,
            'subject' => $this->subjectLine,
            'template_key' => $this->templateKey,
            'status' => 'queued',
            'context' => $this->context,
        ]);

        $settings = $settingsService->get();
        if (! $settingsService->isUsable($settings)) {
            $log->status = 'skipped';
            $log->error_message = 'Email sending is disabled or SMTP settings are incomplete.';
            $log->save();

            return;
        }

        Config::set('mail.default', 'smtp');
        Config::set('mail.mailers.smtp.host', $settings->host);
        Config::set('mail.mailers.smtp.port', (int) $settings->port);
        Config::set('mail.mailers.smtp.encryption', $settings->encryption ?: null);
        Config::set('mail.mailers.smtp.username', $settings->username ?: null);
        Config::set('mail.mailers.smtp.password', $settings->password ?: null);
        Config::set('mail.from.address', $settings->from_address);
        Config::set('mail.from.name', $settings->from_name ?: 'ArvoBill');

        try {
            Mail::to($this->recipient)->send(new TransactionalMail(
                $this->subjectLine,
                $this->heading,
                $this->lines,
                $this->ctaLabel,
                $this->ctaUrl,
            ));

            $log->status = 'sent';
            $log->sent_at = now();
            $log->save();
        } catch (Throwable $exception) {
            $log->status = 'failed';
            $log->error_message = $exception->getMessage();
            $log->save();

            throw $exception;
        }
    }
}
