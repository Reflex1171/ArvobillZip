<?php

namespace App\Services\Billing;

use App\Models\AccountTransaction;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Service;
use App\Services\Email\EmailNotificationService;
use App\Support\BillingCycle;
use Illuminate\Support\Facades\DB;

class ServiceRenewalService
{
    public function __construct(
        private readonly BalanceService $balanceService,
        private readonly InvoiceSettlementService $invoiceSettlementService,
    ) {}

    public function processDueServices(): int
    {
        $services = Service::query()
            ->with(['user', 'product', 'defaultPaymentMethod'])
            ->whereIn('status', ['active', 'suspended'])
            ->whereNotNull('next_due_at')
            ->whereDate('next_due_at', '<=', now()->toDateString())
            ->get();

        $processed = 0;
        foreach ($services as $service) {
            $this->processSingleService($service);
            $processed++;
        }

        return $processed;
    }

    public function processSingleService(Service $service): void
    {
        $invoice = $this->getOrCreateRenewalInvoice($service);

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];
        $billingType = BillingCycle::normalizeBillingType((string) ($snapshot['billing_type'] ?? $service->product?->billing_type ?? 'recurring'));

        if (! $service->auto_renew || $billingType !== 'recurring') {
            return;
        }

        $this->balanceService->applyBalanceToInvoice($invoice);
        $invoice->refresh();
        if ($invoice->status === 'paid') {
            $this->invoiceSettlementService->markPaid($invoice);
            return;
        }

        $paymentMethod = $service->defaultPaymentMethod;
        if (! $paymentMethod || ! $paymentMethod->is_active) {
            $this->markRenewalFailure($service, $invoice, 'No default payment method configured.');
            return;
        }

        $this->markRenewalFailure(
            $service,
            $invoice,
            "Auto-charge via {$paymentMethod->provider} is not configured for off-session billing yet.",
            $paymentMethod->provider,
        );
    }

    public function forceRenew(Service $service): Invoice
    {
        $invoice = $this->getOrCreateRenewalInvoice($service);
        $this->processSingleService($service->fresh(['user', 'product', 'defaultPaymentMethod']));

        return $invoice->fresh();
    }

    private function getOrCreateRenewalInvoice(Service $service): Invoice
    {
        $existing = Invoice::query()
            ->where('service_id', $service->id)
            ->where('type', 'renewal')
            ->where('status', 'unpaid')
            ->latest('id')
            ->first();

        if ($existing) {
            return $existing;
        }

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];
        $billingType = BillingCycle::normalizeBillingType((string) ($snapshot['billing_type'] ?? $service->product?->billing_type ?? 'recurring'));
        if ($billingType !== 'recurring') {
            throw new \RuntimeException("Service #{$service->id} is not recurring and cannot be renewed.");
        }

        $amount = (float) ($snapshot['price'] ?? $service->product?->price_monthly ?? 0);
        $interval = BillingCycle::resolveInterval($snapshot['billing_interval'] ?? $service->product?->billing_interval ?? 1);
        $period = BillingCycle::normalizePeriod((string) ($snapshot['billing_period'] ?? $service->product?->billing_period ?? 'month'));
        $intervalSummary = BillingCycle::intervalSummary($interval, $period);
        $dueDate = $service->next_due_at
            ? $service->next_due_at->toDateString()
            : now()->toDateString();

        return DB::transaction(function () use ($service, $amount, $dueDate): Invoice {
            $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];
            $promoData = is_array($snapshot['promo'] ?? null) ? $snapshot['promo'] : null;
            $remainingCycles = $promoData && isset($promoData['remaining_cycles'])
                ? (int) $promoData['remaining_cycles']
                : 0;

            $discountAmount = 0.0;
            if ($promoData && $remainingCycles > 0) {
                $discountAmount = match ((string) ($promoData['type'] ?? 'fixed')) {
                    'percentage' => round($amount * ((float) ($promoData['value'] ?? 0) / 100), 2),
                    'fixed' => round((float) ($promoData['value'] ?? 0), 2),
                    default => 0.0,
                };
                if ($discountAmount < 0) {
                    $discountAmount = 0;
                }
                if ($discountAmount > $amount) {
                    $discountAmount = $amount;
                }
            }

            $invoice = Invoice::query()->create([
                'user_id' => $service->user_id,
                'order_id' => null,
                'service_id' => $service->id,
                'type' => 'renewal',
                'promo_code_id' => $promoData['promo_code_id'] ?? null,
                'promo_code_code' => $promoData['code'] ?? null,
                'subtotal' => $amount,
                'discount_amount' => $discountAmount,
                'tax' => null,
                'total' => max($amount - $discountAmount, 0),
                'balance_applied' => 0,
                'status' => 'unpaid',
                'due_date' => $dueDate,
                'meta' => ['auto_generated' => true],
            ]);

            $invoice->items()->create([
                'description' => ($service->product?->name ?? 'Service')." Renewal ({$intervalSummary})",
                'amount' => $amount,
            ]);

            if ($discountAmount > 0) {
                $invoice->items()->create([
                    'description' => 'Promo discount',
                    'amount' => 0 - $discountAmount,
                ]);
            }

            if ($promoData && $remainingCycles > 0) {
                $snapshot['promo']['remaining_cycles'] = max($remainingCycles - 1, 0);
                $service->billing_snapshot = $snapshot;
                $service->save();
            }

            return $invoice;
        });
    }

    private function markRenewalFailure(
        Service $service,
        Invoice $invoice,
        string $reason,
        ?string $provider = null,
    ): void {
        $service->renewal_failure_count = (int) $service->renewal_failure_count + 1;

        $maxFailures = (int) config('billing.renewal_suspend_after_failures', 3);
        if ($service->renewal_failure_count >= $maxFailures) {
            $service->status = 'suspended';
        }
        $service->save();

        Payment::query()->create([
            'invoice_id' => $invoice->id,
            'provider' => $provider ?? 'none',
            'provider_payment_id' => 'renewal-failed-'.$service->id.'-'.now()->timestamp,
            'amount' => $invoice->total,
            'currency' => 'USD',
            'status' => 'failed',
        ]);

        AccountTransaction::query()->create([
            'user_id' => $service->user_id,
            'invoice_id' => $invoice->id,
            'service_id' => $service->id,
            'type' => 'payment_failed',
            'amount' => $invoice->total,
            'method' => $provider,
            'reference' => 'renewal:'.$service->id,
            'description' => $reason,
            'meta' => ['renewal_failure_count' => $service->renewal_failure_count],
        ]);

        if ($service->status === 'suspended') {
            $service->loadMissing('user', 'product');
            if ($service->user) {
                app(EmailNotificationService::class)->queueToUser(
                    $service->user,
                    'Service #'.$service->id.' suspended',
                    'Service suspended after failed renewals',
                    [
                        'Your service has been suspended due to repeated renewal payment failures.',
                        'Reason: '.$reason,
                    ],
                    'Open Billing',
                    url('/client/billing'),
                    'service_suspended',
                    ['service_id' => $service->id, 'invoice_id' => $invoice->id],
                );
            }
        }
    }
}
