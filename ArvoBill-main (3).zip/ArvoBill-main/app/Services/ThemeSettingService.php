<?php

namespace App\Services;

use App\Models\ThemeSetting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Storage;

class ThemeSettingService
{
    private const CACHE_KEY = 'theme_settings.active';

    public function getTheme(): array
    {
        return Cache::rememberForever(self::CACHE_KEY, function () {
            $setting = ThemeSetting::query()->first();

            if (! $setting) {
                return ThemeSetting::DEFAULTS;
            }

            return [
                'brand_name' => $setting->brand_name ?: ThemeSetting::DEFAULTS['brand_name'],
                'site_title' => $setting->site_title ?: ThemeSetting::DEFAULTS['site_title'],
                'logo_url' => $this->resolveLogoUrl($setting->logo_path),
                'favicon_url' => $setting->favicon_url ?: ThemeSetting::DEFAULTS['favicon_url'],
                'primary_color' => $setting->primary_color,
                'secondary_color' => $setting->secondary_color,
                'accent_color' => $setting->accent_color,
                'background_color' => $setting->background_color,
                'surface_color' => $setting->surface_color,
                'text_color' => $setting->text_color,
            ];
        });
    }

    /**
     * @param  array<string, string>  $data
     */
    public function updateTheme(array $data): array
    {
        $setting = ThemeSetting::query()->first();

        if (! $setting) {
            $setting = new ThemeSetting();
        }

        $setting->fill($data);
        $setting->save();

        Cache::forget(self::CACHE_KEY);

        return $this->getTheme();
    }

    public function updateLogoPath(?string $path): array
    {
        $setting = ThemeSetting::query()->first();

        if (! $setting) {
            $setting = new ThemeSetting();
            $setting->fill(ThemeSetting::DEFAULTS);
        }

        $oldPath = $setting->logo_path;
        $setting->logo_path = $path;
        $setting->save();

        if (
            $oldPath
            && $oldPath !== $path
            && ! $this->isExternalLogoUrl($oldPath)
            && Storage::disk('public')->exists($oldPath)
        ) {
            Storage::disk('public')->delete($oldPath);
        }

        Cache::forget(self::CACHE_KEY);

        return $this->getTheme();
    }

    public function updateLogoUrl(?string $url): array
    {
        $normalized = $url !== null ? trim($url) : null;
        if ($normalized === '') {
            $normalized = null;
        }

        return $this->updateLogoPath($normalized);
    }

    private function resolveLogoUrl(?string $path): ?string
    {
        if (! $path) {
            return null;
        }

        if ($this->isExternalLogoUrl($path)) {
            return $path;
        }

        return Storage::disk('public')->url($path);
    }

    private function isExternalLogoUrl(string $value): bool
    {
        $lower = strtolower($value);

        return str_starts_with($lower, 'http://') || str_starts_with($lower, 'https://');
    }
}
