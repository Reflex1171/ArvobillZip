<?php

namespace App\Services\Email;

use App\Jobs\Email\SendTransactionalEmailJob;
use App\Models\User;

class EmailNotificationService
{
    /**
     * @param  list<string>  $lines
     * @param  array<string, mixed>  $context
     */
    public function queueToAddress(
        string $email,
        string $subject,
        string $heading,
        array $lines,
        ?string $ctaLabel = null,
        ?string $ctaUrl = null,
        ?string $templateKey = null,
        array $context = [],
    ): void {
        if (! filter_var($email, FILTER_VALIDATE_EMAIL)) {
            return;
        }

        SendTransactionalEmailJob::dispatch(
            recipient: $email,
            subjectLine: $subject,
            heading: $heading,
            lines: $lines,
            ctaLabel: $ctaLabel,
            ctaUrl: $ctaUrl,
            templateKey: $templateKey,
            context: $context,
        )->afterCommit();
    }

    /**
     * @param  list<string>  $lines
     * @param  array<string, mixed>  $context
     */
    public function queueToUser(
        User $user,
        string $subject,
        string $heading,
        array $lines,
        ?string $ctaLabel = null,
        ?string $ctaUrl = null,
        ?string $templateKey = null,
        array $context = [],
    ): void {
        $this->queueToAddress(
            email: (string) $user->email,
            subject: $subject,
            heading: $heading,
            lines: $lines,
            ctaLabel: $ctaLabel,
            ctaUrl: $ctaUrl,
            templateKey: $templateKey,
            context: $context,
        );
    }

    /**
     * @param  list<string>  $lines
     * @param  array<string, mixed>  $context
     */
    public function queueToAdminUsers(
        string $subject,
        string $heading,
        array $lines,
        ?string $ctaLabel = null,
        ?string $ctaUrl = null,
        ?string $templateKey = null,
        array $context = [],
    ): void {
        User::query()
            ->whereIn('role', ['admin', 'superuser'])
            ->each(function (User $user) use ($subject, $heading, $lines, $ctaLabel, $ctaUrl, $templateKey, $context): void {
                $this->queueToUser($user, $subject, $heading, $lines, $ctaLabel, $ctaUrl, $templateKey, $context);
            });
    }
}
