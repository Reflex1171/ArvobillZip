<?php

namespace App\Support;

use Carbon\Carbon;
use Carbon\CarbonInterface;

class BillingCycle
{
    /** @var list<string> */
    public const PERIODS = ['day', 'week', 'month', 'year'];

    public static function normalizeBillingType(?string $value): string
    {
        $raw = strtolower(trim((string) $value));

        if ($raw === 'monthly_subscription') {
            return 'recurring';
        }

        return in_array($raw, ['one_time', 'recurring'], true) ? $raw : 'recurring';
    }

    public static function normalizePeriod(?string $value): string
    {
        $raw = strtolower(trim((string) $value));

        return match ($raw) {
            'daily', 'days' => 'day',
            'weekly', 'weeks' => 'week',
            'monthly', 'months' => 'month',
            'yearly', 'years', 'annually', 'annual' => 'year',
            default => in_array($raw, self::PERIODS, true) ? $raw : 'month',
        };
    }

    public static function resolveInterval(mixed $value): int
    {
        $interval = (int) $value;

        return $interval > 0 ? $interval : 1;
    }

    public static function add(CarbonInterface $date, int $interval, string $period): CarbonInterface
    {
        $interval = self::resolveInterval($interval);
        $period = self::normalizePeriod($period);

        return match ($period) {
            'day' => $date->copy()->addDays($interval),
            'week' => $date->copy()->addWeeks($interval),
            'year' => $date->copy()->addYears($interval),
            default => $date->copy()->addMonths($interval),
        };
    }

    public static function nextDueFromNow(int $interval, string $period): CarbonInterface
    {
        return self::add(now(), $interval, $period);
    }

    public static function billingSummary(string $billingType, int $interval, string $period): string
    {
        $type = self::normalizeBillingType($billingType);
        if ($type === 'one_time') {
            return 'One-time charge';
        }

        $interval = self::resolveInterval($interval);
        $period = self::normalizePeriod($period);

        if ($interval === 1) {
            return match ($period) {
                'day' => 'Billed daily',
                'week' => 'Billed weekly',
                'year' => 'Billed yearly',
                default => 'Billed monthly',
            };
        }

        return sprintf('Billed every %d %s', $interval, self::pluralize($period, $interval));
    }

    public static function intervalSummary(int $interval, string $period): string
    {
        $interval = self::resolveInterval($interval);
        $period = self::normalizePeriod($period);

        if ($interval === 1) {
            return match ($period) {
                'day' => 'Daily',
                'week' => 'Weekly',
                'year' => 'Yearly',
                default => 'Monthly',
            };
        }

        return sprintf('Every %d %s', $interval, self::pluralize($period, $interval));
    }

    private static function pluralize(string $period, int $interval): string
    {
        if ($interval === 1) {
            return $period;
        }

        return $period.'s';
    }

    public static function normalizeProductFields(array $input): array
    {
        $billingType = self::normalizeBillingType((string) ($input['billing_type'] ?? 'recurring'));
        $input['billing_type'] = $billingType;

        if ($billingType === 'one_time') {
            $input['billing_interval'] = null;
            $input['billing_period'] = null;
            $input['allow_auto_renew'] = false;

            return $input;
        }

        $input['billing_interval'] = self::resolveInterval($input['billing_interval'] ?? 1);
        $input['billing_period'] = self::normalizePeriod((string) ($input['billing_period'] ?? 'month'));

        return $input;
    }

    public static function defaultSnapshot(array $data): array
    {
        $billingType = self::normalizeBillingType((string) ($data['billing_type'] ?? 'recurring'));
        $billingInterval = self::resolveInterval($data['billing_interval'] ?? 1);
        $billingPeriod = self::normalizePeriod((string) ($data['billing_period'] ?? 'month'));

        return [
            'billing_type' => $billingType,
            'billing_interval' => $billingInterval,
            'billing_period' => $billingPeriod,
            'billing_summary' => self::billingSummary($billingType, $billingInterval, $billingPeriod),
            'price' => (float) ($data['price'] ?? 0),
            'currency' => (string) ($data['currency'] ?? 'USD'),
        ];
    }
}

