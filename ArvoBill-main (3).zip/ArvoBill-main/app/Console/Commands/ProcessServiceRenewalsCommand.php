<?php

namespace App\Console\Commands;

use App\Services\Billing\ServiceRenewalService;
use Illuminate\Console\Command;

class ProcessServiceRenewalsCommand extends Command
{
    protected $signature = 'billing:process-renewals';

    protected $description = 'Process due recurring services and generate renewal invoices';

    public function handle(ServiceRenewalService $serviceRenewalService): int
    {
        $processed = $serviceRenewalService->processDueServices();

        $this->info("Processed {$processed} due services.");

        return self::SUCCESS;
    }
}

