<?php

namespace App\Console\Commands;

use App\Services\Affiliates\AffiliateService;
use Illuminate\Console\Command;

class ProcessAffiliateEarningsCommand extends Command
{
    protected $signature = 'affiliate:process-earnings';

    protected $description = 'Approve pending affiliate earnings that passed the approval delay';

    public function handle(AffiliateService $affiliateService): int
    {
        $processed = $affiliateService->approveEligiblePendingEarnings();
        $this->info("Processed {$processed} affiliate earning(s).");

        return self::SUCCESS;
    }
}