<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\Str;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_categories', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('slug')->unique();
            $table->text('description')->nullable();
            $table->timestamps();
        });

        Schema::table('products', function (Blueprint $table) {
            $table->foreignId('category_id')
                ->nullable()
                ->after('description')
                ->constrained('product_categories')
                ->nullOnDelete();
        });

        $categoryMap = [];

        $products = DB::table('products')
            ->select('id', 'category')
            ->whereNotNull('category')
            ->where('category', '!=', '')
            ->get();

        foreach ($products as $product) {
            $name = trim((string) $product->category);
            if ($name === '') {
                continue;
            }

            if (! array_key_exists($name, $categoryMap)) {
                $existing = DB::table('product_categories')
                    ->where('name', $name)
                    ->first();

                if ($existing) {
                    $categoryMap[$name] = $existing->id;
                } else {
                    $baseSlug = Str::slug($name) !== '' ? Str::slug($name) : 'category';
                    $slug = $baseSlug;
                    $counter = 2;

                    while (DB::table('product_categories')->where('slug', $slug)->exists()) {
                        $slug = "{$baseSlug}-{$counter}";
                        $counter++;
                    }

                    $categoryMap[$name] = DB::table('product_categories')->insertGetId([
                        'name' => $name,
                        'slug' => $slug,
                        'description' => null,
                        'created_at' => now(),
                        'updated_at' => now(),
                    ]);
                }
            }

            DB::table('products')
                ->where('id', $product->id)
                ->update(['category_id' => $categoryMap[$name]]);
        }
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropConstrainedForeignId('category_id');
        });

        Schema::dropIfExists('product_categories');
    }
};
