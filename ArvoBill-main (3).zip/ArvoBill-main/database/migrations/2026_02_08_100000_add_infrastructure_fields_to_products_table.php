<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->string('infrastructure_type')
                ->default('none')
                ->after('setup_fee');
            $table->unsignedBigInteger('pterodactyl_egg_id')
                ->nullable()
                ->after('infrastructure_type');
            $table->unsignedBigInteger('pterodactyl_default_node_id')
                ->nullable()
                ->after('pterodactyl_egg_id');
            $table->boolean('auto_provision')
                ->default(true)
                ->after('pterodactyl_default_node_id');

            $table->index('infrastructure_type');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('products', function (Blueprint $table) {
            $table->dropIndex(['infrastructure_type']);
            $table->dropColumn([
                'infrastructure_type',
                'pterodactyl_egg_id',
                'pterodactyl_default_node_id',
                'auto_provision',
            ]);
        });
    }
};
