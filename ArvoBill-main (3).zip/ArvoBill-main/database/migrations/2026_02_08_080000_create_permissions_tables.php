<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('permissions', function (Blueprint $table) {
            $table->id();
            $table->string('key')->unique();
            $table->string('description');
            $table->timestamps();
        });

        Schema::create('user_permissions', function (Blueprint $table) {
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->foreignId('permission_id')->constrained()->cascadeOnDelete();

            $table->primary(['user_id', 'permission_id']);
        });

        $now = now();
        DB::table('permissions')->insert([
            ['key' => 'view_users', 'description' => 'View user accounts', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'manage_users', 'description' => 'Manage user roles and permissions', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'view_services', 'description' => 'View service records', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'manage_services', 'description' => 'Update service statuses', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'view_billing', 'description' => 'View orders, invoices, and payments', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'manage_billing', 'description' => 'Manage invoices and billing actions', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'view_tickets', 'description' => 'View support tickets', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'manage_tickets', 'description' => 'Reply to and close tickets', 'created_at' => $now, 'updated_at' => $now],
            ['key' => 'manage_settings', 'description' => 'Manage system and panel settings', 'created_at' => $now, 'updated_at' => $now],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('user_permissions');
        Schema::dropIfExists('permissions');
    }
};
