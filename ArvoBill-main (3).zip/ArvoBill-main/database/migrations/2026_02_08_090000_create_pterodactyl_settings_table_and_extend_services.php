<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('pterodactyl_settings', function (Blueprint $table) {
            $table->id();
            $table->string('panel_url')->nullable();
            $table->text('api_key')->nullable();
            $table->boolean('enabled')->default(false);
            $table->timestamps();
        });

        DB::table('pterodactyl_settings')->insert([
            'panel_url' => null,
            'api_key' => null,
            'enabled' => false,
            'created_at' => now(),
            'updated_at' => now(),
        ]);

        Schema::table('services', function (Blueprint $table) {
            if (! Schema::hasColumn('services', 'pterodactyl_node_id')) {
                $table->unsignedBigInteger('pterodactyl_node_id')->nullable()->after('pterodactyl_server_id');
            }
            if (! Schema::hasColumn('services', 'pterodactyl_egg_id')) {
                $table->unsignedBigInteger('pterodactyl_egg_id')->nullable()->after('pterodactyl_node_id');
            }
            if (! Schema::hasColumn('services', 'pterodactyl_allocation_id')) {
                $table->unsignedBigInteger('pterodactyl_allocation_id')->nullable()->after('pterodactyl_egg_id');
            }
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('services', function (Blueprint $table) {
            if (Schema::hasColumn('services', 'pterodactyl_allocation_id')) {
                $table->dropColumn('pterodactyl_allocation_id');
            }
            if (Schema::hasColumn('services', 'pterodactyl_egg_id')) {
                $table->dropColumn('pterodactyl_egg_id');
            }
            if (Schema::hasColumn('services', 'pterodactyl_node_id')) {
                $table->dropColumn('pterodactyl_node_id');
            }
        });

        Schema::dropIfExists('pterodactyl_settings');
    }
};
