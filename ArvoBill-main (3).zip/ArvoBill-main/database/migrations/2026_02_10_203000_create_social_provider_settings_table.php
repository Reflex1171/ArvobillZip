<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('social_provider_settings', function (Blueprint $table) {
            $table->id();
            $table->string('provider')->unique();
            $table->boolean('enabled')->default(false);
            $table->string('client_id')->nullable();
            $table->string('client_secret')->nullable();
            $table->string('redirect_uri')->nullable();
            $table->string('team_id')->nullable();
            $table->string('key_id')->nullable();
            $table->text('private_key')->nullable();
            $table->timestamps();
        });

        DB::table('social_provider_settings')->insert([
            [
                'provider' => 'google',
                'enabled' => false,
                'created_at' => now(),
                'updated_at' => now(),
            ],
            [
                'provider' => 'apple',
                'enabled' => false,
                'created_at' => now(),
                'updated_at' => now(),
            ],
        ]);
    }

    public function down(): void
    {
        Schema::dropIfExists('social_provider_settings');
    }
};
