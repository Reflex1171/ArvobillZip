<?php

use App\Http\Controllers\Api\Admin\CategoryController as AdminCategoryController;
use App\Http\Controllers\Api\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Api\Admin\InvoiceController as AdminInvoiceController;
use App\Http\Controllers\Api\Admin\Infrastructure\PterodactylResourcesController;
use App\Http\Controllers\Api\Admin\Infrastructure\PterodactylSettingsController;
use App\Http\Controllers\Api\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Api\Admin\PaymentController as AdminPaymentController;
use App\Http\Controllers\Api\Admin\BillingController as AdminBillingController;
use App\Http\Controllers\Api\Admin\AffiliateController as AdminAffiliateController;
use App\Http\Controllers\Api\Admin\PaymentProviderController as AdminPaymentProviderController;
use App\Http\Controllers\Api\Admin\ProductController as AdminProductController;
use App\Http\Controllers\Api\Admin\ProductConfigurationController as AdminProductConfigurationController;
use App\Http\Controllers\Api\Admin\ProductConfigurationOptionController as AdminProductConfigurationOptionController;
use App\Http\Controllers\Api\Admin\ServiceController as AdminServiceController;
use App\Http\Controllers\Api\Admin\ThemeController as AdminThemeController;
use App\Http\Controllers\Api\Admin\TicketController as AdminTicketController;
use App\Http\Controllers\Api\Admin\UserController as AdminUserController;
use App\Http\Controllers\Api\AccountController;
use App\Http\Controllers\Api\AffiliateController;
use App\Http\Controllers\Api\CategoryController;
use App\Http\Controllers\Api\ClientBillingController;
use App\Http\Controllers\Api\DashboardController;
use App\Http\Controllers\Api\InvoiceController;
use App\Http\Controllers\Api\OrderController;
use App\Http\Controllers\Api\PaymentController;
use App\Http\Controllers\Api\PaymentProviderController;
use App\Http\Controllers\Api\PromoCodeController;
use App\Http\Controllers\Api\ProductController;
use App\Http\Controllers\Api\ProductConfigurationController;
use App\Http\Controllers\Api\ServiceController;
use App\Http\Controllers\Api\ThemeController;
use App\Http\Controllers\Api\TicketController;
use App\Http\Controllers\Api\Admin\Settings\EmailSettingsController as AdminEmailSettingsController;
use App\Http\Controllers\Api\Admin\Settings\SocialProviderSettingsController as AdminSocialProviderSettingsController;
use App\Http\Controllers\Api\Admin\PromoCodeController as AdminPromoCodeController;
use App\Http\Controllers\Auth\SocialAuthController;
use App\Http\Controllers\Webhooks\PayPalWebhookController;
use App\Http\Controllers\Webhooks\StripeWebhookController;
use Illuminate\Foundation\Http\Middleware\ValidateCsrfToken;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;

Route::redirect('/', '/products')->name('home');

Route::get('/auth/{provider}/redirect', [SocialAuthController::class, 'redirect'])
    ->name('social.redirect');
Route::match(['GET', 'POST'], '/auth/{provider}/callback', [SocialAuthController::class, 'callback'])
    ->name('social.callback');

Route::get('dashboard', function () {
    return Inertia::render('dashboard');
})->middleware(['auth', 'verified'])->name('dashboard');

Route::get('/api/me', function (Request $request) {
    $user = $request->user();

    if (! $user) {
        return response()->json([
            'data' => null,
        ]);
    }

    return response()->json([
        'data' => [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->role,
            'permissions' => $user->resolvedPermissionKeys(),
        ],
    ]);
});

Route::get('/api/products', [ProductController::class, 'index']);
Route::get('/api/products/{slug}/configurations', [ProductConfigurationController::class, 'index']);
Route::get('/api/products/{slug}', [ProductController::class, 'show']);
Route::post('/api/promo-codes/validate', [PromoCodeController::class, 'validateCode']);
Route::get('/api/categories', [CategoryController::class, 'index']);
Route::get('/api/categories/{slug}/products', [CategoryController::class, 'products']);
Route::get('/api/theme', ThemeController::class);

Route::view('/products', 'storefront');
Route::view('/products/{category}', 'storefront');
Route::view('/products/{category}/{slug}', 'storefront');
Route::view('/products/{category}/{slug}/configure', 'storefront');
Route::view('/checkout/{invoiceId}', 'storefront')->whereNumber('invoiceId');
Route::view('/checkout/product/{slug}', 'storefront');
Route::post('/api/webhooks/stripe', StripeWebhookController::class)
    ->withoutMiddleware([ValidateCsrfToken::class]);
Route::post('/api/webhooks/paypal', PayPalWebhookController::class)
    ->withoutMiddleware([ValidateCsrfToken::class]);

Route::middleware(['auth'])->group(function () {
    Route::get('/api/account', [AccountController::class, 'show']);
    Route::put('/api/account/profile', [AccountController::class, 'updateProfile']);
    Route::put('/api/account/password', [AccountController::class, 'updatePassword']);
    Route::delete('/api/account', [AccountController::class, 'destroy']);

    Route::get('/api/dashboard', DashboardController::class);

    Route::post('/api/orders', [OrderController::class, 'store']);
    Route::get('/api/orders', [OrderController::class, 'index']);
    Route::get('/api/orders/{id}', [OrderController::class, 'show']);
    Route::get('/api/services', [ServiceController::class, 'index']);
    Route::get('/api/services/{id}', [ServiceController::class, 'show']);
    Route::post('/api/services/{id}/cancel', [ServiceController::class, 'cancel']);
    Route::post('/api/services/{id}/upgrade', [ServiceController::class, 'upgrade']);
    Route::get('/api/invoices', [InvoiceController::class, 'index']);
    Route::get('/api/invoices/{id}', [InvoiceController::class, 'show']);
    Route::get('/api/invoices/{id}/pdf', [InvoiceController::class, 'downloadPdf']);
    Route::post('/api/payments/stripe/create-session', [PaymentController::class, 'createStripeSession']);
    Route::post('/api/payments/stripe/confirm-session', [PaymentController::class, 'confirmStripeSession']);
    Route::post('/api/payments/paypal/create-order', [PaymentController::class, 'createPayPalOrder']);
    Route::post('/api/payments/paypal/capture-order', [PaymentController::class, 'capturePayPalOrder']);
    Route::post('/api/payments/apply-credit', [PaymentController::class, 'applyAccountCredit']);
    Route::post('/api/billing/add-funds', [PaymentController::class, 'addFunds']);
    Route::get('/api/payment-providers', PaymentProviderController::class);
    Route::get('/api/client/billing', [ClientBillingController::class, 'show']);
    Route::post('/api/client/billing/payment-methods', [ClientBillingController::class, 'storePaymentMethod']);
    Route::delete('/api/client/billing/payment-methods/{id}', [ClientBillingController::class, 'destroyPaymentMethod']);
    Route::patch('/api/client/billing/payment-methods/{id}/default', [ClientBillingController::class, 'setDefaultPaymentMethod']);
    Route::get('/api/tickets', [TicketController::class, 'index']);
    Route::post('/api/tickets', [TicketController::class, 'store']);
    Route::get('/api/tickets/{id}', [TicketController::class, 'show']);
    Route::post('/api/tickets/{id}/reply', [TicketController::class, 'reply']);
    Route::patch('/api/services/{id}/auto-renew', [ServiceController::class, 'updateAutoRenew']);
    Route::patch('/api/services/{id}/default-payment-method', [ServiceController::class, 'updateDefaultPaymentMethod']);
    Route::get('/api/client/affiliate', [AffiliateController::class, 'show']);
    Route::post('/api/client/affiliate/payout-requests', [AffiliateController::class, 'requestPayout']);

    Route::get('/client/{path?}', fn () => view('client'))->where('path', '.*');
});

Route::middleware(['auth', 'admin'])->group(function () {
    Route::get('/api/admin/dashboard', AdminDashboardController::class)->middleware(
        'permission:view_users,view_services,view_billing,view_tickets,manage_settings,manage_users,manage_services,manage_billing,manage_tickets',
    );

    Route::get('/api/admin/infrastructure/pterodactyl', [PterodactylSettingsController::class, 'show'])->middleware('permission:manage_settings');
    Route::put('/api/admin/infrastructure/pterodactyl', [PterodactylSettingsController::class, 'update'])->middleware('permission:manage_settings');
    Route::post('/api/admin/infrastructure/pterodactyl/test', [PterodactylSettingsController::class, 'testConnection'])->middleware('permission:manage_settings');
    Route::get('/api/admin/infrastructure/nodes', [PterodactylResourcesController::class, 'nodes'])->middleware('permission:view_services');
    Route::get('/api/admin/infrastructure/eggs', [PterodactylResourcesController::class, 'eggs'])->middleware('permission:view_services');
    Route::get('/api/admin/infrastructure/allocations', [PterodactylResourcesController::class, 'allocations'])->middleware('permission:view_services');
    Route::get('/api/admin/infrastructure/servers', [PterodactylResourcesController::class, 'servers'])->middleware('permission:view_services');

    Route::prefix('/api/admin/categories')->group(function () {
        Route::get('/', [AdminCategoryController::class, 'index'])->middleware('permission:manage_settings');
        Route::get('/{category}', [AdminCategoryController::class, 'show'])->middleware('permission:manage_settings');
        Route::post('/', [AdminCategoryController::class, 'store'])->middleware('permission:manage_settings');
        Route::post('/{category}/duplicate', [AdminCategoryController::class, 'duplicate'])->middleware('permission:manage_settings');
        Route::put('/{category}', [AdminCategoryController::class, 'update'])->middleware('permission:manage_settings');
        Route::delete('/{category}', [AdminCategoryController::class, 'destroy'])->middleware('permission:manage_settings');
    });

    Route::prefix('/api/admin/products')->group(function () {
        Route::get('/', [AdminProductController::class, 'index'])->middleware('permission:manage_settings');
        Route::get('/{product}', [AdminProductController::class, 'show'])->middleware('permission:manage_settings');
        Route::post('/', [AdminProductController::class, 'store'])->middleware('permission:manage_settings');
        Route::put('/{product}', [AdminProductController::class, 'update'])->middleware('permission:manage_settings');
        Route::patch('/{product}/toggle', [AdminProductController::class, 'toggle'])->middleware('permission:manage_settings');
        Route::post('/{product}/duplicate', [AdminProductController::class, 'duplicate'])->middleware('permission:manage_settings');
        Route::get('/{id}/configurations', [AdminProductConfigurationController::class, 'index'])->middleware('permission:manage_settings');
        Route::post('/{id}/configurations', [AdminProductConfigurationController::class, 'store'])->middleware('permission:manage_settings');
    });

    Route::put('/api/admin/configurations/{id}', [AdminProductConfigurationController::class, 'update'])->middleware('permission:manage_settings');
    Route::delete('/api/admin/configurations/{id}', [AdminProductConfigurationController::class, 'destroy'])->middleware('permission:manage_settings');
    Route::post('/api/admin/configurations/{id}/options', [AdminProductConfigurationOptionController::class, 'store'])->middleware('permission:manage_settings');
    Route::put('/api/admin/options/{id}', [AdminProductConfigurationOptionController::class, 'update'])->middleware('permission:manage_settings');
    Route::delete('/api/admin/options/{id}', [AdminProductConfigurationOptionController::class, 'destroy'])->middleware('permission:manage_settings');

    Route::get('/api/admin/orders', [AdminOrderController::class, 'index'])->middleware('permission:view_billing');
    Route::get('/api/admin/orders/{id}', [AdminOrderController::class, 'show'])->middleware('permission:view_billing');
    Route::get('/api/admin/services', [AdminServiceController::class, 'index'])->middleware('permission:view_services');
    Route::get('/api/admin/services/{id}', [AdminServiceController::class, 'show'])->middleware('permission:view_services');
    Route::patch('/api/admin/services/{id}/status', [AdminServiceController::class, 'updateStatus'])->middleware('permission:manage_services');
    Route::post('/api/admin/services/{id}/suspend', [AdminServiceController::class, 'suspend'])->middleware('permission:manage_services');
    Route::post('/api/admin/services/{id}/unsuspend', [AdminServiceController::class, 'unsuspend'])->middleware('permission:manage_services');
    Route::post('/api/admin/services/{id}/provision', [AdminServiceController::class, 'provision'])->middleware('permission:manage_services');
    Route::post('/api/admin/services/{id}/retry-provision', [AdminServiceController::class, 'retryProvisioning'])->middleware('permission:manage_services');
    Route::post('/api/admin/services/{id}/force-renew', [AdminServiceController::class, 'forceRenew'])->middleware('permission:manage_services');
    Route::delete('/api/admin/services/{id}/pterodactyl', [AdminServiceController::class, 'deletePterodactylServer'])->middleware('permission:manage_services');

    Route::get('/api/admin/invoices', [AdminInvoiceController::class, 'index'])->middleware('permission:view_billing');
    Route::get('/api/admin/invoices/{id}', [AdminInvoiceController::class, 'show'])->middleware('permission:view_billing');
    Route::patch('/api/admin/invoices/{id}/status', [AdminInvoiceController::class, 'updateStatus'])->middleware('permission:manage_billing');
    Route::get('/api/admin/payments', [AdminPaymentController::class, 'index'])->middleware('permission:view_billing');
    Route::get('/api/admin/payment-providers', [AdminPaymentProviderController::class, 'index'])->middleware('permission:manage_settings');
    Route::put('/api/admin/payment-providers/{provider}', [AdminPaymentProviderController::class, 'update'])->middleware('permission:manage_settings');

    Route::get('/api/admin/users', [AdminUserController::class, 'index'])->middleware('permission:view_users');
    Route::get('/api/admin/users/{id}', [AdminUserController::class, 'show'])->middleware('permission:view_users');
    Route::put('/api/admin/users/{id}/role', [AdminUserController::class, 'updateRole'])->middleware('permission:manage_users');
    Route::put('/api/admin/users/{id}/permissions', [AdminUserController::class, 'updatePermissions'])->middleware('permission:manage_users');
    Route::delete('/api/admin/users/{id}', [AdminUserController::class, 'destroy'])->middleware('permission:manage_users');
    Route::post('/api/admin/users/{id}/sync-pterodactyl', [AdminUserController::class, 'syncPterodactylAccount'])->middleware('permission:manage_users');
    Route::get('/api/admin/users/{id}/transactions', [AdminBillingController::class, 'userTransactions'])->middleware('permission:view_billing');
    Route::post('/api/admin/users/{id}/balance-adjustment', [AdminBillingController::class, 'adjustBalance'])->middleware('permission:manage_billing');
    Route::get('/api/admin/tickets', [AdminTicketController::class, 'index'])->middleware('permission:view_tickets');
    Route::get('/api/admin/tickets/{id}', [AdminTicketController::class, 'show'])->middleware('permission:view_tickets');
    Route::post('/api/admin/tickets/{id}/reply', [AdminTicketController::class, 'reply'])->middleware('permission:manage_tickets');
    Route::patch('/api/admin/tickets/{id}/status', [AdminTicketController::class, 'updateStatus'])->middleware('permission:manage_tickets');
    Route::get('/api/admin/theme', [AdminThemeController::class, 'show'])->middleware('permission:manage_settings');
    Route::put('/api/admin/theme', [AdminThemeController::class, 'update'])->middleware('permission:manage_settings');
    Route::post('/api/admin/theme/logo', [AdminThemeController::class, 'uploadLogo'])->middleware('permission:manage_settings');
    Route::put('/api/admin/theme/logo-url', [AdminThemeController::class, 'setLogoUrl'])->middleware('permission:manage_settings');
    Route::delete('/api/admin/theme/logo', [AdminThemeController::class, 'deleteLogo'])->middleware('permission:manage_settings');

    Route::get('/api/admin/settings/email', [AdminEmailSettingsController::class, 'show'])->middleware('permission:manage_settings');
    Route::put('/api/admin/settings/email', [AdminEmailSettingsController::class, 'update'])->middleware('permission:manage_settings');
    Route::post('/api/admin/settings/email/test', [AdminEmailSettingsController::class, 'sendTest'])->middleware('permission:manage_settings');
    Route::get('/api/admin/settings/social', [AdminSocialProviderSettingsController::class, 'show'])->middleware('permission:manage_settings');
    Route::put('/api/admin/settings/social/{provider}', [AdminSocialProviderSettingsController::class, 'update'])->middleware('permission:manage_settings');
    Route::post('/api/admin/settings/social/{provider}/test', [AdminSocialProviderSettingsController::class, 'test'])->middleware('permission:manage_settings');

    Route::get('/api/admin/affiliates', [AdminAffiliateController::class, 'index'])->middleware('permission:view_billing');
    Route::put('/api/admin/affiliates/settings', [AdminAffiliateController::class, 'updateSettings'])->middleware('permission:manage_settings');
    Route::patch('/api/admin/affiliates/earnings/{id}', [AdminAffiliateController::class, 'updateEarningStatus'])->middleware('permission:manage_billing');
    Route::get('/api/admin/discounts', [AdminPromoCodeController::class, 'index'])->middleware('permission:view_billing');
    Route::post('/api/admin/discounts', [AdminPromoCodeController::class, 'store'])->middleware('permission:manage_billing');
    Route::put('/api/admin/discounts/{id}', [AdminPromoCodeController::class, 'update'])->middleware('permission:manage_billing');
    Route::patch('/api/admin/discounts/{id}/toggle', [AdminPromoCodeController::class, 'toggle'])->middleware('permission:manage_billing');

    Route::get('/admin/{path?}', function () {
        return view('admin');
    })->where('path', '.*');
});

require __DIR__.'/settings.php';
