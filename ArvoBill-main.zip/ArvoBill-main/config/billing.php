<?php

return [
    'add_funds_min' => 5,
    'add_funds_max' => 500,
    'renewal_suspend_after_failures' => 3,
];

