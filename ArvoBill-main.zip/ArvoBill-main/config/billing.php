<?php

return [
    'add_funds_min' => 5,
    'add_funds_max' => 500,
    'renewal_suspend_after_failures' => 3,
    'overdue_reminder_days' => [0, 3, 7],
    'overdue_suspend_after_days' => 3,
    'overdue_terminate_after_days' => 14,
    'terminate_delete_pterodactyl' => false,
];
