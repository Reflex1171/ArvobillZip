<?php

namespace App\Console\Commands;

use App\Services\Billing\OverdueInvoiceService;
use Illuminate\Console\Command;

class ProcessOverdueInvoicesCommand extends Command
{
    protected $signature = 'billing:process-overdue';

    protected $description = 'Process overdue invoices (dunning, suspend, terminate)';

    public function handle(OverdueInvoiceService $overdueInvoiceService): int
    {
        $processed = $overdueInvoiceService->processOverdueInvoices();

        $this->info("Processed {$processed} overdue invoice(s).");

        return self::SUCCESS;
    }
}

