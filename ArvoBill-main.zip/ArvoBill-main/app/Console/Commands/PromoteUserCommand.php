<?php

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;

class PromoteUserCommand extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'user:promote {email} {role}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Promote a user to admin or superuser';

    /**
     * Execute the console command.
     */
    public function handle(): int
    {
        $email = (string) $this->argument('email');
        $role = (string) $this->argument('role');
        $allowedRoles = ['admin', 'superuser'];

        if (! in_array($role, $allowedRoles, true)) {
            $this->error("Invalid role [{$role}]. Allowed roles: admin, superuser.");

            return self::FAILURE;
        }

        $user = User::where('email', $email)->first();

        if (! $user) {
            $this->error("User with email [{$email}] was not found.");

            return self::FAILURE;
        }

        $user->role = $role;
        $user->save();

        $this->info("User [{$user->email}] promoted to [{$role}] successfully.");

        return self::SUCCESS;
    }
}
