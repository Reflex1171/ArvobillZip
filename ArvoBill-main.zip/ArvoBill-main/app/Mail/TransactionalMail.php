<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class TransactionalMail extends Mailable
{
    use Queueable;
    use SerializesModels;

    /**
     * @param  list<string>  $lines
     */
    public function __construct(
        public readonly string $subjectLine,
        public readonly string $heading,
        public readonly array $lines,
        public readonly ?string $ctaLabel = null,
        public readonly ?string $ctaUrl = null,
        public readonly array $mailAttachments = [],
    ) {}

    public function build(): self
    {
        $mail = $this->subject($this->subjectLine)
            ->view('emails.transactional');

        foreach ($this->mailAttachments as $attachment) {
            if (! isset($attachment['data']) || ! is_string($attachment['data'])) {
                continue;
            }

            $mail->attachData(
                $attachment['data'],
                (string) ($attachment['name'] ?? 'attachment.pdf'),
                ['mime' => (string) ($attachment['mime'] ?? 'application/octet-stream')],
            );
        }

        return $mail;
    }
}
