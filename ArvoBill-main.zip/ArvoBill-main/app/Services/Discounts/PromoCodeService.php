<?php

namespace App\Services\Discounts;

use App\Models\Order;
use App\Models\PromoCode;
use App\Models\PromoCodeRedemption;
use App\Models\Product;
use App\Models\User;
use App\Services\Affiliates\AffiliateService;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class PromoCodeService
{
    /**
     * @return array{promo_code: PromoCode|null, code:string|null, discount_amount:float, final_total:float}
     */
    public function resolve(
        ?string $rawCode,
        ?User $user,
        Product $product,
        float $orderSubtotal,
        ?Request $request = null,
    ): array {
        $normalizedCode = $this->normalizeCode($rawCode);
        if ($normalizedCode === null) {
            return [
                'promo_code' => null,
                'code' => null,
                'discount_amount' => 0.0,
                'final_total' => round($orderSubtotal, 2),
            ];
        }

        $promoCode = PromoCode::query()->where('code', $normalizedCode)->first();
        if (! $promoCode) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code is invalid.',
            ]);
        }

        $this->assertUsable($promoCode, $user, $product, $orderSubtotal, $request);

        $discountAmount = $this->calculateDiscount($promoCode, $orderSubtotal);
        $finalTotal = max(round($orderSubtotal - $discountAmount, 2), 0);

        return [
            'promo_code' => $promoCode,
            'code' => $promoCode->code,
            'discount_amount' => $discountAmount,
            'final_total' => $finalTotal,
        ];
    }

    public function redeem(PromoCode $promoCode, User $user, Order $order, int $invoiceId, float $discountAmount): void
    {
        if ($discountAmount <= 0) {
            return;
        }

        $freshPromo = PromoCode::query()->lockForUpdate()->findOrFail($promoCode->id);

        if (! $freshPromo->is_active) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code is no longer active.',
            ]);
        }

        if ($freshPromo->expires_at && $freshPromo->expires_at->isPast()) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code has expired.',
            ]);
        }

        if ($freshPromo->max_uses !== null && $freshPromo->uses >= $freshPromo->max_uses) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code usage limit has been reached.',
            ]);
        }

        $perUserLimit = $freshPromo->max_redemptions_per_user;
        if ($perUserLimit === null && $freshPromo->once_per_user) {
            $perUserLimit = 1;
        }

        if ($perUserLimit !== null) {
            $redemptionCount = PromoCodeRedemption::query()
                ->where('promo_code_id', $freshPromo->id)
                ->where('user_id', $user->id)
                ->count();

            if ($redemptionCount >= (int) $perUserLimit) {
                throw ValidationException::withMessages([
                    'promo_code' => 'Promo code usage limit per customer has been reached.',
                ]);
            }
        }

        $freshPromo->uses = (int) $freshPromo->uses + 1;
        $freshPromo->save();

        PromoCodeRedemption::query()->create([
            'promo_code_id' => $freshPromo->id,
            'user_id' => $user->id,
            'order_id' => $order->id,
            'invoice_id' => $invoiceId,
            'discount_amount' => $discountAmount,
        ]);
    }

    private function normalizeCode(?string $rawCode): ?string
    {
        $normalized = strtoupper(trim((string) $rawCode));

        return $normalized !== '' ? $normalized : null;
    }

    private function assertUsable(
        PromoCode $promoCode,
        ?User $user,
        Product $product,
        float $orderSubtotal,
        ?Request $request,
    ): void {
        if (! $promoCode->is_active) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code is inactive.',
            ]);
        }

        if ($promoCode->expires_at && $promoCode->expires_at->isPast()) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code has expired.',
            ]);
        }

        if ($promoCode->max_uses !== null && $promoCode->uses >= $promoCode->max_uses) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code usage limit has been reached.',
            ]);
        }

        $perUserLimit = $promoCode->max_redemptions_per_user;
        if ($perUserLimit === null && $promoCode->once_per_user) {
            $perUserLimit = 1;
        }

        if ($perUserLimit !== null && $user) {
            $redemptionCount = PromoCodeRedemption::query()
                ->where('promo_code_id', $promoCode->id)
                ->where('user_id', $user->id)
                ->count();

            if ($redemptionCount >= (int) $perUserLimit) {
                throw ValidationException::withMessages([
                    'promo_code' => 'Promo code usage limit per customer has been reached.',
                ]);
            }
        }

        $minimumOrder = $promoCode->minimum_order_amount !== null
            ? (float) $promoCode->minimum_order_amount
            : null;
        if ($minimumOrder !== null && $orderSubtotal < $minimumOrder) {
            throw ValidationException::withMessages([
                'promo_code' => 'Order amount is below promo minimum requirement.',
            ]);
        }

        if ($promoCode->applies_to === 'products') {
            $eligibleProducts = collect($promoCode->eligible_product_ids ?? [])->map(fn ($id) => (int) $id)->filter();
            if (! $eligibleProducts->contains((int) $product->id)) {
                throw ValidationException::withMessages([
                    'promo_code' => 'Promo code does not apply to this product.',
                ]);
            }
        }

        if ($promoCode->applies_to === 'categories') {
            $eligibleCategories = collect($promoCode->eligible_category_ids ?? [])->map(fn ($id) => (int) $id)->filter();
            $productCategoryId = (int) ($product->category_id ?? 0);
            if ($productCategoryId <= 0 || ! $eligibleCategories->contains($productCategoryId)) {
                throw ValidationException::withMessages([
                    'promo_code' => 'Promo code does not apply to this category.',
                ]);
            }
        }

        if ($promoCode->affiliate_exclusive && ! $this->hasAffiliateContext($user, $request)) {
            throw ValidationException::withMessages([
                'promo_code' => 'Promo code is only valid with an affiliate referral.',
            ]);
        }
    }

    private function calculateDiscount(PromoCode $promoCode, float $orderSubtotal): float
    {
        $discountAmount = match ($promoCode->type) {
            'percentage' => round($orderSubtotal * ((float) $promoCode->value / 100), 2),
            'fixed' => round((float) $promoCode->value, 2),
            default => 0.0,
        };

        if ($discountAmount < 0) {
            $discountAmount = 0;
        }

        if ($discountAmount > $orderSubtotal) {
            $discountAmount = round($orderSubtotal, 2);
        }

        return $discountAmount;
    }

    private function hasAffiliateContext(?User $user, ?Request $request): bool
    {
        if ($user && (int) ($user->referred_by ?? 0) > 0) {
            return true;
        }

        if (! $request) {
            return false;
        }

        $code = (string) $request->session()->get(
            AffiliateService::SESSION_KEY,
            (string) $request->cookie(AffiliateService::COOKIE_KEY, ''),
        );

        if ($code === '') {
            return false;
        }

        return User::query()->where('affiliate_code', strtoupper($code))->exists();
    }
}
