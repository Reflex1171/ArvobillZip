<?php

namespace App\Services\Payments;

use App\Models\PaymentProviderSetting;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class PaymentProviderManager
{
    public const PROVIDERS = ['stripe', 'paypal'];

    public const MODES = ['test', 'live'];

    /**
     * @return array<int, array<string, mixed>>
     */
    public function getAdminSettings(): array
    {
        return collect(self::PROVIDERS)
            ->map(function (string $provider): array {
                $rows = PaymentProviderSetting::query()
                    ->where('provider', $provider)
                    ->orderBy('mode')
                    ->get()
                    ->keyBy('mode');

                $active = $rows->firstWhere('enabled', true) ?? $rows->get('test');

                return [
                    'provider' => $provider,
                    'mode' => (string) ($active?->mode ?? 'test'),
                    'enabled' => (bool) ($active?->enabled ?? false),
                    'settings' => collect(self::MODES)->mapWithKeys(function (string $mode) use ($rows): array {
                        /** @var PaymentProviderSetting|null $row */
                        $row = $rows->get($mode);

                        return [
                            $mode => [
                                'public_key' => $row?->public_key,
                                'secret_key_masked' => $this->maskSecret((string) ($row?->secret_key ?? '')),
                                'webhook_secret_masked' => $this->maskSecret((string) ($row?->webhook_secret ?? '')),
                                'has_secret_key' => $this->hasValue($row?->secret_key),
                                'has_webhook_secret' => $this->hasValue($row?->webhook_secret),
                            ],
                        ];
                    })->all(),
                ];
            })
            ->all();
    }

    public function getEnabledCheckoutProviders(): array
    {
        return collect(self::PROVIDERS)
            ->map(function (string $provider): ?array {
                $active = $this->getActiveSetting($provider);
                if (! $active || ! $active->enabled) {
                    return null;
                }

                if (! $this->isUsable($active)) {
                    return null;
                }

                return [
                    'provider' => $provider,
                    'mode' => $active->mode,
                ];
            })
            ->filter()
            ->values()
            ->all();
    }

    public function getActiveCredentials(string $provider): array
    {
        $provider = strtolower($provider);
        if (! in_array($provider, self::PROVIDERS, true)) {
            throw ValidationException::withMessages([
                'provider' => 'Unsupported payment provider.',
            ]);
        }

        $cacheKey = $this->cacheKey($provider);
        $setting = Cache::remember($cacheKey, now()->addMinutes(10), function () use ($provider) {
            return PaymentProviderSetting::query()
                ->where('provider', $provider)
                ->where('enabled', true)
                ->first();
        });

        if (! $setting instanceof PaymentProviderSetting) {
            throw ValidationException::withMessages([
                'provider' => ucfirst($provider).' is disabled.',
            ]);
        }

        if (! $this->isUsable($setting)) {
            throw ValidationException::withMessages([
                'provider' => ucfirst($provider).' credentials are incomplete.',
            ]);
        }

        return [
            'provider' => $provider,
            'mode' => $setting->mode,
            'public_key' => $setting->public_key,
            'secret_key' => (string) $setting->secret_key,
            'webhook_secret' => $setting->webhook_secret !== null
                ? (string) $setting->webhook_secret
                : null,
        ];
    }

    /**
     * @param  array<string, mixed>  $payload
     */
    public function updateProvider(string $provider, array $payload): array
    {
        $provider = strtolower($provider);
        if (! in_array($provider, self::PROVIDERS, true)) {
            throw ValidationException::withMessages([
                'provider' => 'Unsupported payment provider.',
            ]);
        }

        $mode = (string) ($payload['mode'] ?? 'test');
        if (! in_array($mode, self::MODES, true)) {
            throw ValidationException::withMessages([
                'mode' => 'Mode must be test or live.',
            ]);
        }

        $enabled = (bool) ($payload['enabled'] ?? false);
        $publicKey = isset($payload['public_key']) ? trim((string) $payload['public_key']) : null;
        $secretKey = isset($payload['secret_key']) ? trim((string) $payload['secret_key']) : null;
        $webhookSecret = isset($payload['webhook_secret']) ? trim((string) $payload['webhook_secret']) : null;

        $setting = DB::transaction(function () use (
            $provider,
            $mode,
            $publicKey,
            $secretKey,
            $webhookSecret,
            $enabled
        ) {
            $setting = PaymentProviderSetting::query()->firstOrCreate([
                'provider' => $provider,
                'mode' => $mode,
            ], [
                'public_key' => null,
                'secret_key' => '',
                'webhook_secret' => '',
                'enabled' => false,
            ]);

            if ($publicKey !== null) {
                $setting->public_key = $publicKey !== '' ? $publicKey : null;
            }

            if ($secretKey !== null && $secretKey !== '') {
                $setting->secret_key = $secretKey;
            }

            if ($webhookSecret !== null) {
                $setting->webhook_secret = $webhookSecret !== '' ? $webhookSecret : null;
            }

            if ($enabled && ! $this->isUsable($setting)) {
                throw ValidationException::withMessages([
                    'enabled' => ucfirst($provider).' cannot be enabled without required keys.',
                ]);
            }

            if ($enabled) {
                PaymentProviderSetting::query()
                    ->where('provider', $provider)
                    ->update(['enabled' => false]);
                $setting->enabled = true;
            } else {
                $setting->enabled = false;
            }

            $setting->save();

            return $setting->fresh();
        });

        $this->forgetProviderCache($provider);

        return [
            'provider' => $provider,
            'mode' => $setting->mode,
            'enabled' => $setting->enabled,
            'public_key' => $setting->public_key,
            'secret_key_masked' => $this->maskSecret((string) $setting->secret_key),
            'webhook_secret_masked' => $this->maskSecret((string) ($setting->webhook_secret ?? '')),
        ];
    }

    public function forgetProviderCache(string $provider): void
    {
        Cache::forget($this->cacheKey($provider));
    }

    public function getModeBaseUrls(string $provider, string $mode): array
    {
        if ($provider === 'stripe') {
            return ['api_base' => 'https://api.stripe.com'];
        }

        if ($provider === 'paypal') {
            return [
                'api_base' => $mode === 'live'
                    ? 'https://api-m.paypal.com'
                    : 'https://api-m.sandbox.paypal.com',
            ];
        }

        return ['api_base' => ''];
    }

    private function getActiveSetting(string $provider): ?PaymentProviderSetting
    {
        return PaymentProviderSetting::query()
            ->where('provider', $provider)
            ->where('enabled', true)
            ->first();
    }

    private function isUsable(PaymentProviderSetting $setting): bool
    {
        $secret = trim((string) $setting->secret_key);
        if ($secret === '') {
            return false;
        }

        if ($setting->provider === 'stripe') {
            return trim((string) ($setting->webhook_secret ?? '')) !== '';
        }

        if ($setting->provider === 'paypal') {
            return trim((string) ($setting->webhook_secret ?? '')) !== '';
        }

        return false;
    }

    private function cacheKey(string $provider): string
    {
        return 'payment-provider-active:'.$provider;
    }

    private function maskSecret(string $value): ?string
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }

        if (strlen($value) <= 4) {
            return str_repeat('*', strlen($value));
        }

        return str_repeat('*', strlen($value) - 4).substr($value, -4);
    }

    private function hasValue(mixed $value): bool
    {
        return trim((string) $value) !== '';
    }
}
