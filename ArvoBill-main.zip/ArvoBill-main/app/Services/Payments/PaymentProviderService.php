<?php

namespace App\Services\Payments;

use App\Models\PaymentProvider;
use Illuminate\Validation\ValidationException;

class PaymentProviderService
{
    public function ensureEnabled(string $name): void
    {
        $provider = PaymentProvider::query()
            ->where('name', $name)
            ->first();

        if (! $provider || ! $provider->enabled) {
            throw ValidationException::withMessages([
                'provider' => ucfirst($name).' is currently unavailable.',
            ]);
        }
    }
}
