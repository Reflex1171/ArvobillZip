<?php

namespace App\Services;

use App\Models\SocialProviderSetting;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Schema;

class SocialProviderSettingsService
{
    private const CACHE_KEY = 'social:providers';

    /**
     * @return Collection<string, SocialProviderSetting>
     */
    public function getAll(): Collection
    {
        if (! Schema::hasTable('social_provider_settings')) {
            return collect([
                'google' => (new SocialProviderSetting([
                    'provider' => 'google',
                    'enabled' => false,
                ])),
                'apple' => (new SocialProviderSetting([
                    'provider' => 'apple',
                    'enabled' => false,
                ])),
            ]);
        }

        /** @var Collection<string, SocialProviderSetting> $settings */
        $settings = Cache::rememberForever(self::CACHE_KEY, function () {
            $all = SocialProviderSetting::query()->get()->keyBy('provider');

            if ($all->isEmpty()) {
                SocialProviderSetting::query()->create(['provider' => 'google', 'enabled' => false]);
                SocialProviderSetting::query()->create(['provider' => 'apple', 'enabled' => false]);
                $all = SocialProviderSetting::query()->get()->keyBy('provider');
            }

            return $all;
        });

        return $settings;
    }

    public function getProvider(string $provider): SocialProviderSetting
    {
        if (! Schema::hasTable('social_provider_settings')) {
            return new SocialProviderSetting([
                'provider' => $provider,
                'enabled' => false,
            ]);
        }

        /** @var SocialProviderSetting|null $setting */
        $setting = $this->getAll()->get($provider);

        if ($setting) {
            return $setting;
        }

        $setting = SocialProviderSetting::query()->create([
            'provider' => $provider,
            'enabled' => false,
        ]);

        $this->clearCache();

        return $setting;
    }

    /**
     * @return array{google: bool, apple: bool}
     */
    public function getPublicEnabled(): array
    {
        $settings = $this->getAll();

        return [
            'google' => (bool) optional($settings->get('google'))->enabled,
            'apple' => (bool) optional($settings->get('apple'))->enabled,
        ];
    }

    public function clearCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }
}
