<?php

namespace App\Services\Billing;

use App\Models\Invoice;
use App\Models\Service;
use App\Services\Affiliates\AffiliateService;
use App\Services\Email\EmailNotificationService;
use App\Services\Infrastructure\ServiceProvisioner;
use App\Support\BillingCycle;
use Illuminate\Support\Facades\DB;
use RuntimeException;

class InvoiceSettlementService
{
    public function __construct(
        private readonly ServiceProvisioner $serviceProvisioner,
        private readonly BalanceService $balanceService,
        private readonly AffiliateService $affiliateService,
        private readonly EmailNotificationService $emailNotificationService,
    ) {}

    public function markPaid(Invoice $invoice): Invoice
    {
        $invoice = DB::transaction(function () use ($invoice) {
            $invoice = Invoice::query()
                ->with('order.product', 'order.configurations')
                ->lockForUpdate()
                ->findOrFail($invoice->id);

            if ($invoice->status !== 'paid') {
                $invoice->status = 'paid';
                $invoice->save();
            }

            if ($invoice->type === 'credit') {
                $this->balanceService->credit(
                    $invoice->user,
                    (float) $invoice->total,
                    'credit',
                    $invoice,
                    'gateway',
                    'invoice:'.$invoice->id,
                    'Account credit top-up',
                );

                return $invoice->fresh();
            }

            if ($invoice->type === 'renewal') {
                $service = $invoice->relatedService;
                if (! $service) {
                    throw new RuntimeException('Renewal invoice is missing linked service.');
                }

                $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];
                $billingInterval = BillingCycle::resolveInterval($snapshot['billing_interval'] ?? 1);
                $billingPeriod = BillingCycle::normalizePeriod((string) ($snapshot['billing_period'] ?? 'month'));
                $currentDue = $service->next_due_at ?? $service->next_due_date ?? now();
                $nextDue = BillingCycle::add($currentDue, $billingInterval, $billingPeriod);

                $service->next_due_at = $nextDue->toDateString();
                $service->next_due_date = $nextDue->toDateString();
                $service->last_renewed_at = now();
                $service->renewal_failure_count = 0;
                if ($service->status === 'suspended') {
                    $service->status = 'active';
                }
                $service->invoice_id = $invoice->id;
                $service->save();

                return $invoice->fresh();
            }

            if ($invoice->order) {
                if ($invoice->order->status !== 'completed') {
                    $invoice->order->status = 'completed';
                    $invoice->order->save();
                }

                $productBillingType = BillingCycle::normalizeBillingType((string) ($invoice->order->product?->billing_type ?? 'recurring'));
                $productBillingInterval = BillingCycle::resolveInterval($invoice->order->product?->billing_interval ?? 1);
                $productBillingPeriod = BillingCycle::normalizePeriod((string) ($invoice->order->product?->billing_period ?? 'month'));
                $nextDueDate = $productBillingType === 'recurring'
                    ? BillingCycle::nextDueFromNow($productBillingInterval, $productBillingPeriod)->toDateString()
                    : now()->toDateString();

                $service = Service::query()->firstOrCreate(
                    ['invoice_id' => $invoice->id],
                    [
                        'user_id' => $invoice->user_id,
                        'product_id' => $invoice->order->product_id,
                        'order_id' => $invoice->order->id,
                        'status' => 'pending',
                        'billing_cycle' => BillingCycle::intervalSummary(
                            BillingCycle::resolveInterval($invoice->order->product?->billing_interval ?? 1),
                            BillingCycle::normalizePeriod((string) ($invoice->order->product?->billing_period ?? 'month')),
                        ),
                        'billing_snapshot' => BillingCycle::defaultSnapshot([
                            'billing_type' => $productBillingType,
                            'billing_interval' => $productBillingInterval,
                            'billing_period' => $productBillingPeriod,
                            'price' => $invoice->order->product?->price_monthly ?? 0,
                            'currency' => 'USD',
                        ]),
                        'auto_renew' => (bool) ($invoice->order->product?->allow_auto_renew ?? true),
                        'next_due_at' => $productBillingType === 'recurring' ? $nextDueDate : null,
                        'next_due_date' => $nextDueDate,
                        'pterodactyl_server_id' => null,
                        'provisioning_snapshot' => $this->serviceProvisioner->snapshotFromOrder($invoice->order),
                    ],
                );

                if (! $service->provisioning_snapshot) {
                    $service->provisioning_snapshot = $this->serviceProvisioner->snapshotFromOrder($invoice->order);
                    $service->save();
                }

                if (! $service->billing_snapshot) {
                    $service->billing_snapshot = BillingCycle::defaultSnapshot([
                        'billing_type' => $productBillingType,
                        'billing_interval' => $productBillingInterval,
                        'billing_period' => $productBillingPeriod,
                        'price' => $invoice->order->product?->price_monthly ?? 0,
                        'currency' => 'USD',
                    ]);
                    $service->save();
                }

                $promoCode = $invoice->promoCode;
                if ($promoCode && $productBillingType === 'recurring') {
                    $durationCycles = $promoCode->duration_cycles ?? 1;
                    $remainingCycles = max((int) $durationCycles - 1, 0);
                    $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];
                    $snapshot['promo'] = [
                        'promo_code_id' => $promoCode->id,
                        'code' => $promoCode->code,
                        'type' => $promoCode->type,
                        'value' => (float) $promoCode->value,
                        'duration_cycles' => (int) $durationCycles,
                        'remaining_cycles' => $remainingCycles,
                    ];
                    $service->billing_snapshot = $snapshot;
                    $service->save();
                }
            }

            return $invoice->fresh();
        });

        $invoice->loadMissing('user', 'order.product');

        $this->serviceProvisioner->handleInvoicePaid($invoice);
        $this->affiliateService->handleInvoicePaid($invoice);

        if ($invoice->user) {
            $this->emailNotificationService->queueToUser(
                $invoice->user,
                'Invoice #'.$invoice->id.' paid',
                'Payment received',
                [
                    'Invoice #'.$invoice->id.' has been marked as paid.',
                    'Amount received: $'.number_format((float) $invoice->total, 2).'.',
                ],
                'View Invoice',
                url('/client/invoices/'.$invoice->id),
                'invoice_paid',
                [
                    'invoice_id' => $invoice->id,
                    'user_id' => $invoice->user->id,
                ],
            );
        }

        $adminDetail = $invoice->order
            ? 'Order #'.$invoice->order->id
            : 'Invoice #'.$invoice->id;

        $this->emailNotificationService->queueToAdminUsers(
            'Payment received for invoice #'.$invoice->id,
            'Payment received',
            [
                'Invoice #'.$invoice->id.' has been paid.',
                $adminDetail.' is now settled.',
            ],
            'Open Invoice',
            url('/admin/invoices/'.$invoice->id),
            'admin_payment_received',
            [
                'invoice_id' => $invoice->id,
                'order_id' => $invoice->order?->id,
            ],
        );

        return $invoice;
    }
}
