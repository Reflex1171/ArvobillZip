<?php

namespace App\Services\Billing;

use App\Models\Invoice;
use App\Models\Service;
use Illuminate\Support\Facades\DB;

class InvoiceSettlementService
{
    public function markPaid(Invoice $invoice): Invoice
    {
        return DB::transaction(function () use ($invoice) {
            $invoice = Invoice::query()
                ->with('order')
                ->lockForUpdate()
                ->findOrFail($invoice->id);

            if ($invoice->status !== 'paid') {
                $invoice->status = 'paid';
                $invoice->save();
            }

            if ($invoice->order) {
                if ($invoice->order->status !== 'completed') {
                    $invoice->order->status = 'completed';
                    $invoice->order->save();
                }

                Service::query()->firstOrCreate(
                    ['invoice_id' => $invoice->id],
                    [
                        'user_id' => $invoice->user_id,
                        'product_id' => $invoice->order->product_id,
                        'order_id' => $invoice->order->id,
                        'status' => 'pending',
                        'billing_cycle' => 'monthly',
                        'next_due_date' => now()->addMonth()->toDateString(),
                        'pterodactyl_server_id' => null,
                    ],
                );
            }

            return $invoice->fresh();
        });
    }
}
