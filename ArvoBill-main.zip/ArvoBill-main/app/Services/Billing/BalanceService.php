<?php

namespace App\Services\Billing;

use App\Models\AccountTransaction;
use App\Models\Invoice;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class BalanceService
{
    public function credit(
        User $user,
        float $amount,
        string $type,
        ?Invoice $invoice = null,
        ?string $method = null,
        ?string $reference = null,
        ?string $description = null,
        array $meta = [],
    ): void {
        if ($amount <= 0) {
            return;
        }

        $freshUser = User::query()->lockForUpdate()->findOrFail($user->id);
        $freshUser->balance = (float) $freshUser->balance + $amount;
        $freshUser->save();

        AccountTransaction::query()->create([
            'user_id' => $freshUser->id,
            'invoice_id' => $invoice?->id,
            'type' => $type,
            'amount' => $amount,
            'method' => $method,
            'reference' => $reference,
            'description' => $description,
            'meta' => $meta,
        ]);
    }

    public function debit(
        User $user,
        float $amount,
        string $type,
        ?Invoice $invoice = null,
        ?string $method = null,
        ?string $reference = null,
        ?string $description = null,
        array $meta = [],
    ): float {
        if ($amount <= 0) {
            return 0.0;
        }

        $freshUser = User::query()->lockForUpdate()->findOrFail($user->id);
        $debit = min((float) $freshUser->balance, $amount);
        if ($debit <= 0) {
            return 0.0;
        }

        $freshUser->balance = (float) $freshUser->balance - $debit;
        $freshUser->save();

        AccountTransaction::query()->create([
            'user_id' => $freshUser->id,
            'invoice_id' => $invoice?->id,
            'type' => $type,
            'amount' => $debit,
            'method' => $method,
            'reference' => $reference,
            'description' => $description,
            'meta' => $meta,
        ]);

        return $debit;
    }

    public function applyBalanceToInvoice(Invoice $invoice): float
    {
        return DB::transaction(function () use ($invoice): float {
            $freshInvoice = Invoice::query()
                ->with('user')
                ->lockForUpdate()
                ->findOrFail($invoice->id);

            if (! $freshInvoice->user || $freshInvoice->status !== 'unpaid') {
                return 0.0;
            }

            if ($freshInvoice->type === 'credit') {
                return 0.0;
            }

            $outstanding = max((float) $freshInvoice->total, 0);
            if ($outstanding <= 0) {
                return 0.0;
            }

            $debit = $this->debit(
                $freshInvoice->user,
                $outstanding,
                'debit',
                $freshInvoice,
                'balance',
                'invoice:'.$freshInvoice->id,
                'Balance applied to invoice #'.$freshInvoice->id,
            );

            if ($debit <= 0) {
                return 0.0;
            }

            $freshInvoice->balance_applied = (float) $freshInvoice->balance_applied + $debit;
            $freshInvoice->subtotal = max((float) $freshInvoice->subtotal - $debit, 0);
            $freshInvoice->total = max((float) $freshInvoice->total - $debit, 0);

            $freshInvoice->items()->create([
                'description' => 'Account balance applied',
                'amount' => -$debit,
            ]);

            if ((float) $freshInvoice->total <= 0) {
                $freshInvoice->status = 'paid';
            }

            $freshInvoice->save();

            return $debit;
        });
    }
}

