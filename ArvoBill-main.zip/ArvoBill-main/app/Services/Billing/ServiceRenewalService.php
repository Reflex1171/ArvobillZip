<?php

namespace App\Services\Billing;

use App\Models\AccountTransaction;
use App\Models\Invoice;
use App\Models\Payment;
use App\Models\Service;
use App\Support\BillingCycle;
use Illuminate\Support\Facades\DB;

class ServiceRenewalService
{
    public function __construct(
        private readonly BalanceService $balanceService,
        private readonly InvoiceSettlementService $invoiceSettlementService,
    ) {}

    public function processDueServices(): int
    {
        $services = Service::query()
            ->with(['user', 'product', 'defaultPaymentMethod'])
            ->whereIn('status', ['active', 'suspended'])
            ->whereNotNull('next_due_at')
            ->whereDate('next_due_at', '<=', now()->toDateString())
            ->get();

        $processed = 0;
        foreach ($services as $service) {
            $this->processSingleService($service);
            $processed++;
        }

        return $processed;
    }

    public function processSingleService(Service $service): void
    {
        $invoice = $this->getOrCreateRenewalInvoice($service);

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];
        $billingType = BillingCycle::normalizeBillingType((string) ($snapshot['billing_type'] ?? $service->product?->billing_type ?? 'recurring'));

        if (! $service->auto_renew || $billingType !== 'recurring') {
            return;
        }

        $this->balanceService->applyBalanceToInvoice($invoice);
        $invoice->refresh();
        if ($invoice->status === 'paid') {
            $this->invoiceSettlementService->markPaid($invoice);
            return;
        }

        $paymentMethod = $service->defaultPaymentMethod;
        if (! $paymentMethod || ! $paymentMethod->is_active) {
            $this->markRenewalFailure($service, $invoice, 'No default payment method configured.');
            return;
        }

        $this->markRenewalFailure(
            $service,
            $invoice,
            "Auto-charge via {$paymentMethod->provider} is not configured for off-session billing yet.",
            $paymentMethod->provider,
        );
    }

    public function forceRenew(Service $service): Invoice
    {
        $invoice = $this->getOrCreateRenewalInvoice($service);
        $this->processSingleService($service->fresh(['user', 'product', 'defaultPaymentMethod']));

        return $invoice->fresh();
    }

    private function getOrCreateRenewalInvoice(Service $service): Invoice
    {
        $existing = Invoice::query()
            ->where('service_id', $service->id)
            ->where('type', 'renewal')
            ->where('status', 'unpaid')
            ->latest('id')
            ->first();

        if ($existing) {
            return $existing;
        }

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];
        $billingType = BillingCycle::normalizeBillingType((string) ($snapshot['billing_type'] ?? $service->product?->billing_type ?? 'recurring'));
        if ($billingType !== 'recurring') {
            throw new \RuntimeException("Service #{$service->id} is not recurring and cannot be renewed.");
        }

        $amount = (float) ($snapshot['price'] ?? $service->product?->price_monthly ?? 0);
        $interval = BillingCycle::resolveInterval($snapshot['billing_interval'] ?? $service->product?->billing_interval ?? 1);
        $period = BillingCycle::normalizePeriod((string) ($snapshot['billing_period'] ?? $service->product?->billing_period ?? 'month'));
        $intervalSummary = BillingCycle::intervalSummary($interval, $period);
        $dueDate = $service->next_due_at
            ? $service->next_due_at->toDateString()
            : now()->toDateString();

        return DB::transaction(function () use ($service, $amount, $dueDate): Invoice {
            $invoice = Invoice::query()->create([
                'user_id' => $service->user_id,
                'order_id' => null,
                'service_id' => $service->id,
                'type' => 'renewal',
                'subtotal' => $amount,
                'tax' => null,
                'total' => $amount,
                'balance_applied' => 0,
                'status' => 'unpaid',
                'due_date' => $dueDate,
                'meta' => ['auto_generated' => true],
            ]);

            $invoice->items()->create([
                'description' => ($service->product?->name ?? 'Service')." Renewal ({$intervalSummary})",
                'amount' => $amount,
            ]);

            return $invoice;
        });
    }

    private function markRenewalFailure(
        Service $service,
        Invoice $invoice,
        string $reason,
        ?string $provider = null,
    ): void {
        $service->renewal_failure_count = (int) $service->renewal_failure_count + 1;

        $maxFailures = (int) config('billing.renewal_suspend_after_failures', 3);
        if ($service->renewal_failure_count >= $maxFailures) {
            $service->status = 'suspended';
        }
        $service->save();

        Payment::query()->create([
            'invoice_id' => $invoice->id,
            'provider' => $provider ?? 'none',
            'provider_payment_id' => 'renewal-failed-'.$service->id.'-'.now()->timestamp,
            'amount' => $invoice->total,
            'currency' => 'USD',
            'status' => 'failed',
        ]);

        AccountTransaction::query()->create([
            'user_id' => $service->user_id,
            'invoice_id' => $invoice->id,
            'service_id' => $service->id,
            'type' => 'payment_failed',
            'amount' => $invoice->total,
            'method' => $provider,
            'reference' => 'renewal:'.$service->id,
            'description' => $reason,
            'meta' => ['renewal_failure_count' => $service->renewal_failure_count],
        ]);
    }
}
