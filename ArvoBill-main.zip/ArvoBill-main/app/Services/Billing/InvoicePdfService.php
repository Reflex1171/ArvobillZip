<?php

namespace App\Services\Billing;

use App\Models\Invoice;
use App\Services\ThemeSettingService;
use Illuminate\Support\Facades\Date;

class InvoicePdfService
{
    public function __construct(
        private readonly ThemeSettingService $themeSettingService,
    ) {}

    public function filename(Invoice $invoice): string
    {
        return 'invoice-'.$invoice->id.'.pdf';
    }

    public function render(Invoice $invoice): string
    {
        $invoice->loadMissing(['user', 'order.product', 'items']);

        if (class_exists(\Barryvdh\DomPDF\Facade\Pdf::class)) {
            return $this->renderWithDompdf($invoice);
        }

        $content = $this->buildStyledContent($invoice);

        return $this->buildPdfDocument($content);
    }

    private function renderWithDompdf(Invoice $invoice): string
    {
        $theme = $this->themeSettingService->getTheme();
        $brandName = trim((string) ($theme['brand_name'] ?? 'ArvoBill'));
        if ($brandName === '') {
            $brandName = 'ArvoBill';
        }

        $logo = $this->resolveLogoForTemplate($theme['logo_url'] ?? null);

        $subtotal = (float) $invoice->subtotal;
        $discount = (float) ($invoice->discount_amount ?? 0);
        $tax = (float) ($invoice->tax ?? 0);
        $total = (float) $invoice->total;

        $lines = $invoice->items
            ->map(fn ($item) => [
                'description' => (string) $item->description,
                'amount' => (float) $item->amount,
            ])
            ->values()
            ->all();

        $data = [
            'brandName' => $brandName,
            'logoUrl' => $logo,
            'invoiceId' => $invoice->id,
            'status' => strtoupper((string) $invoice->status),
            'issuedAt' => $invoice->created_at?->format('Y-m-d') ?? '-',
            'dueAt' => $invoice->due_date?->format('Y-m-d') ?? '-',
            'clientName' => (string) ($invoice->user?->name ?: 'Client'),
            'clientEmail' => (string) ($invoice->user?->email ?: 'Unknown'),
            'lines' => $lines,
            'subtotal' => $subtotal,
            'discount' => $discount,
            'tax' => $tax,
            'total' => $total,
            'productName' => (string) ($invoice->order?->product?->name ?: 'Service'),
            'generatedAtUtc' => Date::now('UTC')->format('Y-m-d H:i:s'),
        ];

        /** @var \Barryvdh\DomPDF\PDF $pdf */
        $pdf = \Barryvdh\DomPDF\Facade\Pdf::setOption([
            'isRemoteEnabled' => true,
            'isHtml5ParserEnabled' => true,
            'dpi' => 110,
            'defaultFont' => 'DejaVu Sans',
        ])->loadView('pdf.invoice', $data);

        return $pdf->output();
    }

    private function resolveLogoForTemplate(mixed $logoUrl): ?string
    {
        $raw = trim((string) $logoUrl);
        if ($raw === '') {
            return null;
        }

        $path = parse_url($raw, PHP_URL_PATH);
        if (is_string($path)) {
            $publicPath = base_path('public'.$path);
            if (is_file($publicPath) && is_readable($publicPath)) {
                return 'file://'.$publicPath;
            }
        }

        return $raw;
    }

    /**
     * @return list<string>
     */
    private function buildStyledContent(Invoice $invoice): string
    {
        $theme = $this->themeSettingService->getTheme();
        $brandName = trim((string) ($theme['brand_name'] ?? 'ArvoBill'));
        if ($brandName === '') {
            $brandName = 'ArvoBill';
        }

        $commands = [];

        $commands[] = $this->rectFill(0, 730, 612, 62, [0.05, 0.34, 0.65]);
        $commands[] = $this->text(52, 765, 22, 'F2', [1, 1, 1], $brandName.' Invoice');
        $commands[] = $this->text(52, 744, 10, 'F1', [0.85, 0.93, 1], 'Professional Hosting Billing');
        $commands[] = $this->text(420, 748, 11, 'F1', [1, 1, 1], 'Invoice #'.$invoice->id);

        $commands[] = $this->rectStroke(40, 642, 256, 72, [0.82, 0.86, 0.91], 1);
        $commands[] = $this->rectStroke(316, 642, 256, 72, [0.82, 0.86, 0.91], 1);

        $commands[] = $this->text(52, 698, 10, 'F2', [0.19, 0.24, 0.32], 'Billed To');
        $commands[] = $this->text(52, 681, 10, 'F1', [0.25, 0.3, 0.38], (string) ($invoice->user?->name ?: 'Client'));
        $commands[] = $this->text(52, 665, 10, 'F1', [0.25, 0.3, 0.38], (string) ($invoice->user?->email ?: 'Unknown'));

        $commands[] = $this->text(328, 698, 10, 'F2', [0.19, 0.24, 0.32], 'Invoice Details');
        $commands[] = $this->text(328, 681, 10, 'F1', [0.25, 0.3, 0.38], 'Issued: '.($invoice->created_at?->format('Y-m-d') ?? '-'));
        $commands[] = $this->text(328, 665, 10, 'F1', [0.25, 0.3, 0.38], 'Due: '.($invoice->due_date?->format('Y-m-d') ?? '-'));
        $commands[] = $this->text(328, 649, 10, 'F1', [0.25, 0.3, 0.38], 'Status: '.strtoupper((string) $invoice->status));

        $tableTopY = 610;
        $commands[] = $this->rectFill(40, $tableTopY, 532, 24, [0.94, 0.96, 0.98]);
        $commands[] = $this->rectStroke(40, $tableTopY, 532, 24, [0.82, 0.86, 0.91], 1);
        $commands[] = $this->text(52, $tableTopY + 8, 10, 'F2', [0.19, 0.24, 0.32], 'Description');
        $commands[] = $this->text(510, $tableTopY + 8, 10, 'F2', [0.19, 0.24, 0.32], 'Amount');

        $items = $invoice->items->values();
        $maxRows = 15;
        $displayCount = min($items->count(), $maxRows);
        $rowHeight = 24;
        $currentY = $tableTopY - $rowHeight;

        for ($i = 0; $i < $displayCount; $i++) {
            $item = $items[$i];
            if ($i % 2 === 0) {
                $commands[] = $this->rectFill(40, $currentY, 532, $rowHeight, [0.985, 0.99, 1.0]);
            }
            $commands[] = $this->rectStroke(40, $currentY, 532, $rowHeight, [0.88, 0.9, 0.94], 0.5);
            $commands[] = $this->text(52, $currentY + 8, 10, 'F1', [0.2, 0.25, 0.32], $this->truncate($item->description, 72));
            $commands[] = $this->text(500, $currentY + 8, 10, 'F1', [0.2, 0.25, 0.32], '$'.number_format((float) $item->amount, 2));
            $currentY -= $rowHeight;
        }

        if ($items->count() > $maxRows) {
            $commands[] = $this->text(
                52,
                $currentY + 8,
                9,
                'F1',
                [0.45, 0.49, 0.56],
                '...and '.($items->count() - $maxRows).' more line item(s)',
            );
            $currentY -= 16;
        }

        $summaryTop = 120;
        $summaryHeight = 120;
        $commands[] = $this->rectFill(356, $summaryTop, 216, $summaryHeight, [0.97, 0.98, 1.0]);
        $commands[] = $this->rectStroke(356, $summaryTop, 216, $summaryHeight, [0.82, 0.86, 0.91], 1);

        $commands[] = $this->text(368, $summaryTop + 80, 10, 'F1', [0.27, 0.31, 0.38], 'Subtotal');
        $commands[] = $this->text(500, $summaryTop + 80, 10, 'F1', [0.19, 0.24, 0.32], '$'.number_format((float) $invoice->subtotal, 2));
        $commands[] = $this->text(368, $summaryTop + 62, 10, 'F1', [0.27, 0.31, 0.38], 'Discount');
        $commands[] = $this->text(500, $summaryTop + 62, 10, 'F1', [0.19, 0.24, 0.32], '$'.number_format((float) ($invoice->discount_amount ?? 0), 2));
        $commands[] = $this->text(368, $summaryTop + 44, 10, 'F1', [0.27, 0.31, 0.38], 'Tax');
        $commands[] = $this->text(500, $summaryTop + 44, 10, 'F1', [0.19, 0.24, 0.32], '$'.number_format((float) ($invoice->tax ?? 0), 2));
        $commands[] = $this->line(366, $summaryTop + 34, 562, $summaryTop + 34, [0.82, 0.86, 0.91], 1);
        $commands[] = $this->text(368, $summaryTop + 14, 13, 'F2', [0.05, 0.34, 0.65], 'Total');
        $commands[] = $this->text(482, $summaryTop + 14, 15, 'F2', [0.05, 0.34, 0.65], '$'.number_format((float) $invoice->total, 2));

        $productName = $invoice->order?->product?->name ?: 'Service';
        $commands[] = $this->text(40, 92, 9, 'F1', [0.45, 0.49, 0.56], 'Related service: '.$this->truncate($productName, 78));
        $commands[] = $this->text(40, 76, 9, 'F1', [0.45, 0.49, 0.56], 'Generated at '.now()->format('Y-m-d H:i:s').' UTC');
        $commands[] = $this->text(40, 60, 9, 'F1', [0.45, 0.49, 0.56], 'Thank you for choosing '.$brandName.'.');

        return implode("\n", $commands)."\n";
    }

    private function escapePdfText(string $text): string
    {
        return str_replace(
            ['\\', '(', ')'],
            ['\\\\', '\\(', '\\)'],
            preg_replace('/[^\x20-\x7E]/', '', $text) ?? '',
        );
    }

    private function truncate(string $text, int $maxLength): string
    {
        $safe = trim((string) preg_replace('/\s+/', ' ', $text));
        if (strlen($safe) <= $maxLength) {
            return $safe;
        }

        return rtrim(substr($safe, 0, $maxLength - 3)).'...';
    }

    /**
     * @param  array{0: float|int, 1: float|int, 2: float|int}  $rgb
     */
    private function text(float $x, float $y, int $fontSize, string $font, array $rgb, string $text): string
    {
        $escaped = $this->escapePdfText($text);

        return sprintf(
            "BT /%s %d Tf %.3F %.3F %.3F rg 1 0 0 1 %.2F %.2F Tm (%s) Tj ET",
            $font,
            $fontSize,
            $rgb[0],
            $rgb[1],
            $rgb[2],
            $x,
            $y,
            $escaped,
        );
    }

    /**
     * @param  array{0: float|int, 1: float|int, 2: float|int}  $rgb
     */
    private function rectFill(float $x, float $y, float $width, float $height, array $rgb): string
    {
        return sprintf(
            "%.3F %.3F %.3F rg %.2F %.2F %.2F %.2F re f",
            $rgb[0],
            $rgb[1],
            $rgb[2],
            $x,
            $y,
            $width,
            $height,
        );
    }

    /**
     * @param  array{0: float|int, 1: float|int, 2: float|int}  $rgb
     */
    private function rectStroke(float $x, float $y, float $width, float $height, array $rgb, float $lineWidth): string
    {
        return sprintf(
            "%.3F %.3F %.3F RG %.2F w %.2F %.2F %.2F %.2F re S",
            $rgb[0],
            $rgb[1],
            $rgb[2],
            $lineWidth,
            $x,
            $y,
            $width,
            $height,
        );
    }

    /**
     * @param  array{0: float|int, 1: float|int, 2: float|int}  $rgb
     */
    private function line(float $x1, float $y1, float $x2, float $y2, array $rgb, float $lineWidth): string
    {
        return sprintf(
            "%.3F %.3F %.3F RG %.2F w %.2F %.2F m %.2F %.2F l S",
            $rgb[0],
            $rgb[1],
            $rgb[2],
            $lineWidth,
            $x1,
            $y1,
            $x2,
            $y2,
        );
    }

    private function buildPdfDocument(string $stream): string
    {
        $logo = $this->resolveLogoJpeg();
        if ($logo) {
            $stream .= $this->drawLogo($logo['width'], $logo['height']);
        }

        $objects = [];

        $objects[] = "<< /Type /Catalog /Pages 2 0 R >>";
        $objects[] = "<< /Type /Pages /Kids [3 0 R] /Count 1 >>";
        if ($logo) {
            $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> /XObject << /Im1 6 0 R >> >> /Contents 7 0 R >>";
        } else {
            $objects[] = "<< /Type /Page /Parent 2 0 R /MediaBox [0 0 612 792] /Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>";
        }
        $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>";
        $objects[] = "<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>";
        if ($logo) {
            $objects[] = "<< /Type /XObject /Subtype /Image /Width ".$logo['width']." /Height ".$logo['height']." /ColorSpace /DeviceRGB /BitsPerComponent 8 /Filter /DCTDecode /Length ".strlen($logo['data'])." >>\nstream\n".$logo['data']."\nendstream";
        }
        $objects[] = "<< /Length ".strlen($stream)." >>\nstream\n".$stream."endstream";

        $pdf = "%PDF-1.4\n";
        $offsets = [];

        foreach ($objects as $index => $object) {
            $objectNumber = $index + 1;
            $offsets[$objectNumber] = strlen($pdf);
            $pdf .= $objectNumber." 0 obj\n".$object."\nendobj\n";
        }

        $xrefOffset = strlen($pdf);
        $pdf .= "xref\n0 ".(count($objects) + 1)."\n";
        $pdf .= "0000000000 65535 f \n";

        for ($i = 1; $i <= count($objects); $i++) {
            $pdf .= sprintf("%010d 00000 n \n", $offsets[$i]);
        }

        $pdf .= "trailer\n<< /Size ".(count($objects) + 1)." /Root 1 0 R >>\n";
        $pdf .= "startxref\n".$xrefOffset."\n%%EOF";

        return $pdf;
    }

    private function drawLogo(int $imageWidth, int $imageHeight): string
    {
        $targetWidth = 120.0;
        $scale = $targetWidth / max($imageWidth, 1);
        $targetHeight = $imageHeight * $scale;
        $x = 40.0;
        $y = 18.0;

        return sprintf(
            "q %.2F 0 0 %.2F %.2F %.2F cm /Im1 Do Q\n",
            $targetWidth,
            $targetHeight,
            $x,
            $y,
        );
    }

    /**
     * @return array{data: string, width: int, height: int}|null
     */
    private function resolveLogoJpeg(): ?array
    {
        $theme = $this->themeSettingService->getTheme();
        $logoUrl = trim((string) ($theme['logo_url'] ?? ''));
        if ($logoUrl === '') {
            return null;
        }

        $data = $this->loadLogoBinary($logoUrl);
        if (! is_string($data) || $data === '') {
            return null;
        }

        $info = @getimagesizefromstring($data);
        if (! is_array($info)) {
            return null;
        }

        $mime = (string) ($info['mime'] ?? '');
        if ($mime !== 'image/jpeg') {
            $data = $this->convertImageToJpeg($data);
            if (! is_string($data) || $data === '') {
                return null;
            }

            $info = @getimagesizefromstring($data);
            if (! is_array($info) || ($info['mime'] ?? '') !== 'image/jpeg') {
                return null;
            }
        }

        return [
            'data' => $data,
            'width' => (int) ($info[0] ?? 0),
            'height' => (int) ($info[1] ?? 0),
        ];
    }

    private function loadLogoBinary(string $logoUrl): ?string
    {
        $path = parse_url($logoUrl, PHP_URL_PATH);
        if (is_string($path)) {
            $directPublicPath = base_path('public'.$path);
            if (is_file($directPublicPath) && is_readable($directPublicPath)) {
                $data = @file_get_contents($directPublicPath);
                if ($data !== false) {
                    return $data;
                }
            }

            if (str_starts_with($path, '/storage/')) {
                $storagePublicPath = base_path('public'.$path);
                if (is_file($storagePublicPath) && is_readable($storagePublicPath)) {
                    $data = @file_get_contents($storagePublicPath);
                    if ($data !== false) {
                        return $data;
                    }
                }
            }
        }

        // If logo URL points to this same app host, prefer local file read to avoid TLS/network edge cases.
        $logoHost = parse_url($logoUrl, PHP_URL_HOST);
        $appHost = parse_url((string) config('app.url'), PHP_URL_HOST);
        if ($logoHost && $appHost && strcasecmp((string) $logoHost, (string) $appHost) === 0 && is_string($path)) {
            $sameHostPath = base_path('public'.$path);
            if (is_file($sameHostPath) && is_readable($sameHostPath)) {
                $data = @file_get_contents($sameHostPath);
                if ($data !== false) {
                    return $data;
                }
            }
        }

        if (! preg_match('/^https?:\\/\\//i', $logoUrl)) {
            return null;
        }

        $verifyTls = filter_var(
            env('INVOICE_PDF_FETCH_VERIFY_TLS', true),
            FILTER_VALIDATE_BOOL,
            FILTER_NULL_ON_FAILURE
        );

        $context = stream_context_create([
            'http' => ['timeout' => 5],
            'ssl' => [
                'verify_peer' => $verifyTls ?? true,
                'verify_peer_name' => $verifyTls ?? true,
            ],
        ]);

        $data = @file_get_contents($logoUrl, false, $context);
        return $data === false ? null : $data;
    }

    private function convertImageToJpeg(string $binary): ?string
    {
        if (function_exists('imagecreatefromstring') && function_exists('imagejpeg')) {
            $source = @imagecreatefromstring($binary);
            if (! $source) {
                return null;
            }

            $width = imagesx($source);
            $height = imagesy($source);
            if ($width <= 0 || $height <= 0) {
                imagedestroy($source);
                return null;
            }

            $canvas = imagecreatetruecolor($width, $height);
            if (! $canvas) {
                imagedestroy($source);
                return null;
            }

            $white = imagecolorallocate($canvas, 255, 255, 255);
            imagefilledrectangle($canvas, 0, 0, $width, $height, $white);
            imagecopy($canvas, $source, 0, 0, 0, 0, $width, $height);

            ob_start();
            $ok = imagejpeg($canvas, null, 90);
            $jpeg = ob_get_clean();

            imagedestroy($canvas);
            imagedestroy($source);

            if ($ok && is_string($jpeg) && $jpeg !== '') {
                return $jpeg;
            }
        }

        if (class_exists(\Imagick::class)) {
            try {
                $image = new \Imagick();
                $image->readImageBlob($binary);
                $flattened = new \Imagick();
                $flattened->newImage($image->getImageWidth(), $image->getImageHeight(), 'white');
                $flattened->compositeImage($image, \Imagick::COMPOSITE_DEFAULT, 0, 0);
                $flattened->setImageFormat('jpeg');
                $flattened->setImageCompressionQuality(90);
                $jpeg = $flattened->getImageBlob();
                $flattened->clear();
                $flattened->destroy();
                $image->clear();
                $image->destroy();

                if (is_string($jpeg) && $jpeg !== '') {
                    return $jpeg;
                }
            } catch (\Throwable) {
                return null;
            }
        }

        return null;
    }
}
