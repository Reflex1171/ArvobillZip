<?php

namespace App\Services\Billing;

use App\Models\Invoice;
use App\Models\Service;
use App\Services\Email\EmailNotificationService;
use App\Services\Infrastructure\PterodactylService;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\DB;

class OverdueInvoiceService
{
    public function __construct(
        private readonly BalanceService $balanceService,
        private readonly InvoiceSettlementService $invoiceSettlementService,
        private readonly EmailNotificationService $emailNotificationService,
        private readonly PterodactylService $pterodactylService,
    ) {}

    public function processOverdueInvoices(): int
    {
        $invoices = Invoice::query()
            ->with(['user', 'relatedService', 'order.product'])
            ->where('status', 'unpaid')
            ->whereNotNull('due_date')
            ->whereDate('due_date', '<=', now()->toDateString())
            ->orderBy('due_date')
            ->get();

        $processed = 0;

        foreach ($invoices as $invoice) {
            $this->processSingleInvoice($invoice);
            $processed++;
        }

        return $processed;
    }

    public function processSingleInvoice(Invoice $invoice): void
    {
        if ($invoice->status !== 'unpaid' || ! $invoice->due_date) {
            return;
        }

        $this->balanceService->applyBalanceToInvoice($invoice);
        $invoice->refresh();

        if ($invoice->status === 'paid') {
            $this->invoiceSettlementService->markPaid($invoice);
            return;
        }

        $daysOverdue = $this->daysOverdue($invoice->due_date);
        $meta = is_array($invoice->meta) ? $invoice->meta : [];

        $meta['retry_count'] = (int) ($meta['retry_count'] ?? 0) + 1;
        $meta['last_retry_at'] = now()->toISOString();
        $invoice->meta = $meta;
        $invoice->save();

        $this->sendDunningIfNeeded($invoice, $daysOverdue);

        $service = $invoice->relatedService;
        if (! $service) {
            return;
        }

        $this->handleSuspendOrTerminate($service, $invoice, $daysOverdue);
    }

    private function sendDunningIfNeeded(Invoice $invoice, int $daysOverdue): void
    {
        $reminderDays = collect(config('billing.overdue_reminder_days', [0, 3, 7]))
            ->map(fn ($day) => (int) $day)
            ->filter(fn ($day) => $day >= 0)
            ->unique()
            ->values();

        if (! $reminderDays->contains($daysOverdue)) {
            return;
        }

        $meta = is_array($invoice->meta) ? $invoice->meta : [];
        $sent = collect($meta['dunning_sent_days'] ?? [])
            ->map(fn ($value) => (int) $value)
            ->values();

        if ($sent->contains($daysOverdue)) {
            return;
        }

        $meta['dunning_sent_days'] = $sent->push($daysOverdue)->values()->all();
        $invoice->meta = $meta;
        $invoice->save();

        if ($invoice->user) {
            $this->emailNotificationService->queueToUser(
                $invoice->user,
                "Invoice #{$invoice->id} overdue",
                'Payment reminder',
                [
                    "Invoice #{$invoice->id} is {$daysOverdue} day(s) overdue.",
                    'Please make a payment to avoid service suspension.',
                ],
                'Pay Invoice',
                url('/checkout/'.$invoice->id),
                'invoice_overdue',
                ['invoice_id' => $invoice->id, 'days_overdue' => $daysOverdue],
            );
        }
    }

    private function handleSuspendOrTerminate(Service $service, Invoice $invoice, int $daysOverdue): void
    {
        $suspendAfter = (int) config('billing.overdue_suspend_after_days', 3);
        $terminateAfter = (int) config('billing.overdue_terminate_after_days', 14);
        $shouldTerminate = $terminateAfter > 0 && $daysOverdue >= $terminateAfter;
        $shouldSuspend = $suspendAfter > 0 && $daysOverdue >= $suspendAfter;

        if ($shouldTerminate && $service->status !== 'cancelled') {
            $this->terminateService($service, $invoice, $daysOverdue);
            return;
        }

        if ($shouldSuspend && $service->status === 'active') {
            $this->suspendService($service, $invoice, $daysOverdue);
        }
    }

    private function suspendService(Service $service, Invoice $invoice, int $daysOverdue): void
    {
        DB::transaction(function () use ($service, $invoice, $daysOverdue): void {
            $service->status = 'suspended';
            $service->save();

            $meta = is_array($invoice->meta) ? $invoice->meta : [];
            $meta['overdue_action'] = 'suspended';
            $meta['overdue_action_at'] = now()->toISOString();
            $meta['overdue_days'] = $daysOverdue;
            $invoice->meta = $meta;
            $invoice->save();
        });

        if ($service->pterodactyl_server_id) {
            $this->pterodactylService->suspendServer($service->pterodactyl_server_id);
        }

        if ($service->user) {
            $this->emailNotificationService->queueToUser(
                $service->user,
                "Service #{$service->id} suspended",
                'Service suspended for overdue invoice',
                [
                    "Your service has been suspended because invoice #{$invoice->id} is overdue.",
                    "Days overdue: {$daysOverdue}.",
                ],
                'Pay Invoice',
                url('/checkout/'.$invoice->id),
                'service_suspended_overdue',
                ['service_id' => $service->id, 'invoice_id' => $invoice->id],
            );
        }
    }

    private function terminateService(Service $service, Invoice $invoice, int $daysOverdue): void
    {
        DB::transaction(function () use ($service, $invoice, $daysOverdue): void {
            $service->status = 'cancelled';
            $service->save();

            $meta = is_array($invoice->meta) ? $invoice->meta : [];
            $meta['overdue_action'] = 'terminated';
            $meta['overdue_action_at'] = now()->toISOString();
            $meta['overdue_days'] = $daysOverdue;
            $invoice->meta = $meta;
            $invoice->save();
        });

        if ($service->pterodactyl_server_id && config('billing.terminate_delete_pterodactyl', false)) {
            $this->pterodactylService->deleteServer($service->pterodactyl_server_id);
        }

        if ($service->user) {
            $this->emailNotificationService->queueToUser(
                $service->user,
                "Service #{$service->id} terminated",
                'Service terminated for overdue invoice',
                [
                    "Your service has been terminated because invoice #{$invoice->id} is overdue.",
                    "Days overdue: {$daysOverdue}.",
                ],
                'View Invoices',
                url('/client/invoices'),
                'service_terminated_overdue',
                ['service_id' => $service->id, 'invoice_id' => $invoice->id],
            );
        }
    }

    private function daysOverdue(Carbon $dueDate): int
    {
        return max($dueDate->startOfDay()->diffInDays(now()->startOfDay(), false), 0);
    }
}
