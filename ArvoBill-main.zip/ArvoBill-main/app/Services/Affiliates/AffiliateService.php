<?php

namespace App\Services\Affiliates;

use App\Models\AffiliateEarning;
use App\Models\AffiliateReferralVisit;
use App\Models\AffiliateSetting;
use App\Models\Invoice;
use App\Models\User;
use App\Services\Billing\BalanceService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class AffiliateService
{
    public const COOKIE_KEY = 'arvobill_referral_code';
    public const SESSION_KEY = 'affiliate.referral_code';

    public function __construct(private readonly BalanceService $balanceService) {}

    public function getSettings(): AffiliateSetting
    {
        return AffiliateSetting::query()->firstOrCreate([], [
            'enabled' => true,
            'commission_percent' => 10,
            'commission_scope' => 'first_invoice',
            'approval_delay_days' => 30,
            'eligible_product_ids' => null,
        ]);
    }

    public function ensureAffiliateCode(User $user): void
    {
        if ($user->affiliate_code) {
            return;
        }

        $user->affiliate_code = $this->generateUniqueCode();
        $user->save();
    }

    public function registerReferralVisit(User $affiliate, string $code, ?string $ipAddress, ?string $userAgent): void
    {
        AffiliateReferralVisit::query()->create([
            'affiliate_user_id' => $affiliate->id,
            'affiliate_code' => $code,
            'ip_address' => $ipAddress,
            'user_agent' => $userAgent,
        ]);
    }

    public function attachReferralToUser(User $user, ?string $referralCode): void
    {
        if ($user->referred_by || ! $referralCode) {
            $this->ensureAffiliateCode($user);
            return;
        }

        $affiliate = User::query()->where('affiliate_code', $referralCode)->first();
        if (! $affiliate || $affiliate->id === $user->id) {
            $this->ensureAffiliateCode($user);
            return;
        }

        $user->referred_by = $affiliate->id;
        $this->ensureAffiliateCode($user);
        $user->save();

        AffiliateReferralVisit::query()
            ->where('affiliate_code', $referralCode)
            ->whereNull('referred_user_id')
            ->latest('id')
            ->limit(1)
            ->update([
                'referred_user_id' => $user->id,
                'converted_at' => now(),
            ]);
    }

    public function handleInvoicePaid(Invoice $invoice): void
    {
        $invoice->loadMissing('user', 'order.product', 'promoCode');
        $user = $invoice->user;
        if (! $user || ! $user->referred_by) {
            return;
        }

        if ($invoice->status !== 'paid') {
            return;
        }

        $settings = $this->getSettings();
        if (! $settings->enabled) {
            return;
        }

        $affiliate = User::query()->find($user->referred_by);
        if (! $affiliate || $affiliate->id === $user->id) {
            return;
        }

        if (! $this->isEligibleByProduct($settings, $invoice)) {
            return;
        }

        if (! $this->isEligibleByScope($settings, $user, $invoice)) {
            return;
        }

        $promoCode = $invoice->promoCode;
        if ($promoCode && (bool) $promoCode->disables_affiliate) {
            return;
        }

        $amount = round(((float) $invoice->total) * (((float) $settings->commission_percent) / 100), 2);
        if ($amount <= 0) {
            return;
        }

        $eligibleAt = now()->addDays((int) $settings->approval_delay_days);

        AffiliateEarning::query()->updateOrCreate(
            [
                'affiliate_user_id' => $affiliate->id,
                'invoice_id' => $invoice->id,
            ],
            [
                'referred_user_id' => $user->id,
                'amount' => $amount,
                'status' => 'pending',
                'eligible_at' => $eligibleAt,
                'meta' => [
                    'commission_percent' => (float) $settings->commission_percent,
                    'scope' => $settings->commission_scope,
                    'invoice_total' => (float) $invoice->total,
                    'invoice_discount_amount' => (float) ($invoice->discount_amount ?? 0),
                    'promo_code' => $invoice->promo_code_code,
                    'promo_disables_affiliate' => (bool) ($promoCode?->disables_affiliate ?? false),
                ],
            ],
        );
    }

    public function approveEligiblePendingEarnings(): int
    {
        $count = 0;

        AffiliateEarning::query()
            ->where('status', 'pending')
            ->whereNotNull('eligible_at')
            ->where('eligible_at', '<=', now())
            ->chunkById(100, function ($earnings) use (&$count): void {
                foreach ($earnings as $earning) {
                    DB::transaction(function () use ($earning): void {
                        $fresh = AffiliateEarning::query()->lockForUpdate()->find($earning->id);
                        if (! $fresh || $fresh->status !== 'pending') {
                            return;
                        }

                        $fresh->status = 'approved';
                        $fresh->approved_at = now();
                        $fresh->save();

                        $user = User::query()->find($fresh->affiliate_user_id);
                        if ($user) {
                            $this->balanceService->credit(
                                $user,
                                (float) $fresh->amount,
                                'credit',
                                null,
                                'affiliate',
                                'affiliate-earning:'.$fresh->id,
                                'Affiliate commission approved',
                            );
                            $user->affiliate_balance = (float) $user->affiliate_balance + (float) $fresh->amount;
                            $user->save();
                        }
                    });

                    $count++;
                }
            });

        return $count;
    }

    private function isEligibleByProduct(AffiliateSetting $setting, Invoice $invoice): bool
    {
        $eligibleProducts = collect($setting->eligible_product_ids ?? [])->map(fn ($id) => (int) $id)->filter()->values();
        if ($eligibleProducts->isEmpty()) {
            return true;
        }

        $productId = (int) ($invoice->order?->product_id ?? 0);

        return $productId > 0 && $eligibleProducts->contains($productId);
    }

    private function isEligibleByScope(AffiliateSetting $setting, User $referredUser, Invoice $invoice): bool
    {
        if ($setting->commission_scope === 'recurring') {
            return true;
        }

        $earliestInvoiceId = Invoice::query()
            ->where('user_id', $referredUser->id)
            ->where('status', 'paid')
            ->min('id');

        return (int) $earliestInvoiceId === (int) $invoice->id;
    }

    private function generateUniqueCode(): string
    {
        do {
            $code = Str::upper(Str::random(10));
        } while (User::query()->where('affiliate_code', $code)->exists());

        return $code;
    }
}
