<?php

namespace App\Services\Infrastructure;

use App\Jobs\ProvisionPterodactylService;
use App\Models\Invoice;
use App\Models\Order;
use App\Models\Service;
use Illuminate\Support\Facades\Log;
use RuntimeException;

class ServiceProvisioner
{
    public const REQUIRED_PTERODACTYL_KEYS = ['ram', 'disk', 'cpu', 'egg'];

    /**
     * @return array{memory:int,cpu:int,disk:int,swap:int,io:int,backups:int,databases:int}
     */
    public function resolvePterodactylLimits(Service $service): array
    {
        $snapshot = $this->resolveConfigurationSnapshot($service);

        $limits = [
            'memory' => $this->readRequiredStrictInt($snapshot, 'ram'),
            'cpu' => $this->readRequiredStrictInt($snapshot, 'cpu'),
            'disk' => $this->readRequiredStrictInt($snapshot, 'disk'),
            'swap' => $this->readOptionalStrictInt($snapshot, 'swap', 0),
            'io' => $this->readOptionalStrictInt($snapshot, 'io', 500),
            'backups' => $this->readOptionalStrictInt($snapshot, 'backups', 2),
            'databases' => $this->readOptionalStrictInt($snapshot, 'databases', 0),
        ];

        $this->assertSaneLimits($limits);

        return $limits;
    }

    public function resolvePterodactylEggId(Service $service): int
    {
        $snapshot = $this->resolveConfigurationSnapshot($service);

        return $this->readRequiredStrictInt($snapshot, 'egg');
    }

    /**
     * @return array<string, mixed>
     */
    public function resolveConfigurationSnapshot(Service $service): array
    {
        if (is_array($service->provisioning_snapshot)) {
            return $service->provisioning_snapshot;
        }

        $order = $service->relationLoaded('order')
            ? $service->order
            : $service->order()->with('configurations')->first();

        if (! $order) {
            return [];
        }

        return $this->snapshotFromOrder($order);
    }

    /**
     * @return array<string, mixed>
     */
    public function snapshotFromOrder(Order $order): array
    {
        $configurations = $order->relationLoaded('configurations')
            ? $order->configurations
            : $order->configurations()->get();

        $snapshot = [];
        foreach ($configurations as $configuration) {
            $snapshot[strtolower((string) $configuration->configuration_key)] = [
                'selected_value' => (string) $configuration->selected_value,
                'price_modifier' => (float) $configuration->price_modifier,
            ];
        }

        return $snapshot;
    }

    public function handleInvoicePaid(Invoice $invoice): void
    {
        $service = Service::query()
            ->with(['product'])
            ->where('invoice_id', $invoice->id)
            ->first();

        if (! $service || ! $service->product) {
            return;
        }

        if ($service->product->infrastructure_type !== 'pterodactyl') {
            if ($service->status !== 'active') {
                $service->status = 'active';
                $service->provisioning_error = null;
                $service->save();
            }
            return;
        }

        if (! $service->product->auto_provision) {
            if ($service->status === 'pending') {
                $service->provisioning_error = 'Auto-provisioning is disabled for this product.';
                $service->save();
            }
            return;
        }

        $this->dispatchProvisioning($service);
    }

    public function dispatchProvisioning(Service $service): bool
    {
        if ($service->pterodactyl_server_id) {
            return false;
        }

        if (in_array($service->status, ['provisioning', 'active'], true)) {
            return false;
        }

        $service->status = 'provisioning';
        $service->provisioning_error = null;
        $service->save();

        ProvisionPterodactylService::dispatch($service->id)->afterCommit();

        return true;
    }

    /**
     * @param  array<string, mixed>  $limits
     */
    public function assertNodeCapacity(array $node, array $limits): void
    {
        $nodeMemory = (int) ($node['memory'] ?? 0);
        $nodeDisk = (int) ($node['disk'] ?? 0);

        $allocated = is_array($node['allocated_resources'] ?? null)
            ? $node['allocated_resources']
            : [];

        $allocatedMemory = (int) ($allocated['memory'] ?? 0);
        $allocatedDisk = (int) ($allocated['disk'] ?? 0);

        if ($nodeMemory > 0) {
            $availableMemory = max($nodeMemory - $allocatedMemory, 0);
            if ($limits['memory'] > $availableMemory) {
                throw new RuntimeException(
                    "Node does not have enough available RAM. Requested {$limits['memory']}MB, available {$availableMemory}MB.",
                );
            }
        }

        if ($nodeDisk > 0) {
            $availableDisk = max($nodeDisk - $allocatedDisk, 0);
            if ($limits['disk'] > $availableDisk) {
                throw new RuntimeException(
                    "Node does not have enough available disk. Requested {$limits['disk']}MB, available {$availableDisk}MB.",
                );
            }
        }
    }

    /**
     * @param  array<string, int>  $limits
     */
    public function assertSaneLimits(array $limits): void
    {
        if ($limits['memory'] < 256 || $limits['memory'] > 1048576) {
            throw new RuntimeException('RAM limit must be between 256MB and 1048576MB.');
        }
        if ($limits['cpu'] < 10 || $limits['cpu'] > 1000) {
            throw new RuntimeException('CPU limit must be between 10 and 1000.');
        }
        if ($limits['disk'] < 1024 || $limits['disk'] > 10485760) {
            throw new RuntimeException('Disk limit must be between 1024MB and 10485760MB.');
        }
        if ($limits['swap'] < 0 || $limits['swap'] > 1048576) {
            throw new RuntimeException('Swap limit must be between 0 and 1048576MB.');
        }
        if ($limits['io'] < 10 || $limits['io'] > 1000) {
            throw new RuntimeException('IO limit must be between 10 and 1000.');
        }
        if ($limits['backups'] < 0 || $limits['backups'] > 25) {
            throw new RuntimeException('Backups limit must be between 0 and 25.');
        }
        if ($limits['databases'] < 0 || $limits['databases'] > 25) {
            throw new RuntimeException('Databases limit must be between 0 and 25.');
        }
    }

    private function readRequiredStrictInt(array $snapshot, string $key): int
    {
        $entry = $snapshot[strtolower($key)] ?? null;
        $value = is_array($entry) ? ($entry['selected_value'] ?? null) : null;
        if (! is_scalar($value) || ! preg_match('/^\d+$/', trim((string) $value))) {
            throw new RuntimeException("Missing or invalid required '{$key}' configuration value.");
        }

        $intValue = (int) $value;
        if ($intValue <= 0) {
            throw new RuntimeException("Required '{$key}' configuration must be greater than zero.");
        }

        return $intValue;
    }

    private function readOptionalStrictInt(array $snapshot, string $key, int $default): int
    {
        $entry = $snapshot[strtolower($key)] ?? null;
        $value = is_array($entry) ? ($entry['selected_value'] ?? null) : null;
        if ($value === null || $value === '') {
            return $default;
        }

        if (! is_scalar($value) || ! preg_match('/^\d+$/', trim((string) $value))) {
            throw new RuntimeException("Invalid '{$key}' configuration value.");
        }

        return (int) $value;
    }

    public function markProvisioningFailed(Service $service, string $message): void
    {
        Log::error('Service provisioning failed', [
            'service_id' => $service->id,
            'invoice_id' => $service->invoice_id,
            'message' => $message,
        ]);

        $service->status = 'failed';
        $service->provisioning_error = $message;
        $service->save();
    }
}
