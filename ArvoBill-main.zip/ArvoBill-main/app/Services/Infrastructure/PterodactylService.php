<?php

namespace App\Services\Infrastructure;

use App\Models\PterodactylSetting;
use App\Models\User;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use RuntimeException;

class PterodactylService
{
    /**
     * @return array{base_url: string, api_key: string}
     */
    private function credentials(): array
    {
        $setting = PterodactylSetting::query()->first();

        if (! $setting || ! $setting->enabled) {
            throw new RuntimeException('Pterodactyl integration is disabled.');
        }

        $baseUrl = rtrim((string) $setting->panel_url, '/');
        $apiKey = trim((string) $setting->api_key);

        if ($baseUrl === '' || $apiKey === '') {
            throw new RuntimeException('Pterodactyl credentials are incomplete.');
        }

        return [
            'base_url' => $baseUrl,
            'api_key' => $apiKey,
        ];
    }

    /**
     * @param  array<string, mixed>  $query
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    private function request(
        string $method,
        string $path,
        array $query = [],
        array $payload = [],
    ): array {
        $credentials = $this->credentials();
        $url = $credentials['base_url'].'/api/application'.($path[0] === '/' ? $path : '/'.$path);

        $request = Http::withHeaders([
            'Authorization' => 'Bearer '.$credentials['api_key'],
            'Accept' => 'Application/vnd.pterodactyl.v1+json',
            'Content-Type' => 'application/json',
        ]);

        /** @var Response $response */
        $response = match (strtoupper($method)) {
            'GET' => $request->get($url, $query),
            'POST' => $request->post($url, $payload),
            'DELETE' => $request->delete($url, $payload),
            default => throw new RuntimeException('Unsupported method: '.$method),
        };

        if (! $response->successful()) {
            $message = $response->json('errors.0.detail')
                ?? $response->json('message')
                ?? 'Pterodactyl API request failed.';
            throw new RuntimeException((string) $message);
        }

        /** @var array<string, mixed> $json */
        $json = $response->json();

        return $json;
    }

    public function testConnection(): bool
    {
        $this->request('GET', '/nodes', ['per_page' => 1]);

        return true;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchNodes(): array
    {
        $response = $this->request('GET', '/nodes', ['per_page' => 100]);

        return collect($response['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->values()
            ->all();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchEggs(): array
    {
        $nestsResponse = $this->request('GET', '/nests', ['per_page' => 100]);

        $nests = collect($nestsResponse['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->values();

        /** @var Collection<int, array<string,mixed>> $eggs */
        $eggs = $nests->flatMap(function (array $nest): array {
            $nestId = (int) ($nest['id'] ?? 0);
            if ($nestId <= 0) {
                return [];
            }

            $eggResponse = $this->request(
                'GET',
                "/nests/{$nestId}/eggs",
                ['include' => 'nest,variables', 'per_page' => 100],
            );

            return collect($eggResponse['data'] ?? [])
                ->map(function (array $egg) use ($nest): array {
                    $attributes = $egg['attributes'] ?? [];
                    $attributes['nest_name'] = $nest['name'] ?? null;
                    return $attributes;
                })
                ->values()
                ->all();
        });

        return $eggs->values()->all();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchAllocations(?int $nodeId = null): array
    {
        $nodeIds = $nodeId ? [$nodeId] : collect($this->fetchNodes())
            ->map(fn (array $node) => (int) ($node['id'] ?? 0))
            ->filter(fn (int $id) => $id > 0)
            ->values()
            ->all();

        $allocations = collect();

        foreach ($nodeIds as $id) {
            $response = $this->request(
                'GET',
                "/nodes/{$id}/allocations",
                ['per_page' => 200],
            );

            $forNode = collect($response['data'] ?? [])
                ->map(function (array $allocation) use ($id): array {
                    $attributes = $allocation['attributes'] ?? [];
                    $attributes['node_id'] = $id;
                    return $attributes;
                })
                ->values();

            $allocations = $allocations->merge($forNode);
        }

        return $allocations->values()->all();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchServers(): array
    {
        $response = $this->request(
            'GET',
            '/servers',
            ['include' => 'node,allocation,nest,egg', 'per_page' => 100],
        );

        return collect($response['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->values()
            ->all();
    }

    /**
     * @return array<string, mixed>
     */
    public function fetchServer(int|string $serverId): array
    {
        $response = $this->request(
            'GET',
            "/servers/{$serverId}",
            ['include' => 'node,allocation,nest,egg'],
        );

        return $response['attributes'] ?? [];
    }

    public function resolvePanelUserId(User $user): int
    {
        $response = $this->request('GET', '/users', [
            'filter[email]' => $user->email,
            'per_page' => 1,
        ]);

        $found = collect($response['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->first();

        $id = (int) ($found['id'] ?? 0);
        if ($id <= 0) {
            throw new RuntimeException("No Pterodactyl user found for email {$user->email}.");
        }

        return $id;
    }

    /**
     * @return array<string, mixed>
     */
    public function fetchEggDetails(int $nestId, int $eggId): array
    {
        $response = $this->request(
            'GET',
            "/nests/{$nestId}/eggs/{$eggId}",
            ['include' => 'variables,nest'],
        );

        return $response['attributes'] ?? [];
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    public function createServer(array $payload): array
    {
        $response = $this->request('POST', '/servers', [], $payload);

        return $response['attributes'] ?? [];
    }

    public function suspendServer(int|string $serverId): void
    {
        $this->request('POST', "/servers/{$serverId}/suspend");
    }

    public function unsuspendServer(int|string $serverId): void
    {
        $this->request('POST', "/servers/{$serverId}/unsuspend");
    }

    public function deleteServer(int|string $serverId): void
    {
        $this->request('DELETE', "/servers/{$serverId}/force");
    }

    public function panelUrl(): ?string
    {
        $setting = PterodactylSetting::query()->first();

        return $setting?->panel_url ? rtrim((string) $setting->panel_url, '/') : null;
    }
}
