<?php

namespace App\Services\Infrastructure;

use App\Models\PterodactylSetting;
use App\Models\User;
use Illuminate\Http\Client\Response;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;
use RuntimeException;

class PterodactylService
{
    private function shouldVerifyTls(): bool
    {
        $raw = env('PTERODACTYL_VERIFY_TLS');
        if ($raw === null || $raw === '') {
            return true;
        }

        $parsed = filter_var($raw, FILTER_VALIDATE_BOOL, FILTER_NULL_ON_FAILURE);

        return $parsed ?? true;
    }

    /**
     * @return array{base_url: string, api_key: string}
     */
    private function credentials(): array
    {
        $setting = PterodactylSetting::query()->first();

        if (! $setting || ! $setting->enabled) {
            throw new RuntimeException('Pterodactyl integration is disabled.');
        }

        $baseUrl = rtrim((string) $setting->panel_url, '/');
        $apiKey = trim((string) $setting->api_key);

        if ($baseUrl === '' || $apiKey === '') {
            throw new RuntimeException('Pterodactyl credentials are incomplete.');
        }

        return [
            'base_url' => $baseUrl,
            'api_key' => $apiKey,
        ];
    }

    /**
     * @param  array<string, mixed>  $query
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    private function request(
        string $method,
        string $path,
        array $query = [],
        array $payload = [],
    ): array {
        $credentials = $this->credentials();
        $url = $credentials['base_url'].'/api/application'.($path[0] === '/' ? $path : '/'.$path);

        $request = Http::withHeaders([
            'Authorization' => 'Bearer '.$credentials['api_key'],
            'Accept' => 'Application/vnd.pterodactyl.v1+json',
            'Content-Type' => 'application/json',
        ]);

        if (! $this->shouldVerifyTls()) {
            $request = $request->withoutVerifying();
        }

        /** @var Response $response */
        $response = match (strtoupper($method)) {
            'GET' => $request->get($url, $query),
            'POST' => $request->post($url, $payload),
            'DELETE' => $request->delete($url, $payload),
            default => throw new RuntimeException('Unsupported method: '.$method),
        };

        if (! $response->successful()) {
            $message = $response->json('errors.0.detail')
                ?? $response->json('message')
                ?? 'Pterodactyl API request failed.';
            throw new RuntimeException((string) $message);
        }

        /** @var mixed $json */
        $json = $response->json();

        if (is_array($json)) {
            return $json;
        }

        // Some successful endpoints (e.g. DELETE /force) return 204 with no body.
        return [];
    }

    public function testConnection(): bool
    {
        $this->request('GET', '/nodes', ['per_page' => 1]);

        return true;
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchNodes(): array
    {
        $response = $this->request('GET', '/nodes', ['per_page' => 100]);

        return collect($response['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->values()
            ->all();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchEggs(): array
    {
        $nestsResponse = $this->request('GET', '/nests', ['per_page' => 100]);

        $nests = collect($nestsResponse['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->values();

        /** @var Collection<int, array<string,mixed>> $eggs */
        $eggs = $nests->flatMap(function (array $nest): array {
            $nestId = (int) ($nest['id'] ?? 0);
            if ($nestId <= 0) {
                return [];
            }

            $eggResponse = $this->request(
                'GET',
                "/nests/{$nestId}/eggs",
                ['include' => 'nest,variables', 'per_page' => 100],
            );

            return collect($eggResponse['data'] ?? [])
                ->map(function (array $egg) use ($nest): array {
                    $attributes = $egg['attributes'] ?? [];
                    $attributes['nest_name'] = $nest['name'] ?? null;
                    return $attributes;
                })
                ->values()
                ->all();
        });

        return $eggs->values()->all();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchAllocations(?int $nodeId = null): array
    {
        $nodeIds = $nodeId ? [$nodeId] : collect($this->fetchNodes())
            ->map(fn (array $node) => (int) ($node['id'] ?? 0))
            ->filter(fn (int $id) => $id > 0)
            ->values()
            ->all();

        $allocations = collect();

        foreach ($nodeIds as $id) {
            $response = $this->request(
                'GET',
                "/nodes/{$id}/allocations",
                ['per_page' => 200],
            );

            $forNode = collect($response['data'] ?? [])
                ->map(function (array $allocation) use ($id): array {
                    $attributes = $allocation['attributes'] ?? [];
                    $attributes['node_id'] = $id;
                    return $attributes;
                })
                ->values();

            $allocations = $allocations->merge($forNode);
        }

        return $allocations->values()->all();
    }

    /**
     * @return list<array<string, mixed>>
     */
    public function fetchServers(): array
    {
        $response = $this->request(
            'GET',
            '/servers',
            ['include' => 'node,allocation,nest,egg', 'per_page' => 100],
        );

        return collect($response['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->values()
            ->all();
    }

    /**
     * @return array<string, mixed>
     */
    public function fetchServer(int|string $serverId): array
    {
        $response = $this->request(
            'GET',
            "/servers/{$serverId}",
            ['include' => 'node,allocation,nest,egg'],
        );

        return $response['attributes'] ?? [];
    }

    public function resolvePanelUserId(User $user): int
    {
        $response = $this->request('GET', '/users', [
            'filter[email]' => $user->email,
            'per_page' => 1,
        ]);

        $found = collect($response['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->first();

        $id = (int) ($found['id'] ?? 0);
        if ($id <= 0) {
            throw new RuntimeException("No Pterodactyl user found for email {$user->email}.");
        }

        return $id;
    }

    public function getOrCreateUser(User $user): int
    {
        if ((int) $user->pterodactyl_user_id > 0) {
            return (int) $user->pterodactyl_user_id;
        }

        $existingId = $this->resolvePanelUserIdFromEmail($user->email);
        if ($existingId > 0) {
            $user->forceFill([
                'pterodactyl_user_id' => $existingId,
            ])->save();

            return $existingId;
        }

        $createdId = $this->createPanelUser($user);
        if ($createdId <= 0) {
            throw new RuntimeException('Failed to create Pterodactyl user.');
        }

        $user->forceFill([
            'pterodactyl_user_id' => $createdId,
        ])->save();

        return $createdId;
    }

    private function resolvePanelUserIdFromEmail(string $email): int
    {
        $response = $this->request('GET', '/users', [
            'filter[email]' => $email,
            'per_page' => 1,
        ]);

        $found = collect($response['data'] ?? [])
            ->map(fn (array $item) => $item['attributes'] ?? [])
            ->first();

        return (int) ($found['id'] ?? 0);
    }

    private function createPanelUser(User $user): int
    {
        [$firstName, $lastName] = $this->splitName((string) $user->name);
        $username = $this->buildUsername($user);
        $payload = [
            'email' => $user->email,
            'username' => $username,
            'first_name' => $firstName,
            'last_name' => $lastName,
            'language' => 'en',
        ];

        try {
            $response = $this->request('POST', '/users', [], $payload);
        } catch (\Throwable $exception) {
            // Fallback for panels that require a password on create.
            $payload['password'] = Str::random(40);
            $response = $this->request('POST', '/users', [], $payload);
        }

        $id = (int) ($response['attributes']['id'] ?? 0);
        if ($id > 0) {
            return $id;
        }

        return (int) ($response['data']['attributes']['id'] ?? 0);
    }

    /**
     * @return array{0: string, 1: string}
     */
    private function splitName(string $fullName): array
    {
        $trimmed = trim($fullName);
        if ($trimmed === '') {
            return ['ArvoBill', 'User'];
        }

        $parts = preg_split('/\s+/', $trimmed) ?: [];
        if (count($parts) === 1) {
            return [$parts[0], 'User'];
        }

        $firstName = (string) array_shift($parts);
        $lastName = (string) implode(' ', $parts);

        return [$firstName !== '' ? $firstName : 'ArvoBill', $lastName !== '' ? $lastName : 'User'];
    }

    private function buildUsername(User $user): string
    {
        $base = Str::of((string) $user->email)
            ->before('@')
            ->ascii()
            ->lower()
            ->replaceMatches('/[^a-z0-9._-]/', '')
            ->trim('.-_')
            ->value();

        if ($base === '') {
            $base = 'user'.$user->id;
        }

        $base = Str::limit($base, 20, '');
        $suffix = Str::lower(Str::random(6));

        return "{$base}_{$suffix}";
    }

    /**
     * @return array<string, mixed>
     */
    public function fetchEggDetails(int $nestId, int $eggId): array
    {
        $response = $this->request(
            'GET',
            "/nests/{$nestId}/eggs/{$eggId}",
            ['include' => 'variables,nest'],
        );

        return $response['attributes'] ?? [];
    }

    /**
     * @param  array<string, mixed>  $payload
     * @return array<string, mixed>
     */
    public function createServer(array $payload): array
    {
        $response = $this->request('POST', '/servers', [], $payload);

        return $response['attributes'] ?? [];
    }

    public function suspendServer(int|string $serverId): void
    {
        $this->request('POST', "/servers/{$serverId}/suspend");
    }

    public function unsuspendServer(int|string $serverId): void
    {
        $this->request('POST', "/servers/{$serverId}/unsuspend");
    }

    public function deleteServer(int|string $serverId): void
    {
        $this->request('DELETE', "/servers/{$serverId}/force");
    }

    public function panelUrl(): ?string
    {
        $setting = PterodactylSetting::query()->first();

        return $setting?->panel_url ? rtrim((string) $setting->panel_url, '/') : null;
    }
}
