<?php

namespace App\Services\Email;

use App\Models\EmailSetting;
use Illuminate\Support\Facades\Cache;

class EmailSettingsService
{
    private const CACHE_KEY = 'email:settings';

    public function get(): EmailSetting
    {
        return Cache::rememberForever(self::CACHE_KEY, function (): EmailSetting {
            $settings = EmailSetting::query()->first();
            if ($settings) {
                return $settings;
            }

            return EmailSetting::query()->create([
                'host' => null,
                'port' => 587,
                'username' => null,
                'password' => null,
                'encryption' => 'tls',
                'from_address' => null,
                'from_name' => null,
                'enabled' => false,
            ]);
        });
    }

    public function clearCache(): void
    {
        Cache::forget(self::CACHE_KEY);
    }

    public function isUsable(EmailSetting $setting): bool
    {
        if (! $setting->enabled) {
            return false;
        }

        return $this->hasValue($setting->host)
            && (int) $setting->port > 0
            && $this->hasValue($setting->from_address);
    }

    private function hasValue(mixed $value): bool
    {
        return is_string($value) && trim($value) !== '';
    }
}