<?php

namespace App\Services;

use App\Models\ThemeSetting;
use Illuminate\Support\Facades\Cache;

class ThemeSettingService
{
    private const CACHE_KEY = 'theme_settings.active';

    public function getTheme(): array
    {
        return Cache::rememberForever(self::CACHE_KEY, function () {
            $setting = ThemeSetting::query()->first();

            if (! $setting) {
                return ThemeSetting::DEFAULTS;
            }

            return [
                'primary_color' => $setting->primary_color,
                'secondary_color' => $setting->secondary_color,
                'accent_color' => $setting->accent_color,
                'background_color' => $setting->background_color,
                'surface_color' => $setting->surface_color,
                'text_color' => $setting->text_color,
            ];
        });
    }

    /**
     * @param  array<string, string>  $data
     */
    public function updateTheme(array $data): array
    {
        $setting = ThemeSetting::query()->first();

        if (! $setting) {
            $setting = new ThemeSetting();
        }

        $setting->fill($data);
        $setting->save();

        Cache::forget(self::CACHE_KEY);

        return $this->getTheme();
    }
}
