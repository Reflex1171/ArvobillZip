<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ThemeSetting extends Model
{
    public const DEFAULTS = [
        'primary_color' => '#009ddc',
        'secondary_color' => '#25792f',
        'accent_color' => '#118bbb',
        'background_color' => '#2a2d34',
        'surface_color' => '#373b45',
        'text_color' => '#e5e7eb',
    ];

    public const CREATED_AT = null;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'primary_color',
        'secondary_color',
        'accent_color',
        'background_color',
        'surface_color',
        'text_color',
    ];
}
