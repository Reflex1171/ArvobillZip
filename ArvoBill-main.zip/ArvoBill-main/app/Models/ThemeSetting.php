<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ThemeSetting extends Model
{
    public const DEFAULTS = [
        'brand_name' => 'ArvoBill',
        'site_title' => 'ArvoBill',
        'logo_url' => null,
        'favicon_url' => null,
        'primary_color' => '#009ddc',
        'secondary_color' => '#25792f',
        'accent_color' => '#118bbb',
        'background_color' => '#2a2d34',
        'surface_color' => '#373b45',
        'text_color' => '#e5e7eb',
        'warm_white_color' => '#fdfcf9',
        'warm_muted_color' => '#8c8c8c',
        'sidebar_color' => '#1a1c23',
        'card_color' => '#24262d',
        'input_color' => '#2d2f36',
    ];

    public const CREATED_AT = null;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'primary_color',
        'secondary_color',
        'accent_color',
        'background_color',
        'surface_color',
        'text_color',
        'brand_name',
        'logo_path',
        'site_title',
        'favicon_url',
        'warm_white_color',
        'warm_muted_color',
        'sidebar_color',
        'card_color',
        'input_color',
    ];
}
