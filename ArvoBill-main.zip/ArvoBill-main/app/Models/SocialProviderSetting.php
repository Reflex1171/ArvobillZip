<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SocialProviderSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'provider',
        'enabled',
        'client_id',
        'client_secret',
        'redirect_uri',
        'team_id',
        'key_id',
        'private_key',
    ];

    protected function casts(): array
    {
        return [
            'enabled' => 'boolean',
            'client_secret' => 'encrypted',
            'private_key' => 'encrypted',
        ];
    }
}
