<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class AffiliateSetting extends Model
{
    use HasFactory;

    protected $fillable = [
        'enabled',
        'commission_percent',
        'first_invoice_commission_percent',
        'recurring_commission_percent',
        'commission_scope',
        'approval_delay_days',
        'eligible_product_ids',
    ];

    protected function casts(): array
    {
        return [
            'enabled' => 'boolean',
            'commission_percent' => 'decimal:2',
            'first_invoice_commission_percent' => 'decimal:2',
            'recurring_commission_percent' => 'decimal:2',
            'approval_delay_days' => 'integer',
            'eligible_product_ids' => 'array',
        ];
    }
}
