<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class PaymentProviderSetting extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'provider',
        'mode',
        'public_key',
        'secret_key',
        'webhook_secret',
        'enabled',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'enabled' => 'boolean',
            'secret_key' => 'encrypted',
            'webhook_secret' => 'encrypted',
        ];
    }
}
