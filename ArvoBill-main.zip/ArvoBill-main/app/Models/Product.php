<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Product extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'slug',
        'description',
        'category',
        'category_id',
        'price_monthly',
        'setup_fee',
        'billing_type',
        'billing_interval',
        'billing_period',
        'billing_cycle',
        'allow_auto_renew',
        'trial_enabled',
        'trial_interval',
        'trial_period',
        'infrastructure_type',
        'pterodactyl_egg_id',
        'pterodactyl_location_id',
        'pterodactyl_default_node_id',
        'auto_provision',
        'is_active',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'price_monthly' => 'decimal:2',
            'setup_fee' => 'decimal:2',
            'billing_interval' => 'integer',
            'allow_auto_renew' => 'boolean',
            'trial_enabled' => 'boolean',
            'trial_interval' => 'integer',
            'auto_provision' => 'boolean',
            'is_active' => 'boolean',
        ];
    }

    /**
     * Get the category for this product.
     */
    public function category(): BelongsTo
    {
        return $this->belongsTo(ProductCategory::class, 'category_id');
    }

    /**
     * Get the orders for this product.
     */
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    /**
     * Get the services for this product.
     */
    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    /**
     * Get the configurable fields for this product.
     */
    public function configurations(): HasMany
    {
        return $this->hasMany(ProductConfiguration::class)
            ->orderBy('sort_order')
            ->orderBy('id');
    }
}
