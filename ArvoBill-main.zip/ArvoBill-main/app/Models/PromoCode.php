<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;

class PromoCode extends Model
{
    use HasFactory;

    protected $fillable = [
        'code',
        'type',
        'value',
        'max_uses',
        'max_redemptions_per_user',
        'duration_cycles',
        'uses',
        'expires_at',
        'minimum_order_amount',
        'applies_to',
        'eligible_product_ids',
        'eligible_category_ids',
        'affiliate_exclusive',
        'disables_affiliate',
        'once_per_user',
        'is_active',
    ];

    protected function casts(): array
    {
        return [
            'value' => 'decimal:2',
            'minimum_order_amount' => 'decimal:2',
            'expires_at' => 'datetime',
            'eligible_product_ids' => 'array',
            'eligible_category_ids' => 'array',
            'affiliate_exclusive' => 'boolean',
            'disables_affiliate' => 'boolean',
            'once_per_user' => 'boolean',
            'is_active' => 'boolean',
            'max_uses' => 'integer',
            'max_redemptions_per_user' => 'integer',
            'duration_cycles' => 'integer',
            'uses' => 'integer',
        ];
    }

    public function redemptions(): HasMany
    {
        return $this->hasMany(PromoCodeRedemption::class);
    }
}
