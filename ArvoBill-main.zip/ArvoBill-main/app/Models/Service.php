<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class Service extends Model
{
    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'user_id',
        'product_id',
        'order_id',
        'invoice_id',
        'status',
        'billing_cycle',
        'billing_snapshot',
        'auto_renew',
        'default_payment_method_id',
        'renewal_failure_count',
        'last_renewed_at',
        'next_due_at',
        'next_due_date',
        'pterodactyl_server_id',
        'pterodactyl_node_id',
        'pterodactyl_egg_id',
        'pterodactyl_allocation_id',
        'provisioning_snapshot',
        'provisioning_error',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'next_due_date' => 'date',
            'next_due_at' => 'date',
            'last_renewed_at' => 'datetime',
            'auto_renew' => 'boolean',
            'provisioning_snapshot' => 'array',
            'billing_snapshot' => 'array',
        ];
    }

    /**
     * Get the user that owns this service.
     */
    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Get the product associated with this service.
     */
    public function product(): BelongsTo
    {
        return $this->belongsTo(Product::class);
    }

    /**
     * Get the order associated with this service.
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * Get the invoice associated with this service.
     */
    public function invoice(): BelongsTo
    {
        return $this->belongsTo(Invoice::class);
    }

    /**
     * Get default payment method used for auto renewals.
     */
    public function defaultPaymentMethod(): BelongsTo
    {
        return $this->belongsTo(UserPaymentMethod::class, 'default_payment_method_id');
    }
}
