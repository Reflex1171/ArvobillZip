<?php

namespace App\Models;

// use Illuminate\Contracts\Auth\MustVerifyEmail;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasManyThrough;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;
use Laravel\Fortify\TwoFactorAuthenticatable;

class User extends Authenticatable
{
    /** @use HasFactory<\Database\Factories\UserFactory> */
    use HasFactory, Notifiable, TwoFactorAuthenticatable;

    /**
     * The attributes that are mass assignable.
     *
     * @var list<string>
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'role',
    ];

    /**
     * The attributes that should be hidden for serialization.
     *
     * @var list<string>
     */
    protected $hidden = [
        'password',
        'two_factor_secret',
        'two_factor_recovery_codes',
        'remember_token',
    ];

    /**
     * Get the attributes that should be cast.
     *
     * @return array<string, string>
     */
    protected function casts(): array
    {
        return [
            'email_verified_at' => 'datetime',
            'password' => 'hashed',
            'two_factor_confirmed_at' => 'datetime',
        ];
    }

    /**
     * Get the orders for this user.
     */
    public function orders(): HasMany
    {
        return $this->hasMany(Order::class);
    }

    /**
     * Get the invoices for this user.
     */
    public function invoices(): HasMany
    {
        return $this->hasMany(Invoice::class);
    }

    /**
     * Get the payments for this user through invoices.
     */
    public function payments(): HasManyThrough
    {
        return $this->hasManyThrough(Payment::class, Invoice::class);
    }

    /**
     * Get the support tickets for this user.
     */
    public function tickets(): HasMany
    {
        return $this->hasMany(Ticket::class);
    }

    /**
     * Get the services for this user.
     */
    public function services(): HasMany
    {
        return $this->hasMany(Service::class);
    }

    /**
     * Get explicit permissions assigned to this user.
     */
    public function permissions(): BelongsToMany
    {
        return $this->belongsToMany(Permission::class, 'user_permissions');
    }

    /**
     * Determine if the user can access admin area.
     */
    public function canAccessAdmin(): bool
    {
        return in_array($this->role, ['staff', 'admin', 'superuser'], true);
    }

    /**
     * Determine if the user has a specific permission.
     */
    public function hasPermission(string $permissionKey): bool
    {
        if ($this->role === 'superuser' || $this->role === 'admin') {
            return true;
        }

        if ($this->role !== 'staff') {
            return false;
        }

        if ($this->relationLoaded('permissions')) {
            return $this->permissions->contains(
                fn (Permission $permission) => $permission->key === $permissionKey,
            );
        }

        return $this->permissions()->where('key', $permissionKey)->exists();
    }

    /**
     * Resolve permission keys available to this user.
     *
     * @return list<string>
     */
    public function resolvedPermissionKeys(): array
    {
        $allKeys = Permission::query()->orderBy('key')->pluck('key')->all();

        if ($this->role === 'superuser' || $this->role === 'admin') {
            return $allKeys;
        }

        if ($this->role !== 'staff') {
            return [];
        }

        if ($this->relationLoaded('permissions')) {
            /** @var list<string> $keys */
            $keys = $this->permissions
                ->pluck('key')
                ->map(fn ($key) => (string) $key)
                ->values()
                ->all();

            return $keys;
        }

        /** @var list<string> $keys */
        $keys = $this->permissions()->orderBy('key')->pluck('key')->all();

        return $keys;
    }
}
