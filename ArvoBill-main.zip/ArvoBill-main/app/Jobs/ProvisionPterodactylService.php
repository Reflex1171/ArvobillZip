<?php

namespace App\Jobs;

use App\Models\Service;
use App\Services\Email\EmailNotificationService;
use App\Services\Infrastructure\PterodactylService;
use App\Services\Infrastructure\ServiceProvisioner;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use RuntimeException;
use Throwable;

class ProvisionPterodactylService implements ShouldQueue
{
    use Dispatchable;
    use InteractsWithQueue;
    use Queueable;
    use SerializesModels;

    public int $tries = 1;

    public int $timeout = 120;

    public function __construct(public int $serviceId)
    {
        $this->onConnection('database');
    }

    public function handle(
        PterodactylService $pterodactylService,
        ServiceProvisioner $serviceProvisioner,
    ): void {
        $service = Service::query()
            ->with(['user', 'product', 'order.configurations', 'invoice'])
            ->find($this->serviceId);

        if (! $service) {
            return;
        }

        if ($service->pterodactyl_server_id || $service->status === 'active') {
            return;
        }

        if (! $service->product || $service->product->infrastructure_type !== 'pterodactyl') {
            return;
        }

        if (! $service->user || ! $service->invoice || (int) $service->user_id !== (int) $service->invoice->user_id) {
            throw new RuntimeException('Service ownership validation failed for provisioning.');
        }

        try {
            $eggId = $serviceProvisioner->resolvePterodactylEggId($service);
            $locationId = (int) ($service->product->pterodactyl_location_id ?? 0);
            if ($eggId <= 0) {
                throw new RuntimeException('Service is missing a valid Pterodactyl egg selection.');
            }
            if ($locationId <= 0) {
                throw new RuntimeException('Product is missing a Pterodactyl location mapping.');
            }

            $snapshot = $serviceProvisioner->resolveConfigurationSnapshot($service);
            if (! is_array($service->provisioning_snapshot)) {
                $service->provisioning_snapshot = $snapshot;
                $service->save();
            }

            $limits = $serviceProvisioner->resolvePterodactylLimits($service);

            $node = null;
            $allocation = null;

            $nodes = collect($pterodactylService->fetchNodes())
                ->filter(fn (array $candidate) => (int) ($candidate['location_id'] ?? 0) === $locationId)
                ->values();
            if ($nodes->isEmpty()) {
                throw new RuntimeException("No nodes found for location {$locationId}.");
            }

            foreach ($nodes as $candidateNode) {
                try {
                    $serviceProvisioner->assertNodeCapacity($candidateNode, $limits);
                } catch (Throwable) {
                    continue;
                }

                $candidateNodeId = (int) ($candidateNode['id'] ?? 0);
                if ($candidateNodeId <= 0) {
                    continue;
                }

                $candidateAllocation = collect($pterodactylService->fetchAllocations($candidateNodeId))
                    ->first(fn (array $candidate) => ! (bool) ($candidate['assigned'] ?? false));
                if (! $candidateAllocation) {
                    continue;
                }

                $node = $candidateNode;
                $allocation = $candidateAllocation;
                break;
            }

            if (! $node || ! $allocation) {
                throw new RuntimeException("No node with available capacity/allocations found in location {$locationId}.");
            }

            $nodeId = (int) ($node['id'] ?? 0);
            if ($nodeId <= 0) {
                throw new RuntimeException('Resolved node is invalid.');
            }

            $egg = collect($pterodactylService->fetchEggs())
                ->first(fn (array $candidate) => (int) ($candidate['id'] ?? 0) === $eggId);
            if (! $egg) {
                throw new RuntimeException("Configured egg {$eggId} was not found in Pterodactyl.");
            }

            $nestId = (int) ($egg['nest'] ?? $egg['nest_id'] ?? 0);
            if ($nestId <= 0) {
                throw new RuntimeException('Unable to resolve nest for configured egg.');
            }

            $panelUserId = $pterodactylService->getOrCreateUser($service->user);
            $eggDetails = $pterodactylService->fetchEggDetails($nestId, $eggId);

            $environment = collect($eggDetails['relationships']['variables']['data'] ?? [])
                ->mapWithKeys(function (array $variable): array {
                    $attributes = $variable['attributes'] ?? [];
                    $envVariable = (string) ($attributes['env_variable'] ?? '');
                    if ($envVariable === '') {
                        return [];
                    }

                    return [
                        $envVariable => (string) ($attributes['default_value'] ?? ''),
                    ];
                })
                ->all();

            $server = $pterodactylService->createServer([
                'name' => 'svc-'.$service->id.'-'.$service->product->slug,
                'user' => $panelUserId,
                'egg' => $eggId,
                'docker_image' => (string) ($eggDetails['docker_image'] ?? ''),
                'startup' => (string) ($eggDetails['startup'] ?? ''),
                'environment' => $environment,
                'limits' => [
                    'memory' => $limits['memory'],
                    'swap' => $limits['swap'],
                    'disk' => $limits['disk'],
                    'io' => $limits['io'],
                    'cpu' => $limits['cpu'],
                    'threads' => null,
                ],
                'feature_limits' => [
                    'databases' => $limits['databases'],
                    'allocations' => 1,
                    'backups' => $limits['backups'],
                ],
                'allocation' => [
                    'default' => (int) ($allocation['id'] ?? 0),
                ],
            ]);

            $serverId = (string) ($server['id'] ?? '');
            if ($serverId === '') {
                throw new RuntimeException('Pterodactyl did not return a server ID.');
            }

            $service->pterodactyl_server_id = $serverId;
            $service->pterodactyl_node_id = $nodeId;
            $service->pterodactyl_egg_id = $eggId;
            $service->pterodactyl_allocation_id = (int) ($allocation['id'] ?? 0);
            $service->status = 'active';
            $service->provisioning_error = null;
            $service->save();

            if ($service->user) {
                app(EmailNotificationService::class)->queueToUser(
                    $service->user,
                    'Service #'.$service->id.' is active',
                    'Your server is provisioned',
                    [
                        'Your service for '.$service->product->name.' has been provisioned on infrastructure.',
                        'You can now manage it from your client area.',
                    ],
                    'View Service',
                    url('/client/services/'.$service->id),
                    'service_provisioned',
                    [
                        'service_id' => $service->id,
                        'invoice_id' => $service->invoice_id,
                    ],
                );
            }
        } catch (Throwable $exception) {
            $serviceProvisioner->markProvisioningFailed($service, $exception->getMessage());

            throw $exception;
        }
    }

    public function failed(Throwable $exception): void
    {
        $service = Service::query()->find($this->serviceId);
        if (! $service) {
            return;
        }

        app(ServiceProvisioner::class)->markProvisioningFailed($service, $exception->getMessage());
    }
}
