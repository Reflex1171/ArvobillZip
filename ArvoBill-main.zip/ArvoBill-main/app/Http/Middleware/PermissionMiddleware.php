<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class PermissionMiddleware
{
    /**
     * Handle an incoming request.
     */
    public function handle(Request $request, Closure $next, string ...$permissions): Response
    {
        $user = $request->user();

        if (! $user) {
            return redirect()->guest(route('login'));
        }

        if (! $user->canAccessAdmin()) {
            abort(403, 'Forbidden');
        }

        $hasAnyPermission = collect($permissions)->contains(
            fn (string $permission) => $user->hasPermission($permission),
        );

        if (! $hasAnyPermission) {
            abort(403, 'Forbidden');
        }

        return $next($request);
    }
}
