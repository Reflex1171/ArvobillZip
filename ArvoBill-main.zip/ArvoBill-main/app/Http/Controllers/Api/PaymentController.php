<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Payment;
use App\Services\Billing\BalanceService;
use App\Services\Billing\InvoiceSettlementService;
use App\Services\Payments\PaymentProviderManager;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;

class PaymentController extends Controller
{
    public function __construct(
        private readonly BalanceService $balanceService,
        private readonly InvoiceSettlementService $settlementService,
    ) {}

    public function createStripeSession(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
        ]);

        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);

        return $this->createStripeCheckoutForInvoice($request, $invoice, $paymentProviderManager);
    }

    public function createPayPalOrder(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
        ]);

        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);

        return $this->createPayPalCheckoutForInvoice($request, $invoice, $paymentProviderManager);
    }

    public function applyAccountCredit(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
        ]);

        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);
        $appliedAmount = $this->balanceService->applyBalanceToInvoice($invoice);
        $invoice->refresh();

        if ($invoice->status === 'paid') {
            $this->settlementService->markPaid($invoice);
            $invoice->refresh();
        }

        return response()->json([
            'data' => [
                'invoice_id' => $invoice->id,
                'status' => $invoice->status,
                'applied_amount' => (float) $appliedAmount,
                'remaining_total' => (float) $invoice->total,
            ],
        ]);
    }

    public function addFunds(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:'.config('billing.add_funds_min', 5), 'max:'.config('billing.add_funds_max', 500)],
            'provider' => ['required', 'in:stripe,paypal'],
        ]);

        $user = $request->user();
        $amount = (float) $validated['amount'];

        $invoice = DB::transaction(function () use ($user, $amount): Invoice {
            $invoice = Invoice::query()->create([
                'user_id' => $user->id,
                'order_id' => null,
                'service_id' => null,
                'type' => 'credit',
                'subtotal' => $amount,
                'tax' => null,
                'total' => $amount,
                'balance_applied' => 0,
                'status' => 'unpaid',
                'due_date' => now()->toDateString(),
                'meta' => ['purpose' => 'add_funds'],
            ]);

            $invoice->items()->create([
                'description' => 'Account credit top-up',
                'amount' => $amount,
            ]);

            return $invoice;
        });

        if ($validated['provider'] === 'stripe') {
            return $this->createStripeCheckoutForInvoice($request, $invoice, $paymentProviderManager);
        }

        return $this->createPayPalCheckoutForInvoice($request, $invoice, $paymentProviderManager);
    }

    public function confirmStripeSession(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
            'session_id' => ['required', 'string'],
        ]);

        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);
        $credentials = $paymentProviderManager->getActiveCredentials('stripe');
        $modeUrls = $paymentProviderManager->getModeBaseUrls('stripe', $credentials['mode']);

        $sessionId = (string) $validated['session_id'];
        $response = $this->paymentHttp()->withToken((string) $credentials['secret_key'])
            ->get("{$modeUrls['api_base']}/v1/checkout/sessions/{$sessionId}");

        if (! $response->successful()) {
            return response()->json([
                'message' => 'Unable to confirm Stripe checkout session.',
            ], 502);
        }

        $session = $response->json();
        $paymentStatus = (string) ($session['payment_status'] ?? '');
        $metadataInvoiceId = (int) ($session['metadata']['invoice_id'] ?? 0);

        if ($metadataInvoiceId !== $invoice->id) {
            return response()->json([
                'message' => 'Stripe session does not match the invoice.',
            ], 422);
        }

        if ($paymentStatus !== 'paid') {
            return response()->json([
                'message' => 'Stripe session is not paid yet.',
            ], 422);
        }

        Payment::query()->updateOrCreate(
            [
                'provider' => 'stripe',
                'provider_payment_id' => $sessionId,
            ],
            [
                'invoice_id' => $invoice->id,
                'amount' => isset($session['amount_total'])
                    ? ((float) $session['amount_total']) / 100
                    : (float) $invoice->total,
                'currency' => strtoupper((string) ($session['currency'] ?? 'USD')),
                'status' => 'paid',
            ],
        );

        $this->settlementService->markPaid($invoice);

        return response()->json([
            'message' => 'Stripe payment confirmed successfully.',
        ]);
    }

    public function capturePayPalOrder(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
            'order_id' => ['required', 'string'],
        ]);

        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);
        $orderId = trim((string) $validated['order_id']);

        $credentials = $paymentProviderManager->getActiveCredentials('paypal');
        $modeUrls = $paymentProviderManager->getModeBaseUrls('paypal', $credentials['mode']);
        $clientId = (string) ($credentials['public_key'] ?? '');
        $secret = (string) $credentials['secret_key'];
        $apiBase = (string) ($modeUrls['api_base'] ?? '');

        if ($clientId === '' || $secret === '' || $apiBase === '') {
            throw ValidationException::withMessages([
                'provider' => 'PayPal credentials are incomplete.',
            ]);
        }

        $accessToken = $this->createPayPalAccessToken($clientId, $secret, $apiBase);

        $captureResponse = $this->paymentHttp()
            ->withToken($accessToken)
            ->post("{$apiBase}/v2/checkout/orders/{$orderId}/capture");

        $orderPayload = null;
        if ($captureResponse->successful()) {
            $orderPayload = $captureResponse->json();
        } else {
            $lookupResponse = $this->paymentHttp()
                ->withToken($accessToken)
                ->get("{$apiBase}/v2/checkout/orders/{$orderId}");

            if ($lookupResponse->successful()) {
                $orderPayload = $lookupResponse->json();
            }
        }

        if (! is_array($orderPayload)) {
            return response()->json([
                'message' => 'Unable to capture PayPal order.',
            ], 502);
        }

        $status = strtoupper((string) ($orderPayload['status'] ?? ''));
        if ($status !== 'COMPLETED') {
            return response()->json([
                'message' => 'PayPal order is not completed yet.',
            ], 422);
        }

        $purchaseUnit = $orderPayload['purchase_units'][0] ?? [];
        $capture = $purchaseUnit['payments']['captures'][0] ?? [];
        $customId = (string) ($capture['custom_id'] ?? $purchaseUnit['custom_id'] ?? '');
        $metadataInvoiceId = $this->extractInvoiceIdFromCustomId($customId);
        if ($metadataInvoiceId > 0 && $metadataInvoiceId !== $invoice->id) {
            return response()->json([
                'message' => 'PayPal order does not match the invoice.',
            ], 422);
        }

        $amount = (float) ($capture['amount']['value'] ?? $purchaseUnit['amount']['value'] ?? $invoice->total);
        $currency = strtoupper((string) ($capture['amount']['currency_code'] ?? $purchaseUnit['amount']['currency_code'] ?? 'USD'));

        DB::transaction(function () use ($invoice, $orderId, $amount, $currency) {
            Payment::query()->updateOrCreate(
                [
                    'provider' => 'paypal',
                    'provider_payment_id' => $orderId,
                ],
                [
                    'invoice_id' => $invoice->id,
                    'amount' => $amount,
                    'currency' => $currency,
                    'status' => 'paid',
                ],
            );

            $this->settlementService->markPaid($invoice);
        });

        return response()->json([
            'message' => 'PayPal payment confirmed successfully.',
        ]);
    }

    /**
     * @return array{provider:string,checkout_url:?string,provider_payment_id:string,paid_with_balance:bool}
     */
    private function createStripePayloadForInvoice(
        Request $request,
        Invoice $invoice,
        PaymentProviderManager $paymentProviderManager,
    ): array {
        $invoice = $invoice->fresh(['user']) ?? $invoice;
        $this->balanceService->applyBalanceToInvoice($invoice);
        $invoice->refresh();
        if ($invoice->status === 'paid') {
            $this->settlementService->markPaid($invoice);

            return [
                'provider' => 'balance',
                'checkout_url' => null,
                'provider_payment_id' => 'balance-only-'.$invoice->id,
                'paid_with_balance' => true,
            ];
        }

        $credentials = $paymentProviderManager->getActiveCredentials('stripe');
        $modeUrls = $paymentProviderManager->getModeBaseUrls('stripe', $credentials['mode']);
        $amountCents = (int) round(((float) $invoice->total) * 100);
        $response = $this->paymentHttp()->withToken((string) $credentials['secret_key'])
            ->asForm()
            ->post("{$modeUrls['api_base']}/v1/checkout/sessions", [
                'mode' => 'payment',
                'success_url' => url('/client/invoices/'.$invoice->id).'?payment=success&provider=stripe&session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => url('/checkout/'.$invoice->id).'?payment=cancelled',
                'line_items[0][price_data][currency]' => 'usd',
                'line_items[0][price_data][unit_amount]' => $amountCents,
                'line_items[0][price_data][product_data][name]' => 'Invoice #'.$invoice->id,
                'line_items[0][quantity]' => 1,
                'metadata[invoice_id]' => (string) $invoice->id,
                'metadata[user_id]' => (string) $request->user()->id,
                'client_reference_id' => (string) $invoice->id,
            ]);

        if (! $response->successful()) {
            throw ValidationException::withMessages([
                'provider' => 'Failed to create Stripe checkout session.',
            ]);
        }

        $sessionId = (string) $response->json('id');
        $checkoutUrl = (string) $response->json('url');

        Payment::query()->updateOrCreate(
            [
                'provider' => 'stripe',
                'provider_payment_id' => $sessionId,
            ],
            [
                'invoice_id' => $invoice->id,
                'amount' => $invoice->total,
                'currency' => 'USD',
                'status' => 'pending',
            ],
        );

        return [
            'provider' => 'stripe',
            'checkout_url' => $checkoutUrl,
            'provider_payment_id' => $sessionId,
            'paid_with_balance' => false,
        ];
    }

    private function createStripeCheckoutForInvoice(
        Request $request,
        Invoice $invoice,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        return response()->json([
            'data' => $this->createStripePayloadForInvoice($request, $invoice, $paymentProviderManager),
        ]);
    }

    /**
     * @return array{provider:string,checkout_url:?string,provider_payment_id:string,paid_with_balance:bool}
     */
    private function createPayPalPayloadForInvoice(
        Request $request,
        Invoice $invoice,
        PaymentProviderManager $paymentProviderManager,
    ): array {
        $invoice = $invoice->fresh(['user']) ?? $invoice;
        $this->balanceService->applyBalanceToInvoice($invoice);
        $invoice->refresh();
        if ($invoice->status === 'paid') {
            $this->settlementService->markPaid($invoice);

            return [
                'provider' => 'balance',
                'checkout_url' => null,
                'provider_payment_id' => 'balance-only-'.$invoice->id,
                'paid_with_balance' => true,
            ];
        }

        $credentials = $paymentProviderManager->getActiveCredentials('paypal');
        $modeUrls = $paymentProviderManager->getModeBaseUrls('paypal', $credentials['mode']);

        $clientId = (string) ($credentials['public_key'] ?? '');
        $secret = (string) $credentials['secret_key'];
        if ($clientId === '' || $secret === '') {
            throw ValidationException::withMessages([
                'provider' => 'PayPal credentials are incomplete.',
            ]);
        }

        $accessToken = $this->createPayPalAccessToken($clientId, $secret, $modeUrls['api_base']);
        $total = number_format((float) $invoice->total, 2, '.', '');
        $createOrder = $this->paymentHttp()->withToken($accessToken)
            ->post("{$modeUrls['api_base']}/v2/checkout/orders", [
                'intent' => 'CAPTURE',
                'purchase_units' => [
                    [
                        'reference_id' => 'invoice-'.$invoice->id,
                        'custom_id' => 'invoice:'.$invoice->id.'|user:'.$request->user()->id,
                        'amount' => [
                            'currency_code' => 'USD',
                            'value' => $total,
                        ],
                    ],
                ],
                'application_context' => [
                    'return_url' => url('/client/invoices/'.$invoice->id).'?payment=success&provider=paypal',
                    'cancel_url' => url('/checkout/'.$invoice->id).'?payment=cancelled',
                ],
            ]);

        if (! $createOrder->successful()) {
            throw ValidationException::withMessages([
                'provider' => 'Failed to create PayPal order.',
            ]);
        }

        $orderId = (string) $createOrder->json('id');
        $approvalUrl = collect($createOrder->json('links', []))
            ->firstWhere('rel', 'approve')['href'] ?? null;
        if (! is_string($approvalUrl) || $approvalUrl === '') {
            throw ValidationException::withMessages([
                'provider' => 'PayPal approval URL is missing.',
            ]);
        }

        Payment::query()->updateOrCreate(
            [
                'provider' => 'paypal',
                'provider_payment_id' => $orderId,
            ],
            [
                'invoice_id' => $invoice->id,
                'amount' => $invoice->total,
                'currency' => 'USD',
                'status' => 'pending',
            ],
        );

        return [
            'provider' => 'paypal',
            'checkout_url' => $approvalUrl,
            'provider_payment_id' => $orderId,
            'paid_with_balance' => false,
        ];
    }

    private function createPayPalCheckoutForInvoice(
        Request $request,
        Invoice $invoice,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        return response()->json([
            'data' => $this->createPayPalPayloadForInvoice($request, $invoice, $paymentProviderManager),
        ]);
    }

    private function resolvePayableInvoice(Request $request, int $invoiceId): Invoice
    {
        $invoice = Invoice::query()
            ->where('id', $invoiceId)
            ->where('user_id', $request->user()->id)
            ->with('payments')
            ->firstOrFail();

        if ($invoice->status !== 'unpaid') {
            throw ValidationException::withMessages([
                'invoice_id' => 'Only unpaid invoices can be paid.',
            ]);
        }

        return $invoice;
    }

    private function createPayPalAccessToken(
        string $clientId,
        string $secret,
        string $apiBase,
    ): string {
        $tokenResponse = $this->paymentHttp()
            ->asForm()
            ->withBasicAuth($clientId, $secret)
            ->post("{$apiBase}/v1/oauth2/token", [
                'grant_type' => 'client_credentials',
            ]);

        if (! $tokenResponse->successful()) {
            throw ValidationException::withMessages([
                'provider' => 'Unable to authenticate with PayPal.',
            ]);
        }

        $token = (string) $tokenResponse->json('access_token', '');
        if ($token === '') {
            throw ValidationException::withMessages([
                'provider' => 'PayPal access token was not returned.',
            ]);
        }

        return $token;
    }

    private function extractInvoiceIdFromCustomId(string $customId): int
    {
        if ($customId === '') {
            return 0;
        }

        preg_match('/invoice:(\d+)/', $customId, $matches);

        return isset($matches[1]) ? (int) $matches[1] : 0;
    }

    private function paymentHttp(): PendingRequest
    {
        return Http::timeout(30)->retry(2, 200, throw: false);
    }
}
