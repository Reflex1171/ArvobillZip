<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Payment;
use App\Services\Billing\InvoiceSettlementService;
use App\Services\Payments\PaymentProviderManager;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Validation\ValidationException;

class PaymentController extends Controller
{
    public function createStripeSession(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
        ]);

        $credentials = $paymentProviderManager->getActiveCredentials('stripe');
        $modeUrls = $paymentProviderManager->getModeBaseUrls('stripe', $credentials['mode']);
        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);

        $secretKey = (string) $credentials['secret_key'];

        $amountCents = (int) round(((float) $invoice->total) * 100);

        $response = Http::withToken($secretKey)
            ->asForm()
            ->post("{$modeUrls['api_base']}/v1/checkout/sessions", [
                'mode' => 'payment',
                'success_url' => url('/client/invoices/'.$invoice->id).'?payment=success&provider=stripe&session_id={CHECKOUT_SESSION_ID}',
                'cancel_url' => url('/checkout/'.$invoice->id).'?payment=cancelled',
                'line_items[0][price_data][currency]' => 'usd',
                'line_items[0][price_data][unit_amount]' => $amountCents,
                'line_items[0][price_data][product_data][name]' => 'Invoice #'.$invoice->id,
                'line_items[0][quantity]' => 1,
                'metadata[invoice_id]' => (string) $invoice->id,
                'metadata[user_id]' => (string) $request->user()->id,
                'client_reference_id' => (string) $invoice->id,
            ]);

        if (! $response->successful()) {
            return response()->json([
                'message' => 'Failed to create Stripe checkout session.',
            ], 502);
        }

        $sessionId = (string) $response->json('id');
        $checkoutUrl = (string) $response->json('url');

        Payment::query()->updateOrCreate(
            [
                'provider' => 'stripe',
                'provider_payment_id' => $sessionId,
            ],
            [
                'invoice_id' => $invoice->id,
                'amount' => $invoice->total,
                'currency' => 'USD',
                'status' => 'pending',
            ],
        );

        return response()->json([
            'data' => [
                'provider' => 'stripe',
                'checkout_url' => $checkoutUrl,
                'provider_payment_id' => $sessionId,
            ],
        ]);
    }

    public function createPayPalOrder(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
        ]);

        $credentials = $paymentProviderManager->getActiveCredentials('paypal');
        $modeUrls = $paymentProviderManager->getModeBaseUrls('paypal', $credentials['mode']);
        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);

        $clientId = (string) ($credentials['public_key'] ?? '');
        $secret = (string) $credentials['secret_key'];
        if ($clientId === '' || $secret === '') {
            throw ValidationException::withMessages([
                'provider' => 'PayPal credentials are incomplete.',
            ]);
        }
        $accessToken = $this->createPayPalAccessToken($clientId, $secret, $modeUrls['api_base']);
        $total = number_format((float) $invoice->total, 2, '.', '');

        $createOrder = Http::withToken($accessToken)
            ->post("{$modeUrls['api_base']}/v2/checkout/orders", [
                'intent' => 'CAPTURE',
                'purchase_units' => [
                    [
                        'reference_id' => 'invoice-'.$invoice->id,
                        'custom_id' => 'invoice:'.$invoice->id.'|user:'.$request->user()->id,
                        'amount' => [
                            'currency_code' => 'USD',
                            'value' => $total,
                        ],
                    ],
                ],
                'application_context' => [
                    'return_url' => url('/client/invoices/'.$invoice->id).'?payment=success',
                    'cancel_url' => url('/checkout/'.$invoice->id).'?payment=cancelled',
                ],
            ]);

        if (! $createOrder->successful()) {
            return response()->json([
                'message' => 'Failed to create PayPal order.',
            ], 502);
        }

        $orderId = (string) $createOrder->json('id');
        $approvalUrl = collect($createOrder->json('links', []))
            ->firstWhere('rel', 'approve')['href'] ?? null;

        if (! is_string($approvalUrl) || $approvalUrl === '') {
            return response()->json([
                'message' => 'PayPal approval URL is missing.',
            ], 502);
        }

        Payment::query()->updateOrCreate(
            [
                'provider' => 'paypal',
                'provider_payment_id' => $orderId,
            ],
            [
                'invoice_id' => $invoice->id,
                'amount' => $invoice->total,
                'currency' => 'USD',
                'status' => 'pending',
            ],
        );

        return response()->json([
            'data' => [
                'provider' => 'paypal',
                'checkout_url' => $approvalUrl,
                'provider_payment_id' => $orderId,
            ],
        ]);
    }

    public function confirmStripeSession(
        Request $request,
        PaymentProviderManager $paymentProviderManager,
        InvoiceSettlementService $settlementService,
    ): JsonResponse {
        $validated = $request->validate([
            'invoice_id' => ['required', 'integer'],
            'session_id' => ['required', 'string'],
        ]);

        $invoice = $this->resolvePayableInvoice($request, (int) $validated['invoice_id']);
        $credentials = $paymentProviderManager->getActiveCredentials('stripe');
        $modeUrls = $paymentProviderManager->getModeBaseUrls('stripe', $credentials['mode']);

        $sessionId = (string) $validated['session_id'];
        $response = Http::withToken((string) $credentials['secret_key'])
            ->get("{$modeUrls['api_base']}/v1/checkout/sessions/{$sessionId}");

        if (! $response->successful()) {
            return response()->json([
                'message' => 'Unable to confirm Stripe checkout session.',
            ], 502);
        }

        $session = $response->json();
        $paymentStatus = (string) ($session['payment_status'] ?? '');
        $metadataInvoiceId = (int) ($session['metadata']['invoice_id'] ?? 0);

        if ($metadataInvoiceId !== $invoice->id) {
            return response()->json([
                'message' => 'Stripe session does not match the invoice.',
            ], 422);
        }

        if ($paymentStatus !== 'paid') {
            return response()->json([
                'message' => 'Stripe session is not paid yet.',
            ], 422);
        }

        Payment::query()->updateOrCreate(
            [
                'provider' => 'stripe',
                'provider_payment_id' => $sessionId,
            ],
            [
                'invoice_id' => $invoice->id,
                'amount' => isset($session['amount_total'])
                    ? ((float) $session['amount_total']) / 100
                    : (float) $invoice->total,
                'currency' => strtoupper((string) ($session['currency'] ?? 'USD')),
                'status' => 'paid',
            ],
        );

        $settlementService->markPaid($invoice);

        return response()->json([
            'message' => 'Stripe payment confirmed successfully.',
        ]);
    }

    private function resolvePayableInvoice(Request $request, int $invoiceId): Invoice
    {
        $invoice = Invoice::query()
            ->where('id', $invoiceId)
            ->where('user_id', $request->user()->id)
            ->with('payments')
            ->firstOrFail();

        if ($invoice->status !== 'unpaid') {
            throw ValidationException::withMessages([
                'invoice_id' => 'Only unpaid invoices can be paid.',
            ]);
        }

        return $invoice;
    }

    private function createPayPalAccessToken(
        string $clientId,
        string $secret,
        string $apiBase,
    ): string
    {
        $tokenResponse = Http::asForm()
            ->withBasicAuth($clientId, $secret)
            ->post("{$apiBase}/v1/oauth2/token", [
                'grant_type' => 'client_credentials',
            ]);

        if (! $tokenResponse->successful()) {
            throw ValidationException::withMessages([
                'provider' => 'Unable to authenticate with PayPal.',
            ]);
        }

        $token = (string) $tokenResponse->json('access_token', '');
        if ($token === '') {
            throw ValidationException::withMessages([
                'provider' => 'PayPal access token was not returned.',
            ]);
        }
        return $token;
    }
}
