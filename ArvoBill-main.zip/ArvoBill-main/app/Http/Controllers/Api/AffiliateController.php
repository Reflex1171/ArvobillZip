<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AffiliateEarning;
use App\Models\AffiliateReferralVisit;
use App\Services\Affiliates\AffiliateService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class AffiliateController extends Controller
{
    public function show(Request $request, AffiliateService $affiliateService): JsonResponse
    {
        $user = $request->user();
        $affiliateService->ensureAffiliateCode($user);
        $user->refresh();

        $visitsCount = AffiliateReferralVisit::query()
            ->where('affiliate_user_id', $user->id)
            ->count();

        $signupsCount = AffiliateReferralVisit::query()
            ->where('affiliate_user_id', $user->id)
            ->whereNotNull('referred_user_id')
            ->distinct('referred_user_id')
            ->count('referred_user_id');

        $pending = (float) AffiliateEarning::query()
            ->where('affiliate_user_id', $user->id)
            ->where('status', 'pending')
            ->sum('amount');

        $approved = (float) AffiliateEarning::query()
            ->where('affiliate_user_id', $user->id)
            ->whereIn('status', ['approved', 'paid'])
            ->sum('amount');

        $earnings = AffiliateEarning::query()
            ->where('affiliate_user_id', $user->id)
            ->with('invoice')
            ->latest('id')
            ->limit(50)
            ->get();

        return response()->json([
            'data' => [
                'referral_link' => url('/register?ref='.$user->affiliate_code),
                'affiliate_code' => $user->affiliate_code,
                'stats' => [
                    'clicks' => $visitsCount,
                    'signups' => $signupsCount,
                    'pending_earnings' => $pending,
                    'approved_earnings' => $approved,
                    'affiliate_balance' => (float) $user->affiliate_balance,
                ],
                'earnings' => $earnings->map(fn (AffiliateEarning $earning) => [
                    'id' => $earning->id,
                    'invoice_id' => $earning->invoice_id,
                    'amount' => (float) $earning->amount,
                    'status' => $earning->status,
                    'eligible_at' => $earning->eligible_at?->toISOString(),
                    'approved_at' => $earning->approved_at?->toISOString(),
                    'paid_at' => $earning->paid_at?->toISOString(),
                    'created_at' => $earning->created_at?->toISOString(),
                ])->values(),
            ],
        ]);
    }
}