<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\AffiliateEarning;
use App\Models\AffiliatePayoutRequest;
use App\Models\AffiliateReferralVisit;
use App\Services\Affiliates\AffiliateService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AffiliateController extends Controller
{
    public function show(Request $request, AffiliateService $affiliateService): JsonResponse
    {
        $user = $request->user();
        $affiliateService->ensureAffiliateCode($user);
        $user->refresh();

        $visitsCount = AffiliateReferralVisit::query()
            ->where('affiliate_user_id', $user->id)
            ->count();

        $signupsCount = AffiliateReferralVisit::query()
            ->where('affiliate_user_id', $user->id)
            ->whereNotNull('referred_user_id')
            ->distinct('referred_user_id')
            ->count('referred_user_id');

        $pending = (float) AffiliateEarning::query()
            ->where('affiliate_user_id', $user->id)
            ->where('status', 'pending')
            ->sum('amount');

        $approved = (float) AffiliateEarning::query()
            ->where('affiliate_user_id', $user->id)
            ->whereIn('status', ['approved', 'paid'])
            ->sum('amount');

        $pendingPayouts = (float) AffiliatePayoutRequest::query()
            ->where('affiliate_user_id', $user->id)
            ->whereIn('status', ['pending', 'processing'])
            ->sum('amount');

        $earnings = AffiliateEarning::query()
            ->where('affiliate_user_id', $user->id)
            ->with('invoice')
            ->latest('id')
            ->limit(50)
            ->get();

        $payoutRequests = AffiliatePayoutRequest::query()
            ->where('affiliate_user_id', $user->id)
            ->latest('id')
            ->limit(50)
            ->get();

        $availableForPayout = max(0, (float) $user->affiliate_balance - $pendingPayouts);

        return response()->json([
            'data' => [
                'referral_link' => url('/register?ref='.$user->affiliate_code),
                'affiliate_code' => $user->affiliate_code,
                'stats' => [
                    'clicks' => $visitsCount,
                    'signups' => $signupsCount,
                    'pending_earnings' => $pending,
                    'approved_earnings' => $approved,
                    'affiliate_balance' => (float) $user->affiliate_balance,
                    'pending_payouts' => $pendingPayouts,
                    'available_for_payout' => $availableForPayout,
                ],
                'earnings' => $earnings->map(fn (AffiliateEarning $earning) => [
                    'id' => $earning->id,
                    'invoice_id' => $earning->invoice_id,
                    'amount' => (float) $earning->amount,
                    'status' => $earning->status,
                    'eligible_at' => $earning->eligible_at?->toISOString(),
                    'approved_at' => $earning->approved_at?->toISOString(),
                    'paid_at' => $earning->paid_at?->toISOString(),
                    'created_at' => $earning->created_at?->toISOString(),
                ])->values(),
                'payout_requests' => $payoutRequests->map(fn (AffiliatePayoutRequest $payoutRequest) => [
                    'id' => $payoutRequest->id,
                    'amount' => (float) $payoutRequest->amount,
                    'status' => $payoutRequest->status,
                    'payout_method' => $payoutRequest->payout_method,
                    'payout_details' => $payoutRequest->payout_details,
                    'admin_notes' => $payoutRequest->admin_notes,
                    'requested_at' => $payoutRequest->requested_at?->toISOString(),
                    'processed_at' => $payoutRequest->processed_at?->toISOString(),
                    'created_at' => $payoutRequest->created_at?->toISOString(),
                ])->values(),
            ],
        ]);
    }

    public function requestPayout(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'amount' => ['required', 'numeric', 'min:1'],
            'payout_method' => ['nullable', 'in:bank_transfer,paypal,crypto,other'],
            'payout_details' => ['nullable', 'string', 'max:2000'],
        ]);

        $user = $request->user();
        $amount = round((float) $validated['amount'], 2);
        $payoutRequest = null;

        DB::transaction(function () use ($user, $amount, $validated, &$payoutRequest): void {
            $lockedUser = $user->newQuery()->lockForUpdate()->findOrFail($user->id);

            $pendingPayouts = (float) AffiliatePayoutRequest::query()
                ->where('affiliate_user_id', $lockedUser->id)
                ->whereIn('status', ['pending', 'processing'])
                ->sum('amount');

            $availableForPayout = max(0, (float) $lockedUser->affiliate_balance - $pendingPayouts);

            if ($amount > $availableForPayout) {
                throw ValidationException::withMessages([
                    'amount' => 'Requested amount exceeds your available payout balance.',
                ]);
            }

            $payoutRequest = AffiliatePayoutRequest::query()->create([
                'affiliate_user_id' => $lockedUser->id,
                'amount' => $amount,
                'status' => 'pending',
                'payout_method' => $validated['payout_method'] ?? null,
                'payout_details' => $validated['payout_details'] ?? null,
                'requested_at' => now(),
            ]);
        });

        return response()->json([
            'message' => 'Payout request submitted.',
            'data' => [
                'id' => $payoutRequest->id,
                'amount' => (float) $payoutRequest->amount,
                'status' => $payoutRequest->status,
            ],
        ], 201);
    }
}
