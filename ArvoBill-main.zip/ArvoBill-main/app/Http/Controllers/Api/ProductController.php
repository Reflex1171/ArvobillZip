<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $categorySlug = $request->query('category');

        $products = Product::query()
            ->with('category')
            ->where('is_active', true)
            ->when($categorySlug, function ($query, $slug) {
                $query->whereHas('category', fn ($categoryQuery) => $categoryQuery->where('slug', $slug));
            })
            ->orderBy('name')
            ->get()
            ->map(fn (Product $product) => $this->transformProduct($product));

        return response()->json([
            'data' => $products,
        ]);
    }

    public function show(string $slug): JsonResponse
    {
        $product = Product::query()
            ->with('category')
            ->where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();

        return response()->json([
            'data' => $this->transformProduct($product),
        ]);
    }

    private function transformProduct(Product $product): array
    {
        $category = $product->relationLoaded('category')
            ? $product->getRelation('category')
            : $product->category()->first();

        return [
            'id' => $product->id,
            'name' => $product->name,
            'slug' => $product->slug,
            'description' => $product->description,
            'category_id' => $product->category_id,
            'category' => $category ? [
                'id' => $category->id,
                'name' => $category->name,
                'slug' => $category->slug,
                'description' => $category->description,
            ] : null,
            'price_monthly' => (float) $product->price_monthly,
            'setup_fee' => $product->setup_fee !== null ? (float) $product->setup_fee : null,
            'is_active' => $product->is_active,
            'created_at' => $product->created_at?->toISOString(),
            'updated_at' => $product->updated_at?->toISOString(),
        ];
    }
}
