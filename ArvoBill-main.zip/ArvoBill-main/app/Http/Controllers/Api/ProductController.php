<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Support\BillingCycle;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $categorySlug = $request->query('category');

        $products = Product::query()
            ->with('category')
            ->where('is_active', true)
            ->when($categorySlug, function ($query, $slug) {
                $query->whereHas('category', fn ($categoryQuery) => $categoryQuery->where('slug', $slug));
            })
            ->orderBy('name')
            ->get()
            ->map(fn (Product $product) => $this->transformProduct($product));

        return response()->json([
            'data' => $products,
        ]);
    }

    public function show(string $slug): JsonResponse
    {
        $product = Product::query()
            ->with('category')
            ->where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();

        return response()->json([
            'data' => $this->transformProduct($product),
        ]);
    }

    private function transformProduct(Product $product): array
    {
        $billingType = BillingCycle::normalizeBillingType((string) ($product->billing_type ?? 'recurring'));
        $billingInterval = BillingCycle::resolveInterval($product->billing_interval ?? 1);
        $billingPeriod = BillingCycle::normalizePeriod((string) ($product->billing_period ?? 'month'));

        $category = $product->relationLoaded('category')
            ? $product->getRelation('category')
            : $product->category()->first();

        return [
            'id' => $product->id,
            'name' => $product->name,
            'slug' => $product->slug,
            'description' => $product->description,
            'category_id' => $product->category_id,
            'category' => $category ? [
                'id' => $category->id,
                'name' => $category->name,
                'slug' => $category->slug,
                'description' => $category->description,
            ] : null,
            'price_monthly' => (float) $product->price_monthly,
            'setup_fee' => $product->setup_fee !== null ? (float) $product->setup_fee : null,
            'billing_type' => $billingType,
            'billing_interval' => $billingType === 'one_time' ? null : $billingInterval,
            'billing_period' => $billingType === 'one_time' ? null : $billingPeriod,
            'billing_cycle' => BillingCycle::intervalSummary($billingInterval, $billingPeriod),
            'billing_summary' => BillingCycle::billingSummary($billingType, $billingInterval, $billingPeriod),
            'allow_auto_renew' => $billingType === 'recurring' ? (bool) $product->allow_auto_renew : false,
            'infrastructure_type' => $product->infrastructure_type ?? 'none',
            'pterodactyl_egg_id' => $product->pterodactyl_egg_id,
            'pterodactyl_location_id' => $product->pterodactyl_location_id,
            'pterodactyl_default_node_id' => $product->pterodactyl_default_node_id,
            'auto_provision' => (bool) $product->auto_provision,
            'is_active' => $product->is_active,
            'created_at' => $product->created_at?->toISOString(),
            'updated_at' => $product->updated_at?->toISOString(),
        ];
    }
}
