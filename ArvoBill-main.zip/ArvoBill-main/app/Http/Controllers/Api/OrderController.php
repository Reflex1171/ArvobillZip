<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\OrderConfiguration;
use App\Models\Order;
use App\Models\Product;
use App\Models\ProductConfiguration;
use App\Models\ProductConfigurationOption;
use App\Support\BillingCycle;
use App\Services\Discounts\PromoCodeService;
use App\Services\Email\EmailNotificationService;
use App\Services\Infrastructure\ServiceProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $orders = Order::query()
            ->with(['product', 'invoice', 'configurations'])
            ->where('user_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Order $order) => $this->transformOrder($order));

        return response()->json([
            'data' => $orders,
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $order = Order::query()
            ->with(['product', 'invoice.items', 'configurations'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformOrder($order, true),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'product_slug' => ['required', 'string'],
            'configurations' => ['nullable', 'array'],
            'promo_code' => ['nullable', 'string', 'max:64'],
        ]);

        $product = Product::query()
            ->with([
                'configurations' => fn ($query) => $query->orderBy('sort_order')->orderBy('id'),
                'configurations.options' => fn ($query) => $query->where('is_active', true)->orderBy('id'),
            ])
            ->where('slug', $validated['product_slug'])
            ->where('is_active', true)
            ->firstOrFail();

        $user = $request->user();
        $submittedConfigurations = is_array($validated['configurations'] ?? null)
            ? $validated['configurations']
            : [];

        $resolvedSelections = $this->resolveConfigurationSelections(
            $product,
            $product->configurations,
            $submittedConfigurations,
        );

        $modifiersTotal = array_sum(array_map(
            fn (array $selection) => (float) $selection['price_modifier'],
            $resolvedSelections,
        ));

        $subtotal = (float) $product->price_monthly + (float) ($product->setup_fee ?? 0) + $modifiersTotal;
        /** @var PromoCodeService $promoCodeService */
        $promoCodeService = app(PromoCodeService::class);
        $promoResolution = $promoCodeService->resolve(
            (string) ($validated['promo_code'] ?? ''),
            $user,
            $product,
            $subtotal,
            $request,
        );
        $discountAmount = (float) $promoResolution['discount_amount'];
        $promoCode = $promoResolution['promo_code'];
        $tax = null;
        $total = (float) $promoResolution['final_total'];
        $billingType = BillingCycle::normalizeBillingType((string) ($product->billing_type ?? 'recurring'));
        $billingInterval = BillingCycle::resolveInterval($product->billing_interval ?? 1);
        $billingPeriod = BillingCycle::normalizePeriod((string) ($product->billing_period ?? 'month'));
        $billingSummary = BillingCycle::intervalSummary($billingInterval, $billingPeriod);

        $order = DB::transaction(function () use (
            $user,
            $product,
            $subtotal,
            $tax,
            $total,
            $resolvedSelections,
            $billingType,
            $billingSummary,
            $promoCode,
            $discountAmount,
            $promoCodeService,
        ) {
            $order = Order::create([
                'user_id' => $user->id,
                'product_id' => $product->id,
                'status' => 'pending',
                'promo_code_id' => $promoCode?->id,
                'promo_code_code' => $promoCode?->code,
                'discount_amount' => $discountAmount,
            ]);

            $invoice = Invoice::create([
                'user_id' => $user->id,
                'order_id' => $order->id,
                'promo_code_id' => $promoCode?->id,
                'promo_code_code' => $promoCode?->code,
                'subtotal' => $subtotal,
                'discount_amount' => $discountAmount,
                'tax' => $tax,
                'total' => $total,
                'status' => 'unpaid',
                'due_date' => now()->addDays(7)->toDateString(),
            ]);

            $invoice->items()->create([
                'description' => $billingType === 'one_time'
                    ? "{$product->name} (One-time)"
                    : "{$product->name} ({$billingSummary})",
                'amount' => $product->price_monthly,
            ]);

            if ($product->setup_fee !== null && (float) $product->setup_fee > 0) {
                $invoice->items()->create([
                    'description' => "{$product->name} Setup Fee",
                    'amount' => $product->setup_fee,
                ]);
            }

            foreach ($resolvedSelections as $selection) {
                OrderConfiguration::create([
                    'order_id' => $order->id,
                    'configuration_key' => $selection['configuration_key'],
                    'selected_value' => $selection['selected_value'],
                    'price_modifier' => $selection['price_modifier'],
                ]);

                if ((float) $selection['price_modifier'] !== 0.0) {
                    $invoice->items()->create([
                        'description' => "{$selection['configuration_name']}: {$selection['option_label']}",
                        'amount' => $selection['price_modifier'],
                    ]);
                }
            }

            if ($discountAmount > 0) {
                $invoice->items()->create([
                    'description' => "Promo code {$promoCode?->code}",
                    'amount' => 0 - $discountAmount,
                ]);
            }

            if ($promoCode && $discountAmount > 0) {
                $promoCodeService->redeem(
                    $promoCode,
                    $user,
                    $order,
                    (int) $invoice->id,
                    $discountAmount,
                );
            }

            return $order->load(['product', 'invoice.items', 'configurations']);
        });

        /** @var EmailNotificationService $emailNotificationService */
        $emailNotificationService = app(EmailNotificationService::class);
        $invoice = $order->invoice;
        if ($invoice) {
            $emailNotificationService->queueToUser(
                $user,
                'Invoice #'.$invoice->id.' created',
                'A new invoice is ready',
                [
                    'Order #'.$order->id.' has been created for '.$product->name.'.',
                    'Invoice #'.$invoice->id.' total is $'.number_format((float) $invoice->total, 2).'.',
                ],
                'Review Invoice',
                url('/client/invoices/'.$invoice->id),
                'invoice_created',
                [
                    'user_id' => $user->id,
                    'order_id' => $order->id,
                    'invoice_id' => $invoice->id,
                ],
                $invoice->id,
            );

            $emailNotificationService->queueToAdminUsers(
                'New order #'.$order->id.' placed',
                'New order received',
                [
                    'A new order was placed by '.$user->email.'.',
                    'Order #'.$order->id.' for '.$product->name.' created invoice #'.$invoice->id.'.',
                ],
                'Open Order',
                url('/admin/orders/'.$order->id),
                'admin_new_order',
                [
                    'user_id' => $user->id,
                    'order_id' => $order->id,
                    'invoice_id' => $invoice->id,
                ],
            );
        }

        return response()->json([
            'message' => 'Order and invoice created successfully.',
            'data' => $this->transformOrder($order, true),
        ], 201);
    }

    private function transformOrder(Order $order, bool $withInvoiceItems = false): array
    {
        return [
            'id' => $order->id,
            'status' => $order->status,
            'created_at' => $order->created_at?->toISOString(),
            'updated_at' => $order->updated_at?->toISOString(),
            'product' => $order->product ? [
                'id' => $order->product->id,
                'name' => $order->product->name,
                'slug' => $order->product->slug,
            ] : null,
            'configurations' => $order->relationLoaded('configurations')
                ? $order->configurations->map(fn ($configuration) => [
                    'id' => $configuration->id,
                    'configuration_key' => $configuration->configuration_key,
                    'selected_value' => $configuration->selected_value,
                    'price_modifier' => (float) $configuration->price_modifier,
                ])->values()
                : null,
            'promo_code' => $order->promo_code_code,
            'discount_amount' => (float) ($order->discount_amount ?? 0),
            'invoice' => $order->invoice ? [
                'id' => $order->invoice->id,
                'status' => $order->invoice->status,
                'subtotal' => (float) $order->invoice->subtotal,
                'promo_code' => $order->invoice->promo_code_code,
                'discount_amount' => (float) ($order->invoice->discount_amount ?? 0),
                'tax' => $order->invoice->tax !== null ? (float) $order->invoice->tax : null,
                'total' => (float) $order->invoice->total,
                'due_date' => $order->invoice->due_date?->toDateString(),
                'items' => $withInvoiceItems
                    ? $order->invoice->items->map(fn ($item) => [
                        'id' => $item->id,
                        'description' => $item->description,
                        'amount' => (float) $item->amount,
                    ])->values()
                    : null,
            ] : null,
        ];
    }

    /**
     * @param  \Illuminate\Support\Collection<int, ProductConfiguration>  $configurations
     * @param  array<string, mixed>  $submittedConfigurations
     * @param  Product  $product
     * @return array<int, array{
     *   configuration_key: string,
     *   configuration_name: string,
     *   selected_value: string,
     *   option_label: string,
     *   price_modifier: float
     * }>
     */
    private function resolveConfigurationSelections(
        Product $product,
        $configurations,
        array $submittedConfigurations,
    ): array {
        $configurationsByKey = $configurations->keyBy('key');
        $isPterodactyl = $product->infrastructure_type === 'pterodactyl';

        if ($isPterodactyl) {
            $missingRequiredDefinitions = collect(ServiceProvisioner::REQUIRED_PTERODACTYL_KEYS)
                ->reject(fn (string $key) => $configurationsByKey->has($key))
                ->values();
            if ($missingRequiredDefinitions->isNotEmpty()) {
                throw ValidationException::withMessages([
                    'product' => 'Product is missing required provisioning configuration keys: '.$missingRequiredDefinitions->implode(', '),
                ]);
            }
        }

        foreach (array_keys($submittedConfigurations) as $submittedKey) {
            if (! $configurationsByKey->has($submittedKey)) {
                throw ValidationException::withMessages([
                    'configurations' => "Unknown configuration key: {$submittedKey}.",
                ]);
            }
        }

        $resolved = [];

        foreach ($configurations as $configuration) {
            $selectedValueRaw = $submittedConfigurations[$configuration->key] ?? null;
            $selectedValue = is_scalar($selectedValueRaw)
                ? trim((string) $selectedValueRaw)
                : '';

            if ($configuration->required && $selectedValue === '') {
                throw ValidationException::withMessages([
                    "configurations.{$configuration->key}" => "The {$configuration->name} selection is required.",
                ]);
            }

            if ($selectedValue === '') {
                continue;
            }

            $matchedOption = $configuration->options->first(
                fn (ProductConfigurationOption $option) => $option->value === $selectedValue,
            );

            if (! $matchedOption) {
                throw ValidationException::withMessages([
                    "configurations.{$configuration->key}" => "Invalid value selected for {$configuration->name}.",
                ]);
            }

            if ($isPterodactyl && in_array($configuration->key, ServiceProvisioner::REQUIRED_PTERODACTYL_KEYS, true)) {
                if (! preg_match('/^\d+$/', $matchedOption->value)) {
                    throw ValidationException::withMessages([
                        "configurations.{$configuration->key}" => "{$configuration->name} must be numeric.",
                    ]);
                }

                if ((int) $matchedOption->value <= 0) {
                    throw ValidationException::withMessages([
                        "configurations.{$configuration->key}" => "{$configuration->name} must be greater than zero.",
                    ]);
                }
            }

            $resolved[] = [
                'configuration_key' => $configuration->key,
                'configuration_name' => $configuration->name,
                'selected_value' => $matchedOption->value,
                'option_label' => $matchedOption->label,
                'price_modifier' => (float) ($matchedOption->price_modifier ?? 0),
            ];
        }

        if ($isPterodactyl) {
            $resolvedByKey = collect($resolved)->keyBy('configuration_key');
            foreach (ServiceProvisioner::REQUIRED_PTERODACTYL_KEYS as $requiredKey) {
                if (! $resolvedByKey->has($requiredKey)) {
                    throw ValidationException::withMessages([
                        "configurations.{$requiredKey}" => "The {$requiredKey} selection is required.",
                    ]);
                }
            }
        }

        return $resolved;
    }
}
