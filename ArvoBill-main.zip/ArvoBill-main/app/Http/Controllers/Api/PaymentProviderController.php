<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\Payments\PaymentProviderManager;
use Illuminate\Http\JsonResponse;

class PaymentProviderController extends Controller
{
    public function __invoke(PaymentProviderManager $manager): JsonResponse
    {
        return response()->json([
            'data' => $manager->getEnabledCheckoutProviders(),
        ]);
    }
}
