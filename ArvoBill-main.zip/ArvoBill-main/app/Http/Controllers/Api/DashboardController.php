<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Order;
use App\Models\Service;
use App\Models\Ticket;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class DashboardController extends Controller
{
    public function __invoke(Request $request): JsonResponse
    {
        $userId = $request->user()->id;

        $activeServices = Service::query()
            ->where('user_id', $userId)
            ->where('status', 'active')
            ->count();

        $outstandingBalance = (float) (Invoice::query()
            ->where('user_id', $userId)
            ->where('status', 'unpaid')
            ->sum('total') ?? 0);

        $nextInvoice = Invoice::query()
            ->where('user_id', $userId)
            ->where('status', 'unpaid')
            ->orderBy('due_date')
            ->first();

        $openTickets = Ticket::query()
            ->where('user_id', $userId)
            ->whereIn('status', ['open', 'answered'])
            ->count();

        $services = Service::query()
            ->with('product')
            ->where('user_id', $userId)
            ->orderByDesc('created_at')
            ->limit(5)
            ->get()
            ->map(fn (Service $service) => [
                'id' => $service->id,
                'service' => $service->product?->name ?? 'Unknown Product',
                'plan' => $service->product?->slug ?? '-',
                'status' => $service->status,
                'created_at' => $service->created_at?->toDateString(),
            ])
            ->values();

        $invoices = Invoice::query()
            ->where('user_id', $userId)
            ->orderByDesc('created_at')
            ->limit(5)
            ->get()
            ->map(fn (Invoice $invoice) => [
                'id' => $invoice->id,
                'date' => $invoice->created_at?->toDateString(),
                'amount' => (float) $invoice->total,
                'status' => $invoice->status,
            ])
            ->values();

        $activity = Order::query()
            ->with(['product', 'invoice'])
            ->where('user_id', $userId)
            ->orderByDesc('created_at')
            ->limit(5)
            ->get()
            ->map(fn (Order $order) => [
                'text' => "Order #{$order->id} for {$order->product?->name} is {$order->status}.",
                'timestamp' => $order->created_at?->diffForHumans(),
                'invoice_id' => $order->invoice?->id,
            ])
            ->values();

        return response()->json([
            'data' => [
                'stats' => [
                    'active_services' => $activeServices,
                    'open_tickets' => $openTickets,
                    'outstanding_balance' => $outstandingBalance,
                    'next_invoice_due' => $nextInvoice ? [
                        'invoice_id' => $nextInvoice->id,
                        'due_date' => $nextInvoice->due_date?->toDateString(),
                    ] : null,
                ],
                'services' => $services,
                'recent_invoices' => $invoices,
                'recent_activity' => $activity,
            ],
        ]);
    }
}
