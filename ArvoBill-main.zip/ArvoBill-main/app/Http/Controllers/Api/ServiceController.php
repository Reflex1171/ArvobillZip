<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Services\Infrastructure\PterodactylService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ServiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $services = Service::query()
            ->with(['product', 'order', 'invoice'])
            ->where('user_id', $request->user()->id)
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Service $service) => $this->transformService($service))
            ->values();

        return response()->json([
            'data' => $services,
        ]);
    }

    public function show(Request $request, int $id): JsonResponse
    {
        $service = Service::query()
            ->with(['product', 'order.configurations', 'invoice'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformService($service, true),
        ]);
    }

    public function cancel(Request $request, int $id): JsonResponse
    {
        $service = Service::query()
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        if ($service->status === 'cancelled') {
            return response()->json([
                'message' => 'Service is already cancelled.',
                'data' => $this->transformService($service->load(['product', 'order', 'invoice']), true),
            ]);
        }

        $service->status = 'cancelled';
        $service->save();

        return response()->json([
            'message' => 'Service cancellation requested.',
            'data' => $this->transformService($service->fresh()->load(['product', 'order', 'invoice']), true),
        ]);
    }

    public function upgrade(Request $request, int $id): JsonResponse
    {
        $service = Service::query()
            ->with(['product', 'order', 'invoice'])
            ->where('user_id', $request->user()->id)
            ->findOrFail($id);

        return response()->json([
            'message' => 'Upgrade flow coming soon.',
            'data' => $this->transformService($service, true),
        ]);
    }

    private function transformService(Service $service, bool $withRelations = false): array
    {
        $panelUrl = app(PterodactylService::class)->panelUrl();
        $serverInfo = null;

        if ($withRelations && $service->pterodactyl_server_id) {
            try {
                $serverInfo = app(PterodactylService::class)->fetchServer($service->pterodactyl_server_id);
            } catch (\Throwable) {
                $serverInfo = null;
            }
        }

        return [
            'id' => $service->id,
            'status' => $service->status,
            'billing_cycle' => $service->billing_cycle,
            'next_due_date' => $service->next_due_date?->toDateString(),
            'pterodactyl_server_id' => $service->pterodactyl_server_id,
            'pterodactyl_node_id' => $service->pterodactyl_node_id,
            'pterodactyl_egg_id' => $service->pterodactyl_egg_id,
            'pterodactyl_allocation_id' => $service->pterodactyl_allocation_id,
            'pterodactyl_identifier' => is_array($serverInfo) ? ($serverInfo['identifier'] ?? null) : null,
            'pterodactyl_server_status' => is_array($serverInfo) ? ($serverInfo['status'] ?? null) : null,
            'pterodactyl_node_name' => is_array($serverInfo)
                ? ($serverInfo['relationships']['node']['attributes']['name'] ?? null)
                : null,
            'pterodactyl_panel_url' => $panelUrl,
            'provisioning_limits' => $withRelations ? $this->resolveProvisioningLimits($service) : null,
            'created_at' => $service->created_at?->toISOString(),
            'updated_at' => $service->updated_at?->toISOString(),
            'product' => $service->product ? [
                'id' => $service->product->id,
                'name' => $service->product->name,
                'slug' => $service->product->slug,
            ] : null,
            'order' => $withRelations && $service->order ? [
                'id' => $service->order->id,
                'status' => $service->order->status,
            ] : null,
            'invoice' => $withRelations && $service->invoice ? [
                'id' => $service->invoice->id,
                'status' => $service->invoice->status,
                'total' => (float) $service->invoice->total,
                'due_date' => $service->invoice->due_date?->toDateString(),
            ] : null,
        ];
    }

    /**
     * @return array{memory:int,cpu:int,disk:int}
     */
    private function resolveProvisioningLimits(Service $service): array
    {
        $limits = [
            'memory' => 2048,
            'cpu' => 100,
            'disk' => 10240,
        ];

        $order = $service->relationLoaded('order') ? $service->order : $service->order()->with('configurations')->first();
        if (! $order || ! $order->relationLoaded('configurations')) {
            return $limits;
        }

        foreach ($order->configurations as $configuration) {
            $key = strtolower((string) $configuration->configuration_key);
            $value = (int) $configuration->selected_value;
            if ($value <= 0) {
                continue;
            }

            if (in_array($key, ['ram', 'memory'], true)) {
                $limits['memory'] = $value;
            } elseif ($key === 'cpu') {
                $limits['cpu'] = $value;
            } elseif (in_array($key, ['disk', 'storage'], true)) {
                $limits['disk'] = $value;
            }
        }

        return $limits;
    }
}
