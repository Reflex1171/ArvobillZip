<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductConfiguration;
use Illuminate\Http\JsonResponse;

class ProductConfigurationController extends Controller
{
    public function index(string $slug): JsonResponse
    {
        $product = Product::query()
            ->where('slug', $slug)
            ->where('is_active', true)
            ->firstOrFail();

        $configurations = ProductConfiguration::query()
            ->with(['options' => fn ($query) => $query->where('is_active', true)->orderBy('id')])
            ->where('product_id', $product->id)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get()
            ->map(fn (ProductConfiguration $configuration) => [
                'id' => $configuration->id,
                'product_id' => $configuration->product_id,
                'name' => $configuration->name,
                'key' => $configuration->key,
                'input_type' => $configuration->input_type,
                'required' => (bool) $configuration->required,
                'sort_order' => (int) $configuration->sort_order,
                'created_at' => $configuration->created_at?->toISOString(),
                'updated_at' => $configuration->updated_at?->toISOString(),
                'options' => $configuration->options->map(fn ($option) => [
                    'id' => $option->id,
                    'product_configuration_id' => $option->product_configuration_id,
                    'label' => $option->label,
                    'value' => $option->value,
                    'price_modifier' => $option->price_modifier !== null
                        ? (float) $option->price_modifier
                        : null,
                    'is_active' => (bool) $option->is_active,
                    'is_default' => (bool) $option->is_default,
                    'created_at' => $option->created_at?->toISOString(),
                    'updated_at' => $option->updated_at?->toISOString(),
                ])->values(),
            ])->values();

        return response()->json([
            'data' => $configurations,
        ]);
    }
}
