<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Services\ThemeSettingService;
use Illuminate\Http\JsonResponse;

class ThemeController extends Controller
{
    public function __construct(private readonly ThemeSettingService $themeService)
    {
    }

    public function __invoke(): JsonResponse
    {
        return response()->json([
            'data' => $this->themeService->getTheme(),
        ]);
    }
}
