<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\ProductCategory;
use Illuminate\Http\JsonResponse;

class CategoryController extends Controller
{
    public function index(): JsonResponse
    {
        $categories = ProductCategory::query()
            ->withCount(['products as active_products_count' => fn ($query) => $query->where('is_active', true)])
            ->orderBy('name')
            ->get()
            ->map(fn (ProductCategory $category) => $this->transformCategory($category));

        return response()->json([
            'data' => $categories,
        ]);
    }

    public function products(string $slug): JsonResponse
    {
        $category = ProductCategory::query()
            ->where('slug', $slug)
            ->firstOrFail();

        $products = $category->products()
            ->where('is_active', true)
            ->orderBy('name')
            ->get()
            ->map(function ($product) use ($category) {
                return [
                    'id' => $product->id,
                    'name' => $product->name,
                    'slug' => $product->slug,
                    'description' => $product->description,
                    'category_id' => $product->category_id,
                    'category' => $this->transformCategory($category),
                    'price_monthly' => (float) $product->price_monthly,
                    'setup_fee' => $product->setup_fee !== null ? (float) $product->setup_fee : null,
                    'is_active' => $product->is_active,
                    'created_at' => $product->created_at?->toISOString(),
                    'updated_at' => $product->updated_at?->toISOString(),
                ];
            });

        return response()->json([
            'category' => $this->transformCategory($category),
            'data' => $products,
        ]);
    }

    private function transformCategory(ProductCategory $category): array
    {
        return [
            'id' => $category->id,
            'name' => $category->name,
            'slug' => $category->slug,
            'description' => $category->description,
            'active_products_count' => $category->active_products_count ?? null,
        ];
    }
}
