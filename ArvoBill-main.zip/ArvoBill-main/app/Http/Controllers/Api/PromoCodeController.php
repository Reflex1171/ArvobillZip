<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductConfigurationOption;
use App\Services\Discounts\PromoCodeService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class PromoCodeController extends Controller
{
    public function validateCode(Request $request, PromoCodeService $promoCodeService): JsonResponse
    {
        $validated = $request->validate([
            'code' => ['required', 'string', 'max:64'],
            'product_slug' => ['required', 'string'],
            'configurations' => ['nullable', 'array'],
        ]);

        $product = Product::query()
            ->with([
                'configurations' => fn ($query) => $query->orderBy('sort_order')->orderBy('id'),
                'configurations.options' => fn ($query) => $query->where('is_active', true)->orderBy('id'),
            ])
            ->where('slug', $validated['product_slug'])
            ->where('is_active', true)
            ->firstOrFail();

        $configurations = is_array($validated['configurations'] ?? null)
            ? $validated['configurations']
            : [];

        $modifiersTotal = 0.0;
        foreach ($product->configurations as $configuration) {
            $selectedValueRaw = $configurations[$configuration->key] ?? null;
            $selectedValue = is_scalar($selectedValueRaw)
                ? trim((string) $selectedValueRaw)
                : '';

            if ($selectedValue === '') {
                continue;
            }

            $selectedOption = $configuration->options->first(
                fn (ProductConfigurationOption $option) => $option->value === $selectedValue,
            );

            if (! $selectedOption) {
                throw ValidationException::withMessages([
                    "configurations.{$configuration->key}" => "Invalid value selected for {$configuration->name}.",
                ]);
            }

            $modifiersTotal += (float) ($selectedOption->price_modifier ?? 0);
        }

        $subtotal = (float) $product->price_monthly + (float) ($product->setup_fee ?? 0) + $modifiersTotal;

        $resolved = $promoCodeService->resolve(
            (string) $validated['code'],
            $request->user(),
            $product,
            $subtotal,
            $request,
        );

        return response()->json([
            'data' => [
                'code' => $resolved['code'],
                'discount_amount' => $resolved['discount_amount'],
                'subtotal' => round($subtotal, 2),
                'final_total' => $resolved['final_total'],
                'promo' => $resolved['promo_code'] ? [
                    'type' => $resolved['promo_code']->type,
                    'value' => (float) $resolved['promo_code']->value,
                    'affiliate_exclusive' => (bool) $resolved['promo_code']->affiliate_exclusive,
                    'disables_affiliate' => (bool) $resolved['promo_code']->disables_affiliate,
                ] : null,
            ],
        ]);
    }
}