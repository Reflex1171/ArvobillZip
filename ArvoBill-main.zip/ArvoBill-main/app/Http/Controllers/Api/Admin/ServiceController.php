<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Service;
use App\Support\BillingCycle;
use App\Services\Email\EmailNotificationService;
use App\Services\Billing\ServiceRenewalService;
use App\Services\Infrastructure\PterodactylService;
use App\Services\Infrastructure\ServiceProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Validation\ValidationException;

class ServiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $status = $request->query('status');
        $productId = $request->query('product_id');

        $services = Service::query()
            ->with(['user', 'product', 'order', 'invoice', 'defaultPaymentMethod'])
            ->when($status, fn ($query, $value) => $query->where('status', $value))
            ->when($productId, fn ($query, $value) => $query->where('product_id', $value))
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Service $service) => $this->transformService($service))
            ->values();

        return response()->json([
            'data' => $services,
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $service = Service::query()
            ->with(['user', 'product', 'order.configurations', 'invoice', 'defaultPaymentMethod'])
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformService($service, true),
        ]);
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:pending,provisioning,active,suspended,cancelled,failed'],
        ]);

        $service = Service::query()->findOrFail($id);
        $service->status = $validated['status'];
        $service->save();

        return response()->json([
            'message' => 'Service status updated successfully.',
            'data' => $this->transformService($service->fresh()->load(['user', 'product', 'order', 'invoice']), true),
        ]);
    }

    public function suspend(Request $request, int $id): JsonResponse
    {
        $service = Service::query()->findOrFail($id);
        $this->ensureAdminRole($request);

        if ($service->pterodactyl_server_id) {
            app(PterodactylService::class)->suspendServer($service->pterodactyl_server_id);
        }

        $service->status = 'suspended';
        $service->save();

        if ($service->relationLoaded('user') ? $service->user : $service->user()->exists()) {
            $service->loadMissing('user', 'product');
            if ($service->user) {
                app(EmailNotificationService::class)->queueToUser(
                    $service->user,
                    'Service #'.$service->id.' suspended',
                    'Your service has been suspended',
                    [
                        'Service #'.$service->id.' for '.$service->product?->name.' has been suspended.',
                        'Please contact support if this was unexpected.',
                    ],
                    'Open Support',
                    url('/client/support'),
                    'service_suspended',
                    ['service_id' => $service->id],
                );
            }
        }

        return response()->json([
            'message' => 'Service suspended successfully.',
            'data' => $this->transformService($service->fresh()->load(['user', 'product', 'order', 'invoice']), true),
        ]);
    }

    public function unsuspend(Request $request, int $id): JsonResponse
    {
        $service = Service::query()->findOrFail($id);
        $this->ensureAdminRole($request);

        if ($service->status !== 'suspended') {
            return response()->json([
                'message' => 'Service is not suspended.',
                'data' => $this->transformService($service->load(['user', 'product', 'order', 'invoice']), true),
            ]);
        }

        if ($service->pterodactyl_server_id) {
            app(PterodactylService::class)->unsuspendServer($service->pterodactyl_server_id);
        }

        $service->status = 'active';
        $service->save();

        return response()->json([
            'message' => 'Service unsuspended successfully.',
            'data' => $this->transformService($service->fresh()->load(['user', 'product', 'order', 'invoice']), true),
        ]);
    }

    public function provision(Request $request, int $id): JsonResponse
    {
        $this->ensureAdminRole($request);

        $validated = $request->validate([
            'node_id' => ['required', 'integer', 'min:1'],
            'egg_id' => ['required', 'integer', 'min:1'],
            'allocation_id' => ['required', 'integer', 'min:1'],
            'nest_id' => ['required', 'integer', 'min:1'],
            'limits.memory' => ['nullable', 'integer', 'min:256'],
            'limits.cpu' => ['nullable', 'integer', 'min:10'],
            'limits.disk' => ['nullable', 'integer', 'min:1024'],
        ]);

        $service = Service::query()
            ->with(['user', 'product', 'order.configurations', 'invoice'])
            ->findOrFail($id);

        if ($service->pterodactyl_server_id) {
            throw ValidationException::withMessages([
                'service' => 'Service is already provisioned.',
            ]);
        }

        try {
            $limits = $this->resolveProvisioningLimits($service, $validated['limits'] ?? []);
            $pterodactylService = app(PterodactylService::class);
            $panelUserId = $pterodactylService->resolvePanelUserId($service->user);
            $egg = $pterodactylService->fetchEggDetails(
                (int) $validated['nest_id'],
                (int) $validated['egg_id'],
            );

            $environment = collect($egg['relationships']['variables']['data'] ?? [])
                ->mapWithKeys(function (array $variable): array {
                    $attributes = $variable['attributes'] ?? [];
                    $envVariable = (string) ($attributes['env_variable'] ?? '');
                    if ($envVariable === '') {
                        return [];
                    }

                    return [
                        $envVariable => (string) ($attributes['default_value'] ?? ''),
                    ];
                })
                ->all();

            $server = $pterodactylService->createServer([
                'name' => 'svc-'.$service->id.'-'.$service->product->slug,
                'user' => $panelUserId,
                'egg' => (int) $validated['egg_id'],
                'docker_image' => (string) ($egg['docker_image'] ?? ''),
                'startup' => (string) ($egg['startup'] ?? ''),
                'environment' => $environment,
                'limits' => [
                    'memory' => $limits['memory'],
                    'swap' => 0,
                    'disk' => $limits['disk'],
                    'io' => 500,
                    'cpu' => $limits['cpu'],
                    'threads' => null,
                ],
                'feature_limits' => [
                    'databases' => 0,
                    'allocations' => 1,
                    'backups' => 2,
                ],
                'allocation' => [
                    'default' => (int) $validated['allocation_id'],
                ],
            ]);

            $service->pterodactyl_server_id = (string) ($server['id'] ?? '');
            $service->pterodactyl_node_id = (int) $validated['node_id'];
            $service->pterodactyl_egg_id = (int) $validated['egg_id'];
            $service->pterodactyl_allocation_id = (int) $validated['allocation_id'];
            $service->status = 'active';
            $service->provisioning_error = null;
            $service->save();
        } catch (\Throwable $exception) {
            app(ServiceProvisioner::class)->markProvisioningFailed($service, $exception->getMessage());
            throw ValidationException::withMessages([
                'service' => $exception->getMessage(),
            ]);
        }

        return response()->json([
            'message' => 'Service provisioned on Pterodactyl successfully.',
            'data' => $this->transformService(
                $service->fresh()->load(['user', 'product', 'order.configurations', 'invoice']),
                true,
            ),
        ]);
    }

    public function deletePterodactylServer(Request $request, int $id): JsonResponse
    {
        $this->ensureAdminRole($request);

        $service = Service::query()
            ->with(['user', 'product', 'order.configurations', 'invoice'])
            ->findOrFail($id);

        if (! $service->pterodactyl_server_id) {
            throw ValidationException::withMessages([
                'service' => 'Service is not provisioned on Pterodactyl.',
            ]);
        }

        app(PterodactylService::class)->deleteServer($service->pterodactyl_server_id);

        $service->pterodactyl_server_id = null;
        $service->pterodactyl_node_id = null;
        $service->pterodactyl_egg_id = null;
        $service->pterodactyl_allocation_id = null;
        $service->status = 'pending';
        $service->provisioning_error = null;
        $service->save();

        return response()->json([
            'message' => 'Pterodactyl server deleted successfully.',
            'data' => $this->transformService($service->fresh()->load(['user', 'product', 'order.configurations', 'invoice']), true),
        ]);
    }

    public function retryProvisioning(Request $request, int $id): JsonResponse
    {
        $this->ensureAdminRole($request);

        $service = Service::query()
            ->with(['user', 'product', 'order.configurations', 'invoice'])
            ->findOrFail($id);

        if (! $service->product || $service->product->infrastructure_type !== 'pterodactyl') {
            throw ValidationException::withMessages([
                'service' => 'This service product is not configured for Pterodactyl provisioning.',
            ]);
        }

        $dispatched = app(ServiceProvisioner::class)->dispatchProvisioning($service);

        return response()->json([
            'message' => $dispatched
                ? 'Provisioning retry queued.'
                : 'Service is already active or currently provisioning.',
            'data' => $this->transformService(
                $service->fresh()->load(['user', 'product', 'order.configurations', 'invoice']),
                true,
            ),
        ]);
    }

    public function forceRenew(int $id, ServiceRenewalService $serviceRenewalService): JsonResponse
    {
        $service = Service::query()
            ->with(['user', 'product', 'order.configurations', 'invoice', 'defaultPaymentMethod'])
            ->findOrFail($id);

        $invoice = $serviceRenewalService->forceRenew($service);

        return response()->json([
            'message' => 'Renewal processed.',
            'data' => [
                'service' => $this->transformService($service->fresh()->load(['user', 'product', 'order.configurations', 'invoice', 'defaultPaymentMethod']), true),
                'invoice' => [
                    'id' => $invoice->id,
                    'status' => $invoice->status,
                    'total' => (float) $invoice->total,
                    'type' => $invoice->type,
                ],
            ],
        ]);
    }

    private function transformService(Service $service, bool $withRelations = false): array
    {
        $provisioningLimits = $withRelations ? $this->resolveProvisioningLimits($service) : null;
        $panelUrl = app(PterodactylService::class)->panelUrl();
        $serverInfo = null;

        if ($withRelations && $service->pterodactyl_server_id) {
            try {
                $serverInfo = app(PterodactylService::class)->fetchServer($service->pterodactyl_server_id);
            } catch (\Throwable) {
                $serverInfo = null;
            }
        }

        return [
            'id' => $service->id,
            'status' => $service->status,
            'billing_cycle' => $this->billingCycleText($service),
            'billing_type' => $this->billingType($service),
            'billing_interval' => $this->billingInterval($service),
            'billing_period' => $this->billingPeriod($service),
            'billing_summary' => $this->billingSummary($service),
            'auto_renew' => (bool) $service->auto_renew,
            'renewal_failure_count' => (int) $service->renewal_failure_count,
            'next_due_at' => ($service->next_due_at ?? $service->next_due_date)?->toDateString(),
            'next_due_date' => ($service->next_due_at ?? $service->next_due_date)?->toDateString(),
            'pterodactyl_server_id' => $service->pterodactyl_server_id,
            'pterodactyl_node_id' => $service->pterodactyl_node_id,
            'pterodactyl_egg_id' => $service->pterodactyl_egg_id,
            'pterodactyl_allocation_id' => $service->pterodactyl_allocation_id,
            'pterodactyl_identifier' => is_array($serverInfo) ? ($serverInfo['identifier'] ?? null) : null,
            'pterodactyl_server_status' => is_array($serverInfo) ? ($serverInfo['status'] ?? null) : null,
            'pterodactyl_node_name' => is_array($serverInfo)
                ? ($serverInfo['relationships']['node']['attributes']['name'] ?? null)
                : null,
            'pterodactyl_panel_url' => $panelUrl,
            'provisioning_limits' => $provisioningLimits,
            'provisioning_error' => $service->provisioning_error,
            'created_at' => $service->created_at?->toISOString(),
            'updated_at' => $service->updated_at?->toISOString(),
            'user' => $service->user ? [
                'id' => $service->user->id,
                'name' => $service->user->name,
                'email' => $service->user->email,
            ] : null,
            'product' => $service->product ? [
                'id' => $service->product->id,
                'name' => $service->product->name,
                'slug' => $service->product->slug,
            ] : null,
            'order' => $withRelations && $service->order ? [
                'id' => $service->order->id,
                'status' => $service->order->status,
            ] : null,
            'invoice' => $withRelations && $service->invoice ? [
                'id' => $service->invoice->id,
                'status' => $service->invoice->status,
                'total' => (float) $service->invoice->total,
                'due_date' => $service->invoice->due_date?->toDateString(),
            ] : null,
            'default_payment_method' => $withRelations && $service->defaultPaymentMethod ? [
                'id' => $service->defaultPaymentMethod->id,
                'provider' => $service->defaultPaymentMethod->provider,
                'label' => $service->defaultPaymentMethod->label,
                'masked_details' => $service->defaultPaymentMethod->masked_details,
            ] : null,
        ];
    }

    private function billingType(Service $service): string
    {
        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];

        return BillingCycle::normalizeBillingType((string) ($snapshot['billing_type'] ?? 'recurring'));
    }

    private function billingInterval(Service $service): ?int
    {
        if ($this->billingType($service) === 'one_time') {
            return null;
        }

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];

        return BillingCycle::resolveInterval($snapshot['billing_interval'] ?? 1);
    }

    private function billingPeriod(Service $service): ?string
    {
        if ($this->billingType($service) === 'one_time') {
            return null;
        }

        $snapshot = is_array($service->billing_snapshot) ? $service->billing_snapshot : [];

        return BillingCycle::normalizePeriod((string) ($snapshot['billing_period'] ?? 'month'));
    }

    private function billingSummary(Service $service): string
    {
        $type = $this->billingType($service);
        $interval = $this->billingInterval($service) ?? 1;
        $period = $this->billingPeriod($service) ?? 'month';

        return BillingCycle::billingSummary($type, $interval, $period);
    }

    private function billingCycleText(Service $service): string
    {
        $interval = $this->billingInterval($service);
        $period = $this->billingPeriod($service);

        if ($interval === null || $period === null) {
            return 'one-time';
        }

        return BillingCycle::intervalSummary($interval, $period);
    }

    /**
     * @param  array<string, mixed>  $input
     * @return array{memory:int,cpu:int,disk:int}
     */
    private function resolveProvisioningLimits(Service $service, array $input = []): array
    {
        $resolved = [
            'memory' => 2048,
            'cpu' => 100,
            'disk' => 10240,
        ];

        $order = $service->relationLoaded('order') ? $service->order : $service->order()->with('configurations')->first();
        if ($order && $order->relationLoaded('configurations')) {
            foreach ($order->configurations as $configuration) {
                $key = strtolower((string) $configuration->configuration_key);
                $value = (int) $configuration->selected_value;
                if ($value <= 0) {
                    continue;
                }

                if (in_array($key, ['ram', 'memory'], true)) {
                    $resolved['memory'] = $value;
                } elseif ($key === 'cpu') {
                    $resolved['cpu'] = $value;
                } elseif (in_array($key, ['disk', 'storage'], true)) {
                    $resolved['disk'] = $value;
                }
            }
        }

        foreach (['memory', 'cpu', 'disk'] as $field) {
            if (isset($input[$field]) && (int) $input[$field] > 0) {
                $resolved[$field] = (int) $input[$field];
            }
        }

        return $resolved;
    }

    private function ensureAdminRole(Request $request): void
    {
        if (! in_array((string) $request->user()->role, ['admin', 'superuser'], true)) {
            abort(403, 'Only admins can perform this action.');
        }
    }
}
