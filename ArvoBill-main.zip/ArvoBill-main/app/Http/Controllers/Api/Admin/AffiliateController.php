<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\AffiliateEarning;
use App\Models\AffiliateSetting;
use App\Models\User;
use App\Services\Affiliates\AffiliateService;
use App\Services\Billing\BalanceService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class AffiliateController extends Controller
{
    public function index(): JsonResponse
    {
        $settings = AffiliateSetting::query()->first();
        $users = User::query()
            ->whereNotNull('affiliate_code')
            ->withCount('referrals')
            ->withSum(['affiliateEarnings as pending_earnings' => fn ($query) => $query->where('status', 'pending')], 'amount')
            ->withSum(['affiliateEarnings as approved_earnings' => fn ($query) => $query->whereIn('status', ['approved', 'paid'])], 'amount')
            ->orderByDesc('created_at')
            ->get();

        $earnings = AffiliateEarning::query()
            ->with(['affiliateUser', 'referredUser', 'invoice'])
            ->latest('id')
            ->limit(200)
            ->get();

        return response()->json([
            'data' => [
                'settings' => [
                    'enabled' => (bool) ($settings?->enabled ?? true),
                    'commission_percent' => (float) ($settings?->commission_percent ?? 10),
                    'commission_scope' => (string) ($settings?->commission_scope ?? 'first_invoice'),
                    'first_invoice_commission_percent' => (float) ($settings?->first_invoice_commission_percent ?? 15),
                    'recurring_commission_percent' => (float) ($settings?->recurring_commission_percent ?? 5),
                    'approval_delay_days' => (int) ($settings?->approval_delay_days ?? 30),
                    'eligible_product_ids' => $settings?->eligible_product_ids ?? [],
                ],
                'affiliates' => $users->map(fn (User $user) => [
                    'id' => $user->id,
                    'name' => $user->name,
                    'email' => $user->email,
                    'affiliate_code' => $user->affiliate_code,
                    'affiliate_balance' => (float) $user->affiliate_balance,
                    'referrals_count' => (int) $user->referrals_count,
                    'pending_earnings' => (float) ($user->pending_earnings ?? 0),
                    'approved_earnings' => (float) ($user->approved_earnings ?? 0),
                ])->values(),
                'earnings' => $earnings->map(fn (AffiliateEarning $earning) => [
                    'id' => $earning->id,
                    'affiliate_user' => $earning->affiliateUser ? [
                        'id' => $earning->affiliateUser->id,
                        'name' => $earning->affiliateUser->name,
                        'email' => $earning->affiliateUser->email,
                    ] : null,
                    'referred_user' => $earning->referredUser ? [
                        'id' => $earning->referredUser->id,
                        'name' => $earning->referredUser->name,
                        'email' => $earning->referredUser->email,
                    ] : null,
                    'invoice_id' => $earning->invoice_id,
                    'amount' => (float) $earning->amount,
                    'status' => $earning->status,
                    'eligible_at' => $earning->eligible_at?->toISOString(),
                    'approved_at' => $earning->approved_at?->toISOString(),
                    'paid_at' => $earning->paid_at?->toISOString(),
                    'created_at' => $earning->created_at?->toISOString(),
                ])->values(),
            ],
        ]);
    }

    public function updateSettings(Request $request, AffiliateService $affiliateService): JsonResponse
    {
        $validated = $request->validate([
            'enabled' => ['required', 'boolean'],
            'commission_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'commission_scope' => ['required', 'in:first_invoice,recurring,tiered'],
            'first_invoice_commission_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'recurring_commission_percent' => ['required', 'numeric', 'min:0', 'max:100'],
            'approval_delay_days' => ['required', 'integer', 'min:0', 'max:365'],
            'eligible_product_ids' => ['nullable', 'array'],
            'eligible_product_ids.*' => ['integer'],
        ]);

        $settings = $affiliateService->getSettings();
        $settings->fill([
            'enabled' => (bool) $validated['enabled'],
            'commission_percent' => (float) $validated['commission_percent'],
            'commission_scope' => $validated['commission_scope'],
            'first_invoice_commission_percent' => (float) $validated['first_invoice_commission_percent'],
            'recurring_commission_percent' => (float) $validated['recurring_commission_percent'],
            'approval_delay_days' => (int) $validated['approval_delay_days'],
            'eligible_product_ids' => $validated['eligible_product_ids'] ?? [],
        ]);
        $settings->save();

        return response()->json(['message' => 'Affiliate settings updated.']);
    }

    public function updateEarningStatus(Request $request, int $id, BalanceService $balanceService): JsonResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:approved,rejected,paid'],
        ]);

        $earning = AffiliateEarning::query()->with(['affiliateUser'])->findOrFail($id);
        $actor = $request->user();

        DB::transaction(function () use ($earning, $validated, $balanceService, $actor): void {
            $fresh = AffiliateEarning::query()->lockForUpdate()->with('affiliateUser')->findOrFail($earning->id);
            $newStatus = $validated['status'];

            if ($newStatus === 'approved' && $fresh->status === 'pending') {
                $fresh->status = 'approved';
                $fresh->approved_at = now();
                $fresh->approved_by = $actor->id;
                $fresh->save();

                if ($fresh->affiliateUser) {
                    $balanceService->credit(
                        $fresh->affiliateUser,
                        (float) $fresh->amount,
                        'credit',
                        null,
                        'affiliate',
                        'affiliate-earning:'.$fresh->id,
                        'Affiliate commission approved',
                    );

                    $fresh->affiliateUser->affiliate_balance = (float) $fresh->affiliateUser->affiliate_balance + (float) $fresh->amount;
                    $fresh->affiliateUser->save();
                }

                return;
            }

            if ($newStatus === 'paid' && $fresh->status !== 'approved') {
                throw ValidationException::withMessages([
                    'status' => 'Only approved earnings can be marked paid.',
                ]);
            }

            if ($newStatus === 'rejected' && $fresh->status !== 'pending') {
                throw ValidationException::withMessages([
                    'status' => 'Only pending earnings can be rejected.',
                ]);
            }

            if ($newStatus === 'approved' && $fresh->status !== 'pending') {
                throw ValidationException::withMessages([
                    'status' => 'Only pending earnings can be approved.',
                ]);
            }

            $fresh->status = $newStatus;
            if ($newStatus === 'paid') {
                $fresh->paid_at = now();
            }
            $fresh->save();
        });

        return response()->json(['message' => 'Affiliate earning updated.']);
    }
}
