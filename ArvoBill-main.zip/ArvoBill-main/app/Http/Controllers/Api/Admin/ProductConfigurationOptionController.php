<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\ProductConfiguration;
use App\Models\ProductConfigurationOption;
use App\Services\Infrastructure\ServiceProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class ProductConfigurationOptionController extends Controller
{
    public function store(Request $request, int $id): JsonResponse
    {
        $configuration = ProductConfiguration::query()
            ->with('product')
            ->findOrFail($id);

        $validated = $request->validate([
            'label' => ['required', 'string', 'max:255'],
            'value' => ['required', 'string', 'max:255'],
            'price_modifier' => ['nullable', 'numeric'],
            'is_active' => ['required', 'boolean'],
            'is_default' => ['required', 'boolean'],
        ]);

        if ($validated['is_default'] && ! $validated['is_active']) {
            throw ValidationException::withMessages([
                'is_default' => 'Default option must be active.',
            ]);
        }

        $this->validatePterodactylReservedOptionContract(
            $configuration,
            (string) $validated['value'],
        );

        $hasActiveDefault = ProductConfigurationOption::query()
            ->where('product_configuration_id', $configuration->id)
            ->where('is_active', true)
            ->where('is_default', true)
            ->exists();
        if ($this->isProtectedPterodactylConfiguration($configuration) && ! $hasActiveDefault && ! $validated['is_default']) {
            throw ValidationException::withMessages([
                'is_default' => 'Required Pterodactyl configurations must always have a default option.',
            ]);
        }

        $option = DB::transaction(function () use ($configuration, $validated) {
            if ($validated['is_default']) {
                ProductConfigurationOption::query()
                    ->where('product_configuration_id', $configuration->id)
                    ->update(['is_default' => false]);
            }

            return ProductConfigurationOption::create([
                'product_configuration_id' => $configuration->id,
                'label' => $validated['label'],
                'value' => $validated['value'],
                'price_modifier' => $validated['price_modifier'] ?? null,
                'is_active' => $validated['is_active'],
                'is_default' => $validated['is_default'],
            ]);
        });

        return response()->json([
            'message' => 'Configuration option created successfully.',
            'data' => $this->transformOption($option),
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $option = ProductConfigurationOption::query()
            ->with('configuration.product')
            ->findOrFail($id);
        $configuration = $option->configuration;

        $validated = $request->validate([
            'label' => ['required', 'string', 'max:255'],
            'value' => ['required', 'string', 'max:255'],
            'price_modifier' => ['nullable', 'numeric'],
            'is_active' => ['required', 'boolean'],
            'is_default' => ['required', 'boolean'],
        ]);

        if ($validated['is_default'] && ! $validated['is_active']) {
            throw ValidationException::withMessages([
                'is_default' => 'Default option must be active.',
            ]);
        }

        $this->validatePterodactylReservedOptionContract(
            $configuration,
            (string) $validated['value'],
        );

        DB::transaction(function () use ($option, $validated, $configuration) {
            if ($validated['is_default']) {
                ProductConfigurationOption::query()
                    ->where('product_configuration_id', $option->product_configuration_id)
                    ->where('id', '!=', $option->id)
                    ->update(['is_default' => false]);
            }

            $option->update([
                'label' => $validated['label'],
                'value' => $validated['value'],
                'price_modifier' => $validated['price_modifier'] ?? null,
                'is_active' => $validated['is_active'],
                'is_default' => $validated['is_active'] ? $validated['is_default'] : false,
            ]);

            if ($this->isProtectedPterodactylConfiguration($configuration)) {
                $hasActiveDefault = ProductConfigurationOption::query()
                    ->where('product_configuration_id', $configuration->id)
                    ->where('is_active', true)
                    ->where('is_default', true)
                    ->exists();

                if (! $hasActiveDefault) {
                    throw ValidationException::withMessages([
                        'is_default' => 'Required Pterodactyl configurations must always have an active default option.',
                    ]);
                }
            }
        });

        return response()->json([
            'message' => 'Configuration option updated successfully.',
            'data' => $this->transformOption($option->fresh()),
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $option = ProductConfigurationOption::query()
            ->with('configuration.product')
            ->findOrFail($id);

        if ($this->isProtectedPterodactylConfiguration($option->configuration)) {
            $activeCount = ProductConfigurationOption::query()
                ->where('product_configuration_id', $option->product_configuration_id)
                ->where('is_active', true)
                ->count();
            if ($activeCount <= 1) {
                throw ValidationException::withMessages([
                    'option' => 'Required Pterodactyl configurations must keep at least one active option.',
                ]);
            }
        }

        $option->delete();

        return response()->json([
            'message' => 'Configuration option deleted successfully.',
        ]);
    }

    private function transformOption(ProductConfigurationOption $option): array
    {
        return [
            'id' => $option->id,
            'product_configuration_id' => $option->product_configuration_id,
            'label' => $option->label,
            'value' => $option->value,
            'price_modifier' => $option->price_modifier !== null
                ? (float) $option->price_modifier
                : null,
            'is_active' => (bool) $option->is_active,
            'is_default' => (bool) $option->is_default,
            'created_at' => $option->created_at?->toISOString(),
            'updated_at' => $option->updated_at?->toISOString(),
        ];
    }

    private function isProtectedPterodactylConfiguration(ProductConfiguration $configuration): bool
    {
        return $configuration->product?->infrastructure_type === 'pterodactyl'
            && in_array(
                strtolower((string) $configuration->key),
                ServiceProvisioner::REQUIRED_PTERODACTYL_KEYS,
                true,
            );
    }

    private function validatePterodactylReservedOptionContract(
        ProductConfiguration $configuration,
        string $value,
    ): void {
        if (! $this->isStrictNumericPterodactylConfiguration($configuration)) {
            return;
        }

        if (! preg_match('/^\d+$/', trim($value))) {
            throw ValidationException::withMessages([
                'value' => 'RAM, Disk, CPU, Egg, and Location option values must be numeric for Pterodactyl products.',
            ]);
        }

        if ((int) $value <= 0) {
            throw ValidationException::withMessages([
                'value' => 'RAM, Disk, CPU, Egg, and Location option values must be greater than zero.',
            ]);
        }
    }

    private function isStrictNumericPterodactylConfiguration(ProductConfiguration $configuration): bool
    {
        if ($configuration->product?->infrastructure_type !== 'pterodactyl') {
            return false;
        }

        $key = strtolower((string) $configuration->key);

        return in_array($key, [
            ...ServiceProvisioner::REQUIRED_PTERODACTYL_KEYS,
            ...ServiceProvisioner::OPTIONAL_PTERODACTYL_KEYS,
        ], true);
    }
}
