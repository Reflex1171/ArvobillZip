<?php

namespace App\Http\Controllers\Api\Admin\Infrastructure;

use App\Http\Controllers\Controller;
use App\Services\Infrastructure\PterodactylService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PterodactylResourcesController extends Controller
{
    public function nodes(PterodactylService $pterodactylService): JsonResponse
    {
        $nodes = collect($pterodactylService->fetchNodes())
            ->map(fn (array $node) => [
                'id' => (int) ($node['id'] ?? 0),
                'name' => $node['name'] ?? null,
                'location_id' => $node['location_id'] ?? null,
                'memory' => (int) ($node['memory'] ?? 0),
                'disk' => (int) ($node['disk'] ?? 0),
                'allocated_resources' => [
                    'memory' => (int) ($node['allocated_resources']['memory'] ?? 0),
                    'disk' => (int) ($node['allocated_resources']['disk'] ?? 0),
                ],
                'server_count' => (int) ($node['relationships']['servers']['meta']['count'] ?? 0),
            ])
            ->values();

        return response()->json(['data' => $nodes]);
    }

    public function eggs(PterodactylService $pterodactylService): JsonResponse
    {
        $eggs = collect($pterodactylService->fetchEggs())
            ->map(fn (array $egg) => [
                'id' => (int) ($egg['id'] ?? 0),
                'name' => $egg['name'] ?? null,
                'nest' => $egg['nest_name'] ?? null,
                'docker_image' => $egg['docker_image'] ?? null,
                'startup' => $egg['startup'] ?? null,
                'nest_id' => (int) ($egg['nest'] ?? 0),
            ])
            ->values();

        return response()->json(['data' => $eggs]);
    }

    public function allocations(Request $request, PterodactylService $pterodactylService): JsonResponse
    {
        $validated = $request->validate([
            'node_id' => ['nullable', 'integer'],
        ]);

        $nodeId = isset($validated['node_id']) ? (int) $validated['node_id'] : null;
        $allocations = collect($pterodactylService->fetchAllocations($nodeId))
            ->map(fn (array $allocation) => [
                'id' => (int) ($allocation['id'] ?? 0),
                'node_id' => (int) ($allocation['node_id'] ?? 0),
                'ip' => $allocation['ip'] ?? null,
                'port' => (int) ($allocation['port'] ?? 0),
                'assigned' => (bool) ($allocation['assigned'] ?? false),
            ])
            ->values();

        return response()->json(['data' => $allocations]);
    }

    public function servers(PterodactylService $pterodactylService): JsonResponse
    {
        $servers = collect($pterodactylService->fetchServers())
            ->map(fn (array $server) => [
                'id' => (int) ($server['id'] ?? 0),
                'identifier' => $server['identifier'] ?? null,
                'name' => $server['name'] ?? null,
                'node' => $server['relationships']['node']['attributes']['name'] ?? null,
                'status' => $server['status'] ?? null,
                'uuid' => $server['uuid'] ?? null,
            ])
            ->values();

        return response()->json(['data' => $servers]);
    }
}
