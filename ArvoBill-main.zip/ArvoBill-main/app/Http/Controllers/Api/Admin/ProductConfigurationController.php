<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductConfiguration;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ProductConfigurationController extends Controller
{
    public function index(int $productId): JsonResponse
    {
        $product = Product::query()->findOrFail($productId);

        $configurations = ProductConfiguration::query()
            ->with('options')
            ->where('product_id', $product->id)
            ->orderBy('sort_order')
            ->orderBy('id')
            ->get()
            ->map(fn (ProductConfiguration $configuration) => $this->transformConfiguration($configuration))
            ->values();

        return response()->json([
            'data' => $configurations,
        ]);
    }

    public function store(Request $request, int $id): JsonResponse
    {
        $product = Product::query()->findOrFail($id);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'key' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('product_configurations', 'key')->where(
                    fn ($query) => $query->where('product_id', $product->id),
                ),
            ],
            'input_type' => ['required', 'in:buttons,select,dropdown'],
            'required' => ['required', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ]);

        $key = trim((string) ($validated['key'] ?? ''));
        if ($key === '') {
            $key = Str::snake($validated['name']);
        }

        $configuration = ProductConfiguration::create([
            'product_id' => $product->id,
            'name' => $validated['name'],
            'key' => $this->uniqueKey($product->id, $key),
            'input_type' => $validated['input_type'],
            'required' => $validated['required'],
            'sort_order' => $validated['sort_order'] ?? 0,
        ]);

        return response()->json([
            'message' => 'Configuration created successfully.',
            'data' => $this->transformConfiguration($configuration->fresh()->load('options')),
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $configuration = ProductConfiguration::query()->findOrFail($id);

        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'key' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('product_configurations', 'key')
                    ->ignore($configuration->id)
                    ->where(fn ($query) => $query->where('product_id', $configuration->product_id)),
            ],
            'input_type' => ['required', 'in:buttons,select,dropdown'],
            'required' => ['required', 'boolean'],
            'sort_order' => ['nullable', 'integer', 'min:0'],
        ]);

        $key = trim((string) ($validated['key'] ?? ''));
        if ($key === '') {
            $key = Str::snake($validated['name']);
        }

        $configuration->update([
            'name' => $validated['name'],
            'key' => $this->uniqueKey($configuration->product_id, $key, $configuration->id),
            'input_type' => $validated['input_type'],
            'required' => $validated['required'],
            'sort_order' => $validated['sort_order'] ?? $configuration->sort_order,
        ]);

        return response()->json([
            'message' => 'Configuration updated successfully.',
            'data' => $this->transformConfiguration($configuration->fresh()->load('options')),
        ]);
    }

    public function destroy(int $id): JsonResponse
    {
        $configuration = ProductConfiguration::query()->findOrFail($id);
        $configuration->delete();

        return response()->json([
            'message' => 'Configuration deleted successfully.',
        ]);
    }

    private function uniqueKey(int $productId, string $key, ?int $ignoreId = null): string
    {
        $normalized = Str::snake($key);
        $baseKey = $normalized !== '' ? $normalized : 'configuration';
        $candidate = $baseKey;
        $counter = 2;

        while (
            ProductConfiguration::query()
                ->where('product_id', $productId)
                ->where('key', $candidate)
                ->when($ignoreId !== null, fn ($query) => $query->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $candidate = "{$baseKey}_{$counter}";
            $counter++;
        }

        return $candidate;
    }

    private function transformConfiguration(ProductConfiguration $configuration): array
    {
        return [
            'id' => $configuration->id,
            'product_id' => $configuration->product_id,
            'name' => $configuration->name,
            'key' => $configuration->key,
            'input_type' => $configuration->input_type,
            'required' => (bool) $configuration->required,
            'sort_order' => (int) $configuration->sort_order,
            'created_at' => $configuration->created_at?->toISOString(),
            'updated_at' => $configuration->updated_at?->toISOString(),
            'options' => $configuration->options->map(fn ($option) => [
                'id' => $option->id,
                'product_configuration_id' => $option->product_configuration_id,
                'label' => $option->label,
                'value' => $option->value,
                'price_modifier' => $option->price_modifier !== null
                    ? (float) $option->price_modifier
                    : null,
                'is_active' => (bool) $option->is_active,
                'is_default' => (bool) $option->is_default,
                'created_at' => $option->created_at?->toISOString(),
                'updated_at' => $option->updated_at?->toISOString(),
            ])->values(),
        ];
    }
}
