<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Permission;
use App\Models\User;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;

class UserController extends Controller
{
    public function index(): JsonResponse
    {
        $users = User::query()
            ->with('permissions')
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'data' => $users->map(fn (User $user) => $this->transformUserSummary($user))->values(),
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $user = User::query()
            ->with([
                'permissions',
                'services.product',
                'orders.product',
                'invoices.order.product',
                'tickets',
            ])
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformUserDetail($user),
        ]);
    }

    public function updateRole(Request $request, int $id): JsonResponse
    {
        $actor = $request->user();
        $user = User::query()->with('permissions')->findOrFail($id);

        $validated = $request->validate([
            'role' => ['required', 'in:user,staff,admin,superuser'],
        ]);

        $targetRole = $validated['role'];

        if ($targetRole === 'superuser' && $actor->role !== 'superuser') {
            throw ValidationException::withMessages([
                'role' => 'Only superusers can promote users to superuser.',
            ]);
        }

        DB::transaction(function () use ($user, $targetRole) {
            $user->role = $targetRole;
            $user->save();

            if ($targetRole !== 'staff') {
                $user->permissions()->detach();
            }
        });

        return response()->json([
            'message' => 'User role updated successfully.',
            'data' => $this->transformUserDetail($user->fresh()->load([
                'permissions',
                'services.product',
                'orders.product',
                'invoices.order.product',
                'tickets',
            ])),
        ]);
    }

    public function updatePermissions(Request $request, int $id): JsonResponse
    {
        $user = User::query()->with('permissions')->findOrFail($id);

        $validated = $request->validate([
            'permissions' => ['required', 'array'],
            'permissions.*' => ['string', 'exists:permissions,key'],
        ]);

        if ($user->role !== 'staff') {
            throw ValidationException::withMessages([
                'permissions' => 'Explicit permissions can only be assigned to staff accounts.',
            ]);
        }

        $keys = collect($validated['permissions'])
            ->map(fn (mixed $value) => (string) $value)
            ->unique()
            ->values();

        $permissionIds = Permission::query()
            ->whereIn('key', $keys)
            ->pluck('id')
            ->all();

        $user->permissions()->sync($permissionIds);

        return response()->json([
            'message' => 'User permissions updated successfully.',
            'data' => $this->transformUserDetail($user->fresh()->load([
                'permissions',
                'services.product',
                'orders.product',
                'invoices.order.product',
                'tickets',
            ])),
        ]);
    }

    private function transformUserSummary(User $user): array
    {
        return [
            'id' => $user->id,
            'name' => $user->name,
            'email' => $user->email,
            'role' => $user->role,
            'created_at' => $user->created_at?->toISOString(),
            'permissions' => $user->resolvedPermissionKeys(),
        ];
    }

    private function transformUserDetail(User $user): array
    {
        $availablePermissions = Permission::query()
            ->orderBy('key')
            ->get(['key', 'description'])
            ->map(fn (Permission $permission) => [
                'key' => $permission->key,
                'description' => $permission->description,
            ])
            ->values();

        return [
            ...$this->transformUserSummary($user),
            'last_login_at' => null,
            'available_permissions' => $availablePermissions,
            'services' => $user->services->map(fn ($service) => [
                'id' => $service->id,
                'status' => $service->status,
                'created_at' => $service->created_at?->toISOString(),
                'product' => $service->product ? [
                    'id' => $service->product->id,
                    'name' => $service->product->name,
                ] : null,
            ])->values(),
            'orders' => $user->orders->map(fn ($order) => [
                'id' => $order->id,
                'status' => $order->status,
                'created_at' => $order->created_at?->toISOString(),
                'product' => $order->product ? [
                    'id' => $order->product->id,
                    'name' => $order->product->name,
                ] : null,
            ])->values(),
            'invoices' => $user->invoices->map(fn ($invoice) => [
                'id' => $invoice->id,
                'status' => $invoice->status,
                'total' => (float) $invoice->total,
                'created_at' => $invoice->created_at?->toISOString(),
            ])->values(),
            'tickets' => $user->tickets->map(fn ($ticket) => [
                'id' => $ticket->id,
                'subject' => $ticket->subject,
                'status' => $ticket->status,
                'priority' => $ticket->priority,
                'updated_at' => $ticket->updated_at?->toISOString(),
            ])->values(),
        ];
    }
}
