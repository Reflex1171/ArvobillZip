<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Order;
use App\Models\Service;
use App\Models\User;
use Illuminate\Http\JsonResponse;

class DashboardController extends Controller
{
    public function __invoke(): JsonResponse
    {
        $totalUsers = User::query()->count();

        $activeServices = Service::query()
            ->where('status', 'active')
            ->count();

        $monthlyRevenue = (float) (Invoice::query()
            ->where('status', 'paid')
            ->whereYear('created_at', now()->year)
            ->whereMonth('created_at', now()->month)
            ->sum('total') ?? 0);

        $pendingOrders = Order::query()
            ->where('status', 'pending')
            ->count();

        return response()->json([
            'data' => [
                'total_users' => $totalUsers,
                'active_services' => $activeServices,
                'monthly_revenue' => $monthlyRevenue,
                'pending_orders' => $pendingOrders,
            ],
        ]);
    }
}
