<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\PromoCode;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PromoCodeController extends Controller
{
    public function index(): JsonResponse
    {
        $promoCodes = PromoCode::query()
            ->with(['redemptions.user', 'redemptions.order', 'redemptions.invoice'])
            ->orderByDesc('created_at')
            ->get();

        return response()->json([
            'data' => $promoCodes->map(fn (PromoCode $promoCode) => $this->transformPromoCode($promoCode, true))->values(),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $this->validatePayload($request);

        $promoCode = PromoCode::query()->create($validated);

        return response()->json([
            'message' => 'Promo code created successfully.',
            'data' => $this->transformPromoCode($promoCode->fresh(), true),
        ], 201);
    }

    public function update(Request $request, int $id): JsonResponse
    {
        $promoCode = PromoCode::query()->findOrFail($id);
        $validated = $this->validatePayload($request, $promoCode->id);
        $promoCode->fill($validated);
        $promoCode->save();

        return response()->json([
            'message' => 'Promo code updated successfully.',
            'data' => $this->transformPromoCode($promoCode->fresh()->load(['redemptions.user', 'redemptions.order', 'redemptions.invoice']), true),
        ]);
    }

    public function toggle(int $id): JsonResponse
    {
        $promoCode = PromoCode::query()->findOrFail($id);
        $promoCode->is_active = ! $promoCode->is_active;
        $promoCode->save();

        return response()->json([
            'message' => 'Promo code status updated successfully.',
            'data' => $this->transformPromoCode($promoCode->fresh()->load(['redemptions.user', 'redemptions.order', 'redemptions.invoice']), true),
        ]);
    }

    private function validatePayload(Request $request, ?int $ignoreId = null): array
    {
        $uniqueRule = 'unique:promo_codes,code';
        if ($ignoreId !== null) {
            $uniqueRule .= ','.$ignoreId;
        }

        $validated = $request->validate([
            'code' => ['required', 'string', 'max:64', $uniqueRule],
            'type' => ['required', 'in:percentage,fixed'],
            'value' => ['required', 'numeric', 'min:0.01'],
            'max_uses' => ['nullable', 'integer', 'min:1'],
            'max_redemptions_per_user' => ['nullable', 'integer', 'min:1'],
            'duration_cycles' => ['nullable', 'integer', 'min:1'],
            'expires_at' => ['nullable', 'date'],
            'minimum_order_amount' => ['nullable', 'numeric', 'min:0'],
            'applies_to' => ['required', 'in:all,products,categories'],
            'eligible_product_ids' => ['nullable', 'array'],
            'eligible_product_ids.*' => ['integer'],
            'eligible_category_ids' => ['nullable', 'array'],
            'eligible_category_ids.*' => ['integer'],
            'affiliate_exclusive' => ['required', 'boolean'],
            'disables_affiliate' => ['required', 'boolean'],
            'once_per_user' => ['nullable', 'boolean'],
            'is_active' => ['required', 'boolean'],
        ]);

        $validated['code'] = strtoupper(trim((string) $validated['code']));
        if ($validated['type'] === 'percentage' && (float) $validated['value'] > 100) {
            $validated['value'] = 100;
        }
        if (isset($validated['max_redemptions_per_user'])) {
            $validated['once_per_user'] = (int) $validated['max_redemptions_per_user'] === 1;
        } elseif (! array_key_exists('once_per_user', $validated)) {
            $validated['once_per_user'] = false;
        }

        return $validated;
    }

    private function transformPromoCode(PromoCode $promoCode, bool $withRedemptions = false): array
    {
        return [
            'id' => $promoCode->id,
            'code' => $promoCode->code,
            'type' => $promoCode->type,
            'value' => (float) $promoCode->value,
            'max_uses' => $promoCode->max_uses,
            'max_redemptions_per_user' => $promoCode->max_redemptions_per_user,
            'duration_cycles' => $promoCode->duration_cycles,
            'uses' => (int) $promoCode->uses,
            'expires_at' => $promoCode->expires_at?->toISOString(),
            'minimum_order_amount' => $promoCode->minimum_order_amount !== null ? (float) $promoCode->minimum_order_amount : null,
            'applies_to' => $promoCode->applies_to,
            'eligible_product_ids' => $promoCode->eligible_product_ids ?? [],
            'eligible_category_ids' => $promoCode->eligible_category_ids ?? [],
            'affiliate_exclusive' => (bool) $promoCode->affiliate_exclusive,
            'disables_affiliate' => (bool) $promoCode->disables_affiliate,
            'once_per_user' => (bool) $promoCode->once_per_user,
            'is_active' => (bool) $promoCode->is_active,
            'created_at' => $promoCode->created_at?->toISOString(),
            'redemptions' => $withRedemptions
                ? $promoCode->redemptions->map(fn ($redemption) => [
                    'id' => $redemption->id,
                    'discount_amount' => (float) $redemption->discount_amount,
                    'created_at' => $redemption->created_at?->toISOString(),
                    'user' => $redemption->user ? [
                        'id' => $redemption->user->id,
                        'name' => $redemption->user->name,
                        'email' => $redemption->user->email,
                    ] : null,
                    'order_id' => $redemption->order_id,
                    'invoice_id' => $redemption->invoice_id,
                ])->values()
                : null,
        ];
    }
}
