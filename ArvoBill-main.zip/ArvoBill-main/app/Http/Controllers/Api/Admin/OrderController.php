<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $status = $request->query('status');

        $orders = Order::query()
            ->with(['user', 'product', 'invoice', 'configurations'])
            ->when($status, fn ($query, $value) => $query->where('status', $value))
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Order $order) => $this->transformOrder($order));

        return response()->json([
            'data' => $orders,
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $order = Order::query()
            ->with(['user', 'product', 'invoice.items', 'configurations'])
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformOrder($order, true),
        ]);
    }

    private function transformOrder(Order $order, bool $withInvoiceItems = false): array
    {
        return [
            'id' => $order->id,
            'status' => $order->status,
            'created_at' => $order->created_at?->toISOString(),
            'updated_at' => $order->updated_at?->toISOString(),
            'user' => $order->user ? [
                'id' => $order->user->id,
                'name' => $order->user->name,
                'email' => $order->user->email,
            ] : null,
            'product' => $order->product ? [
                'id' => $order->product->id,
                'name' => $order->product->name,
                'slug' => $order->product->slug,
            ] : null,
            'configurations' => $order->relationLoaded('configurations')
                ? $order->configurations->map(fn ($configuration) => [
                    'id' => $configuration->id,
                    'configuration_key' => $configuration->configuration_key,
                    'selected_value' => $configuration->selected_value,
                    'price_modifier' => (float) $configuration->price_modifier,
                ])->values()
                : null,
            'invoice' => $order->invoice ? [
                'id' => $order->invoice->id,
                'status' => $order->invoice->status,
                'subtotal' => (float) $order->invoice->subtotal,
                'tax' => $order->invoice->tax !== null ? (float) $order->invoice->tax : null,
                'total' => (float) $order->invoice->total,
                'due_date' => $order->invoice->due_date?->toDateString(),
                'items' => $withInvoiceItems
                    ? $order->invoice->items->map(fn ($item) => [
                        'id' => $item->id,
                        'description' => $item->description,
                        'amount' => (float) $item->amount,
                    ])->values()
                    : null,
            ] : null,
        ];
    }
}
