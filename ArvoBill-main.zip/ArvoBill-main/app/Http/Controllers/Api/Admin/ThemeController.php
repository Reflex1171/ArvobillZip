<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Services\ThemeSettingService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ThemeController extends Controller
{
    public function __construct(private readonly ThemeSettingService $themeService)
    {
    }

    public function show(): JsonResponse
    {
        return response()->json([
            'data' => $this->themeService->getTheme(),
        ]);
    }

    public function update(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'brand_name' => ['nullable', 'string', 'max:120'],
            'site_title' => ['nullable', 'string', 'max:120'],
            'favicon_url' => ['nullable', 'url', 'max:2048'],
            'primary_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'secondary_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'accent_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'background_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'surface_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'text_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'warm_white_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'warm_muted_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'sidebar_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'card_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
            'input_color' => ['required', 'regex:/^#[0-9A-Fa-f]{6}$/'],
        ]);

        return response()->json([
            'message' => 'Theme updated successfully.',
            'data' => $this->themeService->updateTheme($validated),
        ]);
    }

    public function uploadLogo(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'logo' => ['required', 'file', 'mimes:jpg,jpeg,png,webp,svg', 'max:2048'],
        ]);

        $path = $validated['logo']->store('branding', 'public');

        return response()->json([
            'message' => 'Logo uploaded successfully.',
            'data' => $this->themeService->updateLogoPath($path),
        ]);
    }

    public function deleteLogo(): JsonResponse
    {
        return response()->json([
            'message' => 'Logo removed successfully.',
            'data' => $this->themeService->updateLogoPath(null),
        ]);
    }

    public function setLogoUrl(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'logo_url' => ['nullable', 'url', 'max:2048'],
        ]);

        return response()->json([
            'message' => 'Logo URL saved successfully.',
            'data' => $this->themeService->updateLogoUrl($validated['logo_url'] ?? null),
        ]);
    }
}
