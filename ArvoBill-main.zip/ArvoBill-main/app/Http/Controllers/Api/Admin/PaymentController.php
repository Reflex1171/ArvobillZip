<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $status = $request->query('status');
        $provider = $request->query('provider');

        $payments = Payment::query()
            ->with(['invoice.user', 'invoice.order.product'])
            ->when($status, fn ($query, $value) => $query->where('status', $value))
            ->when($provider, fn ($query, $value) => $query->where('provider', $value))
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Payment $payment) => $this->transformPayment($payment))
            ->values();

        return response()->json([
            'data' => $payments,
        ]);
    }

    private function transformPayment(Payment $payment): array
    {
        return [
            'id' => $payment->id,
            'provider' => $payment->provider,
            'provider_payment_id' => $payment->provider_payment_id,
            'amount' => (float) $payment->amount,
            'currency' => $payment->currency,
            'status' => $payment->status,
            'created_at' => $payment->created_at?->toISOString(),
            'invoice' => $payment->invoice ? [
                'id' => $payment->invoice->id,
                'status' => $payment->invoice->status,
                'user' => $payment->invoice->user ? [
                    'id' => $payment->invoice->user->id,
                    'name' => $payment->invoice->user->name,
                    'email' => $payment->invoice->user->email,
                ] : null,
            ] : null,
        ];
    }
}
