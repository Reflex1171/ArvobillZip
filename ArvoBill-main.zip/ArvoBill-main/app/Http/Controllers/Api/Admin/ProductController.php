<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class ProductController extends Controller
{
    public function index(): JsonResponse
    {
        $products = Product::query()
            ->with('category')
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Product $product) => $this->transformProduct($product));

        return response()->json([
            'data' => $products,
        ]);
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json([
            'data' => $this->transformProduct($product->load('category')),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['nullable', 'string', 'max:255', 'unique:products,slug'],
            'description' => ['required', 'string'],
            'category_id' => ['required', 'integer', 'exists:product_categories,id'],
            'price_monthly' => ['required', 'numeric', 'min:0'],
            'setup_fee' => ['nullable', 'numeric', 'min:0'],
            'is_active' => ['required', 'boolean'],
        ]);

        $slug = trim((string) ($validated['slug'] ?? ''));
        if ($slug === '') {
            $slug = Str::slug($validated['name']);
        }

        $product = Product::create([
            ...$validated,
            'slug' => $this->uniqueSlug($slug),
        ]);

        return response()->json([
            'message' => 'Product created successfully.',
            'data' => $this->transformProduct($product->fresh()->load('category')),
        ], 201);
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('products', 'slug')->ignore($product->id),
            ],
            'description' => ['required', 'string'],
            'category_id' => ['required', 'integer', 'exists:product_categories,id'],
            'price_monthly' => ['required', 'numeric', 'min:0'],
            'setup_fee' => ['nullable', 'numeric', 'min:0'],
            'is_active' => ['required', 'boolean'],
        ]);

        $slug = trim((string) ($validated['slug'] ?? ''));
        if ($slug === '') {
            $slug = Str::slug($validated['name']);
        }

        $product->update([
            ...$validated,
            'slug' => $this->uniqueSlug($slug, $product->id),
        ]);

        return response()->json([
            'message' => 'Product updated successfully.',
            'data' => $this->transformProduct($product->fresh()->load('category')),
        ]);
    }

    public function destroy(Product $product): JsonResponse
    {
        $product->delete();

        return response()->json([
            'message' => 'Product deleted successfully.',
        ]);
    }

    public function toggle(Product $product): JsonResponse
    {
        $product->is_active = ! $product->is_active;
        $product->save();

        return response()->json([
            'message' => $product->is_active
                ? 'Product enabled successfully.'
                : 'Product disabled successfully.',
            'data' => $this->transformProduct($product->fresh()->load('category')),
        ]);
    }

    private function uniqueSlug(string $slug, ?int $ignoreId = null): string
    {
        $normalized = Str::slug($slug);
        $baseSlug = $normalized !== '' ? $normalized : 'product';
        $candidate = $baseSlug;
        $counter = 2;

        while (
            Product::query()
                ->where('slug', $candidate)
                ->when($ignoreId !== null, fn ($query) => $query->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $candidate = "{$baseSlug}-{$counter}";
            $counter++;
        }

        return $candidate;
    }

    private function transformProduct(Product $product): array
    {
        $category = $product->relationLoaded('category')
            ? $product->getRelation('category')
            : $product->category()->first();

        return [
            'id' => $product->id,
            'name' => $product->name,
            'slug' => $product->slug,
            'description' => $product->description,
            'category_id' => $product->category_id,
            'category' => $category ? [
                'id' => $category->id,
                'name' => $category->name,
                'slug' => $category->slug,
                'description' => $category->description,
            ] : null,
            'price_monthly' => (float) $product->price_monthly,
            'setup_fee' => $product->setup_fee !== null ? (float) $product->setup_fee : null,
            'is_active' => $product->is_active,
            'created_at' => $product->created_at?->toISOString(),
            'updated_at' => $product->updated_at?->toISOString(),
        ];
    }
}
