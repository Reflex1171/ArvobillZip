<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductConfiguration;
use App\Models\ProductConfigurationOption;
use App\Support\BillingCycle;
use App\Services\Infrastructure\ServiceProvisioner;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class ProductController extends Controller
{
    public function index(): JsonResponse
    {
        $products = Product::query()
            ->with('category')
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Product $product) => $this->transformProduct($product));

        return response()->json([
            'data' => $products,
        ]);
    }

    public function show(Product $product): JsonResponse
    {
        return response()->json([
            'data' => $this->transformProduct($product->load('category')),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['nullable', 'string', 'max:255', 'unique:products,slug'],
            'description' => ['required', 'string'],
            'category_id' => ['required', 'integer', 'exists:product_categories,id'],
            'price_monthly' => ['required', 'numeric', 'min:0'],
            'setup_fee' => ['nullable', 'numeric', 'min:0'],
            'billing_type' => ['required', 'in:one_time,recurring'],
            'billing_interval' => ['nullable', 'integer', 'min:1'],
            'billing_period' => ['nullable', 'in:day,week,month,year'],
            'allow_auto_renew' => ['required', 'boolean'],
            'infrastructure_type' => ['required', 'in:none,pterodactyl'],
            'pterodactyl_egg_id' => ['nullable', 'integer', 'min:1'],
            'pterodactyl_location_id' => ['nullable', 'integer', 'min:1'],
            'pterodactyl_default_node_id' => ['nullable', 'integer', 'min:1'],
            'auto_provision' => ['required', 'boolean'],
            'is_active' => ['required', 'boolean'],
        ]);

        $slug = trim((string) ($validated['slug'] ?? ''));
        if ($slug === '') {
            $slug = Str::slug($validated['name']);
        }

        $normalizedBilling = $this->normalizeBillingInput($validated);

        $product = Product::create([
            ...$this->normalizeInfrastructureInput($validated),
            ...$normalizedBilling,
            'category' => $this->resolveLegacyCategoryName((int) $validated['category_id']),
            'slug' => $this->uniqueSlug($slug),
        ]);

        if ($product->infrastructure_type === 'pterodactyl') {
            $this->ensureRequiredPterodactylConfigurations($product);
        }

        return response()->json([
            'message' => 'Product created successfully.',
            'data' => $this->transformProduct($product->fresh()->load('category')),
        ], 201);
    }

    public function update(Request $request, Product $product): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('products', 'slug')->ignore($product->id),
            ],
            'description' => ['required', 'string'],
            'category_id' => ['required', 'integer', 'exists:product_categories,id'],
            'price_monthly' => ['required', 'numeric', 'min:0'],
            'setup_fee' => ['nullable', 'numeric', 'min:0'],
            'billing_type' => ['required', 'in:one_time,recurring'],
            'billing_interval' => ['nullable', 'integer', 'min:1'],
            'billing_period' => ['nullable', 'in:day,week,month,year'],
            'allow_auto_renew' => ['required', 'boolean'],
            'infrastructure_type' => ['required', 'in:none,pterodactyl'],
            'pterodactyl_egg_id' => ['nullable', 'integer', 'min:1'],
            'pterodactyl_location_id' => ['nullable', 'integer', 'min:1'],
            'pterodactyl_default_node_id' => ['nullable', 'integer', 'min:1'],
            'auto_provision' => ['required', 'boolean'],
            'is_active' => ['required', 'boolean'],
        ]);

        $slug = trim((string) ($validated['slug'] ?? ''));
        if ($slug === '') {
            $slug = Str::slug($validated['name']);
        }

        $normalizedBilling = $this->normalizeBillingInput($validated);

        $product->update([
            ...$this->normalizeInfrastructureInput($validated),
            ...$normalizedBilling,
            'category' => $this->resolveLegacyCategoryName((int) $validated['category_id']),
            'slug' => $this->uniqueSlug($slug, $product->id),
        ]);

        if ($product->infrastructure_type === 'pterodactyl') {
            $this->ensureRequiredPterodactylConfigurations($product);
        }

        return response()->json([
            'message' => 'Product updated successfully.',
            'data' => $this->transformProduct($product->fresh()->load('category')),
        ]);
    }

    private function ensureRequiredPterodactylConfigurations(Product $product): void
    {
        $existing = ProductConfiguration::query()
            ->where('product_id', $product->id)
            ->get()
            ->keyBy('key');

        $defaults = [
            'ram' => ['name' => 'RAM', 'sort_order' => 0],
            'disk' => ['name' => 'Disk', 'sort_order' => 1],
            'cpu' => ['name' => 'CPU', 'sort_order' => 2],
            'egg' => ['name' => 'Egg', 'sort_order' => 3],
        ];

        foreach (ServiceProvisioner::REQUIRED_PTERODACTYL_KEYS as $key) {
            if (! $existing->has($key)) {
                $config = ProductConfiguration::query()->create([
                    'product_id' => $product->id,
                    'name' => $defaults[$key]['name'],
                    'key' => $key,
                    'input_type' => 'buttons',
                    'required' => true,
                    'sort_order' => $defaults[$key]['sort_order'],
                ]);
                $existing->put($key, $config);
                continue;
            }

            $configuration = $existing->get($key);
            if (! $configuration->required) {
                $configuration->required = true;
                $configuration->save();
            }
        }
    }

    public function destroy(Product $product): JsonResponse
    {
        $product->delete();

        return response()->json([
            'message' => 'Product deleted successfully.',
        ]);
    }

    public function toggle(Product $product): JsonResponse
    {
        $product->is_active = ! $product->is_active;
        $product->save();

        return response()->json([
            'message' => $product->is_active
                ? 'Product enabled successfully.'
                : 'Product disabled successfully.',
            'data' => $this->transformProduct($product->fresh()->load('category')),
        ]);
    }

    public function duplicate(Product $product): JsonResponse
    {
        $product->load(['category', 'configurations.options']);

        $duplicated = DB::transaction(function () use ($product) {
            $baseName = trim($product->name) !== '' ? $product->name : 'Product';
            $copyName = "{$baseName} (Copy)";
            $copySlug = $this->uniqueSlug("{$product->slug}-copy");

            $newProduct = Product::create([
                'name' => $copyName,
                'slug' => $copySlug,
                'description' => $product->description,
                'category' => $product->category ?? $this->resolveLegacyCategoryName((int) $product->category_id),
                'category_id' => $product->category_id,
                'price_monthly' => $product->price_monthly,
                'setup_fee' => $product->setup_fee,
                'billing_type' => $product->billing_type,
                'billing_interval' => $product->billing_interval,
                'billing_period' => $product->billing_period,
                'billing_cycle' => $product->billing_cycle,
                'allow_auto_renew' => $product->allow_auto_renew,
                'infrastructure_type' => $product->infrastructure_type,
                'pterodactyl_egg_id' => $product->pterodactyl_egg_id,
                'pterodactyl_location_id' => $product->pterodactyl_location_id,
                'pterodactyl_default_node_id' => $product->pterodactyl_default_node_id,
                'auto_provision' => $product->auto_provision,
                'is_active' => false,
            ]);

            foreach ($product->configurations as $configuration) {
                $newConfiguration = ProductConfiguration::create([
                    'product_id' => $newProduct->id,
                    'name' => $configuration->name,
                    'key' => $configuration->key,
                    'input_type' => $configuration->input_type,
                    'required' => $configuration->required,
                    'sort_order' => $configuration->sort_order,
                ]);

                foreach ($configuration->options as $option) {
                    ProductConfigurationOption::create([
                        'product_configuration_id' => $newConfiguration->id,
                        'label' => $option->label,
                        'value' => $option->value,
                        'price_modifier' => $option->price_modifier,
                        'is_active' => $option->is_active,
                        'is_default' => $option->is_default,
                    ]);
                }
            }

            if ($newProduct->infrastructure_type === 'pterodactyl') {
                $this->ensureRequiredPterodactylConfigurations($newProduct);
            }

            return $newProduct;
        });

        return response()->json([
            'message' => 'Product duplicated successfully.',
            'data' => $this->transformProduct($duplicated->fresh()->load('category')),
        ], 201);
    }

    /**
     * @param  array<string, mixed>  $validated
     * @return array<string, mixed>
     */
    private function normalizeInfrastructureInput(array $validated): array
    {
        if ($validated['infrastructure_type'] === 'pterodactyl') {
            if (($validated['auto_provision'] ?? false) && (! isset($validated['pterodactyl_location_id']) || (int) $validated['pterodactyl_location_id'] <= 0)) {
                throw ValidationException::withMessages([
                    'pterodactyl_location_id' => 'Auto-provisioned Pterodactyl products require a location ID.',
                ]);
            }

            if (! isset($validated['pterodactyl_egg_id'])) {
                $validated['pterodactyl_egg_id'] = null;
            }

            if (! isset($validated['pterodactyl_default_node_id'])) {
                $validated['pterodactyl_default_node_id'] = null;
            }

            return $validated;
        }

        $validated['pterodactyl_egg_id'] = null;
        $validated['pterodactyl_location_id'] = null;
        $validated['pterodactyl_default_node_id'] = null;
        $validated['auto_provision'] = false;

        return $validated;
    }

    private function uniqueSlug(string $slug, ?int $ignoreId = null): string
    {
        $normalized = Str::slug($slug);
        $baseSlug = $normalized !== '' ? $normalized : 'product';
        $candidate = $baseSlug;
        $counter = 2;

        while (
            Product::query()
                ->where('slug', $candidate)
                ->when($ignoreId !== null, fn ($query) => $query->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $candidate = "{$baseSlug}-{$counter}";
            $counter++;
        }

        return $candidate;
    }

    private function transformProduct(Product $product): array
    {
        $billingType = BillingCycle::normalizeBillingType((string) ($product->billing_type ?? 'recurring'));
        $billingInterval = BillingCycle::resolveInterval($product->billing_interval ?? 1);
        $billingPeriod = BillingCycle::normalizePeriod((string) ($product->billing_period ?? 'month'));

        $category = $product->relationLoaded('category')
            ? $product->getRelation('category')
            : $product->category()->first();

        return [
            'id' => $product->id,
            'name' => $product->name,
            'slug' => $product->slug,
            'description' => $product->description,
            'category_id' => $product->category_id,
            'category' => $category ? [
                'id' => $category->id,
                'name' => $category->name,
                'slug' => $category->slug,
                'description' => $category->description,
            ] : null,
            'price_monthly' => (float) $product->price_monthly,
            'setup_fee' => $product->setup_fee !== null ? (float) $product->setup_fee : null,
            'billing_type' => $billingType,
            'billing_interval' => $billingType === 'one_time' ? null : $billingInterval,
            'billing_period' => $billingType === 'one_time' ? null : $billingPeriod,
            'billing_cycle' => BillingCycle::intervalSummary($billingInterval, $billingPeriod),
            'billing_summary' => BillingCycle::billingSummary($billingType, $billingInterval, $billingPeriod),
            'allow_auto_renew' => $billingType === 'recurring' ? (bool) $product->allow_auto_renew : false,
            'infrastructure_type' => $product->infrastructure_type ?? 'none',
            'pterodactyl_egg_id' => $product->pterodactyl_egg_id,
            'pterodactyl_location_id' => $product->pterodactyl_location_id,
            'pterodactyl_default_node_id' => $product->pterodactyl_default_node_id,
            'auto_provision' => (bool) $product->auto_provision,
            'is_active' => $product->is_active,
            'created_at' => $product->created_at?->toISOString(),
            'updated_at' => $product->updated_at?->toISOString(),
        ];
    }

    private function resolveLegacyCategoryName(int $categoryId): string
    {
        $name = ProductCategory::query()
            ->whereKey($categoryId)
            ->value('name');

        return is_string($name) && trim($name) !== '' ? $name : 'Uncategorized';
    }

    /**
     * @param  array<string, mixed>  $validated
     * @return array<string, mixed>
     */
    private function normalizeBillingInput(array $validated): array
    {
        $billingType = (string) ($validated['billing_type'] ?? 'recurring');

        if ($billingType === 'one_time') {
            $validated['billing_interval'] = null;
            $validated['billing_period'] = null;
            $validated['allow_auto_renew'] = false;

            return $validated;
        }

        if (! isset($validated['billing_interval']) || (int) $validated['billing_interval'] < 1) {
            throw ValidationException::withMessages([
                'billing_interval' => 'Recurring products require a billing interval of at least 1.',
            ]);
        }

        if (! isset($validated['billing_period'])) {
            throw ValidationException::withMessages([
                'billing_period' => 'Recurring products require a billing period unit.',
            ]);
        }

        $validated['billing_interval'] = BillingCycle::resolveInterval($validated['billing_interval']);
        $validated['billing_period'] = BillingCycle::normalizePeriod((string) $validated['billing_period']);

        return $validated;
    }
}
