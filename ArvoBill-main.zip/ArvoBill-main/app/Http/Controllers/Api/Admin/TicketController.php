<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Ticket;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class TicketController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $status = $request->query('status');
        $priority = $request->query('priority');

        $tickets = Ticket::query()
            ->with([
                'user',
                'messages' => fn ($query) => $query->latest()->limit(1),
            ])
            ->when($status, fn ($query, $value) => $query->where('status', $value))
            ->when($priority, fn ($query, $value) => $query->where('priority', $value))
            ->orderByDesc('updated_at')
            ->get()
            ->map(fn (Ticket $ticket) => $this->transformTicket($ticket))
            ->values();

        return response()->json([
            'data' => $tickets,
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $ticket = Ticket::query()
            ->with([
                'user',
                'messages' => fn ($query) => $query->with('user')->orderBy('created_at'),
            ])
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformTicket($ticket, true),
        ]);
    }

    public function reply(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'message' => ['required', 'string'],
        ]);

        $ticket = Ticket::query()->findOrFail($id);

        if ($ticket->status === 'closed') {
            return response()->json([
                'message' => 'Closed tickets cannot be replied to unless reopened.',
            ], 422);
        }

        $ticket = DB::transaction(function () use ($ticket, $request, $validated) {
            $ticket->messages()->create([
                'user_id' => $request->user()->id,
                'message' => $validated['message'],
                'is_admin' => true,
            ]);

            $ticket->status = 'answered';
            $ticket->save();

            return $ticket->fresh()->load([
                'user',
                'messages' => fn ($query) => $query->with('user')->orderBy('created_at'),
            ]);
        });

        return response()->json([
            'message' => 'Reply added successfully.',
            'data' => $this->transformTicket($ticket, true),
        ]);
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:open,answered,closed'],
        ]);

        $ticket = Ticket::query()->with([
            'user',
            'messages' => fn ($query) => $query->with('user')->orderBy('created_at'),
        ])->findOrFail($id);
        $ticket->status = $validated['status'];
        $ticket->save();

        return response()->json([
            'message' => 'Ticket status updated successfully.',
            'data' => $this->transformTicket($ticket->fresh()->load([
                'user',
                'messages' => fn ($query) => $query->with('user')->orderBy('created_at'),
            ]), true),
        ]);
    }

    private function transformTicket(Ticket $ticket, bool $withMessages = false): array
    {
        $lastMessage = $ticket->messages->last();

        return [
            'id' => $ticket->id,
            'subject' => $ticket->subject,
            'status' => $ticket->status,
            'priority' => $ticket->priority,
            'created_at' => $ticket->created_at?->toISOString(),
            'updated_at' => $ticket->updated_at?->toISOString(),
            'last_reply_at' => $lastMessage?->created_at?->toISOString(),
            'user' => $ticket->user ? [
                'id' => $ticket->user->id,
                'name' => $ticket->user->name,
                'email' => $ticket->user->email,
            ] : null,
            'messages' => $withMessages
                ? $ticket->messages->map(fn ($message) => [
                    'id' => $message->id,
                    'user_id' => $message->user_id,
                    'message' => $message->message,
                    'is_admin' => $message->is_admin,
                    'created_at' => $message->created_at?->toISOString(),
                    'user' => $message->user ? [
                        'id' => $message->user->id,
                        'name' => $message->user->name,
                        'email' => $message->user->email,
                    ] : null,
                ])->values()
                : null,
        ];
    }
}
