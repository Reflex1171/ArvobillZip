<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Models\ProductCategory;
use App\Models\ProductConfiguration;
use App\Models\ProductConfigurationOption;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;
use Illuminate\Validation\Rule;

class CategoryController extends Controller
{
    public function index(): JsonResponse
    {
        $categories = ProductCategory::query()
            ->withCount('products')
            ->orderBy('name')
            ->get()
            ->map(fn (ProductCategory $category) => $this->transformCategory($category));

        return response()->json([
            'data' => $categories,
        ]);
    }

    public function show(ProductCategory $category): JsonResponse
    {
        return response()->json([
            'data' => $this->transformCategory($category->loadCount('products')),
        ]);
    }

    public function store(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => ['nullable', 'string', 'max:255', 'unique:product_categories,slug'],
            'description' => ['nullable', 'string'],
        ]);

        $slug = trim((string) ($validated['slug'] ?? ''));
        if ($slug === '') {
            $slug = Str::slug($validated['name']);
        }

        $category = ProductCategory::create([
            'name' => $validated['name'],
            'slug' => $this->uniqueSlug($slug),
            'description' => $validated['description'] ?? null,
        ]);

        return response()->json([
            'message' => 'Category created successfully.',
            'data' => $this->transformCategory($category->loadCount('products')),
        ], 201);
    }

    public function update(Request $request, ProductCategory $category): JsonResponse
    {
        $validated = $request->validate([
            'name' => ['required', 'string', 'max:255'],
            'slug' => [
                'nullable',
                'string',
                'max:255',
                Rule::unique('product_categories', 'slug')->ignore($category->id),
            ],
            'description' => ['nullable', 'string'],
        ]);

        $slug = trim((string) ($validated['slug'] ?? ''));
        if ($slug === '') {
            $slug = Str::slug($validated['name']);
        }

        $category->update([
            'name' => $validated['name'],
            'slug' => $this->uniqueSlug($slug, $category->id),
            'description' => $validated['description'] ?? null,
        ]);

        return response()->json([
            'message' => 'Category updated successfully.',
            'data' => $this->transformCategory($category->fresh()->loadCount('products')),
        ]);
    }

    public function destroy(ProductCategory $category): JsonResponse
    {
        $category->products()->update(['category_id' => null]);
        $category->delete();

        return response()->json([
            'message' => 'Category deleted successfully.',
        ]);
    }

    public function duplicate(ProductCategory $category): JsonResponse
    {
        $category->load(['products.configurations.options']);

        $duplicatedCategory = DB::transaction(function () use ($category) {
            $copyName = trim((string) $category->name) !== ''
                ? "{$category->name} (Copy)"
                : 'Category Copy';
            $copySlug = $this->uniqueSlug("{$category->slug}-copy");

            $newCategory = ProductCategory::query()->create([
                'name' => $copyName,
                'slug' => $copySlug,
                'description' => $category->description,
            ]);

            foreach ($category->products as $product) {
                $newProduct = Product::query()->create([
                    'name' => trim((string) $product->name) !== '' ? "{$product->name} (Copy)" : 'Product Copy',
                    'slug' => $this->uniqueProductSlug("{$product->slug}-copy"),
                    'description' => $product->description,
                    'category' => $newCategory->name,
                    'category_id' => $newCategory->id,
                    'price_monthly' => $product->price_monthly,
                    'setup_fee' => $product->setup_fee,
                    'billing_type' => $product->billing_type,
                    'billing_interval' => $product->billing_interval,
                    'billing_period' => $product->billing_period,
                    'billing_cycle' => $product->billing_cycle,
                    'allow_auto_renew' => $product->allow_auto_renew,
                    'infrastructure_type' => $product->infrastructure_type,
                    'pterodactyl_egg_id' => $product->pterodactyl_egg_id,
                    'pterodactyl_location_id' => $product->pterodactyl_location_id,
                    'pterodactyl_default_node_id' => $product->pterodactyl_default_node_id,
                    'auto_provision' => $product->auto_provision,
                    'is_active' => false,
                ]);

                foreach ($product->configurations as $configuration) {
                    $newConfiguration = ProductConfiguration::query()->create([
                        'product_id' => $newProduct->id,
                        'name' => $configuration->name,
                        'key' => $configuration->key,
                        'input_type' => $configuration->input_type,
                        'required' => $configuration->required,
                        'sort_order' => $configuration->sort_order,
                    ]);

                    foreach ($configuration->options as $option) {
                        ProductConfigurationOption::query()->create([
                            'product_configuration_id' => $newConfiguration->id,
                            'label' => $option->label,
                            'value' => $option->value,
                            'price_modifier' => $option->price_modifier,
                            'is_active' => $option->is_active,
                            'is_default' => $option->is_default,
                        ]);
                    }
                }
            }

            return $newCategory;
        });

        return response()->json([
            'message' => 'Category duplicated successfully.',
            'data' => $this->transformCategory($duplicatedCategory->loadCount('products')),
        ], 201);
    }

    private function uniqueSlug(string $slug, ?int $ignoreId = null): string
    {
        $baseSlug = Str::slug($slug) !== '' ? Str::slug($slug) : 'category';
        $candidate = $baseSlug;
        $counter = 2;

        while (
            ProductCategory::query()
                ->where('slug', $candidate)
                ->when($ignoreId !== null, fn ($query) => $query->where('id', '!=', $ignoreId))
                ->exists()
        ) {
            $candidate = "{$baseSlug}-{$counter}";
            $counter++;
        }

        return $candidate;
    }

    private function uniqueProductSlug(string $slug): string
    {
        $baseSlug = Str::slug($slug) !== '' ? Str::slug($slug) : 'product';
        $candidate = $baseSlug;
        $counter = 2;

        while (Product::query()->where('slug', $candidate)->exists()) {
            $candidate = "{$baseSlug}-{$counter}";
            $counter++;
        }

        return $candidate;
    }

    private function transformCategory(ProductCategory $category): array
    {
        return [
            'id' => $category->id,
            'name' => $category->name,
            'slug' => $category->slug,
            'description' => $category->description,
            'products_count' => $category->products_count ?? null,
            'created_at' => $category->created_at?->toISOString(),
            'updated_at' => $category->updated_at?->toISOString(),
        ];
    }
}
