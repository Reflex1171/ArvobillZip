<?php

namespace App\Http\Controllers\Api\Admin;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class InvoiceController extends Controller
{
    public function index(Request $request): JsonResponse
    {
        $status = $request->query('status');

        $invoices = Invoice::query()
            ->with(['user', 'order.product'])
            ->when($status, fn ($query, $value) => $query->where('status', $value))
            ->orderByDesc('created_at')
            ->get()
            ->map(fn (Invoice $invoice) => $this->transformInvoice($invoice));

        return response()->json([
            'data' => $invoices,
        ]);
    }

    public function show(int $id): JsonResponse
    {
        $invoice = Invoice::query()
            ->with(['user', 'order.product', 'items'])
            ->findOrFail($id);

        return response()->json([
            'data' => $this->transformInvoice($invoice, true),
        ]);
    }

    public function updateStatus(Request $request, int $id): JsonResponse
    {
        $validated = $request->validate([
            'status' => ['required', 'in:unpaid,cancelled'],
        ]);

        $invoice = DB::transaction(function () use ($id, $validated) {
            $invoice = Invoice::query()->with('order')->findOrFail($id);
            $invoice->status = $validated['status'];
            $invoice->save();

            if ($invoice->order) {
                $invoice->order->status = match ($validated['status']) {
                    'cancelled' => 'cancelled',
                    default => 'pending',
                };
                $invoice->order->save();
            }

            return $invoice;
        });

        return response()->json([
            'message' => 'Invoice status updated successfully.',
            'data' => $this->transformInvoice($invoice->fresh()->load(['user', 'order.product', 'items']), true),
        ]);
    }

    private function transformInvoice(Invoice $invoice, bool $withItems = false): array
    {
        return [
            'id' => $invoice->id,
            'status' => $invoice->status,
            'subtotal' => (float) $invoice->subtotal,
            'tax' => $invoice->tax !== null ? (float) $invoice->tax : null,
            'total' => (float) $invoice->total,
            'due_date' => $invoice->due_date?->toDateString(),
            'created_at' => $invoice->created_at?->toISOString(),
            'user' => $invoice->user ? [
                'id' => $invoice->user->id,
                'name' => $invoice->user->name,
                'email' => $invoice->user->email,
            ] : null,
            'order' => $invoice->order ? [
                'id' => $invoice->order->id,
                'status' => $invoice->order->status,
                'product' => $invoice->order->product ? [
                    'id' => $invoice->order->product->id,
                    'name' => $invoice->order->product->name,
                    'slug' => $invoice->order->product->slug,
                ] : null,
            ] : null,
            'items' => $withItems
                ? $invoice->items->map(fn ($item) => [
                    'id' => $item->id,
                    'description' => $item->description,
                    'amount' => (float) $item->amount,
                ])->values()
                : null,
        ];
    }
}
