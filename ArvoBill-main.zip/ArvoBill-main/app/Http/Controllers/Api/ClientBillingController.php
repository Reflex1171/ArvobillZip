<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\UserPaymentMethod;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;

class ClientBillingController extends Controller
{
    public function show(Request $request): JsonResponse
    {
        $user = $request->user();

        $outstandingInvoices = Invoice::query()
            ->where('user_id', $user->id)
            ->where('status', 'unpaid')
            ->orderBy('due_date')
            ->get();

        $transactions = $user->accountTransactions()
            ->latest('id')
            ->limit(15)
            ->get();

        $methods = $user->paymentMethods()
            ->where('is_active', true)
            ->orderByDesc('is_default')
            ->orderByDesc('id')
            ->get();

        return response()->json([
            'data' => [
                'summary' => [
                    'currency' => 'USD',
                    'current_balance' => (float) $user->balance,
                    'credit_balance' => (float) $user->balance,
                    'outstanding_amount' => (float) $outstandingInvoices->sum('total'),
                ],
                'payment_methods' => $methods->map(fn (UserPaymentMethod $method) => [
                    'id' => (string) $method->id,
                    'provider' => $method->provider,
                    'type' => $method->type,
                    'label' => $method->label,
                    'masked_details' => $method->masked_details,
                    'is_default' => (bool) $method->is_default,
                ])->values(),
                'outstanding_invoices' => $outstandingInvoices->map(fn (Invoice $invoice) => [
                    'id' => $invoice->id,
                    'created_at' => $invoice->created_at?->toISOString(),
                    'amount' => (float) $invoice->total,
                    'status' => $invoice->status,
                ])->values(),
                'recent_transactions' => $transactions->map(fn ($transaction) => [
                    'id' => (string) $transaction->id,
                    'date' => $transaction->created_at?->toISOString(),
                    'description' => $transaction->description ?? ucfirst(str_replace('_', ' ', (string) $transaction->type)),
                    'amount' => (float) $transaction->amount,
                    'method' => $transaction->method ?? '-',
                    'status' => $transaction->type === 'payment_failed' ? 'failed' : 'paid',
                ])->values(),
            ],
        ]);
    }

    public function storePaymentMethod(Request $request): JsonResponse
    {
        $validated = $request->validate([
            'provider' => ['required', 'in:stripe,paypal'],
            'type' => ['required', 'in:card,paypal'],
            'label' => ['required', 'string', 'max:100'],
            'masked_details' => ['required', 'string', 'max:100'],
            'provider_reference' => ['nullable', 'string', 'max:255'],
            'is_default' => ['required', 'boolean'],
        ]);

        $user = $request->user();
        if ($validated['is_default']) {
            $user->paymentMethods()->update(['is_default' => false]);
        }

        $method = $user->paymentMethods()->create($validated);

        return response()->json([
            'data' => [
                'id' => (string) $method->id,
                'provider' => $method->provider,
                'type' => $method->type,
                'label' => $method->label,
                'masked_details' => $method->masked_details,
                'is_default' => (bool) $method->is_default,
            ],
        ], 201);
    }

    public function destroyPaymentMethod(Request $request, int $id): JsonResponse
    {
        $method = $request->user()->paymentMethods()->findOrFail($id);
        $method->is_active = false;
        $method->is_default = false;
        $method->save();

        return response()->json(['message' => 'Payment method removed.']);
    }

    public function setDefaultPaymentMethod(Request $request, int $id): JsonResponse
    {
        $user = $request->user();
        $method = $user->paymentMethods()->where('is_active', true)->findOrFail($id);
        $user->paymentMethods()->update(['is_default' => false]);
        $method->is_default = true;
        $method->save();

        return response()->json(['message' => 'Default payment method updated.']);
    }
}

