<?php

namespace App\Http\Controllers\Webhooks;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Payment;
use App\Services\Billing\InvoiceSettlementService;
use App\Services\Payments\PaymentProviderManager;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class StripeWebhookController extends Controller
{
    public function __invoke(
        Request $request,
        InvoiceSettlementService $settlementService,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse {
        $payload = $request->getContent();
        $signature = (string) $request->header('Stripe-Signature', '');
        $secret = '';
        try {
            $credentials = $paymentProviderManager->getActiveCredentials('stripe');
            $secret = (string) ($credentials['webhook_secret'] ?? '');
        } catch (\Throwable) {
            $secret = '';
        }

        if (! $this->isValidSignature($payload, $signature, $secret)) {
            return response()->json(['message' => 'Invalid signature.'], 400);
        }

        $event = json_decode($payload, true);
        if (! is_array($event) || ($event['type'] ?? null) !== 'checkout.session.completed') {
            return response()->json(['received' => true]);
        }

        $session = $event['data']['object'] ?? [];
        $invoiceId = (int) ($session['metadata']['invoice_id'] ?? 0);
        $sessionId = (string) ($session['id'] ?? '');

        if ($invoiceId <= 0 || $sessionId === '') {
            return response()->json(['received' => true]);
        }

        $invoice = Invoice::query()->find($invoiceId);
        if (! $invoice) {
            return response()->json(['received' => true]);
        }

        $amount = isset($session['amount_total'])
            ? ((float) $session['amount_total']) / 100
            : (float) $invoice->total;
        $currency = strtoupper((string) ($session['currency'] ?? 'USD'));

        DB::transaction(function () use (
            $invoice,
            $sessionId,
            $amount,
            $currency,
            $settlementService
        ) {
            Payment::query()->updateOrCreate(
                [
                    'provider' => 'stripe',
                    'provider_payment_id' => $sessionId,
                ],
                [
                    'invoice_id' => $invoice->id,
                    'amount' => $amount,
                    'currency' => $currency,
                    'status' => 'paid',
                ],
            );

            $settlementService->markPaid($invoice);
        });

        return response()->json(['received' => true]);
    }

    private function isValidSignature(string $payload, string $signatureHeader, string $secret): bool
    {
        if ($secret === '' || $signatureHeader === '') {
            return false;
        }

        $parts = collect(explode(',', $signatureHeader))
            ->map(fn (string $part) => explode('=', trim($part), 2))
            ->filter(fn (array $segments) => count($segments) === 2);

        $timestamp = $parts
            ->first(fn (array $segments) => $segments[0] === 't')[1] ?? null;
        $signatures = $parts
            ->filter(fn (array $segments) => $segments[0] === 'v1')
            ->map(fn (array $segments) => $segments[1])
            ->values();

        if (! is_string($timestamp) || ! ctype_digit($timestamp) || $signatures->isEmpty()) {
            return false;
        }

        if (abs(time() - (int) $timestamp) > 300) {
            return false;
        }

        $signedPayload = $timestamp.'.'.$payload;
        $computed = hash_hmac('sha256', $signedPayload, $secret);

        return $signatures->contains(
            fn (string $signature) => hash_equals($computed, $signature),
        );
    }
}
