<?php

namespace App\Http\Controllers\Webhooks;

use App\Http\Controllers\Controller;
use App\Models\Invoice;
use App\Models\Payment;
use App\Services\Billing\InvoiceSettlementService;
use App\Services\Payments\PaymentProviderManager;
use Illuminate\Http\Client\PendingRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class PayPalWebhookController extends Controller
{
    public function __invoke(
        Request $request,
        InvoiceSettlementService $settlementService,
        PaymentProviderManager $paymentProviderManager,
    ): JsonResponse
    {
        $payload = $request->json()->all();
        if (! $this->verifySignature($request, $payload, $paymentProviderManager)) {
            return response()->json(['message' => 'Invalid signature.'], 400);
        }

        if (($payload['event_type'] ?? null) !== 'PAYMENT.CAPTURE.COMPLETED') {
            return response()->json(['received' => true]);
        }

        $resource = $payload['resource'] ?? [];
        $orderId = (string) ($resource['supplementary_data']['related_ids']['order_id'] ?? '');
        $captureId = (string) ($resource['id'] ?? '');
        $customId = (string) ($resource['custom_id']
            ?? $resource['supplementary_data']['related_ids']['custom_id']
            ?? '');

        $invoiceId = $this->extractInvoiceId($customId);
        $payment = null;

        if ($orderId !== '') {
            $payment = Payment::query()
                ->where('provider', 'paypal')
                ->where('provider_payment_id', $orderId)
                ->first();
        }

        if ($invoiceId <= 0) {
            $invoiceId = $payment?->invoice_id ?? 0;
        }

        if ($invoiceId <= 0) {
            return response()->json(['received' => true]);
        }

        $invoice = Invoice::query()->find($invoiceId);
        if (! $invoice) {
            return response()->json(['received' => true]);
        }

        $amount = (float) ($resource['amount']['value'] ?? $invoice->total);
        $currency = strtoupper((string) ($resource['amount']['currency_code'] ?? 'USD'));
        $providerPaymentId = $captureId !== '' ? $captureId : ($orderId !== '' ? $orderId : 'paypal-'.$invoiceId);

        DB::transaction(function () use (
            $payment,
            $invoice,
            $providerPaymentId,
            $amount,
            $currency,
            $settlementService
        ) {
            if ($payment) {
                $payment->status = 'paid';
                $payment->amount = $amount;
                $payment->currency = $currency;
                $payment->save();
            } else {
                Payment::query()->updateOrCreate(
                    [
                        'provider' => 'paypal',
                        'provider_payment_id' => $providerPaymentId,
                    ],
                    [
                        'invoice_id' => $invoice->id,
                        'amount' => $amount,
                        'currency' => $currency,
                        'status' => 'paid',
                    ],
                );
            }

            $settlementService->markPaid($invoice);
        });

        return response()->json(['received' => true]);
    }

    private function verifySignature(
        Request $request,
        array $payload,
        PaymentProviderManager $paymentProviderManager,
    ): bool
    {
        try {
            $credentials = $paymentProviderManager->getActiveCredentials('paypal');
            $mode = (string) $credentials['mode'];
            $modeUrls = $paymentProviderManager->getModeBaseUrls('paypal', $mode);
        } catch (\Throwable) {
            return false;
        }

        $clientId = (string) ($credentials['public_key'] ?? '');
        $secret = (string) ($credentials['secret_key'] ?? '');
        $webhookId = (string) ($credentials['webhook_secret'] ?? '');
        $apiBase = (string) ($modeUrls['api_base'] ?? '');

        if ($clientId === '' || $secret === '' || $webhookId === '' || $apiBase === '') {
            return false;
        }

        $accessTokenResponse = $this->paymentHttp()
            ->asForm()
            ->withBasicAuth($clientId, $secret)
            ->post("{$apiBase}/v1/oauth2/token", [
                'grant_type' => 'client_credentials',
            ]);

        if (! $accessTokenResponse->successful()) {
            return false;
        }

        $accessToken = (string) $accessTokenResponse->json('access_token', '');
        if ($accessToken === '') {
            return false;
        }

        $verificationResponse = $this->paymentHttp()
            ->withToken($accessToken)
            ->post("{$apiBase}/v1/notifications/verify-webhook-signature", [
                'transmission_id' => (string) $request->header('paypal-transmission-id', ''),
                'transmission_time' => (string) $request->header('paypal-transmission-time', ''),
                'cert_url' => (string) $request->header('paypal-cert-url', ''),
                'auth_algo' => (string) $request->header('paypal-auth-algo', ''),
                'transmission_sig' => (string) $request->header('paypal-transmission-sig', ''),
                'webhook_id' => $webhookId,
                'webhook_event' => $payload,
            ]);

        if (! $verificationResponse->successful()) {
            return false;
        }

        return $verificationResponse->json('verification_status') === 'SUCCESS';
    }

    private function extractInvoiceId(string $customId): int
    {
        if ($customId === '') {
            return 0;
        }

        preg_match('/invoice:(\d+)/', $customId, $matches);

        return isset($matches[1]) ? (int) $matches[1] : 0;
    }

    private function paymentHttp(): PendingRequest
    {
        return Http::timeout(30)->retry(2, 200, throw: false);
    }
}
