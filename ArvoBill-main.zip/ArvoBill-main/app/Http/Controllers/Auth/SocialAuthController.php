<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use App\Models\SocialAccount;
use App\Models\User;
use App\Services\Affiliates\AffiliateService;
use App\Services\Email\EmailNotificationService;
use App\Services\SocialProviderSettingsService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Str;

class SocialAuthController extends Controller
{
    private const PROVIDERS = ['google', 'apple'];

    public function redirect(Request $request, string $provider, SocialProviderSettingsService $settingsService): RedirectResponse
    {
        $this->ensureProviderIsSupported($provider);
        $this->captureIntendedRedirect($request);
        $this->captureReferralCode($request);

        $setting = $settingsService->getProvider($provider);
        if (! $setting->enabled || ! $this->hasValidConfig($provider, $setting)) {
            return redirect()->route('login')->with('status', 'Social login is not enabled.');
        }

        return redirect()->away($this->buildAuthUrl($provider, $setting));
    }

    public function callback(Request $request, string $provider, SocialProviderSettingsService $settingsService): RedirectResponse
    {
        $this->ensureProviderIsSupported($provider);

        try {
            $setting = $settingsService->getProvider($provider);
            if (! $setting->enabled || ! $this->hasValidConfig($provider, $setting)) {
                return redirect()->route('login')->with('status', 'Social login is not enabled.');
            }

            $socialUser = $this->exchangeCodeForUser($request, $provider, $setting);
        } catch (\Throwable $exception) {
            return redirect()->route('login')->with('status', 'Social login failed. Please try again.');
        }

        $providerId = (string) ($socialUser['id'] ?? '');
        if ($providerId === '') {
            return redirect()->route('login')->with('status', 'Unable to fetch account identity from provider.');
        }

        $account = SocialAccount::query()
            ->where('provider', $provider)
            ->where('provider_id', $providerId)
            ->first();

        if ($account) {
            $user = $account->user;
        } else {
            $email = $socialUser['email'] ?? null;
            if (! $email) {
                return redirect()->route('login')->with('status', 'Unable to fetch email address from provider.');
            }

            $user = User::query()->where('email', $email)->first();

            if (! $user) {
                $user = User::create([
                    'name' => (string) ($socialUser['name'] ?? 'New User'),
                    'email' => $email,
                    'password' => Str::random(48),
                ]);
                $user->forceFill(['email_verified_at' => now()])->save();

                $this->attachReferralToUser($request, $user);
                $this->sendWelcomeEmail($user);
            }

            SocialAccount::create([
                'user_id' => $user->id,
                'provider' => $provider,
                'provider_id' => $providerId,
                'email' => $email,
                'avatar_url' => $socialUser['avatar'] ?? null,
            ]);
        }

        Auth::login($user, true);

        return redirect()->intended('/client/dashboard');
    }

    private function hasValidConfig(string $provider, \App\Models\SocialProviderSetting $setting): bool
    {
        if (! $setting->client_id || ! $setting->client_secret || ! $setting->redirect_uri) {
            return false;
        }

        if ($provider === 'apple') {
            return (bool) ($setting->team_id && $setting->key_id && $setting->private_key);
        }

        return true;
    }

    private function buildAuthUrl(string $provider, \App\Models\SocialProviderSetting $setting): string
    {
        $state = Str::random(40);
        request()->session()->put("oauth_state_{$provider}", $state);

        if ($provider === 'google') {
            $query = http_build_query([
                'client_id' => $setting->client_id,
                'redirect_uri' => $setting->redirect_uri,
                'response_type' => 'code',
                'scope' => 'openid email profile',
                'state' => $state,
                'prompt' => 'select_account',
                'access_type' => 'offline',
                'include_granted_scopes' => 'true',
            ]);

            return 'https://accounts.google.com/o/oauth2/v2/auth?'.$query;
        }

        $query = http_build_query([
            'client_id' => $setting->client_id,
            'redirect_uri' => $setting->redirect_uri,
            'response_type' => 'code id_token',
            'response_mode' => 'form_post',
            'scope' => 'name email',
            'state' => $state,
        ]);

        return 'https://appleid.apple.com/auth/authorize?'.$query;
    }

    private function exchangeCodeForUser(Request $request, string $provider, \App\Models\SocialProviderSetting $setting): array
    {
        $state = (string) $request->input('state', '');
        $expected = (string) $request->session()->pull("oauth_state_{$provider}", '');
        if ($expected === '' || $state !== $expected) {
            throw new \RuntimeException('Invalid OAuth state.');
        }

        if ($provider === 'google') {
            $tokenResponse = Http::asForm()->post('https://oauth2.googleapis.com/token', [
                'client_id' => $setting->client_id,
                'client_secret' => $setting->client_secret,
                'code' => (string) $request->input('code', ''),
                'grant_type' => 'authorization_code',
                'redirect_uri' => $setting->redirect_uri,
            ]);

            if (! $tokenResponse->ok()) {
                throw new \RuntimeException('Unable to fetch Google token.');
            }

            $tokenData = $tokenResponse->json();
            $idToken = (string) ($tokenData['id_token'] ?? '');
            $accessToken = (string) ($tokenData['access_token'] ?? '');

            if ($idToken === '' && $accessToken === '') {
                throw new \RuntimeException('Google token missing.');
            }

            $profile = Http::withToken($accessToken)->get('https://openidconnect.googleapis.com/v1/userinfo');
            if (! $profile->ok()) {
                throw new \RuntimeException('Unable to fetch Google profile.');
            }

            return [
                'id' => (string) ($profile['sub'] ?? ''),
                'email' => (string) ($profile['email'] ?? ''),
                'name' => (string) ($profile['name'] ?? ''),
                'avatar' => (string) ($profile['picture'] ?? ''),
            ];
        }

        $clientSecret = $this->buildAppleClientSecret($setting);
        $tokenResponse = Http::asForm()->post('https://appleid.apple.com/auth/token', [
            'client_id' => $setting->client_id,
            'client_secret' => $clientSecret,
            'code' => (string) $request->input('code', ''),
            'grant_type' => 'authorization_code',
            'redirect_uri' => $setting->redirect_uri,
        ]);

        if (! $tokenResponse->ok()) {
            throw new \RuntimeException('Unable to fetch Apple token.');
        }

        $tokenData = $tokenResponse->json();
        $idToken = (string) ($tokenData['id_token'] ?? '');
        if ($idToken === '') {
            throw new \RuntimeException('Apple token missing.');
        }

        $claims = $this->decodeJwt($idToken);
        $email = (string) ($claims['email'] ?? '');
        $name = 'Apple User';

        $namePayload = $request->input('user');
        if (is_string($namePayload)) {
            $decoded = json_decode($namePayload, true);
            if (is_array($decoded)) {
                $namePayload = $decoded;
            }
        }

        if (is_array($namePayload)) {
            $first = (string) ($namePayload['name']['firstName'] ?? '');
            $last = (string) ($namePayload['name']['lastName'] ?? '');
            $name = trim($first.' '.$last) ?: $name;
        }

        return [
            'id' => (string) ($claims['sub'] ?? ''),
            'email' => $email,
            'name' => $name,
            'avatar' => null,
        ];
    }

    private function buildAppleClientSecret(\App\Models\SocialProviderSetting $setting): string
    {
        $now = time();
        $payload = [
            'iss' => $setting->team_id,
            'iat' => $now,
            'exp' => $now + 3600,
            'aud' => 'https://appleid.apple.com',
            'sub' => $setting->client_id,
        ];

        $header = [
            'alg' => 'ES256',
            'kid' => $setting->key_id,
            'typ' => 'JWT',
        ];

        $segments = [
            $this->base64UrlEncode(json_encode($header, JSON_UNESCAPED_SLASHES)),
            $this->base64UrlEncode(json_encode($payload, JSON_UNESCAPED_SLASHES)),
        ];

        $signingInput = implode('.', $segments);
        $signature = '';
        $key = $setting->private_key;
        if (! $key || ! openssl_sign($signingInput, $signature, $key, OPENSSL_ALGO_SHA256)) {
            throw new \RuntimeException('Unable to sign Apple client secret.');
        }

        $joseSignature = $this->derToJose($signature, 256);
        $segments[] = $this->base64UrlEncode($joseSignature);

        return implode('.', $segments);
    }

    /**
     * @return array<string, mixed>
     */
    private function decodeJwt(string $jwt): array
    {
        $parts = explode('.', $jwt);
        if (count($parts) < 2) {
            return [];
        }

        $payload = $this->base64UrlDecode($parts[1]);
        $decoded = json_decode($payload, true);
        if (! is_array($decoded)) {
            return [];
        }

        return $decoded;
    }

    private function base64UrlEncode(string $value): string
    {
        return rtrim(strtr(base64_encode($value), '+/', '-_'), '=');
    }

    private function base64UrlDecode(string $value): string
    {
        $value = strtr($value, '-_', '+/');
        $pad = strlen($value) % 4;
        if ($pad > 0) {
            $value .= str_repeat('=', 4 - $pad);
        }

        return (string) base64_decode($value);
    }

    private function derToJose(string $der, int $keySize): string
    {
        $offset = 0;
        if (ord($der[$offset]) !== 0x30) {
            throw new \RuntimeException('Invalid DER signature.');
        }
        $offset++;
        $this->readDerLength($der, $offset);

        if (ord($der[$offset]) !== 0x02) {
            throw new \RuntimeException('Invalid DER signature.');
        }
        $offset++;
        $rLength = $this->readDerLength($der, $offset);
        $r = substr($der, $offset, $rLength);
        $offset += $rLength;

        if (ord($der[$offset]) !== 0x02) {
            throw new \RuntimeException('Invalid DER signature.');
        }
        $offset++;
        $sLength = $this->readDerLength($der, $offset);
        $s = substr($der, $offset, $sLength);

        $length = intdiv($keySize, 8);
        $r = ltrim($r, "\x00");
        $s = ltrim($s, "\x00");
        $r = str_pad($r, $length, "\x00", STR_PAD_LEFT);
        $s = str_pad($s, $length, "\x00", STR_PAD_LEFT);

        return $r.$s;
    }

    private function readDerLength(string $der, int &$offset): int
    {
        $length = ord($der[$offset]);
        $offset++;

        if ($length & 0x80) {
            $num = $length & 0x7f;
            $length = 0;
            for ($i = 0; $i < $num; $i++) {
                $length = ($length << 8) | ord($der[$offset]);
                $offset++;
            }
        }

        return $length;
    }

    private function ensureProviderIsSupported(string $provider): void
    {
        if (! in_array($provider, self::PROVIDERS, true)) {
            abort(404);
        }
    }

    private function captureIntendedRedirect(Request $request): void
    {
        $redirect = (string) $request->query('redirect', '');
        if ($redirect === '' || ! str_starts_with($redirect, '/')) {
            return;
        }

        $request->session()->put('url.intended', $redirect);
    }

    private function captureReferralCode(Request $request): void
    {
        $ref = strtoupper(trim((string) $request->query('ref', '')));
        if ($ref === '') {
            return;
        }

        $request->session()->put(AffiliateService::SESSION_KEY, $ref);
        Cookie::queue(
            AffiliateService::COOKIE_KEY,
            $ref,
            60 * 24 * 30,
            '/',
            null,
            false,
            false,
            false,
            'Lax',
        );
    }

    private function attachReferralToUser(Request $request, User $user): void
    {
        /** @var AffiliateService $affiliateService */
        $affiliateService = app(AffiliateService::class);

        $referralCode = (string) $request->session()->get(
            AffiliateService::SESSION_KEY,
            (string) $request->cookie(AffiliateService::COOKIE_KEY, ''),
        );

        $affiliateService->attachReferralToUser($user, $referralCode !== '' ? strtoupper($referralCode) : null);

        $request->session()->forget(AffiliateService::SESSION_KEY);
        Cookie::queue(Cookie::forget(AffiliateService::COOKIE_KEY));
    }

    private function sendWelcomeEmail(User $user): void
    {
        /** @var EmailNotificationService $emailNotificationService */
        $emailNotificationService = app(EmailNotificationService::class);
        $emailNotificationService->queueToUser(
            $user->fresh(),
            'Welcome to ArvoBill',
            'Your account is ready',
            [
                'Your ArvoBill account has been created successfully.',
                'You can now place orders, manage services, and track billing in your client area.',
            ],
            'Open Client Area',
            url('/client/dashboard'),
            'account_created',
            ['user_id' => $user->id],
        );
    }
}
