<?php

namespace App\Actions\Fortify;

use App\Concerns\PasswordValidationRules;
use App\Concerns\ProfileValidationRules;
use App\Models\User;
use App\Services\Affiliates\AffiliateService;
use App\Services\Email\EmailNotificationService;
use Illuminate\Support\Facades\Cookie;
use Illuminate\Support\Facades\Validator;
use Laravel\Fortify\Contracts\CreatesNewUsers;

class CreateNewUser implements CreatesNewUsers
{
    use PasswordValidationRules, ProfileValidationRules;

    /**
     * Validate and create a newly registered user.
     *
     * @param  array<string, string>  $input
     */
    public function create(array $input): User
    {
        Validator::make($input, [
            ...$this->profileRules(),
            'password' => $this->passwordRules(),
        ])->validate();

        $user = User::create([
            'name' => $input['name'],
            'email' => $input['email'],
            'password' => $input['password'],
        ]);

        /** @var AffiliateService $affiliateService */
        $affiliateService = app(AffiliateService::class);

        $referralCode = (string) request()->session()->get(
            AffiliateService::SESSION_KEY,
            (string) request()->cookie(AffiliateService::COOKIE_KEY, ''),
        );
        if ($referralCode === '') {
            $referralCode = (string) request()->query('ref', '');
        }

        $affiliateService->attachReferralToUser($user, $referralCode !== '' ? strtoupper($referralCode) : null);

        request()->session()->forget(AffiliateService::SESSION_KEY);
        Cookie::queue(Cookie::forget(AffiliateService::COOKIE_KEY));

        /** @var EmailNotificationService $emailNotificationService */
        $emailNotificationService = app(EmailNotificationService::class);
        $emailNotificationService->queueToUser(
            $user->fresh(),
            'Welcome to ArvoBill',
            'Your account is ready',
            [
                'Your ArvoBill account has been created successfully.',
                'You can now place orders, manage services, and track billing in your client area.',
            ],
            'Open Client Area',
            url('/client/dashboard'),
            'account_created',
            ['user_id' => $user->id],
        );

        return $user;
    }
}
