<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">

        <script>
            (function() {
                const appearance = localStorage.getItem('appearance') || 'system';
                const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                const isDark = appearance === 'dark' || (appearance === 'system' && prefersDark);

                document.documentElement.classList.toggle('dark', isDark);
                document.documentElement.style.colorScheme = isDark ? 'dark' : 'light';
            })();
        </script>

        <title>{{ config('app.name', 'Laravel') }} - Client Area</title>

        @viteReactRefresh
        @vite(['resources/css/app.css', 'resources/js/client-app.tsx'])
    </head>
    <body class="antialiased">
        <div
            id="client-app"
            data-user-name="{{ auth()->user()?->name }}"
            data-user-email="{{ auth()->user()?->email }}"
        ></div>
    </body>
</html>
