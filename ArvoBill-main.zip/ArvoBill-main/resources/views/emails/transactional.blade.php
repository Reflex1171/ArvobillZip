<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width,initial-scale=1">
    <title>{{ $subjectLine }}</title>
</head>
<body style="margin:0;background:#0f172a;color:#e5e7eb;font-family:Arial,sans-serif;">
    <table role="presentation" width="100%" cellspacing="0" cellpadding="0" style="padding:24px 0;">
        <tr>
            <td align="center">
                <table role="presentation" width="620" cellspacing="0" cellpadding="0" style="max-width:620px;background:#1e293b;border:1px solid #334155;border-radius:12px;overflow:hidden;">
                    <tr>
                        <td style="padding:24px 28px;border-bottom:1px solid #334155;">
                            <h1 style="margin:0;font-size:22px;line-height:1.3;color:#f8fafc;">{{ $heading }}</h1>
                        </td>
                    </tr>
                    <tr>
                        <td style="padding:20px 28px;">
                            @foreach($lines as $line)
                                <p style="margin:0 0 14px 0;font-size:15px;line-height:1.55;color:#cbd5e1;">{{ $line }}</p>
                            @endforeach

                            @if($ctaLabel && $ctaUrl)
                                <p style="margin:20px 0 0 0;">
                                    <a href="{{ $ctaUrl }}" style="display:inline-block;padding:10px 16px;border-radius:8px;background:#0ea5e9;color:#ffffff;text-decoration:none;font-weight:700;">
                                        {{ $ctaLabel }}
                                    </a>
                                </p>
                            @endif
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>