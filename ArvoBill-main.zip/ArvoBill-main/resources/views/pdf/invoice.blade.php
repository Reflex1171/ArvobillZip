<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <style>
        body {
            margin: 0;
            color: #1f2937;
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            line-height: 1.4;
            background: #ffffff;
        }
        .page {
            padding: 28px 34px 22px;
        }
        .header {
            background: linear-gradient(120deg, #0b4f9b 0%, #1b72cc 100%);
            color: #ffffff;
            border-radius: 10px;
            padding: 20px 24px;
            margin-bottom: 16px;
        }
        .header-row {
            width: 100%;
        }
        .brand {
            font-size: 24px;
            font-weight: 700;
        }
        .brand-line {
            font-size: 12px;
            opacity: 0.9;
            margin-top: 4px;
        }
        .invoice-id {
            text-align: right;
            font-size: 14px;
            font-weight: 700;
        }
        .logo-wrap {
            margin-bottom: 12px;
        }
        .logo {
            max-height: 58px;
            max-width: 220px;
        }
        .meta-grid {
            width: 100%;
            margin-bottom: 16px;
        }
        .meta-card {
            width: 48.8%;
            border: 1px solid #d7dde8;
            border-radius: 8px;
            padding: 12px 14px;
            vertical-align: top;
            min-height: 86px;
        }
        .meta-title {
            font-size: 11px;
            font-weight: 700;
            color: #334155;
            text-transform: uppercase;
            letter-spacing: 0.05em;
            margin-bottom: 8px;
        }
        .meta-line {
            color: #374151;
            margin-bottom: 4px;
        }
        .items {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 18px;
        }
        .items th {
            background: #eef3f9;
            color: #1f2937;
            text-align: left;
            padding: 10px 12px;
            font-size: 11px;
            border: 1px solid #d7dde8;
            text-transform: uppercase;
            letter-spacing: 0.05em;
        }
        .items td {
            padding: 10px 12px;
            border: 1px solid #e4e8f0;
            color: #374151;
            font-size: 12px;
        }
        .items .amount {
            text-align: right;
            white-space: nowrap;
        }
        .items tr:nth-child(even) td {
            background: #fafcff;
        }
        .summary-wrap {
            width: 100%;
            margin-bottom: 18px;
        }
        .summary {
            width: 42%;
            margin-left: auto;
            border: 1px solid #d7dde8;
            border-radius: 8px;
            padding: 10px 14px;
        }
        .summary-row {
            width: 100%;
            padding: 5px 0;
            color: #374151;
            font-size: 12px;
        }
        .summary-row .right {
            text-align: right;
            white-space: nowrap;
        }
        .summary-divider {
            border-top: 1px solid #cfd6e3;
            margin: 8px 0;
        }
        .summary-total {
            font-weight: 700;
            color: #0b4f9b;
            font-size: 20px;
        }
        .footer {
            border-top: 1px solid #e5e7eb;
            padding-top: 10px;
            color: #6b7280;
            font-size: 10px;
        }
    </style>
</head>
<body>
    <div class="page">
        <div class="header">
            @if($logoUrl)
                <div class="logo-wrap">
                    <img src="{{ $logoUrl }}" alt="Logo" class="logo">
                </div>
            @endif
            <table class="header-row" cellpadding="0" cellspacing="0">
                <tr>
                    <td>
                        <div class="brand">{{ $brandName }} Invoice</div>
                        <div class="brand-line">Professional Hosting Billing</div>
                    </td>
                    <td class="invoice-id">Invoice #{{ $invoiceId }}</td>
                </tr>
            </table>
        </div>

        <table class="meta-grid" cellpadding="0" cellspacing="0">
            <tr>
                <td class="meta-card">
                    <div class="meta-title">Billed To</div>
                    <div class="meta-line">{{ $clientName }}</div>
                    <div class="meta-line">{{ $clientEmail }}</div>
                </td>
                <td style="width:2.4%"></td>
                <td class="meta-card">
                    <div class="meta-title">Invoice Details</div>
                    <div class="meta-line">Issued: {{ $issuedAt }}</div>
                    <div class="meta-line">Due: {{ $dueAt }}</div>
                    <div class="meta-line">Status: {{ $status }}</div>
                </td>
            </tr>
        </table>

        <table class="items">
            <thead>
                <tr>
                    <th style="width:78%">Description</th>
                    <th style="width:22%; text-align:right;">Amount</th>
                </tr>
            </thead>
            <tbody>
                @forelse($lines as $line)
                    <tr>
                        <td>{{ $line['description'] }}</td>
                        <td class="amount">${{ number_format((float) $line['amount'], 2) }}</td>
                    </tr>
                @empty
                    <tr>
                        <td>No line items</td>
                        <td class="amount">$0.00</td>
                    </tr>
                @endforelse
            </tbody>
        </table>

        <div class="summary-wrap">
            <div class="summary">
                <table width="100%" cellpadding="0" cellspacing="0">
                    <tr class="summary-row">
                        <td>Subtotal</td>
                        <td class="right">${{ number_format((float) $subtotal, 2) }}</td>
                    </tr>
                    <tr class="summary-row">
                        <td>Discount</td>
                        <td class="right">${{ number_format((float) $discount, 2) }}</td>
                    </tr>
                    <tr class="summary-row">
                        <td>Tax</td>
                        <td class="right">${{ number_format((float) $tax, 2) }}</td>
                    </tr>
                </table>
                <div class="summary-divider"></div>
                <table width="100%" cellpadding="0" cellspacing="0">
                    <tr class="summary-total">
                        <td>Total</td>
                        <td class="right">${{ number_format((float) $total, 2) }}</td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="footer">
            <div>Related service: {{ $productName }}</div>
            <div>Generated at {{ $generatedAtUtc }} UTC</div>
            <div>Thank you for choosing {{ $brandName }}.</div>
        </div>
    </div>
</body>
</html>
