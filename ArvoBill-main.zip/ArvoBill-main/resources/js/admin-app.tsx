import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './admin/styles.css';
import { AdminApp } from './admin/admin-app';
import { ThemeProvider } from './contexts/theme-context';
import { initializeTheme } from './hooks/use-appearance';

const mountNode = document.getElementById('admin-app');

if (!mountNode) {
    throw new Error('Admin app mount node not found.');
}

initializeTheme();

createRoot(mountNode).render(
    <StrictMode>
        <ThemeProvider>
            <BrowserRouter>
                <AdminApp />
            </BrowserRouter>
        </ThemeProvider>
    </StrictMode>,
);
