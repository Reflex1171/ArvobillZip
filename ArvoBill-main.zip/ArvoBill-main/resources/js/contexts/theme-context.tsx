import {
    createContext,
    ReactNode,
    useContext,
    useEffect,
    useMemo,
    useState,
} from 'react';
import { getThemeSettings, updateThemeSettings } from '@/lib/theme-api';
import type { ThemeSettings } from '@/types/theme';

const defaultTheme: ThemeSettings = {
    brand_name: 'ArvoBill',
    site_title: 'ArvoBill',
    logo_url: null,
    favicon_url: null,
    primary_color: '#009ddc',
    secondary_color: '#25792f',
    accent_color: '#118bbb',
    background_color: '#2a2d34',
    surface_color: '#373b45',
    text_color: '#e5e7eb',
};

type ThemeContextValue = {
    theme: ThemeSettings;
    isLoading: boolean;
    error: string | null;
    applyTheme: (nextTheme: ThemeSettings) => void;
    saveTheme: (nextTheme: ThemeSettings) => Promise<void>;
    defaults: ThemeSettings;
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

function setThemeVariables(theme: ThemeSettings): void {
    document.documentElement.style.setProperty('--panel-primary', theme.primary_color);
    document.documentElement.style.setProperty(
        '--panel-secondary',
        theme.secondary_color,
    );
    document.documentElement.style.setProperty('--panel-accent', theme.accent_color);
    document.documentElement.style.setProperty('--panel-bg', theme.background_color);
    document.documentElement.style.setProperty('--panel-surface', theme.surface_color);
    document.documentElement.style.setProperty('--panel-text', theme.text_color);

    const title = (theme.site_title || theme.brand_name || 'ArvoBill').trim();
    document.title = title;

    if (theme.favicon_url) {
        let favicon = document.querySelector("link[rel='icon'][data-theme-favicon='1']") as HTMLLinkElement | null;
        if (!favicon) {
            favicon = document.createElement('link');
            favicon.setAttribute('rel', 'icon');
            favicon.setAttribute('data-theme-favicon', '1');
            document.head.appendChild(favicon);
        }
        favicon.href = theme.favicon_url;
    }
}

export function ThemeProvider({ children }: { children: ReactNode }) {
    const [theme, setTheme] = useState<ThemeSettings>(defaultTheme);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        setThemeVariables(defaultTheme);

        async function loadTheme() {
            try {
                const data = await getThemeSettings();
                setTheme(data);
                setThemeVariables(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load theme settings.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadTheme();
    }, []);

    function applyTheme(nextTheme: ThemeSettings): void {
        setTheme(nextTheme);
        setThemeVariables(nextTheme);
    }

    async function saveTheme(nextTheme: ThemeSettings): Promise<void> {
        const saved = await updateThemeSettings(nextTheme);
        applyTheme(saved);
    }

    const value = useMemo<ThemeContextValue>(
        () => ({
            theme,
            isLoading,
            error,
            applyTheme,
            saveTheme,
            defaults: defaultTheme,
        }),
        [theme, isLoading, error],
    );

    return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
    const context = useContext(ThemeContext);

    if (!context) {
        throw new Error('useTheme must be used within ThemeProvider.');
    }

    return context;
}
