import {
    createContext,
    ReactNode,
    useContext,
    useEffect,
    useMemo,
    useState,
} from 'react';
import { getThemeSettings, updateThemeSettings } from '@/lib/theme-api';
import type { ThemeSettings } from '@/types/theme';

const defaultTheme: ThemeSettings = {
    brand_name: 'ArvoBill',
    site_title: 'ArvoBill',
    logo_url: null,
    favicon_url: null,
    primary_color: '#009ddc',
    secondary_color: '#25792f',
    accent_color: '#118bbb',
    background_color: '#2a2d34',
    surface_color: '#373b45',
    text_color: '#e5e7eb',
    warm_white_color: '#fdfcf9',
    warm_muted_color: '#8c8c8c',
    sidebar_color: '#1a1c23',
    card_color: '#24262d',
    input_color: '#2d2f36',
};

type ThemeContextValue = {
    theme: ThemeSettings;
    isLoading: boolean;
    error: string | null;
    applyTheme: (nextTheme: ThemeSettings) => void;
    saveTheme: (nextTheme: ThemeSettings) => Promise<void>;
    defaults: ThemeSettings;
};

const ThemeContext = createContext<ThemeContextValue | null>(null);

function setThemeVariables(theme: ThemeSettings): void {
    const root = document.documentElement;
    root.style.setProperty('--panel-primary', theme.primary_color);
    root.style.setProperty(
        '--panel-secondary',
        theme.secondary_color,
    );
    root.style.setProperty('--panel-accent', theme.accent_color);
    root.style.setProperty('--panel-bg', theme.background_color);
    root.style.setProperty('--background', theme.background_color);
    root.style.setProperty('--panel-surface', theme.surface_color);
    root.style.setProperty('--panel-text', theme.text_color);
    root.style.setProperty('--color-warm-white', theme.warm_white_color);
    root.style.setProperty('--color-warm-muted', theme.warm_muted_color);
    root.style.setProperty('--color-sidebar', theme.sidebar_color);
    root.style.setProperty('--color-card', theme.card_color);
    root.style.setProperty('--color-input', theme.input_color);

    const title = (theme.site_title || theme.brand_name || 'ArvoBill').trim();
    document.title = title;

    if (theme.favicon_url) {
        const iconLinks = Array.from(
            document.querySelectorAll("link[rel='icon'], link[rel='shortcut icon'], link[rel='apple-touch-icon']"),
        ) as HTMLLinkElement[];

        if (iconLinks.length === 0) {
            const favicon = document.createElement('link');
            favicon.setAttribute('rel', 'icon');
            favicon.setAttribute('data-theme-favicon', '1');
            favicon.href = theme.favicon_url;
            document.head.appendChild(favicon);
        } else {
            iconLinks.forEach((link) => {
                link.href = theme.favicon_url ?? link.href;
                link.setAttribute('data-theme-favicon', '1');
            });
        }
    }
}

export function ThemeProvider({ children }: { children: ReactNode }) {
    const [theme, setTheme] = useState<ThemeSettings>(defaultTheme);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        setThemeVariables(defaultTheme);

        async function loadTheme() {
            try {
                const data = await getThemeSettings();
                setTheme(data);
                setThemeVariables(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load theme settings.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadTheme();
    }, []);

    function applyTheme(nextTheme: ThemeSettings): void {
        setTheme(nextTheme);
        setThemeVariables(nextTheme);
    }

    async function saveTheme(nextTheme: ThemeSettings): Promise<void> {
        const saved = await updateThemeSettings(nextTheme);
        applyTheme(saved);
    }

    const value = useMemo<ThemeContextValue>(
        () => ({
            theme,
            isLoading,
            error,
            applyTheme,
            saveTheme,
            defaults: defaultTheme,
        }),
        [theme, isLoading, error],
    );

    return <ThemeContext.Provider value={value}>{children}</ThemeContext.Provider>;
}

export function useTheme() {
    const context = useContext(ThemeContext);

    if (!context) {
        throw new Error('useTheme must be used within ThemeProvider.');
    }

    return context;
}
