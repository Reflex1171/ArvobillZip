import { Link, usePage } from '@inertiajs/react';
import { home } from '@/routes';
import type { AuthLayoutProps, SharedData } from '@/types';

export default function AuthSimpleLayout({
    children,
    title,
    description,
}: AuthLayoutProps) {
    const { theme } = usePage<SharedData>().props;
    const brandName = theme?.brand_name || theme?.site_title || 'ArvoBill';
    const logoUrl = theme?.logo_url || null;

    return (
        <div className="relative flex min-h-svh items-center justify-center bg-[var(--panel-bg)] px-4 py-10">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top,rgba(0,153,220,0.12),transparent_55%)]" />
            <div className="relative w-full max-w-md">
                <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-8 shadow-xl">
                    <div className="mb-6 flex flex-col items-center gap-3 text-center">
                        <Link href={home()} className="flex flex-col items-center gap-2">
                            {logoUrl ? (
                                <img
                                    src={logoUrl}
                                    alt={`${brandName} logo`}
                                    className="h-14 w-auto object-contain"
                                />
                            ) : (
                                <span className="text-base font-semibold tracking-wide text-[var(--panel-text)]">
                                    {brandName}
                                </span>
                            )}
                        </Link>
                        <div className="space-y-2">
                            <h1 className="text-2xl font-semibold text-[var(--panel-text)]">{title}</h1>
                            <p className="text-sm text-white/70">{description}</p>
                        </div>
                    </div>
                    <div className="text-[var(--panel-text)]">{children}</div>
                </div>
            </div>
        </div>
    );
}
