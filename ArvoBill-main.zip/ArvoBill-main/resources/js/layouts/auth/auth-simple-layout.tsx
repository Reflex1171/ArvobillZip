import { Link } from '@inertiajs/react';
import AppLogoIcon from '@/components/app-logo-icon';
import { home } from '@/routes';
import type { AuthLayoutProps } from '@/types';

export default function AuthSimpleLayout({
    children,
    title,
    description,
}: AuthLayoutProps) {
    return (
        <div className="relative flex min-h-svh items-center justify-center overflow-hidden bg-[var(--panel-bg)] p-6 md:p-10">
            <div className="pointer-events-none absolute inset-0 bg-[radial-gradient(circle_at_top_left,rgba(0,153,220,0.18),transparent_45%),radial-gradient(circle_at_bottom_right,rgba(17,139,187,0.12),transparent_50%)]" />
            <div className="relative w-full max-w-md">
                <div className="rounded-2xl border border-white/15 bg-[var(--panel-surface)]/95 p-8 shadow-2xl backdrop-blur">
                    <div className="mb-8 flex flex-col items-center gap-4">
                        <Link href={home()} className="flex flex-col items-center gap-3 font-medium">
                            <div className="mb-1 flex h-12 w-12 items-center justify-center rounded-xl bg-[var(--panel-primary)] text-white shadow-md">
                                <AppLogoIcon className="size-7 fill-current text-white" />
                            </div>
                            <span className="text-base font-semibold tracking-wide text-[var(--panel-text)]">
                                ArvoBill
                            </span>
                        </Link>

                        <div className="space-y-2 text-center">
                            <h1 className="text-2xl font-semibold text-[var(--panel-text)]">{title}</h1>
                            <p className="text-center text-sm text-white/70">
                                {description}
                            </p>
                        </div>
                    </div>
                    <div className="text-[var(--panel-text)]">{children}</div>
                </div>
            </div>
        </div>
    );
}
