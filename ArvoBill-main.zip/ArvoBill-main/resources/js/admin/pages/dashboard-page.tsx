import { useEffect, useState } from 'react';
import { formatCurrency, getAdminDashboardData } from '@/lib/dashboard-api';

export function DashboardPage() {
  const [data, setData] = useState<{
    total_users: number;
    active_services: number;
    monthly_revenue: number;
    pending_orders: number;
  } | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const response = await getAdminDashboardData();
        setData(response);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load dashboard.',
        );
      }
    }

    void loadDashboard();
  }, []);

  const stats = [
    {
      label: 'Total Users',
      value: data ? data.total_users.toLocaleString() : '-',
      detail: 'Registered client accounts',
    },
    {
      label: 'Active Services',
      value: data ? data.active_services.toLocaleString() : '-',
      detail: 'Services currently in active state',
    },
    {
      label: 'Monthly Revenue',
      value: data ? formatCurrency(data.monthly_revenue) : '-',
      detail: 'Paid invoices this month',
    },
    {
      label: 'Pending Orders',
      value: data ? data.pending_orders.toLocaleString() : '-',
      detail: 'Orders awaiting completion',
    },
  ];

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-xl font-semibold">Admin Dashboard</h2>
        <p className="mt-1 text-sm text-white/70 ">
          Platform-level metrics and operational controls.
        </p>
      </section>

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => (
          <article
            key={stat.label}
            className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4 shadow-sm "
          >
            <p className="text-sm text-white/70 ">
              {stat.label}
            </p>
            <p className="mt-2 text-2xl font-semibold">{stat.value}</p>
            <p className="mt-2 text-xs text-white/70 ">
              {stat.detail}
            </p>
          </article>
        ))}
      </section>
    </div>
  );
}
