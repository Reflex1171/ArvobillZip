import { useEffect, useState } from 'react';
import { listPterodactylNodes } from '@/lib/pterodactyl-api';
import type { PterodactylNode } from '@/types/pterodactyl';

export function InfrastructureNodesPage() {
    const [nodes, setNodes] = useState<PterodactylNode[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadNodes() {
            try {
                const data = await listPterodactylNodes();
                setNodes(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load nodes.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadNodes();
    }, []);

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Pterodactyl Nodes</h2>
                <p className="mt-1 text-sm text-white/70">
                    Infrastructure capacity across connected nodes.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)]">
                <table className="min-w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/70">
                        <tr>
                            <th className="px-4 py-3 font-medium">Node</th>
                            <th className="px-4 py-3 font-medium">Location</th>
                            <th className="px-4 py-3 font-medium">RAM</th>
                            <th className="px-4 py-3 font-medium">Disk</th>
                            <th className="px-4 py-3 font-medium">Servers</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            <tr>
                                <td colSpan={5} className="px-4 py-4 text-white/70">
                                    Loading nodes...
                                </td>
                            </tr>
                        ) : nodes.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="px-4 py-4 text-white/70">
                                    No nodes found.
                                </td>
                            </tr>
                        ) : (
                            nodes.map((node) => (
                                <tr key={node.id} className="border-t border-white/10">
                                    <td className="px-4 py-3">{node.name ?? `Node ${node.id}`}</td>
                                    <td className="px-4 py-3">{node.location_id ?? '-'}</td>
                                    <td className="px-4 py-3">
                                        {node.allocated_resources.memory} / {node.memory} MB
                                    </td>
                                    <td className="px-4 py-3">
                                        {node.allocated_resources.disk} / {node.disk} MB
                                    </td>
                                    <td className="px-4 py-3">{node.server_count}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}
