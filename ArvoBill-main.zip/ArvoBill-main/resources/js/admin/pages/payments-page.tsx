import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { listAdminPayments } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { PaymentSummary } from '@/types/billing';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function PaymentsPage() {
    const [status, setStatus] = useState<string>('');
    const [provider, setProvider] = useState<string>('');
    const [payments, setPayments] = useState<PaymentSummary[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadPayments() {
            try {
                setIsLoading(true);
                const data = await listAdminPayments({
                    status: status || undefined,
                    provider: provider || undefined,
                });
                setPayments(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load payments.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadPayments();
    }, [status, provider]);

    const totalPaid = useMemo(
        () =>
            payments
                .filter((payment) => payment.status === 'paid')
                .reduce((sum, payment) => sum + payment.amount, 0),
        [payments],
    );

    return (
        <section className="space-y-6">
            <div className="flex flex-wrap items-end justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-semibold">Payments</h2>
                    <p className="mt-1 text-sm text-white/70">
                        Incoming transactions from Stripe test mode and PayPal sandbox.
                    </p>
                </div>
                <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] px-4 py-3 text-sm">
                    <p className="text-white/70">Paid total (visible rows)</p>
                    <p className="text-lg font-semibold">{formatCurrency(totalPaid)}</p>
                </div>
            </div>

            <div className="grid gap-3 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4 md:grid-cols-2">
                <label className="space-y-1 text-sm">
                    <span className="font-medium">Status</span>
                    <select
                        value={status}
                        onChange={(event) => setStatus(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                    >
                        <option value="">All</option>
                        <option value="pending">Pending</option>
                        <option value="paid">Paid</option>
                        <option value="failed">Failed</option>
                    </select>
                </label>
                <label className="space-y-1 text-sm">
                    <span className="font-medium">Provider</span>
                    <select
                        value={provider}
                        onChange={(event) => setProvider(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                    >
                        <option value="">All</option>
                        <option value="stripe">Stripe</option>
                        <option value="paypal">PayPal</option>
                    </select>
                </label>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)]">
                <table className="min-w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/70">
                        <tr>
                            <th className="px-4 py-3 font-medium">Provider</th>
                            <th className="px-4 py-3 font-medium">Invoice</th>
                            <th className="px-4 py-3 font-medium">Amount</th>
                            <th className="px-4 py-3 font-medium">Status</th>
                            <th className="px-4 py-3 font-medium">Date</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            <tr>
                                <td colSpan={5} className="px-4 py-6 text-center text-white/70">
                                    Loading payments...
                                </td>
                            </tr>
                        ) : payments.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="px-4 py-6 text-center text-white/70">
                                    No payments found.
                                </td>
                            </tr>
                        ) : (
                            payments.map((payment) => (
                                <tr key={payment.id} className="border-t border-white/10">
                                    <td className="px-4 py-3 capitalize">{payment.provider}</td>
                                    <td className="px-4 py-3">
                                        {payment.invoice ? (
                                            <Link
                                                to={`/admin/invoices/${payment.invoice.id}`}
                                                className="text-[var(--panel-primary)] hover:underline"
                                            >
                                                #{payment.invoice.id}
                                            </Link>
                                        ) : (
                                            '-'
                                        )}
                                    </td>
                                    <td className="px-4 py-3">
                                        {formatCurrency(payment.amount)} {payment.currency}
                                    </td>
                                    <td className="px-4 py-3">
                                        <StatusBadge status={payment.status} />
                                    </td>
                                    <td className="px-4 py-3">{formatDate(payment.created_at)}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}
