import { FormEvent, useEffect, useState } from 'react';
import { useTheme } from '@/contexts/theme-context';
import { deleteThemeLogo, setThemeLogoUrl, uploadThemeLogo } from '@/lib/theme-api';
import type { ThemeSettings } from '@/types/theme';

type ThemeField = {
  key: keyof ThemeSettings;
  label: string;
};

const fields: ThemeField[] = [
  { key: 'primary_color', label: 'Primary Color' },
  { key: 'secondary_color', label: 'Secondary Color' },
  { key: 'accent_color', label: 'Accent Color' },
  { key: 'background_color', label: 'Background Color' },
  { key: 'surface_color', label: 'Surface Color' },
  { key: 'text_color', label: 'Text Color' },
];

export function ThemePage() {
  const { theme, applyTheme, saveTheme, defaults } = useTheme();
  const [draft, setDraft] = useState<ThemeSettings>(theme);
  const [logoUrlInput, setLogoUrlInput] = useState(theme.logo_url ?? '');
  const [isSaving, setIsSaving] = useState(false);
  const [isUploadingLogo, setIsUploadingLogo] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setDraft(theme);
    setLogoUrlInput(theme.logo_url ?? '');
  }, [theme]);

  function updateField(key: keyof ThemeSettings, value: string) {
    const next = {
      ...draft,
      [key]: value,
    };

    setDraft(next);
    applyTheme(next);
    setMessage(null);
    setError(null);
  }

  async function handleSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setIsSaving(true);
      await saveTheme(draft);
      setMessage('Theme saved successfully.');
      setError(null);
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : 'Failed to save theme.',
      );
    } finally {
      setIsSaving(false);
    }
  }

  async function handleLogoUpload(file: File | null) {
    if (!file) return;

    try {
      setIsUploadingLogo(true);
      const next = await uploadThemeLogo(file);
      applyTheme(next);
      setDraft(next);
      setMessage('Logo uploaded successfully.');
      setError(null);
    } catch (uploadError) {
      setError(
        uploadError instanceof Error
          ? uploadError.message
          : 'Failed to upload logo.',
      );
    } finally {
      setIsUploadingLogo(false);
    }
  }

  async function handleLogoRemove() {
    try {
      setIsUploadingLogo(true);
      const next = await deleteThemeLogo();
      applyTheme(next);
      setDraft(next);
      setMessage('Logo removed.');
      setError(null);
    } catch (removeError) {
      setError(
        removeError instanceof Error
          ? removeError.message
          : 'Failed to remove logo.',
      );
    } finally {
      setIsUploadingLogo(false);
    }
  }

  async function handleLogoUrlSave() {
    try {
      setIsUploadingLogo(true);
      const next = await setThemeLogoUrl(logoUrlInput);
      applyTheme(next);
      setDraft(next);
      setLogoUrlInput(next.logo_url ?? '');
      setMessage('Logo URL saved successfully.');
      setError(null);
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : 'Failed to save logo URL.',
      );
    } finally {
      setIsUploadingLogo(false);
    }
  }

  function handleReset() {
    setDraft(defaults);
    applyTheme(defaults);
    setMessage('Reset to default theme values.');
    setError(null);
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Theme Settings</h2>
        <p className="mt-1 text-sm text-white/70">
          Configure panel colours globally for client and admin areas.
        </p>
      </div>

      {message ? (
        <div className="rounded-lg border border-[var(--panel-accent)]/40 bg-[var(--panel-accent)]/15 p-4 text-sm text-[var(--panel-text)]">
          {message}
        </div>
      ) : null}

      {error ? (
        <div className="rounded-lg border border-rose-400/40 bg-rose-500/20 p-4 text-sm text-rose-200">
          {error}
        </div>
      ) : null}

      <form
        onSubmit={(event) => void handleSave(event)}
        className="space-y-6 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6"
      >
        <div className="grid gap-4 md:grid-cols-2">
          <label className="space-y-2">
            <span className="block text-sm font-medium">Brand Name</span>
            <input
              type="text"
              value={draft.brand_name}
              onChange={(event) => updateField('brand_name', event.target.value)}
              className="w-full rounded-lg border border-white/20 bg-transparent px-3 py-2 text-sm"
              placeholder="Your Company"
              maxLength={120}
            />
          </label>
          <div className="space-y-2">
            <span className="block text-sm font-medium">Panel Logo</span>
            <div className="flex items-center gap-4">
              <div className="flex items-center justify-center overflow-hidden">
                {draft.logo_url ? (
                  <img src={draft.logo_url} alt="Panel logo" className="h-14 w-auto object-contain" />
                ) : (
                  <span className="text-xs text-white/60">No logo</span>
                )}
              </div>
              <div className="flex flex-wrap gap-2">
                <label className="cursor-pointer rounded-lg border border-white/25 px-3 py-2 text-xs font-semibold hover:bg-white/10">
                  {isUploadingLogo ? 'Uploading...' : 'Upload Logo'}
                  <input
                    type="file"
                    accept=".png,.jpg,.jpeg,.webp,.svg"
                    className="hidden"
                    onChange={(event) => void handleLogoUpload(event.target.files?.[0] ?? null)}
                    disabled={isUploadingLogo}
                  />
                </label>
                <button
                  type="button"
                  onClick={() => void handleLogoRemove()}
                  disabled={isUploadingLogo || !draft.logo_url}
                  className="rounded-lg border border-white/25 px-3 py-2 text-xs font-semibold hover:bg-white/10 disabled:opacity-60"
                >
                  Remove Logo
                </button>
              </div>
            </div>
            <div className="mt-3 flex flex-col gap-2 sm:flex-row sm:items-center">
              <input
                type="url"
                value={logoUrlInput}
                onChange={(event) => setLogoUrlInput(event.target.value)}
                className="w-full rounded-lg border border-white/20 bg-transparent px-3 py-2 text-sm"
                placeholder="https://example.com/logo.png"
              />
              <button
                type="button"
                onClick={() => void handleLogoUrlSave()}
                disabled={isUploadingLogo}
                className="rounded-lg bg-[var(--panel-secondary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
              >
                Save Logo Link
              </button>
            </div>
          </div>
        </div>

        <div className="grid gap-4 md:grid-cols-2">
          {fields.map((field) => (
            <label key={field.key} className="space-y-2">
              <span className="block text-sm font-medium">
                {field.label}
              </span>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={draft[field.key]}
                  onChange={(event) =>
                    updateField(field.key, event.target.value)
                  }
                  className="h-10 w-14 cursor-pointer rounded border border-white/20 bg-transparent"
                />
                <input
                  type="text"
                  value={draft[field.key]}
                  onChange={(event) =>
                    updateField(field.key, event.target.value)
                  }
                  className="w-full rounded-lg border border-white/20 bg-transparent px-3 py-2 text-sm"
                />
              </div>
            </label>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="submit"
            disabled={isSaving}
            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
          >
            {isSaving ? 'Saving...' : 'Save Theme'}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="rounded-lg border border-white/25 px-4 py-2 text-sm font-semibold hover:bg-[var(--panel-surface)]/10"
          >
            Reset to Defaults
          </button>
        </div>
      </form>
    </section>
  );
}
