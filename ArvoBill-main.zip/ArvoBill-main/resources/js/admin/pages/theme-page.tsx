import { FormEvent, useEffect, useState } from 'react';
import { useTheme } from '@/contexts/theme-context';
import type { ThemeSettings } from '@/types/theme';

type ThemeField = {
  key: keyof ThemeSettings;
  label: string;
};

const fields: ThemeField[] = [
  { key: 'primary_color', label: 'Primary Color' },
  { key: 'secondary_color', label: 'Secondary Color' },
  { key: 'accent_color', label: 'Accent Color' },
  { key: 'background_color', label: 'Background Color' },
  { key: 'surface_color', label: 'Surface Color' },
  { key: 'text_color', label: 'Text Color' },
];

export function ThemePage() {
  const { theme, applyTheme, saveTheme, defaults } = useTheme();
  const [draft, setDraft] = useState<ThemeSettings>(theme);
  const [isSaving, setIsSaving] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    setDraft(theme);
  }, [theme]);

  function updateField(key: keyof ThemeSettings, value: string) {
    const next = {
      ...draft,
      [key]: value,
    };

    setDraft(next);
    applyTheme(next);
    setMessage(null);
    setError(null);
  }

  async function handleSave(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    try {
      setIsSaving(true);
      await saveTheme(draft);
      setMessage('Theme saved successfully.');
      setError(null);
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : 'Failed to save theme.',
      );
    } finally {
      setIsSaving(false);
    }
  }

  function handleReset() {
    setDraft(defaults);
    applyTheme(defaults);
    setMessage('Reset to default theme values.');
    setError(null);
  }

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Theme Settings</h2>
        <p className="mt-1 text-sm text-white/70">
          Configure panel colours globally for client and admin areas.
        </p>
      </div>

      {message ? (
        <div className="rounded-lg border border-[var(--panel-accent)]/40 bg-[var(--panel-accent)]/15 p-4 text-sm text-[var(--panel-text)]">
          {message}
        </div>
      ) : null}

      {error ? (
        <div className="rounded-lg border border-rose-400/40 bg-rose-500/20 p-4 text-sm text-rose-200">
          {error}
        </div>
      ) : null}

      <form
        onSubmit={(event) => void handleSave(event)}
        className="space-y-6 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6"
      >
        <div className="grid gap-4 md:grid-cols-2">
          {fields.map((field) => (
            <label key={field.key} className="space-y-2">
              <span className="block text-sm font-medium">
                {field.label}
              </span>
              <div className="flex items-center gap-3">
                <input
                  type="color"
                  value={draft[field.key]}
                  onChange={(event) =>
                    updateField(field.key, event.target.value)
                  }
                  className="h-10 w-14 cursor-pointer rounded border border-white/20 bg-transparent"
                />
                <input
                  type="text"
                  value={draft[field.key]}
                  onChange={(event) =>
                    updateField(field.key, event.target.value)
                  }
                  className="w-full rounded-lg border border-white/20 bg-transparent px-3 py-2 text-sm"
                />
              </div>
            </label>
          ))}
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <button
            type="submit"
            disabled={isSaving}
            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
          >
            {isSaving ? 'Saving...' : 'Save Theme'}
          </button>
          <button
            type="button"
            onClick={handleReset}
            className="rounded-lg border border-white/25 px-4 py-2 text-sm font-semibold hover:bg-[var(--panel-surface)]/10"
          >
            Reset to Defaults
          </button>
        </div>
      </form>
    </section>
  );
}
