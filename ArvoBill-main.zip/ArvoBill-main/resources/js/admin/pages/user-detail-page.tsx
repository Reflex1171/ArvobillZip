import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
    getAdminUserById,
    syncAdminUserPterodactylAccount,
    updateAdminUserPermissions,
    updateAdminUserRole,
} from '@/lib/products-api';
import type { AdminUserDetail } from '@/types/account';

function formatDate(value: string | null | undefined): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function UserDetailPage() {
    const { id } = useParams<{ id: string }>();
    const [user, setUser] = useState<AdminUserDetail | null>(null);
    const [role, setRole] = useState<'user' | 'staff' | 'admin' | 'superuser'>('user');
    const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isSavingRole, setIsSavingRole] = useState(false);
    const [isSavingPermissions, setIsSavingPermissions] = useState(false);
    const [isSyncingPterodactyl, setIsSyncingPterodactyl] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [message, setMessage] = useState<string | null>(null);

    useEffect(() => {
        async function loadUser() {
            if (!id) {
                setError('Missing user id.');
                setIsLoading(false);
                return;
            }

            try {
                const data = await getAdminUserById(id);
                setUser(data);
                setRole(data.role);
                setSelectedPermissions(data.permissions);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load user details.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadUser();
    }, [id]);

    const permissionSet = useMemo(
        () => new Set(selectedPermissions),
        [selectedPermissions],
    );

    function togglePermission(permissionKey: string) {
        setSelectedPermissions((current) =>
            current.includes(permissionKey)
                ? current.filter((key) => key !== permissionKey)
                : [...current, permissionKey],
        );
    }

    async function handleRoleSave() {
        if (!id) return;

        try {
            setIsSavingRole(true);
            const updated = await updateAdminUserRole(id, role);
            setUser(updated);
            setSelectedPermissions(updated.permissions);
            setMessage('Role updated successfully.');
            setError(null);
        } catch (updateError) {
            setError(
                updateError instanceof Error
                    ? updateError.message
                    : 'Failed to update role.',
            );
        } finally {
            setIsSavingRole(false);
        }
    }

    async function handlePermissionsSave() {
        if (!id) return;

        try {
            setIsSavingPermissions(true);
            const updated = await updateAdminUserPermissions(id, selectedPermissions);
            setUser(updated);
            setSelectedPermissions(updated.permissions);
            setMessage('Permissions updated successfully.');
            setError(null);
        } catch (updateError) {
            setError(
                updateError instanceof Error
                    ? updateError.message
                    : 'Failed to update permissions.',
            );
        } finally {
            setIsSavingPermissions(false);
        }
    }

    async function handlePterodactylSync() {
        if (!id) return;

        try {
            setIsSyncingPterodactyl(true);
            const updated = await syncAdminUserPterodactylAccount(id);
            setUser(updated);
            setMessage('Pterodactyl account synced successfully.');
            setError(null);
        } catch (syncError) {
            setError(
                syncError instanceof Error
                    ? syncError.message
                    : 'Failed to sync Pterodactyl account.',
            );
        } finally {
            setIsSyncingPterodactyl(false);
        }
    }

    if (isLoading) {
        return <div className="text-sm text-white/70">Loading user details...</div>;
    }

    if (!user) {
        return (
            <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                {error ?? 'User not found.'}
            </div>
        );
    }

    return (
        <section className="space-y-6">
            <div className="flex items-center justify-between">
                <div>
                    <h2 className="text-xl font-semibold">{user.name}</h2>
                    <p className="mt-1 text-sm text-white/70">{user.email}</p>
                </div>
                <Link to="/admin/users" className="text-sm text-[var(--panel-primary)] hover:underline">
                    Back to users
                </Link>
            </div>

            {message ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-900/20 dark:text-emerald-300">
                    {message}
                </div>
            ) : null}
            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="grid gap-6 lg:grid-cols-2">
                <article className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5">
                    <h3 className="text-lg font-semibold">Account Info</h3>
                    <dl className="space-y-2 text-sm">
                        <div className="flex justify-between gap-4">
                            <dt className="text-white/70">Role</dt>
                            <dd>{user.role}</dd>
                        </div>
                        <div className="flex justify-between gap-4">
                            <dt className="text-white/70">Created</dt>
                            <dd>{formatDate(user.created_at)}</dd>
                        </div>
                        <div className="flex justify-between gap-4">
                            <dt className="text-white/70">Last login</dt>
                            <dd>{formatDate(user.last_login_at)}</dd>
                        </div>
                        <div className="flex justify-between gap-4">
                            <dt className="text-white/70">Pterodactyl User ID</dt>
                            <dd>{user.pterodactyl_user_id ?? '-'}</dd>
                        </div>
                    </dl>

                    <div className="space-y-2">
                        <label className="text-sm font-medium">Role</label>
                        <select
                            value={role}
                            onChange={(event) =>
                                setRole(
                                    event.target.value as
                                        | 'user'
                                        | 'staff'
                                        | 'admin'
                                        | 'superuser',
                                )
                            }
                            className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        >
                            <option value="user">User</option>
                            <option value="staff">Staff</option>
                            <option value="admin">Admin</option>
                            <option value="superuser">Superuser</option>
                        </select>
                        <button
                            type="button"
                            onClick={() => void handleRoleSave()}
                            disabled={isSavingRole}
                            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                        >
                            {isSavingRole ? 'Saving...' : 'Save Role'}
                        </button>
                    </div>

                    <div className="space-y-2">
                        <button
                            type="button"
                            onClick={() => void handlePterodactylSync()}
                            disabled={isSyncingPterodactyl}
                            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                        >
                            {isSyncingPterodactyl
                                ? 'Syncing...'
                                : 'Sync Pterodactyl Account'}
                        </button>
                        {user.pterodactyl_user_id && user.pterodactyl_panel_url ? (
                            <a
                                href={`${user.pterodactyl_panel_url}/admin/users/view/${user.pterodactyl_user_id}`}
                                target="_blank"
                                rel="noreferrer"
                                className="inline-block text-sm text-[var(--panel-primary)] hover:underline"
                            >
                                View user in Pterodactyl
                            </a>
                        ) : null}
                    </div>
                </article>

                <article className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5">
                    <h3 className="text-lg font-semibold">Permissions</h3>
                    <p className="text-sm text-white/70">
                        Staff accounts require explicit permission assignments.
                    </p>
                    <div className="grid gap-2">
                        {user.available_permissions.map((permission) => (
                            <label key={permission.key} className="flex items-start gap-2 rounded-lg border border-white/10 p-2 text-sm">
                                <input
                                    type="checkbox"
                                    checked={permissionSet.has(permission.key)}
                                    onChange={() => togglePermission(permission.key)}
                                    disabled={role !== 'staff'}
                                    className="mt-0.5 size-4"
                                />
                                <span>
                                    <span className="font-medium">{permission.key}</span>
                                    <span className="block text-white/70">{permission.description}</span>
                                </span>
                            </label>
                        ))}
                    </div>
                    <button
                        type="button"
                        onClick={() => void handlePermissionsSave()}
                        disabled={role !== 'staff' || isSavingPermissions}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                    >
                        {isSavingPermissions ? 'Saving...' : 'Save Permissions'}
                    </button>
                </article>
            </div>

            <div className="grid gap-6 lg:grid-cols-2">
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5">
                    <h3 className="mb-3 text-lg font-semibold">Services</h3>
                    <ul className="space-y-2 text-sm">
                        {user.services.map((service) => (
                            <li key={service.id} className="flex items-center justify-between rounded-lg border border-white/10 p-2">
                                <span>#{service.id} {service.product?.name ?? 'Service'}</span>
                                <Link to={`/admin/services/${service.id}`} className="text-[var(--panel-primary)] hover:underline">
                                    View
                                </Link>
                            </li>
                        ))}
                        {user.services.length === 0 ? <li className="text-white/70">No services.</li> : null}
                    </ul>
                </article>
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5">
                    <h3 className="mb-3 text-lg font-semibold">Orders</h3>
                    <ul className="space-y-2 text-sm">
                        {user.orders.map((order) => (
                            <li key={order.id} className="flex items-center justify-between rounded-lg border border-white/10 p-2">
                                <span>#{order.id} {order.product?.name ?? 'Order'}</span>
                                <Link to={`/admin/orders/${order.id}`} className="text-[var(--panel-primary)] hover:underline">
                                    View
                                </Link>
                            </li>
                        ))}
                        {user.orders.length === 0 ? <li className="text-white/70">No orders.</li> : null}
                    </ul>
                </article>
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5">
                    <h3 className="mb-3 text-lg font-semibold">Invoices</h3>
                    <ul className="space-y-2 text-sm">
                        {user.invoices.map((invoice) => (
                            <li key={invoice.id} className="flex items-center justify-between rounded-lg border border-white/10 p-2">
                                <span>#{invoice.id}</span>
                                <Link to={`/admin/invoices/${invoice.id}`} className="text-[var(--panel-primary)] hover:underline">
                                    View
                                </Link>
                            </li>
                        ))}
                        {user.invoices.length === 0 ? <li className="text-white/70">No invoices.</li> : null}
                    </ul>
                </article>
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5">
                    <h3 className="mb-3 text-lg font-semibold">Tickets</h3>
                    <ul className="space-y-2 text-sm">
                        {user.tickets.map((ticket) => (
                            <li key={ticket.id} className="flex items-center justify-between rounded-lg border border-white/10 p-2">
                                <span>#{ticket.id} {ticket.subject ?? 'Ticket'}</span>
                                <Link to={`/admin/tickets/${ticket.id}`} className="text-[var(--panel-primary)] hover:underline">
                                    View
                                </Link>
                            </li>
                        ))}
                        {user.tickets.length === 0 ? <li className="text-white/70">No tickets.</li> : null}
                    </ul>
                </article>
            </div>
        </section>
    );
}
