import { useEffect, useMemo, useState } from 'react';
import {
    createAdminPromoCode,
    listAdminPromoCodes,
    toggleAdminPromoCode,
    updateAdminPromoCode,
    type AdminPromoCode,
} from '@/lib/billing-api';

type PromoFormState = Omit<
    AdminPromoCode,
    'id' | 'uses' | 'created_at' | 'redemptions' | 'once_per_user'
>;

const defaultForm: PromoFormState = {
    code: '',
    type: 'percentage',
    value: 10,
    max_uses: null,
    max_redemptions_per_user: null,
    duration_cycles: null,
    expires_at: null,
    minimum_order_amount: null,
    applies_to: 'all',
    eligible_product_ids: [],
    eligible_category_ids: [],
    affiliate_exclusive: false,
    disables_affiliate: false,
    is_active: true,
};

function parseIdList(input: string): number[] {
    return input
        .split(',')
        .map((value) => Number.parseInt(value.trim(), 10))
        .filter((value) => Number.isFinite(value) && value > 0);
}

export function DiscountsPage() {
    const [promoCodes, setPromoCodes] = useState<AdminPromoCode[]>([]);
    const [form, setForm] = useState<PromoFormState>(defaultForm);
    const [eligibleProductIdsInput, setEligibleProductIdsInput] = useState('');
    const [eligibleCategoryIdsInput, setEligibleCategoryIdsInput] = useState('');
    const [editingId, setEditingId] = useState<number | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState<string | null>(null);

    async function loadPromoCodes() {
        setIsLoading(true);
        try {
            const data = await listAdminPromoCodes();
            setPromoCodes(data);
            setError(null);
        } catch (loadError) {
            setError(loadError instanceof Error ? loadError.message : 'Failed to load promo codes.');
        } finally {
            setIsLoading(false);
        }
    }

    useEffect(() => {
        void loadPromoCodes();
    }, []);

    const sortedPromoCodes = useMemo(
        () => [...promoCodes].sort((a, b) => b.id - a.id),
        [promoCodes],
    );

    function resetForm() {
        setForm(defaultForm);
        setEligibleProductIdsInput('');
        setEligibleCategoryIdsInput('');
        setEditingId(null);
    }

    function startEdit(promoCode: AdminPromoCode) {
        setForm({
            code: promoCode.code,
            type: promoCode.type,
            value: promoCode.value,
            max_uses: promoCode.max_uses,
            max_redemptions_per_user: promoCode.max_redemptions_per_user,
            duration_cycles: promoCode.duration_cycles,
            expires_at: promoCode.expires_at,
            minimum_order_amount: promoCode.minimum_order_amount,
            applies_to: promoCode.applies_to,
            eligible_product_ids: promoCode.eligible_product_ids,
            eligible_category_ids: promoCode.eligible_category_ids,
            affiliate_exclusive: promoCode.affiliate_exclusive,
            disables_affiliate: promoCode.disables_affiliate,
            is_active: promoCode.is_active,
        });
        setEligibleProductIdsInput(promoCode.eligible_product_ids.join(','));
        setEligibleCategoryIdsInput(promoCode.eligible_category_ids.join(','));
        setEditingId(promoCode.id);
        setSuccess(null);
        setError(null);
    }

    async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
        event.preventDefault();
        setIsSaving(true);
        setError(null);
        setSuccess(null);

        const payload: PromoFormState = {
            ...form,
            code: form.code.trim().toUpperCase(),
            eligible_product_ids: parseIdList(eligibleProductIdsInput),
            eligible_category_ids: parseIdList(eligibleCategoryIdsInput),
            max_uses: form.max_uses && form.max_uses > 0 ? form.max_uses : null,
            max_redemptions_per_user:
                form.max_redemptions_per_user && form.max_redemptions_per_user > 0
                    ? form.max_redemptions_per_user
                    : null,
            duration_cycles:
                form.duration_cycles && form.duration_cycles > 0
                    ? form.duration_cycles
                    : null,
            minimum_order_amount:
                form.minimum_order_amount && form.minimum_order_amount > 0
                    ? form.minimum_order_amount
                    : null,
            expires_at: form.expires_at || null,
        };

        try {
            if (editingId) {
                const updated = await updateAdminPromoCode(editingId, payload);
                setPromoCodes((current) =>
                    current.map((code) => (code.id === editingId ? updated : code)),
                );
                setSuccess('Promo code updated.');
            } else {
                const created = await createAdminPromoCode(payload);
                setPromoCodes((current) => [created, ...current]);
                setSuccess('Promo code created.');
            }

            resetForm();
        } catch (saveError) {
            setError(saveError instanceof Error ? saveError.message : 'Failed to save promo code.');
        } finally {
            setIsSaving(false);
        }
    }

    async function handleToggle(id: number) {
        try {
            const updated = await toggleAdminPromoCode(id);
            setPromoCodes((current) => current.map((code) => (code.id === id ? updated : code)));
        } catch (toggleError) {
            setError(toggleError instanceof Error ? toggleError.message : 'Failed to toggle promo code.');
        }
    }

    return (
        <section className="space-y-6">
            <header>
                <h1 className="text-3xl font-semibold">Discounts</h1>
                <p className="mt-2 text-white/70">
                    Create and manage promo codes, usage limits, expiry, and affiliate interaction rules.
                </p>
            </header>

            {error ? (
                <div className="rounded-lg border border-rose-300/40 bg-rose-500/10 px-4 py-3 text-sm text-rose-100">
                    {error}
                </div>
            ) : null}
            {success ? (
                <div className="rounded-lg border border-emerald-300/40 bg-emerald-500/10 px-4 py-3 text-sm text-emerald-100">
                    {success}
                </div>
            ) : null}

            <form onSubmit={handleSubmit} className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6">
                <h2 className="text-lg font-semibold">{editingId ? 'Edit promo code' : 'Create promo code'}</h2>
                <div className="mt-4 grid gap-4 md:grid-cols-2">
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Code</span>
                        <input
                            value={form.code}
                            onChange={(event) => setForm((current) => ({ ...current, code: event.target.value.toUpperCase() }))}
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                            required
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Type</span>
                        <select
                            value={form.type}
                            onChange={(event) =>
                                setForm((current) => ({
                                    ...current,
                                    type: event.target.value as PromoFormState['type'],
                                }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        >
                            <option value="percentage">Percentage</option>
                            <option value="fixed">Fixed</option>
                        </select>
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Value</span>
                        <input
                            type="number"
                            min={0.01}
                            step="0.01"
                            value={form.value}
                            onChange={(event) =>
                                setForm((current) => ({ ...current, value: Number(event.target.value) }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                            required
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Max uses</span>
                        <input
                            type="number"
                            min={1}
                            value={form.max_uses ?? ''}
                            onChange={(event) =>
                                setForm((current) => ({
                                    ...current,
                                    max_uses: event.target.value === '' ? null : Number(event.target.value),
                                }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Max redemptions per user</span>
                        <input
                            type="number"
                            min={1}
                            value={form.max_redemptions_per_user ?? ''}
                            onChange={(event) =>
                                setForm((current) => ({
                                    ...current,
                                    max_redemptions_per_user:
                                        event.target.value === '' ? null : Number(event.target.value),
                                }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Discount duration (billing cycles)</span>
                        <input
                            type="number"
                            min={1}
                            value={form.duration_cycles ?? ''}
                            onChange={(event) =>
                                setForm((current) => ({
                                    ...current,
                                    duration_cycles:
                                        event.target.value === '' ? null : Number(event.target.value),
                                }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Minimum order amount</span>
                        <input
                            type="number"
                            min={0}
                            step="0.01"
                            value={form.minimum_order_amount ?? ''}
                            onChange={(event) =>
                                setForm((current) => ({
                                    ...current,
                                    minimum_order_amount:
                                        event.target.value === '' ? null : Number(event.target.value),
                                }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Expires at</span>
                        <input
                            type="datetime-local"
                            value={form.expires_at ? form.expires_at.slice(0, 16) : ''}
                            onChange={(event) =>
                                setForm((current) => ({
                                    ...current,
                                    expires_at: event.target.value ? new Date(event.target.value).toISOString() : null,
                                }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Applies to</span>
                        <select
                            value={form.applies_to}
                            onChange={(event) =>
                                setForm((current) => ({
                                    ...current,
                                    applies_to: event.target.value as PromoFormState['applies_to'],
                                }))
                            }
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                        >
                            <option value="all">All</option>
                            <option value="products">Products</option>
                            <option value="categories">Categories</option>
                        </select>
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Eligible product IDs (comma-separated)</span>
                        <input
                            value={eligibleProductIdsInput}
                            onChange={(event) => setEligibleProductIdsInput(event.target.value)}
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                            placeholder="1,2,3"
                        />
                    </label>
                    <label className="space-y-1 text-sm">
                        <span className="text-white/80">Eligible category IDs (comma-separated)</span>
                        <input
                            value={eligibleCategoryIdsInput}
                            onChange={(event) => setEligibleCategoryIdsInput(event.target.value)}
                            className="w-full rounded-lg border border-white/15 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                            placeholder="1,2"
                        />
                    </label>
                </div>
                <div className="mt-4 flex flex-wrap items-center gap-4 text-sm">
                    <label className="inline-flex items-center gap-2">
                        <input
                            type="checkbox"
                            checked={form.affiliate_exclusive}
                            onChange={(event) =>
                                setForm((current) => ({ ...current, affiliate_exclusive: event.target.checked }))
                            }
                        />
                        Affiliate exclusive
                    </label>
                    <label className="inline-flex items-center gap-2">
                        <input
                            type="checkbox"
                            checked={form.disables_affiliate}
                            onChange={(event) =>
                                setForm((current) => ({ ...current, disables_affiliate: event.target.checked }))
                            }
                        />
                        Disable affiliate commission
                    </label>
                    <label className="inline-flex items-center gap-2">
                        <input
                            type="checkbox"
                            checked={form.is_active}
                            onChange={(event) =>
                                setForm((current) => ({ ...current, is_active: event.target.checked }))
                            }
                        />
                        Active
                    </label>
                </div>
                <div className="mt-5 flex gap-3">
                    <button
                        type="submit"
                        disabled={isSaving}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                    >
                        {isSaving ? 'Saving...' : editingId ? 'Update Promo Code' : 'Create Promo Code'}
                    </button>
                    {editingId ? (
                        <button
                            type="button"
                            onClick={resetForm}
                            className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10"
                        >
                            Cancel edit
                        </button>
                    ) : null}
                </div>
            </form>

            <div className="overflow-hidden rounded-xl border border-white/10 bg-[var(--panel-surface)]">
                <table className="min-w-full divide-y divide-white/10 text-sm">
                    <thead>
                        <tr className="text-left text-white/70">
                            <th className="px-4 py-3">Code</th>
                            <th className="px-4 py-3">Type</th>
                            <th className="px-4 py-3">Value</th>
                            <th className="px-4 py-3">Uses</th>
                            <th className="px-4 py-3">Status</th>
                            <th className="px-4 py-3">Actions</th>
                        </tr>
                    </thead>
                    <tbody className="divide-y divide-white/10">
                        {isLoading ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={6}>Loading promo codes...</td>
                            </tr>
                        ) : sortedPromoCodes.length === 0 ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={6}>No promo codes created yet.</td>
                            </tr>
                        ) : (
                            sortedPromoCodes.map((promoCode) => (
                                <tr key={promoCode.id}>
                                    <td className="px-4 py-3 font-mono">{promoCode.code}</td>
                                    <td className="px-4 py-3">{promoCode.type}</td>
                                    <td className="px-4 py-3">{promoCode.value}</td>
                                    <td className="px-4 py-3">
                                        {promoCode.uses}
                                        {promoCode.max_uses ? ` / ${promoCode.max_uses}` : ''}
                                    </td>
                                    <td className="px-4 py-3">
                                        <span className={`rounded-full px-2 py-1 text-xs ${promoCode.is_active ? 'bg-emerald-500/20 text-emerald-300' : 'bg-rose-500/20 text-rose-300'}`}>
                                            {promoCode.is_active ? 'Active' : 'Disabled'}
                                        </span>
                                    </td>
                                    <td className="px-4 py-3">
                                        <div className="flex flex-wrap gap-2">
                                            <button
                                                type="button"
                                                onClick={() => startEdit(promoCode)}
                                                className="rounded border border-white/20 px-2 py-1 text-xs hover:bg-white/10"
                                            >
                                                Edit
                                            </button>
                                            <button
                                                type="button"
                                                onClick={() => void handleToggle(promoCode.id)}
                                                className="rounded border border-white/20 px-2 py-1 text-xs hover:bg-white/10"
                                            >
                                                {promoCode.is_active ? 'Disable' : 'Enable'}
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}
