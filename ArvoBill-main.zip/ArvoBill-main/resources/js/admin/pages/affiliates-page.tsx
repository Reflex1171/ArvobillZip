import { useEffect, useState } from 'react';
import {
    getAdminAffiliateData,
    updateAffiliateEarningStatus,
    updateAffiliateSettings,
} from '@/lib/affiliate-api';
import type { AffiliateAdminPayload, AffiliateAdminSettings } from '@/types/affiliate';
import { formatCurrency } from '@/lib/billing-api';

function formatDate(value: string | null): string {
    if (!value) return '-';

    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function AffiliatesPage() {
    const [data, setData] = useState<AffiliateAdminPayload | null>(null);
    const [settings, setSettings] = useState<AffiliateAdminSettings | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);

    async function load() {
        try {
            setIsLoading(true);
            const payload = await getAdminAffiliateData();
            setData(payload);
            setSettings(payload.settings);
            setError(null);
        } catch (loadError) {
            setError(loadError instanceof Error ? loadError.message : 'Failed to load affiliate data.');
        } finally {
            setIsLoading(false);
        }
    }

    useEffect(() => {
        void load();
    }, []);

    async function saveSettings() {
        if (!settings) return;

        try {
            setIsSaving(true);
            await updateAffiliateSettings(settings);
            await load();
        } catch (saveError) {
            setError(saveError instanceof Error ? saveError.message : 'Failed to save settings.');
        } finally {
            setIsSaving(false);
        }
    }

    async function setEarningStatus(id: number, status: 'approved' | 'rejected' | 'paid') {
        try {
            await updateAffiliateEarningStatus(id, status);
            await load();
        } catch (updateError) {
            setError(updateError instanceof Error ? updateError.message : 'Failed to update earning.');
        }
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold">Affiliates</h2>
                <p className="mt-1 text-sm text-white/70">
                    Configure commission rules and manage affiliate earnings.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="text-lg font-semibold">Program Settings</h3>

                <div className="mt-4 grid gap-4 md:grid-cols-2">
                    <label className="flex items-center gap-3 text-sm">
                        <input
                            type="checkbox"
                            checked={Boolean(settings?.enabled)}
                            onChange={(event) =>
                                setSettings((current) =>
                                    current ? { ...current, enabled: event.target.checked } : current,
                                )
                            }
                        />
                        <span>Enable affiliate program</span>
                    </label>

                    <label className="space-y-1 text-sm">
                        <span className="font-medium">Commission %</span>
                        <input
                            type="number"
                            min={0}
                            max={100}
                            step="0.01"
                            value={settings?.commission_percent ?? 10}
                            onChange={(event) =>
                                setSettings((current) =>
                                    current
                                        ? { ...current, commission_percent: Number(event.target.value) }
                                        : current,
                                )
                            }
                            className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        />
                    </label>

                    <label className="space-y-1 text-sm">
                        <span className="font-medium">Commission Scope</span>
                        <select
                            value={settings?.commission_scope ?? 'first_invoice'}
                            onChange={(event) =>
                                setSettings((current) =>
                                    current
                                        ? {
                                              ...current,
                                              commission_scope: event.target.value as
                                                  | 'first_invoice'
                                                  | 'recurring'
                                                  | 'tiered',
                                          }
                                        : current,
                                )
                            }
                            className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        >
                            <option value="first_invoice">First invoice only</option>
                            <option value="recurring">Recurring invoices</option>
                            <option value="tiered">Tiered (higher first invoice)</option>
                        </select>
                    </label>

                    <label className="space-y-1 text-sm">
                        <span className="font-medium">First Invoice Commission %</span>
                        <input
                            type="number"
                            min={0}
                            max={100}
                            step="0.01"
                            value={settings?.first_invoice_commission_percent ?? 15}
                            onChange={(event) =>
                                setSettings((current) =>
                                    current
                                        ? {
                                              ...current,
                                              first_invoice_commission_percent: Number(event.target.value),
                                          }
                                        : current,
                                )
                            }
                            className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        />
                    </label>

                    <label className="space-y-1 text-sm">
                        <span className="font-medium">Recurring Commission %</span>
                        <input
                            type="number"
                            min={0}
                            max={100}
                            step="0.01"
                            value={settings?.recurring_commission_percent ?? 5}
                            onChange={(event) =>
                                setSettings((current) =>
                                    current
                                        ? {
                                              ...current,
                                              recurring_commission_percent: Number(event.target.value),
                                          }
                                        : current,
                                )
                            }
                            className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        />
                    </label>

                    <label className="space-y-1 text-sm">
                        <span className="font-medium">Approval Delay (days)</span>
                        <input
                            type="number"
                            min={0}
                            max={365}
                            value={settings?.approval_delay_days ?? 30}
                            onChange={(event) =>
                                setSettings((current) =>
                                    current
                                        ? { ...current, approval_delay_days: Number(event.target.value) }
                                        : current,
                                )
                            }
                            className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        />
                    </label>
                </div>

                <button
                    type="button"
                    onClick={() => void saveSettings()}
                    disabled={isSaving}
                    className="mt-4 rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                >
                    {isSaving ? 'Saving...' : 'Save Settings'}
                </button>
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="mb-4 text-lg font-semibold">Affiliates</h3>
                <div className="overflow-x-auto rounded-lg border border-white/10">
                    <table className="min-w-full text-left text-sm">
                        <thead className="bg-white/5 text-white/70">
                            <tr>
                                <th className="px-4 py-3 font-medium">User</th>
                                <th className="px-4 py-3 font-medium">Code</th>
                                <th className="px-4 py-3 font-medium">Referrals</th>
                                <th className="px-4 py-3 font-medium">Pending</th>
                                <th className="px-4 py-3 font-medium">Approved</th>
                                <th className="px-4 py-3 font-medium">Balance</th>
                            </tr>
                        </thead>
                        <tbody>
                            {isLoading ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={6}>Loading affiliates...</td>
                                </tr>
                            ) : (data?.affiliates.length ?? 0) === 0 ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={6}>No affiliates found.</td>
                                </tr>
                            ) : (
                                data?.affiliates.map((affiliate) => (
                                    <tr key={affiliate.id} className="border-t border-white/10">
                                        <td className="px-4 py-3">{affiliate.name}<div className="text-xs text-white/70">{affiliate.email}</div></td>
                                        <td className="px-4 py-3 font-mono">{affiliate.affiliate_code ?? '-'}</td>
                                        <td className="px-4 py-3">{affiliate.referrals_count}</td>
                                        <td className="px-4 py-3">{formatCurrency(affiliate.pending_earnings)}</td>
                                        <td className="px-4 py-3">{formatCurrency(affiliate.approved_earnings)}</td>
                                        <td className="px-4 py-3">{formatCurrency(affiliate.affiliate_balance)}</td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="mb-4 text-lg font-semibold">Earnings</h3>
                <div className="overflow-x-auto rounded-lg border border-white/10">
                    <table className="min-w-full text-left text-sm">
                        <thead className="bg-white/5 text-white/70">
                            <tr>
                                <th className="px-4 py-3 font-medium">ID</th>
                                <th className="px-4 py-3 font-medium">Affiliate</th>
                                <th className="px-4 py-3 font-medium">Referred User</th>
                                <th className="px-4 py-3 font-medium">Invoice</th>
                                <th className="px-4 py-3 font-medium">Amount</th>
                                <th className="px-4 py-3 font-medium">Status</th>
                                <th className="px-4 py-3 font-medium">Eligible</th>
                                <th className="px-4 py-3 font-medium">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {isLoading ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={8}>Loading earnings...</td>
                                </tr>
                            ) : (data?.earnings.length ?? 0) === 0 ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={8}>No earnings found.</td>
                                </tr>
                            ) : (
                                data?.earnings.map((earning) => (
                                    <tr key={earning.id} className="border-t border-white/10">
                                        <td className="px-4 py-3">#{earning.id}</td>
                                        <td className="px-4 py-3">{earning.affiliate_user?.email ?? '-'}</td>
                                        <td className="px-4 py-3">{earning.referred_user?.email ?? '-'}</td>
                                        <td className="px-4 py-3">#{earning.invoice_id}</td>
                                        <td className="px-4 py-3">{formatCurrency(earning.amount)}</td>
                                        <td className="px-4 py-3 capitalize">{earning.status}</td>
                                        <td className="px-4 py-3">{formatDate(earning.eligible_at)}</td>
                                        <td className="px-4 py-3">
                                            <div className="flex gap-2">
                                                <button type="button" onClick={() => void setEarningStatus(earning.id, 'approved')} className="rounded border border-white/20 px-2 py-1 text-xs">Approve</button>
                                                <button type="button" onClick={() => void setEarningStatus(earning.id, 'paid')} className="rounded border border-white/20 px-2 py-1 text-xs">Paid</button>
                                                <button type="button" onClick={() => void setEarningStatus(earning.id, 'rejected')} className="rounded border border-rose-400/50 px-2 py-1 text-xs text-rose-200">Reject</button>
                                            </div>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </article>
        </section>
    );
}
