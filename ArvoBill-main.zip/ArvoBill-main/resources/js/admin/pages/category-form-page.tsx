import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  createAdminCategory,
  getAdminCategoryById,
  updateAdminCategory,
} from '@/lib/products-api';
import type { CategoryPayload } from '@/types/category';

type CategoryFormState = {
  name: string;
  slug: string;
  description: string;
};

const initialState: CategoryFormState = {
  name: '',
  slug: '',
  description: '',
};

function toSlug(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

export function CategoryFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = useMemo(() => Boolean(id), [id]);
  const navigate = useNavigate();

  const [form, setForm] = useState<CategoryFormState>(initialState);
  const [isLoading, setIsLoading] = useState(isEdit);
  const [isSaving, setIsSaving] = useState(false);
  const [slugEdited, setSlugEdited] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadCategory() {
      if (!id) return;

      try {
        const category = await getAdminCategoryById(id);
        setForm({
          name: category.name,
          slug: category.slug,
          description: category.description ?? '',
        });
        setSlugEdited(true);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load category.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadCategory();
  }, [id]);

  function onNameChange(event: ChangeEvent<HTMLInputElement>) {
    const nextName = event.target.value;
    setForm((current) => ({
      ...current,
      name: nextName,
      slug: slugEdited ? current.slug : toSlug(nextName),
    }));
  }

  function onSlugChange(event: ChangeEvent<HTMLInputElement>) {
    setSlugEdited(true);
    setForm((current) => ({
      ...current,
      slug: event.target.value,
    }));
  }

  function onDescriptionChange(event: ChangeEvent<HTMLTextAreaElement>) {
    setForm((current) => ({
      ...current,
      description: event.target.value,
    }));
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const payload: CategoryPayload = {
      name: form.name.trim(),
      slug: form.slug.trim(),
      description: form.description.trim() === '' ? null : form.description.trim(),
    };

    if (!payload.name) {
      setError('Category name is required.');

      return;
    }

    try {
      setIsSaving(true);
      setError(null);

      if (id) {
        await updateAdminCategory(id, payload);
      } else {
        await createAdminCategory(payload);
      }

      navigate('/admin/categories');
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : 'Failed to save category.',
      );
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <section className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">
            {isEdit ? 'Edit Category' : 'New Category'}
          </h2>
          <p className="mt-1 text-sm text-white/70 ">
            Categories drive public product navigation URLs.
          </p>
        </div>
        <Link
          to="/admin/categories"
          className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
        >
          Back to Categories
        </Link>
      </section>

      {isLoading ? (
        <div className="rounded-lg border border-white/10 bg-[var(--panel-surface)] p-4 text-sm text-white/70  ">
          Loading category...
        </div>
      ) : null}

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      {!isLoading ? (
        <form
          onSubmit={(event) => void onSubmit(event)}
          className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm "
        >
          <label className="block space-y-1">
            <span className="text-sm font-medium">Name</span>
            <input
              name="name"
              value={form.name}
              onChange={onNameChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              required
            />
          </label>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Slug</span>
            <input
              name="slug"
              value={form.slug}
              onChange={onSlugChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              placeholder="minecraft-hosting"
            />
          </label>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Description</span>
            <textarea
              value={form.description}
              onChange={onDescriptionChange}
              rows={4}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
            />
          </label>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSaving}
              className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
            >
              {isSaving
                ? 'Saving...'
                : isEdit
                 ? 'Update Category'
                 : 'Create Category'}
            </button>
          </div>
        </form>
      ) : null}
    </div>
  );
}
