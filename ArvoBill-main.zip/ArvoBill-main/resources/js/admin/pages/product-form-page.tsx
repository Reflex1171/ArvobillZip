import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  createAdminProduct,
  getAdminProductById,
  listAdminCategories,
  updateAdminProduct,
} from '@/lib/products-api';
import type { ProductCategory } from '@/types/category';
import type { ProductPayload } from '@/types/product';

type ProductFormState = {
  name: string;
  slug: string;
  description: string;
  category_id: string;
  price_monthly: string;
  setup_fee: string;
  is_active: boolean;
};

const initialState: ProductFormState = {
  name: '',
  slug: '',
  description: '',
  category_id: '',
  price_monthly: '',
  setup_fee: '',
  is_active: true,
};

function toSlug(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

export function ProductFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = useMemo(() => Boolean(id), [id]);
  const navigate = useNavigate();

  const [form, setForm] = useState<ProductFormState>(initialState);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [isLoading, setIsLoading] = useState(isEdit);
  const [isSaving, setIsSaving] = useState(false);
  const [slugEdited, setSlugEdited] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadCategories() {
      try {
        const data = await listAdminCategories();
        setCategories(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load categories.',
        );
      }
    }

    void loadCategories();
  }, []);

  useEffect(() => {
    async function loadProduct() {
      if (!id) return;

      try {
        const product = await getAdminProductById(id);
        setForm({
          name: product.name,
          slug: product.slug,
          description: product.description,
          category_id:
            product.category_id !== null
              ? String(product.category_id)
              : '',
          price_monthly: String(product.price_monthly),
          setup_fee:
            product.setup_fee !== null ? String(product.setup_fee) : '',
          is_active: product.is_active,
        });
        setSlugEdited(true);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load product.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadProduct();
  }, [id]);

  function onNameChange(event: ChangeEvent<HTMLInputElement>) {
    const nextName = event.target.value;

    setForm((current) => ({
      ...current,
      name: nextName,
      slug: slugEdited ? current.slug : toSlug(nextName),
    }));
  }

  function onSlugChange(event: ChangeEvent<HTMLInputElement>) {
    setSlugEdited(true);
    setForm((current) => ({
      ...current,
      slug: event.target.value,
    }));
  }

  function onInputChange(
    event: ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) {
    const { name, value } = event.target;
    setForm((current) => ({
      ...current,
      [name]: value,
    }));
  }

  function onToggleActive(event: ChangeEvent<HTMLInputElement>) {
    setForm((current) => ({
      ...current,
      is_active: event.target.checked,
    }));
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const payload: ProductPayload = {
      name: form.name.trim(),
      slug: form.slug.trim(),
      description: form.description.trim(),
      category_id: Number(form.category_id),
      price_monthly: Number(form.price_monthly),
      setup_fee: form.setup_fee.trim() === '' ? null : Number(form.setup_fee),
      is_active: form.is_active,
    };

    if (!payload.name || !payload.description) {
      setError('Name and description are required.');

      return;
    }

    if (Number.isNaN(payload.category_id) || payload.category_id <= 0) {
      setError('Category is required.');

      return;
    }

    if (Number.isNaN(payload.price_monthly) || payload.price_monthly < 0) {
      setError('Monthly price must be a valid non-negative number.');

      return;
    }

    if (
      payload.setup_fee !== null &&
      (Number.isNaN(payload.setup_fee) || payload.setup_fee < 0)
    ) {
      setError('Setup fee must be a valid non-negative number.');

      return;
    }

    try {
      setIsSaving(true);
      setError(null);

      if (id) {
        await updateAdminProduct(id, payload);
      } else {
        await createAdminProduct(payload);
      }

      navigate('/admin/products');
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : 'Failed to save product.',
      );
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <section className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">
            {isEdit ? 'Edit Product' : 'New Product'}
          </h2>
          <p className="mt-1 text-sm text-white/70 ">
            Define catalogue data now so checkout can integrate later.
          </p>
        </div>
        <Link
          to="/admin/products"
          className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
        >
          Back to Products
        </Link>
      </section>
      {isEdit && id ? (
        <section>
          <Link
            to={`/admin/products/${id}/configurations`}
            className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
          >
            Manage Configurations
          </Link>
        </section>
      ) : null}

      {isLoading ? (
        <div className="rounded-lg border border-white/10 bg-[var(--panel-surface)] p-4 text-sm text-white/70  ">
          Loading product...
        </div>
      ) : null}

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      {!isLoading ? (
        <form
          onSubmit={(event) => void onSubmit(event)}
          className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm "
        >
          <label className="block space-y-1">
            <span className="text-sm font-medium">Name</span>
            <input
              name="name"
              value={form.name}
              onChange={onNameChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              required
            />
          </label>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Slug</span>
            <input
              name="slug"
              value={form.slug}
              onChange={onSlugChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              placeholder="auto-generated-from-name"
            />
          </label>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Description</span>
            <textarea
              name="description"
              value={form.description}
              onChange={onInputChange}
              rows={4}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              required
            />
          </label>

          <div className="grid gap-4 md:grid-cols-2">
            <label className="block space-y-1">
              <span className="text-sm font-medium">Category</span>
              <select
                name="category_id"
                value={form.category_id}
                onChange={onInputChange}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
                required
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block space-y-1">
              <span className="text-sm font-medium">
                Monthly price (USD)
              </span>
              <input
                name="price_monthly"
                type="number"
                step="0.01"
                min="0"
                value={form.price_monthly}
                onChange={onInputChange}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
                required
              />
            </label>
          </div>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Setup fee (USD)</span>
            <input
              name="setup_fee"
              type="number"
              step="0.01"
              min="0"
              value={form.setup_fee}
              onChange={onInputChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              placeholder="Optional"
            />
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={onToggleActive}
              className="size-4 rounded border-white/20 "
            />
            <span className="text-sm font-medium">Product is active</span>
          </label>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSaving}
              className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
            >
              {isSaving
                ? 'Saving...'
                : isEdit
                 ? 'Update Product'
                 : 'Create Product'}
            </button>
          </div>
        </form>
      ) : null}
    </div>
  );
}
