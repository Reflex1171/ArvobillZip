import { ChangeEvent, FormEvent, useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
  createAdminProduct,
  getAdminProductById,
  listAdminCategories,
  updateAdminProduct,
} from '@/lib/products-api';
import type { ProductCategory } from '@/types/category';
import type { ProductPayload } from '@/types/product';

type ProductFormState = {
  name: string;
  slug: string;
  description: string;
  category_id: string;
  price_monthly: string;
  setup_fee: string;
  billing_type: 'one_time' | 'recurring';
  billing_interval: string;
  billing_period: 'day' | 'week' | 'month' | 'year';
  allow_auto_renew: boolean;
  trial_enabled: boolean;
  trial_interval: string;
  trial_period: 'day' | 'week' | 'month' | 'year';
  infrastructure_type: 'none' | 'pterodactyl';
  pterodactyl_egg_id: string;
  pterodactyl_location_id: string;
  auto_provision: boolean;
  is_active: boolean;
};

const initialState: ProductFormState = {
  name: '',
  slug: '',
  description: '',
  category_id: '',
  price_monthly: '',
  setup_fee: '',
  billing_type: 'recurring',
  billing_interval: '1',
  billing_period: 'month',
  allow_auto_renew: true,
  trial_enabled: false,
  trial_interval: '7',
  trial_period: 'day',
  infrastructure_type: 'none',
  pterodactyl_egg_id: '',
  pterodactyl_location_id: '',
  auto_provision: true,
  is_active: true,
};

function toSlug(value: string): string {
  return value
    .trim()
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-');
}

export function ProductFormPage() {
  const { id } = useParams<{ id: string }>();
  const isEdit = useMemo(() => Boolean(id), [id]);
  const navigate = useNavigate();

  const [form, setForm] = useState<ProductFormState>(initialState);
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [isLoading, setIsLoading] = useState(isEdit);
  const [isSaving, setIsSaving] = useState(false);
  const [slugEdited, setSlugEdited] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadCategories() {
      try {
        const data = await listAdminCategories();
        setCategories(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load categories.',
        );
      }
    }

    void loadCategories();
  }, []);

  useEffect(() => {
    async function loadProduct() {
      if (!id) return;

      try {
        const product = await getAdminProductById(id);
        setForm({
          name: product.name,
          slug: product.slug,
          description: product.description,
          category_id:
            product.category_id !== null
              ? String(product.category_id)
              : '',
          price_monthly: String(product.price_monthly),
          setup_fee:
            product.setup_fee !== null ? String(product.setup_fee) : '',
          billing_type: product.billing_type ?? 'recurring',
          billing_interval:
            product.billing_interval !== null
              ? String(product.billing_interval)
              : '1',
          billing_period: product.billing_period ?? 'month',
          allow_auto_renew: Boolean(product.allow_auto_renew ?? true),
          trial_enabled: Boolean(product.trial_enabled ?? false),
          trial_interval:
            product.trial_interval !== null
              ? String(product.trial_interval)
              : '7',
          trial_period: product.trial_period ?? 'day',
          infrastructure_type:
            product.infrastructure_type === 'pterodactyl'
              ? 'pterodactyl'
              : 'none',
          pterodactyl_egg_id:
            product.pterodactyl_egg_id !== null
              ? String(product.pterodactyl_egg_id)
              : '',
          pterodactyl_location_id:
            product.pterodactyl_location_id !== null
              ? String(product.pterodactyl_location_id)
              : '',
          auto_provision: Boolean(product.auto_provision),
          is_active: product.is_active,
        });
        setSlugEdited(true);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load product.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadProduct();
  }, [id]);

  function onNameChange(event: ChangeEvent<HTMLInputElement>) {
    const nextName = event.target.value;

    setForm((current) => ({
      ...current,
      name: nextName,
      slug: slugEdited ? current.slug : toSlug(nextName),
    }));
  }

  function onSlugChange(event: ChangeEvent<HTMLInputElement>) {
    setSlugEdited(true);
    setForm((current) => ({
      ...current,
      slug: event.target.value,
    }));
  }

  function onInputChange(
    event: ChangeEvent<
      HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement
    >,
  ) {
    const { name, value } = event.target;
    setForm((current) => ({
      ...current,
      [name]: value,
    }));
  }

  function onToggleActive(event: ChangeEvent<HTMLInputElement>) {
    setForm((current) => ({
      ...current,
      is_active: event.target.checked,
    }));
  }

  function onToggleAutoProvision(event: ChangeEvent<HTMLInputElement>) {
    setForm((current) => ({
      ...current,
      auto_provision: event.target.checked,
    }));
  }

  function onToggleAllowAutoRenew(event: ChangeEvent<HTMLInputElement>) {
    setForm((current) => ({
      ...current,
      allow_auto_renew: event.target.checked,
    }));
  }

  function onToggleTrial(event: ChangeEvent<HTMLInputElement>) {
    setForm((current) => ({
      ...current,
      trial_enabled: event.target.checked,
    }));
  }

  async function onSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();

    const payload: ProductPayload = {
      name: form.name.trim(),
      slug: form.slug.trim(),
      description: form.description.trim(),
      category_id: Number(form.category_id),
      price_monthly: Number(form.price_monthly),
      setup_fee: form.setup_fee.trim() === '' ? null : Number(form.setup_fee),
      billing_type: form.billing_type,
      billing_interval:
        form.billing_type === 'recurring'
          ? Number(form.billing_interval)
          : null,
      billing_period:
        form.billing_type === 'recurring' ? form.billing_period : null,
      allow_auto_renew:
        form.billing_type === 'recurring' ? form.allow_auto_renew : false,
      trial_enabled:
        form.billing_type === 'recurring' ? form.trial_enabled : false,
      trial_interval:
        form.billing_type === 'recurring' && form.trial_enabled
          ? Number(form.trial_interval)
          : null,
      trial_period:
        form.billing_type === 'recurring' && form.trial_enabled
          ? form.trial_period
          : null,
      infrastructure_type: form.infrastructure_type,
      pterodactyl_egg_id:
        form.pterodactyl_egg_id.trim() === ''
          ? null
          : Number(form.pterodactyl_egg_id),
      pterodactyl_location_id:
        form.pterodactyl_location_id.trim() === ''
          ? null
          : Number(form.pterodactyl_location_id),
      pterodactyl_default_node_id: null,
      auto_provision: form.auto_provision,
      is_active: form.is_active,
    };

    if (!payload.name || !payload.description) {
      setError('Name and description are required.');

      return;
    }

    if (Number.isNaN(payload.category_id) || payload.category_id <= 0) {
      setError('Category is required.');

      return;
    }

    if (Number.isNaN(payload.price_monthly) || payload.price_monthly < 0) {
      setError('Monthly price must be a valid non-negative number.');

      return;
    }

    if (
      payload.setup_fee !== null &&
      (Number.isNaN(payload.setup_fee) || payload.setup_fee < 0)
    ) {
      setError('Setup fee must be a valid non-negative number.');

      return;
    }

    if (
      payload.billing_type === 'recurring' &&
      (
        payload.billing_interval === null ||
        Number.isNaN(payload.billing_interval) ||
        payload.billing_interval < 1
      )
    ) {
      setError('Recurring products require a billing interval of at least 1.');
      return;
    }

    if (
      payload.trial_enabled &&
      (
        payload.trial_interval === null ||
        Number.isNaN(payload.trial_interval) ||
        payload.trial_interval < 1
      )
    ) {
      setError('Trials require a valid interval of at least 1.');
      return;
    }

    if (
      payload.infrastructure_type === 'pterodactyl' &&
      payload.pterodactyl_egg_id !== null &&
      (Number.isNaN(payload.pterodactyl_egg_id) || payload.pterodactyl_egg_id <= 0)
    ) {
      setError('Pterodactyl Egg ID must be a valid positive number when provided.');
      return;
    }

    if (
      payload.infrastructure_type === 'pterodactyl' &&
      payload.auto_provision &&
      (payload.pterodactyl_location_id === null ||
        Number.isNaN(payload.pterodactyl_location_id) ||
        payload.pterodactyl_location_id <= 0)
    ) {
      setError('Auto-provision requires a valid location ID.');
      return;
    }

    try {
      setIsSaving(true);
      setError(null);

      if (id) {
        await updateAdminProduct(id, payload);
      } else {
        await createAdminProduct(payload);
      }

      navigate('/admin/products');
    } catch (saveError) {
      setError(
        saveError instanceof Error
          ? saveError.message
          : 'Failed to save product.',
      );
    } finally {
      setIsSaving(false);
    }
  }

  return (
    <div className="space-y-6">
      <section className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">
            {isEdit ? 'Edit Product' : 'New Product'}
          </h2>
          <p className="mt-1 text-sm text-white/70 ">
            Define catalogue data now so checkout can integrate later.
          </p>
        </div>
        <Link
          to="/admin/products"
          className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
        >
          Back to Products
        </Link>
      </section>
      {isEdit && id ? (
        <section>
          <Link
            to={`/admin/products/${id}/configurations`}
            className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
          >
            Manage Configurations
          </Link>
        </section>
      ) : null}

      {isLoading ? (
        <div className="rounded-lg border border-white/10 bg-[var(--panel-surface)] p-4 text-sm text-white/70  ">
          Loading product...
        </div>
      ) : null}

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      {!isLoading ? (
        <form
          onSubmit={(event) => void onSubmit(event)}
          className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm "
        >
          <label className="block space-y-1">
            <span className="text-sm font-medium">Name</span>
            <input
              name="name"
              value={form.name}
              onChange={onNameChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              required
            />
          </label>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Slug</span>
            <input
              name="slug"
              value={form.slug}
              onChange={onSlugChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              placeholder="auto-generated-from-name"
            />
          </label>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Description</span>
            <textarea
              name="description"
              value={form.description}
              onChange={onInputChange}
              rows={4}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              required
            />
          </label>

          <div className="grid gap-4 md:grid-cols-2">
            <label className="block space-y-1">
              <span className="text-sm font-medium">Category</span>
              <select
                name="category_id"
                value={form.category_id}
                onChange={onInputChange}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
                required
              >
                <option value="">Select a category</option>
                {categories.map((category) => (
                  <option key={category.id} value={category.id}>
                    {category.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block space-y-1">
              <span className="text-sm font-medium">
                Monthly price (USD)
              </span>
              <input
                name="price_monthly"
                type="number"
                step="0.01"
                min="0"
                value={form.price_monthly}
                onChange={onInputChange}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
                required
              />
            </label>
          </div>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Setup fee (USD)</span>
            <input
              name="setup_fee"
              type="number"
              step="0.01"
              min="0"
              value={form.setup_fee}
              onChange={onInputChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              placeholder="Optional"
            />
          </label>

          <div className="grid gap-4 md:grid-cols-3">
            <label className="block space-y-1">
              <span className="text-sm font-medium">Billing type</span>
              <select
                name="billing_type"
                value={form.billing_type}
                onChange={onInputChange}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              >
                <option value="one_time">One-time</option>
                <option value="recurring">Recurring</option>
              </select>
            </label>
            <label className="block space-y-1">
              <span className="text-sm font-medium">Billing interval</span>
              <input
                name="billing_interval"
                type="number"
                min="1"
                step="1"
                value={form.billing_interval}
                onChange={onInputChange}
                disabled={form.billing_type !== 'recurring'}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm disabled:opacity-60"
              />
            </label>
            <label className="block space-y-1">
              <span className="text-sm font-medium">Billing period unit</span>
              <select
                name="billing_period"
                value={form.billing_period}
                onChange={onInputChange}
                disabled={form.billing_type !== 'recurring'}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm disabled:opacity-60"
              >
                <option value="day">Day</option>
                <option value="week">Week</option>
                <option value="month">Month</option>
                <option value="year">Year</option>
              </select>
            </label>
          </div>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.allow_auto_renew}
              onChange={onToggleAllowAutoRenew}
              disabled={form.billing_type !== 'recurring'}
              className="size-4 rounded border-white/20 disabled:opacity-60"
            />
            <span className="text-sm font-medium">
              Allow auto-renew
            </span>
          </label>

          <div className="grid gap-4 md:grid-cols-3">
            <label className="flex items-center gap-2 md:col-span-3">
              <input
                type="checkbox"
                checked={form.trial_enabled}
                onChange={onToggleTrial}
                disabled={form.billing_type !== 'recurring'}
                className="size-4 rounded border-white/20 disabled:opacity-60"
              />
              <span className="text-sm font-medium">
                Enable free trial
              </span>
            </label>
            <label className="block space-y-1">
              <span className="text-sm font-medium">Trial interval</span>
              <input
                name="trial_interval"
                type="number"
                min="1"
                step="1"
                value={form.trial_interval}
                onChange={onInputChange}
                disabled={!form.trial_enabled || form.billing_type !== 'recurring'}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm disabled:opacity-60"
              />
            </label>
            <label className="block space-y-1">
              <span className="text-sm font-medium">Trial period unit</span>
              <select
                name="trial_period"
                value={form.trial_period}
                onChange={onInputChange}
                disabled={!form.trial_enabled || form.billing_type !== 'recurring'}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm disabled:opacity-60"
              >
                <option value="day">Day</option>
                <option value="week">Week</option>
                <option value="month">Month</option>
                <option value="year">Year</option>
              </select>
            </label>
          </div>

          <div className="grid gap-4 md:grid-cols-2">
            <label className="block space-y-1">
              <span className="text-sm font-medium">Infrastructure Type</span>
              <select
                name="infrastructure_type"
                value={form.infrastructure_type}
                onChange={onInputChange}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              >
                <option value="none">None</option>
                <option value="pterodactyl">Pterodactyl</option>
              </select>
            </label>
            <label className="block space-y-1">
              <span className="text-sm font-medium">Pterodactyl Egg ID</span>
              <input
                name="pterodactyl_egg_id"
                type="number"
                min="1"
                value={form.pterodactyl_egg_id}
                onChange={onInputChange}
                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
                placeholder="Optional fallback/manual provisioning"
              />
            </label>
          </div>

          <label className="block space-y-1">
            <span className="text-sm font-medium">Pterodactyl Location ID</span>
            <input
              name="pterodactyl_location_id"
              type="number"
              min="1"
              value={form.pterodactyl_location_id}
              onChange={onInputChange}
              className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm "
              placeholder="Required when auto-provision is enabled"
            />
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.auto_provision}
              onChange={onToggleAutoProvision}
              className="size-4 rounded border-white/20 "
            />
            <span className="text-sm font-medium">Enable auto-provision after payment</span>
          </label>

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              checked={form.is_active}
              onChange={onToggleActive}
              className="size-4 rounded border-white/20 "
            />
            <span className="text-sm font-medium">Product is active</span>
          </label>

          <div className="pt-2">
            <button
              type="submit"
              disabled={isSaving}
              className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
            >
              {isSaving
                ? 'Saving...'
                : isEdit
                 ? 'Update Product'
                 : 'Create Product'}
            </button>
          </div>
        </form>
      ) : null}
    </div>
  );
}
