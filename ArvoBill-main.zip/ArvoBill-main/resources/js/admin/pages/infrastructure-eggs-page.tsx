import { useEffect, useState } from 'react';
import { listPterodactylEggs } from '@/lib/pterodactyl-api';
import type { PterodactylEgg } from '@/types/pterodactyl';

export function InfrastructureEggsPage() {
    const [eggs, setEggs] = useState<PterodactylEgg[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadEggs() {
            try {
                const data = await listPterodactylEggs();
                setEggs(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load eggs.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadEggs();
    }, []);

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Pterodactyl Eggs</h2>
                <p className="mt-1 text-sm text-white/70">
                    Templates available for future product mapping and provisioning.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)]">
                <table className="min-w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/70">
                        <tr>
                            <th className="px-4 py-3 font-medium">Egg</th>
                            <th className="px-4 py-3 font-medium">Game / Nest</th>
                            <th className="px-4 py-3 font-medium">Docker Image</th>
                            <th className="px-4 py-3 font-medium">Startup</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            <tr>
                                <td colSpan={4} className="px-4 py-4 text-white/70">
                                    Loading eggs...
                                </td>
                            </tr>
                        ) : eggs.length === 0 ? (
                            <tr>
                                <td colSpan={4} className="px-4 py-4 text-white/70">
                                    No eggs found.
                                </td>
                            </tr>
                        ) : (
                            eggs.map((egg) => (
                                <tr key={egg.id} className="border-t border-white/10">
                                    <td className="px-4 py-3">{egg.name ?? `Egg ${egg.id}`}</td>
                                    <td className="px-4 py-3">{egg.nest ?? '-'}</td>
                                    <td className="px-4 py-3">{egg.docker_image ?? '-'}</td>
                                    <td className="px-4 py-3">{egg.startup ?? '-'}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}
