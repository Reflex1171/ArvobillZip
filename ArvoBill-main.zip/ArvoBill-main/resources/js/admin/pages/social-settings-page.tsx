import { useEffect, useState } from 'react';
import { getSocialProviderSettings, testSocialProvider, updateSocialProviderSettings } from '@/lib/affiliate-api';
import type { SocialProviderSettingsPayload } from '@/types/affiliate';

type ProviderKey = 'google' | 'apple';

const providerLabels: Record<ProviderKey, string> = {
    google: 'Google',
    apple: 'Apple',
};

export function SocialSettingsPage() {
    const [settings, setSettings] = useState<SocialProviderSettingsPayload | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState<ProviderKey | null>(null);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [secrets, setSecrets] = useState<Record<ProviderKey, { client_secret: string; private_key: string }>>({
        google: { client_secret: '', private_key: '' },
        apple: { client_secret: '', private_key: '' },
    });

    async function load() {
        try {
            setIsLoading(true);
            const payload = await getSocialProviderSettings();
            setSettings(payload);
            setError(null);
        } catch (loadError) {
            setError(loadError instanceof Error ? loadError.message : 'Failed to load social settings.');
        } finally {
            setIsLoading(false);
        }
    }

    useEffect(() => {
        void load();
    }, []);

    async function save(provider: ProviderKey) {
        if (!settings) return;

        try {
            setIsSaving(provider);
            const current = settings[provider];
            const secretInput = secrets[provider];
            await updateSocialProviderSettings(provider, {
                enabled: current.enabled,
                client_id: current.client_id,
                client_secret: secretInput.client_secret || null,
                redirect_uri: current.redirect_uri,
                team_id: current.team_id ?? null,
                key_id: current.key_id ?? null,
                private_key: secretInput.private_key || null,
            });
            setSecrets((prev) => ({
                ...prev,
                [provider]: { client_secret: '', private_key: '' },
            }));
            setMessage(`${providerLabels[provider]} settings saved.`);
            setError(null);
            await load();
        } catch (saveError) {
            setError(saveError instanceof Error ? saveError.message : 'Failed to save social settings.');
        } finally {
            setIsSaving(null);
        }
    }

    async function test(provider: ProviderKey) {
        try {
            const data = await testSocialProvider(provider);
            window.open(data.auth_url, '_blank', 'noopener,noreferrer');
            setMessage(`${providerLabels[provider]} test started. Complete the flow in the new tab.`);
            setError(null);
        } catch (testError) {
            setError(testError instanceof Error ? testError.message : 'Failed to start OAuth test.');
        }
    }

    function updateField(provider: ProviderKey, field: keyof SocialProviderSettingsPayload[ProviderKey], value: string | boolean) {
        if (!settings) return;
        setSettings({
            ...settings,
            [provider]: {
                ...settings[provider],
                [field]: value,
            },
        });
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold">Social Login</h2>
                <p className="mt-1 text-sm text-white/70">
                    Configure Google and Apple login credentials for client authentication.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            {message ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-900/20 dark:text-emerald-300">
                    {message}
                </div>
            ) : null}

            {isLoading || !settings ? (
                <p className="text-sm text-white/70">Loading settings...</p>
            ) : (
                (['google', 'apple'] as ProviderKey[]).map((provider) => {
                    const data = settings[provider];
                    const secretInput = secrets[provider];
                    return (
                        <article
                            key={provider}
                            className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm"
                        >
                            <div className="flex flex-wrap items-center justify-between gap-2">
                                <div>
                                    <h3 className="text-lg font-semibold">{providerLabels[provider]}</h3>
                                    <p className="text-sm text-white/70">
                                        {provider === 'google'
                                            ? 'Use the OAuth client credentials from Google Cloud.'
                                            : 'Use Sign in with Apple services + key.'}
                                    </p>
                                </div>
                                <label className="flex items-center gap-2 text-sm">
                                    <input
                                        type="checkbox"
                                        checked={data.enabled}
                                        onChange={(event) => updateField(provider, 'enabled', event.target.checked)}
                                    />
                                    <span>Enabled</span>
                                </label>
                            </div>

                            <div className="mt-4 grid gap-4 md:grid-cols-2">
                                <label className="space-y-1 text-sm">
                                    <span className="font-medium">Client ID</span>
                                    <input
                                        type="text"
                                        value={data.client_id ?? ''}
                                        onChange={(event) => updateField(provider, 'client_id', event.target.value || null)}
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                    />
                                </label>

                                <label className="space-y-1 text-sm">
                                    <span className="font-medium">Client Secret</span>
                                    <input
                                        type="password"
                                        value={secretInput.client_secret}
                                        onChange={(event) =>
                                            setSecrets((prev) => ({
                                                ...prev,
                                                [provider]: { ...prev[provider], client_secret: event.target.value },
                                            }))
                                        }
                                        placeholder={data.client_secret_masked ?? 'Not set'}
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                    />
                                </label>

                                <label className="space-y-1 text-sm md:col-span-2">
                                    <span className="font-medium">Redirect URI</span>
                                    <input
                                        type="url"
                                        value={data.redirect_uri ?? ''}
                                        onChange={(event) => updateField(provider, 'redirect_uri', event.target.value || null)}
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                    />
                                </label>

                                {provider === 'apple' ? (
                                    <>
                                        <label className="space-y-1 text-sm">
                                            <span className="font-medium">Team ID</span>
                                            <input
                                                type="text"
                                                value={data.team_id ?? ''}
                                                onChange={(event) => updateField(provider, 'team_id', event.target.value || null)}
                                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                            />
                                        </label>
                                        <label className="space-y-1 text-sm">
                                            <span className="font-medium">Key ID</span>
                                            <input
                                                type="text"
                                                value={data.key_id ?? ''}
                                                onChange={(event) => updateField(provider, 'key_id', event.target.value || null)}
                                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                            />
                                        </label>
                                        <label className="space-y-1 text-sm md:col-span-2">
                                            <span className="font-medium">Private Key</span>
                                            <textarea
                                                value={secretInput.private_key}
                                                onChange={(event) =>
                                                    setSecrets((prev) => ({
                                                        ...prev,
                                                        [provider]: { ...prev[provider], private_key: event.target.value },
                                                    }))
                                                }
                                                placeholder={data.private_key_masked ?? 'Not set'}
                                                rows={4}
                                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                            />
                                        </label>
                                    </>
                                ) : null}
                            </div>

                            <div className="mt-4 flex flex-wrap gap-2">
                                <button
                                    type="button"
                                    onClick={() => void save(provider)}
                                    disabled={isSaving !== null || isLoading}
                                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                                >
                                    {isSaving === provider ? 'Saving...' : 'Save Settings'}
                                </button>
                                <button
                                    type="button"
                                    onClick={() => void test(provider)}
                                    disabled={isSaving !== null || isLoading}
                                    className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10 disabled:opacity-60"
                                >
                                    Test OAuth
                                </button>
                            </div>
                        </article>
                    );
                })
            )}
        </section>
    );
}
