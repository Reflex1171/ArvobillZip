import { useEffect, useState } from 'react';
import { listPterodactylServers } from '@/lib/pterodactyl-api';
import type { PterodactylServer } from '@/types/pterodactyl';

export function InfrastructureServersPage() {
    const [servers, setServers] = useState<PterodactylServer[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadServers() {
            try {
                const data = await listPterodactylServers();
                setServers(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load servers.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadServers();
    }, []);

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Pterodactyl Servers</h2>
                <p className="mt-1 text-sm text-white/70">
                    Current infrastructure servers visible from the panel.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)]">
                <table className="min-w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/70">
                        <tr>
                            <th className="px-4 py-3 font-medium">Server ID</th>
                            <th className="px-4 py-3 font-medium">Name</th>
                            <th className="px-4 py-3 font-medium">Node</th>
                            <th className="px-4 py-3 font-medium">Status</th>
                            <th className="px-4 py-3 font-medium">Identifier</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            <tr>
                                <td colSpan={5} className="px-4 py-4 text-white/70">
                                    Loading servers...
                                </td>
                            </tr>
                        ) : servers.length === 0 ? (
                            <tr>
                                <td colSpan={5} className="px-4 py-4 text-white/70">
                                    No servers found.
                                </td>
                            </tr>
                        ) : (
                            servers.map((server) => (
                                <tr key={server.id} className="border-t border-white/10">
                                    <td className="px-4 py-3">#{server.id}</td>
                                    <td className="px-4 py-3">{server.name ?? '-'}</td>
                                    <td className="px-4 py-3">{server.node ?? '-'}</td>
                                    <td className="px-4 py-3">{server.status ?? '-'}</td>
                                    <td className="px-4 py-3">{server.identifier ?? '-'}</td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}
