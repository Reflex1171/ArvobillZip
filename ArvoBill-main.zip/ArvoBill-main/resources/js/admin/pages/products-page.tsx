import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { formatCurrency, listAdminProducts, toggleAdminProduct } from '@/lib/products-api';
import type { Product } from '@/types/product';

export function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pendingId, setPendingId] = useState<number | null>(null);

  async function loadProducts() {
    try {
      const data = await listAdminProducts();
      setProducts(data);
      setError(null);
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : 'Failed to load products.',
      );
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    void loadProducts();
  }, []);

  async function handleToggle(productId: number) {
    try {
      setPendingId(productId);
      const updated = await toggleAdminProduct(productId);
      setProducts((current) =>
        current.map((product) =>
          product.id === updated.id ? updated : product,
        ),
      );
    } catch (toggleError) {
      setError(
        toggleError instanceof Error
          ? toggleError.message
          : 'Failed to toggle product status.',
      );
    } finally {
      setPendingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <section className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">Products</h2>
          <p className="mt-1 text-sm text-white/70 ">
            Create and manage catalogue products for client checkout.
          </p>
        </div>
        <Link
          to="/admin/products/new"
          className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110"
        >
          New Product
        </Link>
      </section>

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      <section className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-white/5 text-white/70 ">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Category</th>
              <th className="px-4 py-3 font-medium">Price</th>
              <th className="px-4 py-3 font-medium">Infrastructure</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td
                  className="px-4 py-4 text-white/70 "
                  colSpan={6}
                >
                  Loading products...
                </td>
              </tr>
            ) : products.length === 0 ? (
              <tr>
                <td
                  className="px-4 py-4 text-white/70 "
                  colSpan={6}
                >
                  No products yet.
                </td>
              </tr>
            ) : (
              products.map((product) => (
                <tr
                  key={product.id}
                  className="border-t border-white/10 "
                >
                  <td className="px-4 py-3">
                    <p className="font-medium">{product.name}</p>
                    <p className="text-xs text-white/70 ">
                      {product.slug}
                    </p>
                  </td>
                  <td className="px-4 py-3">
                    {product.category?.name ?? 'Unassigned'}
                  </td>
                  <td className="px-4 py-3">
                    {formatCurrency(product.price_monthly)}
                  </td>
                  <td className="px-4 py-3">
                    <span className="capitalize">{product.infrastructure_type}</span>
                    {product.infrastructure_type === 'pterodactyl' ? (
                      <p className="text-xs text-white/70">
                        {product.auto_provision ? 'Auto' : 'Manual'} provisioning
                        {product.pterodactyl_location_id
                          ? ` (Location ${product.pterodactyl_location_id})`
                          : ''}
                      </p>
                    ) : null}
                  </td>
                  <td className="px-4 py-3">
                    <span
                      className={[
                        'rounded-full px-2.5 py-1 text-xs font-semibold',
                        product.is_active
                          ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
                          : 'bg-white/10 text-white/80',
                      ].join(' ')}
                    >
                      {product.is_active ? 'Active' : 'Inactive'}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex flex-wrap gap-2">
                      <Link
                        to={`/admin/products/${product.id}/edit`}
                        className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10"
                      >
                        Edit
                      </Link>
                      <Link
                        to={`/admin/products/${product.id}/configurations`}
                        className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10"
                      >
                        Config
                      </Link>
                      <button
                        type="button"
                        disabled={pendingId === product.id}
                        onClick={() =>
                          void handleToggle(product.id)
                        }
                        className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10 disabled:opacity-50"
                      >
                        {product.is_active
                          ? 'Disable'
                          : 'Enable'}
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}
