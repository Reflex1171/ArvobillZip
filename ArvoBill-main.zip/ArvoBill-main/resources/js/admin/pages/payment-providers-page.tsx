import { useEffect, useMemo, useState } from 'react';
import {
    listAdminPaymentProviders,
    updateAdminPaymentProvider,
} from '@/lib/billing-api';
import type { AdminPaymentProviderSettings } from '@/types/billing';

type ProviderDraft = {
    provider: string;
    mode: 'test' | 'live';
    enabled: boolean;
    public_key: string;
    secret_key: string;
    webhook_secret: string;
    confirm_overwrite: boolean;
};

function toDraft(provider: AdminPaymentProviderSettings): ProviderDraft {
    const selectedModeSettings = provider.settings[provider.mode];

    return {
        provider: provider.provider,
        mode: provider.mode,
        enabled: provider.enabled,
        public_key: selectedModeSettings.public_key ?? '',
        secret_key: '',
        webhook_secret: '',
        confirm_overwrite: false,
    };
}

export function PaymentProvidersPage() {
    const [providers, setProviders] = useState<AdminPaymentProviderSettings[]>([]);
    const [drafts, setDrafts] = useState<Record<string, ProviderDraft>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [savingProvider, setSavingProvider] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadSettings() {
            try {
                setIsLoading(true);
                const data = await listAdminPaymentProviders();
                setProviders(data);
                setDrafts(
                    Object.fromEntries(
                        data.map((provider) => [provider.provider, toDraft(provider)]),
                    ),
                );
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load payment provider settings.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadSettings();
    }, []);

    const enabledCount = useMemo(
        () => Object.values(drafts).filter((draft) => draft.enabled).length,
        [drafts],
    );

    function setDraft(provider: string, updater: (draft: ProviderDraft) => ProviderDraft) {
        setDrafts((current) => {
            const target = current[provider];
            if (!target) return current;

            return {
                ...current,
                [provider]: updater(target),
            };
        });
    }

    function handleModeChange(providerName: string, mode: 'test' | 'live') {
        const provider = providers.find((item) => item.provider === providerName);
        if (!provider) return;

        setDraft(providerName, (current) => ({
            ...current,
            mode,
            public_key: provider.settings[mode].public_key ?? '',
            secret_key: '',
            webhook_secret: '',
            confirm_overwrite: false,
        }));
    }

    async function handleSave(providerName: string) {
        const draft = drafts[providerName];
        if (!draft) return;

        if (draft.secret_key !== '' && !draft.confirm_overwrite) {
            setError('Please confirm overwrite before saving new secret keys.');
            return;
        }

        if (!draft.enabled && enabledCount <= 1) {
            setError('At least one provider should remain enabled for checkout.');
            return;
        }

        try {
            setSavingProvider(providerName);
            await updateAdminPaymentProvider(providerName, {
                mode: draft.mode,
                enabled: draft.enabled,
                public_key: draft.public_key || null,
                secret_key: draft.secret_key || null,
                webhook_secret: draft.webhook_secret || null,
                confirm_overwrite: draft.confirm_overwrite,
            });

            const refreshed = await listAdminPaymentProviders();
            setProviders(refreshed);
            setDrafts(
                Object.fromEntries(
                    refreshed.map((provider) => [provider.provider, toDraft(provider)]),
                ),
            );
            setError(null);
        } catch (saveError) {
            setError(
                saveError instanceof Error
                    ? saveError.message
                    : 'Failed to save payment provider settings.',
            );
        } finally {
            setSavingProvider(null);
        }
    }

    if (isLoading) {
        return (
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                Loading payment provider settings...
            </div>
        );
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-2xl font-semibold">Payment Providers</h2>
                <p className="mt-1 text-sm text-white/70">
                    Configure Stripe and PayPal credentials, mode, and availability.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="grid gap-4 lg:grid-cols-2">
                {providers.map((provider) => {
                    const draft = drafts[provider.provider];
                    if (!draft) return null;

                    const modeSettings = provider.settings[draft.mode];
                    const saving = savingProvider === provider.provider;
                    const hasRequiredSecrets =
                        modeSettings.has_secret_key && modeSettings.has_webhook_secret;

                    return (
                        <article
                            key={provider.provider}
                            className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm"
                        >
                            <div className="flex items-center justify-between">
                                <h3 className="text-lg font-semibold capitalize">
                                    {provider.provider}
                                </h3>
                                <span
                                    className={[
                                        'rounded-full px-3 py-1 text-xs font-semibold uppercase',
                                        draft.enabled
                                            ? 'bg-emerald-600/20 text-emerald-300'
                                            : 'bg-zinc-600/20 text-zinc-300',
                                    ].join(' ')}
                                >
                                    {draft.enabled ? 'Enabled' : 'Disabled'}
                                </span>
                            </div>

                            <div className="grid gap-3">
                                <label className="space-y-1 text-sm">
                                    <span className="font-medium">Mode</span>
                                    <select
                                        value={draft.mode}
                                        onChange={(event) =>
                                            handleModeChange(
                                                provider.provider,
                                                event.target.value as 'test' | 'live',
                                            )
                                        }
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                    >
                                        <option value="test">Test</option>
                                        <option value="live">Live</option>
                                    </select>
                                </label>

                                <label className="flex items-center gap-3 text-sm">
                                    <input
                                        type="checkbox"
                                        checked={draft.enabled}
                                        onChange={(event) =>
                                            setDraft(provider.provider, (current) => ({
                                                ...current,
                                                enabled: event.target.checked,
                                            }))
                                        }
                                        className="size-4"
                                    />
                                    <span>Enabled</span>
                                </label>

                                <label className="space-y-1 text-sm">
                                    <span className="font-medium">
                                        {provider.provider === 'paypal' ? 'Client ID' : 'Public Key'}
                                    </span>
                                    <input
                                        type="text"
                                        value={draft.public_key}
                                        onChange={(event) =>
                                            setDraft(provider.provider, (current) => ({
                                                ...current,
                                                public_key: event.target.value,
                                            }))
                                        }
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                    />
                                </label>

                                <label className="space-y-1 text-sm">
                                    <span className="font-medium">Secret Key</span>
                                    <input
                                        type="password"
                                        value={draft.secret_key}
                                        onChange={(event) =>
                                            setDraft(provider.provider, (current) => ({
                                                ...current,
                                                secret_key: event.target.value,
                                            }))
                                        }
                                        placeholder={modeSettings.secret_key_masked ?? 'Not set'}
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                    />
                                </label>

                                <label className="space-y-1 text-sm">
                                    <span className="font-medium">
                                        {provider.provider === 'paypal'
                                            ? 'Webhook ID'
                                            : 'Webhook Secret'}
                                    </span>
                                    <input
                                        type="password"
                                        value={draft.webhook_secret}
                                        onChange={(event) =>
                                            setDraft(provider.provider, (current) => ({
                                                ...current,
                                                webhook_secret: event.target.value,
                                            }))
                                        }
                                        placeholder={modeSettings.webhook_secret_masked ?? 'Not set'}
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                                    />
                                </label>

                                <label className="flex items-center gap-3 text-sm">
                                    <input
                                        type="checkbox"
                                        checked={draft.confirm_overwrite}
                                        onChange={(event) =>
                                            setDraft(provider.provider, (current) => ({
                                                ...current,
                                                confirm_overwrite: event.target.checked,
                                            }))
                                        }
                                        className="size-4"
                                    />
                                    <span>Confirm secret overwrite</span>
                                </label>
                            </div>

                            {draft.enabled && !hasRequiredSecrets ? (
                                <p className="rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800 dark:border-amber-900/40 dark:bg-amber-900/20 dark:text-amber-300">
                                    This mode is missing required secret values. Save valid keys before enabling.
                                </p>
                            ) : null}

                            <button
                                type="button"
                                onClick={() => void handleSave(provider.provider)}
                                disabled={saving}
                                className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                            >
                                {saving ? 'Saving...' : 'Save'}
                            </button>
                        </article>
                    );
                })}
            </div>
        </section>
    );
}
