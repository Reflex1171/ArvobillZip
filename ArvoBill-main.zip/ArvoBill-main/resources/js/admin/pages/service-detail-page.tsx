import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { StatusBadge } from '@/components/status-badge';
import { formatCurrency } from '@/lib/products-api';
import {
    listPterodactylAllocations,
    listPterodactylEggs,
    listPterodactylNodes,
} from '@/lib/pterodactyl-api';
import {
    deleteAdminPterodactylServer,
    getAdminService,
    provisionAdminService,
    retryAdminServiceProvisioning,
    suspendAdminService,
    unsuspendAdminService,
    updateAdminServiceStatus,
} from '@/lib/services-api';
import type {
    PterodactylAllocation,
    PterodactylEgg,
    PterodactylNode,
} from '@/types/pterodactyl';
import type { ServiceStatus, ServiceSummary } from '@/types/service';

const statusOptions: ServiceStatus[] = [
    'pending',
    'provisioning',
    'active',
    'suspended',
    'cancelled',
    'failed',
];

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function ServiceDetailPage() {
    const { id = '' } = useParams();
    const [service, setService] = useState<ServiceSummary | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [showProvisionForm, setShowProvisionForm] = useState(false);
    const [nodes, setNodes] = useState<PterodactylNode[]>([]);
    const [eggs, setEggs] = useState<PterodactylEgg[]>([]);
    const [allocations, setAllocations] = useState<PterodactylAllocation[]>([]);
    const [selectedNodeId, setSelectedNodeId] = useState<number | null>(null);
    const [selectedEggId, setSelectedEggId] = useState<number | null>(null);
    const [selectedAllocationId, setSelectedAllocationId] = useState<number | null>(null);
    const [memoryLimit, setMemoryLimit] = useState(2048);
    const [cpuLimit, setCpuLimit] = useState(100);
    const [diskLimit, setDiskLimit] = useState(10240);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadService() {
            try {
                const data = await getAdminService(id);
                setService(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load service.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadService();
    }, [id]);

    useEffect(() => {
        if (!showProvisionForm) return;

        async function loadProvisioningData() {
            try {
                const [nodeData, eggData] = await Promise.all([
                    listPterodactylNodes(),
                    listPterodactylEggs(),
                ]);
                setNodes(nodeData);
                setEggs(eggData);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load provisioning options.',
                );
            }
        }

        void loadProvisioningData();
    }, [showProvisionForm]);

    useEffect(() => {
        if (!selectedNodeId) {
            setAllocations([]);
            return;
        }

        async function loadAllocations() {
            try {
                const data = await listPterodactylAllocations(selectedNodeId ?? undefined);
                setAllocations(data.filter((allocation) => !allocation.assigned));
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load allocations.',
                );
            }
        }

        void loadAllocations();
    }, [selectedNodeId]);

    async function handleStatusChange(nextStatus: ServiceStatus) {
        if (!service) return;

        try {
            setIsSubmitting(true);
            const updated = await updateAdminServiceStatus(String(service.id), nextStatus);
            setService(updated);
            setMessage(`Service status changed to ${nextStatus}.`);
            setError(null);
        } catch (updateError) {
            setError(
                updateError instanceof Error
                    ? updateError.message
                    : 'Failed to update status.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleSuspend() {
        if (!service) return;
        try {
            setIsSubmitting(true);
            const updated = await suspendAdminService(String(service.id));
            setService(updated);
            setMessage('Service suspended.');
            setError(null);
        } catch (suspendError) {
            setError(
                suspendError instanceof Error
                    ? suspendError.message
                    : 'Failed to suspend service.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleUnsuspend() {
        if (!service) return;
        try {
            setIsSubmitting(true);
            const updated = await unsuspendAdminService(String(service.id));
            setService(updated);
            setMessage('Service unsuspended.');
            setError(null);
        } catch (unsuspendError) {
            setError(
                unsuspendError instanceof Error
                    ? unsuspendError.message
                    : 'Failed to unsuspend service.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleProvision() {
        if (!service || !selectedNodeId || !selectedEggId || !selectedAllocationId) {
            setError('Please select node, egg, and allocation before provisioning.');
            return;
        }

        const selectedEgg = eggs.find((egg) => egg.id === selectedEggId);
        if (!selectedEgg || !selectedEgg.nest_id) {
            setError('Selected egg is missing nest information.');
            return;
        }

        try {
            setIsSubmitting(true);
            const updated = await provisionAdminService(String(service.id), {
                node_id: selectedNodeId,
                egg_id: selectedEggId,
                nest_id: selectedEgg.nest_id,
                allocation_id: selectedAllocationId,
                limits: {
                    memory: memoryLimit,
                    cpu: cpuLimit,
                    disk: diskLimit,
                },
            });
            setService(updated);
            setShowProvisionForm(false);
            setMessage('Service provisioned on Pterodactyl.');
            setError(null);
        } catch (provisionError) {
            setError(
                provisionError instanceof Error
                    ? provisionError.message
                    : 'Failed to provision service.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleDeleteServer() {
        if (!service) return;
        if (!window.confirm('Delete the linked Pterodactyl server for this service?')) {
            return;
        }

        try {
            setIsSubmitting(true);
            const updated = await deleteAdminPterodactylServer(String(service.id));
            setService(updated);
            setMessage('Pterodactyl server deleted.');
            setError(null);
        } catch (deleteError) {
            setError(
                deleteError instanceof Error
                    ? deleteError.message
                    : 'Failed to delete server.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleRetryProvisioning() {
        if (!service) return;

        try {
            setIsSubmitting(true);
            const updated = await retryAdminServiceProvisioning(String(service.id));
            setService(updated);
            setMessage('Provisioning retry queued.');
            setError(null);
        } catch (retryError) {
            setError(
                retryError instanceof Error
                    ? retryError.message
                    : 'Failed to queue provisioning retry.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    if (isLoading) {
        return <div className="text-sm text-white/70">Loading service...</div>;
    }

    if (!service) {
        return <div className="text-sm text-white/70">Service not found.</div>;
    }

    const isProvisioned = Boolean(service.pterodactyl_server_id);

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">Service #{service.id}</h2>
                    <p className="mt-1 text-sm text-white/70">
                        {service.product?.name ?? '-'} for {service.user?.name ?? '-'}
                    </p>
                </div>
                <Link
                    to="/admin/services"
                    className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
                >
                    Back to services
                </Link>
            </div>

            {message ? (
                <div className="rounded-lg border border-[var(--panel-accent)]/40 bg-[var(--panel-accent)]/15 p-4 text-sm text-[var(--panel-text)]">
                    {message}
                </div>
            ) : null}

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="grid gap-4 md:grid-cols-2">
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                    <h3 className="font-semibold">Lifecycle</h3>
                    <div className="mt-4 space-y-3 text-sm">
                        <div className="flex items-center justify-between gap-4">
                            <span className="text-white/70">Current Status</span>
                            <StatusBadge status={service.status} />
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <span className="text-white/70">Billing Cycle</span>
                            <span>{service.billing_summary}</span>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <span className="text-white/70">Next Due Date</span>
                            <span>{formatDate(service.next_due_at ?? service.next_due_date)}</span>
                        </div>
                        {service.provisioning_error ? (
                            <div className="rounded-lg border border-rose-300/40 bg-rose-500/10 p-2 text-xs text-rose-200">
                                {service.provisioning_error}
                            </div>
                        ) : null}
                        <div className="pt-2">
                            <label className="mb-2 block text-xs uppercase tracking-wide text-white/60">
                                Change Status
                            </label>
                            <select
                                value={service.status}
                                onChange={(event) =>
                                    void handleStatusChange(event.target.value as ServiceStatus)
                                }
                                disabled={isSubmitting}
                                className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm disabled:opacity-60"
                            >
                                {statusOptions.map((status) => (
                                    <option key={status} value={status}>
                                        {status.charAt(0).toUpperCase() + status.slice(1)}
                                    </option>
                                ))}
                            </select>
                        </div>
                    </div>
                </article>

                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                    <h3 className="font-semibold">Links & Provisioning</h3>
                    <dl className="mt-4 space-y-3 text-sm">
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Order</dt>
                            <dd>{service.order ? `#${service.order.id}` : '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Invoice</dt>
                            <dd>{service.invoice ? `#${service.invoice.id}` : '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Invoice Total</dt>
                            <dd>{service.invoice ? formatCurrency(service.invoice.total) : '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Pterodactyl Server ID</dt>
                            <dd>{service.pterodactyl_server_id ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Node</dt>
                            <dd>{service.pterodactyl_node_name ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Panel Status</dt>
                            <dd>{service.pterodactyl_server_status ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Resource Limits</dt>
                            <dd>
                                {service.provisioning_limits
                                    ? `${service.provisioning_limits.memory}MB / ${service.provisioning_limits.cpu}% / ${service.provisioning_limits.disk}MB`
                                    : '-'}
                            </dd>
                        </div>
                    </dl>
                </article>
            </div>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="font-semibold">Admin Actions</h3>
                <div className="mt-4 flex flex-wrap gap-3">
                    {!isProvisioned ? (
                        <button
                            type="button"
                            onClick={() => {
                                setShowProvisionForm((current) => !current);
                                const defaults = service.provisioning_limits;
                                setMemoryLimit(defaults?.memory ?? 2048);
                                setCpuLimit(defaults?.cpu ?? 100);
                                setDiskLimit(defaults?.disk ?? 10240);
                            }}
                            disabled={isSubmitting || service.status === 'cancelled'}
                            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            Provision on Pterodactyl
                        </button>
                    ) : null}
                    <button
                        type="button"
                        onClick={() => void handleSuspend()}
                        disabled={isSubmitting || service.status === 'cancelled'}
                        className="rounded-lg border border-amber-400/40 bg-amber-500/20 px-4 py-2 text-sm font-semibold text-amber-100 hover:bg-amber-500/30 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Suspend
                    </button>
                    <button
                        type="button"
                        onClick={() => void handleUnsuspend()}
                        disabled={isSubmitting || service.status !== 'suspended'}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Unsuspend
                    </button>
                    {isProvisioned ? (
                        <button
                            type="button"
                            onClick={() => void handleDeleteServer()}
                            disabled={isSubmitting}
                            className="rounded-lg border border-rose-400/40 bg-rose-500/20 px-4 py-2 text-sm font-semibold text-rose-100 hover:bg-rose-500/30 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            Delete Server
                        </button>
                    ) : null}
                    {service.status === 'failed' ? (
                        <button
                            type="button"
                            onClick={() => void handleRetryProvisioning()}
                            disabled={isSubmitting}
                            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
                        >
                            Retry Provisioning
                        </button>
                    ) : null}
                </div>

                {showProvisionForm ? (
                    <div className="mt-5 space-y-3 rounded-lg border border-white/10 bg-[var(--panel-bg)] p-4">
                        <h4 className="text-sm font-semibold">Provision Settings</h4>
                        <div className="grid gap-3 md:grid-cols-3">
                            <label className="text-sm">
                                <span className="mb-1 block text-white/70">Node</span>
                                <select
                                    value={selectedNodeId ?? ''}
                                    onChange={(event) => setSelectedNodeId(Number(event.target.value) || null)}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2"
                                >
                                    <option value="">Select node</option>
                                    {nodes.map((node) => (
                                        <option key={node.id} value={node.id}>
                                            {node.name ?? `Node ${node.id}`}
                                        </option>
                                    ))}
                                </select>
                            </label>
                            <label className="text-sm">
                                <span className="mb-1 block text-white/70">Egg</span>
                                <select
                                    value={selectedEggId ?? ''}
                                    onChange={(event) => setSelectedEggId(Number(event.target.value) || null)}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2"
                                >
                                    <option value="">Select egg</option>
                                    {eggs.map((egg) => (
                                        <option key={egg.id} value={egg.id}>
                                            {egg.name ?? `Egg ${egg.id}`} ({egg.nest ?? '-'})
                                        </option>
                                    ))}
                                </select>
                            </label>
                            <label className="text-sm">
                                <span className="mb-1 block text-white/70">Allocation</span>
                                <select
                                    value={selectedAllocationId ?? ''}
                                    onChange={(event) => setSelectedAllocationId(Number(event.target.value) || null)}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2"
                                >
                                    <option value="">Select allocation</option>
                                    {allocations.map((allocation) => (
                                        <option key={allocation.id} value={allocation.id}>
                                            {allocation.ip}:{allocation.port}
                                        </option>
                                    ))}
                                </select>
                            </label>
                        </div>
                        <div className="grid gap-3 md:grid-cols-3">
                            <label className="text-sm">
                                <span className="mb-1 block text-white/70">RAM (MB)</span>
                                <input
                                    type="number"
                                    min={256}
                                    value={memoryLimit}
                                    onChange={(event) => setMemoryLimit(Number(event.target.value))}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2"
                                />
                            </label>
                            <label className="text-sm">
                                <span className="mb-1 block text-white/70">CPU (%)</span>
                                <input
                                    type="number"
                                    min={10}
                                    value={cpuLimit}
                                    onChange={(event) => setCpuLimit(Number(event.target.value))}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2"
                                />
                            </label>
                            <label className="text-sm">
                                <span className="mb-1 block text-white/70">Disk (MB)</span>
                                <input
                                    type="number"
                                    min={1024}
                                    value={diskLimit}
                                    onChange={(event) => setDiskLimit(Number(event.target.value))}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2"
                                />
                            </label>
                        </div>
                        <button
                            type="button"
                            onClick={() => void handleProvision()}
                            disabled={isSubmitting}
                            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                        >
                            Confirm Provisioning
                        </button>
                    </div>
                ) : null}
            </article>
        </section>
    );
}
