import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getAdminInvoice, updateAdminInvoiceStatus } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { InvoiceStatus, InvoiceSummary } from '@/types/billing';

function formatDate(value: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [invoice, setInvoice] = useState<InvoiceSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isUpdating, setIsUpdating] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadInvoice() {
      if (!id) {
        setError('Missing invoice id.');
        setIsLoading(false);
        return;
      }

      try {
        const data = await getAdminInvoice(id);
        setInvoice(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load invoice.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadInvoice();
  }, [id]);

  async function handleStatusUpdate(status: InvoiceStatus) {
    if (!id) return;

    try {
      setIsUpdating(true);
      const updated = await updateAdminInvoiceStatus(id, status);
      setInvoice(updated);
      setError(null);
    } catch (updateError) {
      setError(
        updateError instanceof Error
          ? updateError.message
          : 'Failed to update invoice status.',
      );
    } finally {
      setIsUpdating(false);
    }
  }

  if (isLoading) return <div className="text-sm text-white/70 ">Loading invoice...</div>;

  if (error || !invoice) {
    return (
      <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
        {error ?? 'Invoice not found.'}
      </div>
    );
  }

  return (
    <section className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">Invoice #{invoice.id}</h2>
          <p className="mt-1 text-sm text-white/70 ">
            Due {formatDate(invoice.due_date)}
          </p>
        </div>
        <StatusBadge status={invoice.status} />
      </div>

      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm ">
        <h3 className="mb-3 font-semibold">Context</h3>
        <div className="grid gap-2 text-sm">
          <p>
            <span className="text-white/70 ">User:</span>{' '}
            {invoice.user?.name} ({invoice.user?.email})
          </p>
          <p>
            <span className="text-white/70 ">Order:</span>{' '}
            {invoice.order ? (
              <Link
                to={`/admin/orders/${invoice.order.id}`}
                className="text-[var(--panel-primary)] hover:underline"
              >
                #{invoice.order.id}
              </Link>
            ) : (
              '-'
            )}
          </p>
          <p>
            <span className="text-white/70 ">Product:</span>{' '}
            {invoice.order?.product?.name ?? '-'}
          </p>
        </div>
      </div>

      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
        <div className="border-b border-white/10 px-4 py-3 ">
          <h3 className="font-semibold">Invoice Items</h3>
        </div>
        <table className="min-w-full text-left text-sm">
          <thead className="bg-white/5 text-white/70 ">
            <tr>
              <th className="px-4 py-3 font-medium">Description</th>
              <th className="px-4 py-3 font-medium">Amount</th>
            </tr>
          </thead>
          <tbody>
            {(invoice.items ?? []).map((item) => (
              <tr key={item.id} className="border-t border-white/10 ">
                <td className="px-4 py-3">{item.description}</td>
                <td className="px-4 py-3">{formatCurrency(item.amount)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm ">
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-white/70 ">Subtotal</span>
            <span>{formatCurrency(invoice.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/70 ">Tax</span>
            <span>{formatCurrency(invoice.tax ?? 0)}</span>
          </div>
          <div className="flex justify-between border-t border-white/10 pt-2 font-semibold ">
            <span>Total</span>
            <span>{formatCurrency(invoice.total)}</span>
          </div>
        </div>
      </div>

      <div className="rounded-lg border border-cyan-200 bg-cyan-50 p-3 text-sm text-cyan-800 dark:border-cyan-900/40 dark:bg-cyan-900/20 dark:text-cyan-300">
        Paid status is normally controlled by Stripe and PayPal webhooks. Admins can override when needed.
      </div>

      <div className="flex flex-wrap items-center gap-3">
        <button
          type="button"
          disabled={isUpdating || invoice.status === 'paid'}
          onClick={() => void handleStatusUpdate('paid')}
          className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-60"
        >
          Mark Paid
        </button>
        <button
          type="button"
          disabled={isUpdating}
          onClick={() => void handleStatusUpdate('cancelled')}
          className="rounded-lg bg-rose-600 px-4 py-2 text-sm font-semibold text-white hover:bg-rose-700 disabled:opacity-60"
        >
          Mark Cancelled
        </button>
        <button
          type="button"
          disabled={isUpdating}
          onClick={() => void handleStatusUpdate('unpaid')}
          className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10 disabled:opacity-60"
        >
          Set Unpaid
        </button>
      </div>
    </section>
  );
}
