import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusBadge } from '@/components/status-badge';
import { listAdminTickets } from '@/lib/support-api';
import type { TicketPriority, TicketStatus, TicketSummary } from '@/types/support';

const statusOptions: Array<{ label: string; value: '' | TicketStatus }> = [
    { label: 'All Statuses', value: '' },
    { label: 'Open', value: 'open' },
    { label: 'Answered', value: 'answered' },
    { label: 'Closed', value: 'closed' },
];

const priorityOptions: Array<{ label: string; value: '' | TicketPriority }> = [
    { label: 'All Priorities', value: '' },
    { label: 'Low', value: 'low' },
    { label: 'Medium', value: 'medium' },
    { label: 'High', value: 'high' },
];

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
}

export function TicketsPage() {
    const [tickets, setTickets] = useState<TicketSummary[]>([]);
    const [status, setStatus] = useState<'' | TicketStatus>('');
    const [priority, setPriority] = useState<'' | TicketPriority>('');
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadTickets() {
            try {
                setIsLoading(true);
                const data = await listAdminTickets({ status, priority });
                setTickets(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load tickets.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadTickets();
    }, [status, priority]);

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">Tickets</h2>
                    <p className="mt-1 text-sm text-white/70">
                        Monitor and respond to all customer support conversations.
                    </p>
                </div>
                <div className="flex flex-wrap gap-2">
                    <select
                        value={status}
                        onChange={(event) =>
                            setStatus(event.target.value as '' | TicketStatus)
                        }
                        className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                    >
                        {statusOptions.map((item) => (
                            <option key={item.label} value={item.value}>
                                {item.label}
                            </option>
                        ))}
                    </select>
                    <select
                        value={priority}
                        onChange={(event) =>
                            setPriority(event.target.value as '' | TicketPriority)
                        }
                        className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                    >
                        {priorityOptions.map((item) => (
                            <option key={item.label} value={item.value}>
                                {item.label}
                            </option>
                        ))}
                    </select>
                </div>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm">
                <table className="min-w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/70">
                        <tr>
                            <th className="px-4 py-3 font-medium">Ticket ID</th>
                            <th className="px-4 py-3 font-medium">User</th>
                            <th className="px-4 py-3 font-medium">Subject</th>
                            <th className="px-4 py-3 font-medium">Status</th>
                            <th className="px-4 py-3 font-medium">Priority</th>
                            <th className="px-4 py-3 font-medium">Last Reply</th>
                            <th className="px-4 py-3 font-medium">View</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={7}>
                                    Loading tickets...
                                </td>
                            </tr>
                        ) : tickets.length === 0 ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={7}>
                                    No tickets found.
                                </td>
                            </tr>
                        ) : (
                            tickets.map((ticket) => (
                                <tr key={ticket.id} className="border-t border-white/10">
                                    <td className="px-4 py-3 font-medium">#{ticket.id}</td>
                                    <td className="px-4 py-3">
                                        <div>{ticket.user?.name ?? '-'}</div>
                                        <div className="text-xs text-white/70">
                                            {ticket.user?.email ?? '-'}
                                        </div>
                                    </td>
                                    <td className="px-4 py-3">{ticket.subject}</td>
                                    <td className="px-4 py-3">
                                        <StatusBadge status={ticket.status} />
                                    </td>
                                    <td className="px-4 py-3">
                                        <PriorityBadge priority={ticket.priority} />
                                    </td>
                                    <td className="px-4 py-3">
                                        {formatDate(ticket.last_reply_at)}
                                    </td>
                                    <td className="px-4 py-3">
                                        <Link
                                            to={`/admin/tickets/${ticket.id}`}
                                            className="text-[var(--panel-primary)] hover:underline"
                                        >
                                            View ticket
                                        </Link>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}

