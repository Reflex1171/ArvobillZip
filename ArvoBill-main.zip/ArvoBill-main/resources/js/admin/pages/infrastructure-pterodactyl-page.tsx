import { useEffect, useState } from 'react';
import {
    getPterodactylSettings,
    testPterodactylConnection,
    updatePterodactylSettings,
} from '@/lib/pterodactyl-api';
import type { PterodactylSettings } from '@/types/pterodactyl';

export function InfrastructurePterodactylPage() {
    const [settings, setSettings] = useState<PterodactylSettings | null>(null);
    const [panelUrl, setPanelUrl] = useState('');
    const [apiKey, setApiKey] = useState('');
    const [enabled, setEnabled] = useState(false);
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [isTesting, setIsTesting] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function load() {
            try {
                const data = await getPterodactylSettings();
                setSettings(data);
                setPanelUrl(data.panel_url ?? '');
                setEnabled(data.enabled);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load Pterodactyl settings.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void load();
    }, []);

    async function handleSave() {
        try {
            setIsSaving(true);
            const updated = await updatePterodactylSettings({
                panel_url: panelUrl || null,
                api_key: apiKey || undefined,
                enabled,
            });
            setSettings(updated);
            setApiKey('');
            setMessage('Pterodactyl settings saved successfully.');
            setError(null);
        } catch (saveError) {
            setError(
                saveError instanceof Error
                    ? saveError.message
                    : 'Failed to save Pterodactyl settings.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleTestConnection() {
        try {
            setIsTesting(true);
            await testPterodactylConnection();
            setMessage('Connection successful.');
            setError(null);
        } catch (testError) {
            setError(
                testError instanceof Error
                    ? testError.message
                    : 'Connection test failed.',
            );
        } finally {
            setIsTesting(false);
        }
    }

    if (isLoading) {
        return <div className="text-sm text-white/70">Loading infrastructure settings...</div>;
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Pterodactyl Integration</h2>
                <p className="mt-1 text-sm text-white/70">
                    Configure panel connectivity for infrastructure provisioning.
                </p>
            </div>

            {message ? (
                <div className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-700 dark:border-emerald-900/40 dark:bg-emerald-900/20 dark:text-emerald-300">
                    {message}
                </div>
            ) : null}
            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <label className="block space-y-1 text-sm">
                    <span className="font-medium">Panel URL</span>
                    <input
                        value={panelUrl}
                        onChange={(event) => setPanelUrl(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        placeholder="https://panel.example.com"
                    />
                </label>

                <label className="block space-y-1 text-sm">
                    <span className="font-medium">API Key</span>
                    <input
                        type="password"
                        value={apiKey}
                        onChange={(event) => setApiKey(event.target.value)}
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2"
                        placeholder={settings?.api_key_masked ?? 'Enter API key'}
                    />
                    <span className="text-xs text-white/70">
                        Key is stored encrypted and never exposed to clients.
                    </span>
                </label>

                <label className="flex items-center gap-3 text-sm">
                    <input
                        type="checkbox"
                        checked={enabled}
                        onChange={(event) => setEnabled(event.target.checked)}
                        className="size-4"
                    />
                    <span>Enable Pterodactyl Integration</span>
                </label>

                <div className="flex flex-wrap gap-3">
                    <button
                        type="button"
                        onClick={() => void handleSave()}
                        disabled={isSaving}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                    >
                        {isSaving ? 'Saving...' : 'Save Settings'}
                    </button>
                    <button
                        type="button"
                        onClick={() => void handleTestConnection()}
                        disabled={isTesting}
                        className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10 disabled:opacity-60"
                    >
                        {isTesting ? 'Testing...' : 'Test Connection'}
                    </button>
                </div>
            </div>
        </section>
    );
}
