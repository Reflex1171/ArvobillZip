import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { getAdminOrder } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { OrderSummary } from '@/types/billing';

function formatDate(value: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function OrderDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [order, setOrder] = useState<OrderSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadOrder() {
      if (!id) {
        setError('Missing order id.');
        setIsLoading(false);
        return;
      }

      try {
        const data = await getAdminOrder(id);
        setOrder(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load order.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadOrder();
  }, [id]);

  if (isLoading) return <div className="text-sm text-white/70 ">Loading order...</div>;

  if (error || !order) {
    return (
      <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
        {error ?? 'Order not found.'}
      </div>
    );
  }

  return (
    <section className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">Order #{order.id}</h2>
          <p className="mt-1 text-sm text-white/70 ">
            Created {formatDate(order.created_at)}
          </p>
        </div>
        <StatusBadge status={order.status} />
      </div>

      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm ">
        <h3 className="mb-3 font-semibold">Summary</h3>
        <div className="grid gap-2 text-sm">
          <p>
            <span className="text-white/70 ">User:</span>{' '}
            {order.user?.name} ({order.user?.email})
          </p>
          <p>
            <span className="text-white/70 ">Product:</span>{' '}
            {order.product?.name ?? '-'}
          </p>
          <p>
            <span className="text-white/70 ">Invoice:</span>{' '}
            {order.invoice ? (
              <Link
                to={`/admin/invoices/${order.invoice.id}`}
                className="text-[var(--panel-primary)] hover:underline"
              >
                #{order.invoice.id}
              </Link>
            ) : (
              '-'
            )}
          </p>
        </div>
      </div>

      {order.configurations && order.configurations.length > 0 ? (
        <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm ">
          <h3 className="mb-3 font-semibold">Selected Configuration</h3>
          <div className="space-y-2 text-sm">
            {order.configurations.map((configuration) => (
              <div
                key={configuration.id}
                className="flex items-center justify-between gap-4"
              >
                <span className="text-white/70 ">{configuration.configuration_key}</span>
                <span>
                  {configuration.selected_value}{' '}
                  {configuration.price_modifier !== 0
                    ? `(${configuration.price_modifier > 0 ? '+' : ''}${formatCurrency(configuration.price_modifier)})`
                    : ''}
                </span>
              </div>
            ))}
          </div>
        </div>
      ) : null}

      {order.invoice ? (
        <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm ">
          <h3 className="mb-3 font-semibold">Invoice Snapshot</h3>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-white/70 ">Subtotal</span>
              <span>{formatCurrency(order.invoice.subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-white/70 ">Tax</span>
              <span>{formatCurrency(order.invoice.tax ?? 0)}</span>
            </div>
            <div className="flex justify-between font-semibold">
              <span>Total</span>
              <span>{formatCurrency(order.invoice.total)}</span>
            </div>
          </div>
        </div>
      ) : null}
    </section>
  );
}
