import { FormEvent, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
    createAdminConfigurationOption,
    createAdminProductConfiguration,
    deleteAdminConfigurationOption,
    deleteAdminProductConfiguration,
    getAdminProductById,
    listAdminProductConfigurations,
    updateAdminConfigurationOption,
    updateAdminProductConfiguration,
} from '@/lib/products-api';
import type {
    ProductConfiguration,
    ProductConfigurationInputType,
    ProductConfigurationOption,
} from '@/types/product-configuration';

type ConfigurationDraft = {
    name: string;
    key: string;
    input_type: ProductConfigurationInputType;
    required: boolean;
    sort_order: number;
};

type OptionDraft = {
    label: string;
    value: string;
    price_modifier: string;
    is_active: boolean;
    is_default: boolean;
};

const inputTypes: ProductConfigurationInputType[] = ['buttons', 'select', 'dropdown'];

const emptyConfigurationDraft: ConfigurationDraft = {
    name: '',
    key: '',
    input_type: 'buttons',
    required: true,
    sort_order: 0,
};

const emptyOptionDraft: OptionDraft = {
    label: '',
    value: '',
    price_modifier: '0',
    is_active: true,
    is_default: false,
};

export function ProductConfigurationsPage() {
    const { id = '' } = useParams<{ id: string }>();
    const [productName, setProductName] = useState('Product');
    const [configurations, setConfigurations] = useState<ProductConfiguration[]>([]);
    const [configurationDraft, setConfigurationDraft] = useState<ConfigurationDraft>(
        emptyConfigurationDraft,
    );
    const [optionDraftByConfiguration, setOptionDraftByConfiguration] = useState<
        Record<number, OptionDraft>
    >({});
    const [configurationDraftById, setConfigurationDraftById] = useState<
        Record<number, ConfigurationDraft>
    >({});
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [message, setMessage] = useState<string | null>(null);

    async function loadData() {
        if (!id) return;

        try {
            setIsLoading(true);
            const [product, configurationData] = await Promise.all([
                getAdminProductById(id),
                listAdminProductConfigurations(id),
            ]);
            setProductName(product.name);
            setConfigurations(configurationData);
            setError(null);
        } catch (loadError) {
            setError(
                loadError instanceof Error
                    ? loadError.message
                    : 'Failed to load product configurations.',
            );
        } finally {
            setIsLoading(false);
        }
    }

    useEffect(() => {
        void loadData();
    }, [id]);

    const sortedConfigurations = useMemo(
        () =>
            [...configurations].sort((a, b) =>
                a.sort_order === b.sort_order ? a.id - b.id : a.sort_order - b.sort_order,
            ),
        [configurations],
    );

    function getOptionDraft(configurationId: number): OptionDraft {
        return optionDraftByConfiguration[configurationId] ?? emptyOptionDraft;
    }

    function getConfigurationDraft(
        configuration: ProductConfiguration,
    ): ConfigurationDraft {
        return (
            configurationDraftById[configuration.id] ?? {
                name: configuration.name,
                key: configuration.key,
                input_type: configuration.input_type,
                required: configuration.required,
                sort_order: configuration.sort_order,
            }
        );
    }

    function setOptionDraft(
        configurationId: number,
        nextDraft: OptionDraft,
    ): void {
        setOptionDraftByConfiguration((current) => ({
            ...current,
            [configurationId]: nextDraft,
        }));
    }

    function setConfigurationEditDraft(
        configurationId: number,
        nextDraft: ConfigurationDraft,
    ): void {
        setConfigurationDraftById((current) => ({
            ...current,
            [configurationId]: nextDraft,
        }));
    }

    async function handleCreateConfiguration(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        if (!id) return;

        try {
            setIsSaving(true);
            await createAdminProductConfiguration(id, {
                ...configurationDraft,
                key: configurationDraft.key.trim(),
            });
            setConfigurationDraft({
                ...emptyConfigurationDraft,
                sort_order: configurations.length,
            });
            setMessage('Configuration added.');
            setError(null);
            await loadData();
        } catch (createError) {
            setError(
                createError instanceof Error
                    ? createError.message
                    : 'Failed to create configuration.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleDeleteConfiguration(configurationId: number) {
        const confirmed = window.confirm(
            'Delete this configuration and all of its options?',
        );
        if (!confirmed) return;

        try {
            setIsSaving(true);
            await deleteAdminProductConfiguration(configurationId);
            setMessage('Configuration deleted.');
            setError(null);
            await loadData();
        } catch (deleteError) {
            setError(
                deleteError instanceof Error
                    ? deleteError.message
                    : 'Failed to delete configuration.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleUpdateConfiguration(configuration: ProductConfiguration) {
        const draft = getConfigurationDraft(configuration);

        try {
            setIsSaving(true);
            await updateAdminProductConfiguration(String(configuration.id), {
                name: draft.name.trim(),
                key: draft.key.trim(),
                input_type: draft.input_type,
                required: draft.required,
                sort_order: configuration.sort_order,
            });
            setMessage('Configuration updated.');
            setError(null);
            await loadData();
        } catch (updateError) {
            setError(
                updateError instanceof Error
                    ? updateError.message
                    : 'Failed to update configuration.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleMoveConfiguration(
        configuration: ProductConfiguration,
        direction: 'up' | 'down',
    ) {
        const index = sortedConfigurations.findIndex((item) => item.id === configuration.id);
        const swapIndex = direction === 'up' ? index - 1 : index + 1;
        if (index < 0 || swapIndex < 0 || swapIndex >= sortedConfigurations.length) {
            return;
        }

        const target = sortedConfigurations[swapIndex];

        try {
            setIsSaving(true);
            await Promise.all([
                updateAdminProductConfiguration(String(configuration.id), {
                    name: configuration.name,
                    key: configuration.key,
                    input_type: configuration.input_type,
                    required: configuration.required,
                    sort_order: target.sort_order,
                }),
                updateAdminProductConfiguration(String(target.id), {
                    name: target.name,
                    key: target.key,
                    input_type: target.input_type,
                    required: target.required,
                    sort_order: configuration.sort_order,
                }),
            ]);
            setMessage('Configuration order updated.');
            setError(null);
            await loadData();
        } catch (moveError) {
            setError(
                moveError instanceof Error
                    ? moveError.message
                    : 'Failed to reorder configurations.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleCreateOption(configurationId: number) {
        const draft = getOptionDraft(configurationId);

        try {
            setIsSaving(true);
            await createAdminConfigurationOption(String(configurationId), {
                label: draft.label.trim(),
                value: draft.value.trim(),
                price_modifier: Number(draft.price_modifier),
                is_active: draft.is_active,
                is_default: draft.is_default,
            });
            setOptionDraft(configurationId, emptyOptionDraft);
            setMessage('Option created.');
            setError(null);
            await loadData();
        } catch (createError) {
            setError(
                createError instanceof Error
                    ? createError.message
                    : 'Failed to create option.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleToggleOption(option: ProductConfigurationOption) {
        try {
            setIsSaving(true);
            await updateAdminConfigurationOption(String(option.id), {
                label: option.label,
                value: option.value,
                price_modifier: option.price_modifier ?? 0,
                is_active: !option.is_active,
                is_default: !option.is_active ? false : option.is_default,
            });
            setMessage(option.is_active ? 'Option disabled.' : 'Option enabled.');
            setError(null);
            await loadData();
        } catch (toggleError) {
            setError(
                toggleError instanceof Error
                    ? toggleError.message
                    : 'Failed to update option.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleEditOption(option: ProductConfigurationOption) {
        const nextLabel = window.prompt('Option label', option.label);
        if (nextLabel === null) return;

        const nextValue = window.prompt('Option value', option.value);
        if (nextValue === null) return;

        const nextModifier = window.prompt(
            'Price modifier (can be negative)',
            String(option.price_modifier ?? 0),
        );
        if (nextModifier === null) return;

        const parsedModifier = Number(nextModifier);
        if (Number.isNaN(parsedModifier)) {
            setError('Price modifier must be a valid number.');
            return;
        }

        try {
            setIsSaving(true);
            await updateAdminConfigurationOption(String(option.id), {
                label: nextLabel.trim(),
                value: nextValue.trim(),
                price_modifier: parsedModifier,
                is_active: option.is_active,
                is_default: option.is_default,
            });
            setMessage('Option updated.');
            setError(null);
            await loadData();
        } catch (updateError) {
            setError(
                updateError instanceof Error
                    ? updateError.message
                    : 'Failed to update option.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleSetDefaultOption(option: ProductConfigurationOption) {
        try {
            setIsSaving(true);
            await updateAdminConfigurationOption(String(option.id), {
                label: option.label,
                value: option.value,
                price_modifier: option.price_modifier ?? 0,
                is_active: true,
                is_default: true,
            });
            setMessage('Default option updated.');
            setError(null);
            await loadData();
        } catch (setDefaultError) {
            setError(
                setDefaultError instanceof Error
                    ? setDefaultError.message
                    : 'Failed to set default option.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    async function handleDeleteOption(optionId: number) {
        const confirmed = window.confirm('Delete this option?');
        if (!confirmed) return;

        try {
            setIsSaving(true);
            await deleteAdminConfigurationOption(optionId);
            setMessage('Option deleted.');
            setError(null);
            await loadData();
        } catch (deleteError) {
            setError(
                deleteError instanceof Error
                    ? deleteError.message
                    : 'Failed to delete option.',
            );
        } finally {
            setIsSaving(false);
        }
    }

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">
                        Configurations: {productName}
                    </h2>
                    <p className="mt-1 text-sm text-white/70">
                        Define configurable fields and option pricing for this product.
                    </p>
                </div>
                <Link
                    to="/admin/products"
                    className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
                >
                    Back to Products
                </Link>
            </div>

            {message ? (
                <div className="rounded-lg border border-[var(--panel-accent)]/40 bg-[var(--panel-accent)]/15 p-4 text-sm text-[var(--panel-text)]">
                    {message}
                </div>
            ) : null}

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <form
                onSubmit={(event) => void handleCreateConfiguration(event)}
                className="grid gap-3 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4 md:grid-cols-5"
            >
                <input
                    placeholder="Name (RAM)"
                    value={configurationDraft.name}
                    onChange={(event) =>
                        setConfigurationDraft((current) => ({
                            ...current,
                            name: event.target.value,
                        }))
                    }
                    className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                    required
                />
                <input
                    placeholder="Key (ram)"
                    value={configurationDraft.key}
                    onChange={(event) =>
                        setConfigurationDraft((current) => ({
                            ...current,
                            key: event.target.value,
                        }))
                    }
                    className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                />
                <select
                    value={configurationDraft.input_type}
                    onChange={(event) =>
                        setConfigurationDraft((current) => ({
                            ...current,
                            input_type: event.target.value as ProductConfigurationInputType,
                        }))
                    }
                    className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                >
                    {inputTypes.map((type) => (
                        <option key={type} value={type}>
                            {type}
                        </option>
                    ))}
                </select>
                <label className="flex items-center gap-2 rounded-lg border border-white/20 px-3 py-2 text-sm">
                    <input
                        type="checkbox"
                        checked={configurationDraft.required}
                        onChange={(event) =>
                            setConfigurationDraft((current) => ({
                                ...current,
                                required: event.target.checked,
                            }))
                        }
                        className="size-4 rounded border-white/20"
                    />
                    Required
                </label>
                <button
                    type="submit"
                    disabled={isSaving}
                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                >
                    Add Configuration
                </button>
            </form>

            {isLoading ? (
                <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4 text-sm text-white/70">
                    Loading configurations...
                </div>
            ) : (
                <div className="space-y-4">
                    {sortedConfigurations.length === 0 ? (
                        <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4 text-sm text-white/70">
                            No configurations defined for this product yet.
                        </div>
                    ) : (
                        sortedConfigurations.map((configuration, index) => {
                            const draft = getOptionDraft(configuration.id);
                            const configurationDraftForItem =
                                getConfigurationDraft(configuration);

                            return (
                                <article
                                    key={configuration.id}
                                    className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4"
                                >
                                    <div className="grid gap-3 md:grid-cols-4">
                                        <input
                                            value={configurationDraftForItem.name}
                                            onChange={(event) =>
                                                setConfigurationEditDraft(
                                                    configuration.id,
                                                    {
                                                        ...configurationDraftForItem,
                                                        name: event.target.value,
                                                    },
                                                )
                                            }
                                            className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                                        />
                                        <input
                                            value={configurationDraftForItem.key}
                                            onChange={(event) =>
                                                setConfigurationEditDraft(
                                                    configuration.id,
                                                    {
                                                        ...configurationDraftForItem,
                                                        key: event.target.value,
                                                    },
                                                )
                                            }
                                            className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                                        />
                                        <select
                                            value={configurationDraftForItem.input_type}
                                            onChange={(event) =>
                                                setConfigurationEditDraft(
                                                    configuration.id,
                                                    {
                                                        ...configurationDraftForItem,
                                                        input_type:
                                                            event.target
                                                                .value as ProductConfigurationInputType,
                                                    },
                                                )
                                            }
                                            className="rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                                        >
                                            {inputTypes.map((type) => (
                                                <option key={type} value={type}>
                                                    {type}
                                                </option>
                                            ))}
                                        </select>
                                        <label className="flex items-center gap-2 rounded-lg border border-white/20 px-3 py-2 text-sm">
                                            <input
                                                type="checkbox"
                                                checked={configurationDraftForItem.required}
                                                onChange={(event) =>
                                                    setConfigurationEditDraft(
                                                        configuration.id,
                                                        {
                                                            ...configurationDraftForItem,
                                                            required:
                                                                event.target.checked,
                                                        },
                                                    )
                                                }
                                                className="size-4 rounded border-white/20"
                                            />
                                            Required
                                        </label>
                                    </div>
                                    <div className="flex flex-wrap items-center justify-between gap-3">
                                        <div className="text-xs text-white/70">
                                            Key: {configuration.key} • Sort:{' '}
                                            {configuration.sort_order}
                                        </div>
                                        <div className="flex flex-wrap gap-2">
                                            <button
                                                type="button"
                                                disabled={isSaving}
                                                onClick={() =>
                                                    void handleUpdateConfiguration(
                                                        configuration,
                                                    )
                                                }
                                                className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10 disabled:opacity-50"
                                            >
                                                Save
                                            </button>
                                            <button
                                                type="button"
                                                disabled={index === 0 || isSaving}
                                                onClick={() =>
                                                    void handleMoveConfiguration(
                                                        configuration,
                                                        'up',
                                                    )
                                                }
                                                className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10 disabled:opacity-50"
                                            >
                                                Move Up
                                            </button>
                                            <button
                                                type="button"
                                                disabled={
                                                    index === sortedConfigurations.length - 1 ||
                                                    isSaving
                                                }
                                                onClick={() =>
                                                    void handleMoveConfiguration(
                                                        configuration,
                                                        'down',
                                                    )
                                                }
                                                className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10 disabled:opacity-50"
                                            >
                                                Move Down
                                            </button>
                                            <button
                                                type="button"
                                                disabled={isSaving}
                                                onClick={() =>
                                                    void handleDeleteConfiguration(
                                                        configuration.id,
                                                    )
                                                }
                                                className="rounded-md border border-rose-400/40 bg-rose-500/20 px-2.5 py-1 text-xs font-medium text-rose-100 hover:bg-rose-500/30 disabled:opacity-50"
                                            >
                                                Delete
                                            </button>
                                        </div>
                                    </div>
                                    {configuration.required &&
                                    !configuration.options.some(
                                        (option) => option.is_active && option.is_default,
                                    ) ? (
                                        <div className="rounded-lg border border-amber-400/40 bg-amber-500/20 p-2 text-xs text-amber-100">
                                            Required configuration has no default option.
                                        </div>
                                    ) : null}

                                    <div className="overflow-x-auto rounded-lg border border-white/10">
                                        <table className="min-w-full text-left text-sm">
                                            <thead className="bg-white/5 text-white/70">
                                                <tr>
                                                    <th className="px-3 py-2 font-medium">Label</th>
                                                    <th className="px-3 py-2 font-medium">Value</th>
                                                    <th className="px-3 py-2 font-medium">
                                                        Modifier
                                                    </th>
                                                    <th className="px-3 py-2 font-medium">
                                                        Status
                                                    </th>
                                                    <th className="px-3 py-2 font-medium">
                                                        Default
                                                    </th>
                                                    <th className="px-3 py-2 font-medium">
                                                        Actions
                                                    </th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {configuration.options.map((option) => (
                                                    <tr
                                                        key={option.id}
                                                        className="border-t border-white/10"
                                                    >
                                                        <td className="px-3 py-2">
                                                            {option.label}
                                                        </td>
                                                        <td className="px-3 py-2">
                                                            {option.value}
                                                        </td>
                                                        <td className="px-3 py-2">
                                                            {option.price_modifier ?? 0}
                                                        </td>
                                                        <td className="px-3 py-2">
                                                            {option.is_active
                                                                ? 'Active'
                                                                : 'Disabled'}
                                                        </td>
                                                        <td className="px-3 py-2">
                                                            {option.is_default ? 'Yes' : 'No'}
                                                        </td>
                                                        <td className="px-3 py-2">
                                                            <div className="flex flex-wrap gap-2">
                                                                <button
                                                                    type="button"
                                                                    onClick={() =>
                                                                        void handleEditOption(
                                                                            option,
                                                                        )
                                                                    }
                                                                    className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10"
                                                                >
                                                                    Edit
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    disabled={option.is_default}
                                                                    onClick={() =>
                                                                        void handleSetDefaultOption(
                                                                            option,
                                                                        )
                                                                    }
                                                                    className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10 disabled:opacity-50"
                                                                >
                                                                    Set Default
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    onClick={() =>
                                                                        void handleToggleOption(
                                                                            option,
                                                                        )
                                                                    }
                                                                    className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10"
                                                                >
                                                                    {option.is_active
                                                                        ? 'Disable'
                                                                        : 'Enable'}
                                                                </button>
                                                                <button
                                                                    type="button"
                                                                    onClick={() =>
                                                                        void handleDeleteOption(
                                                                            option.id,
                                                                        )
                                                                    }
                                                                    className="rounded-md border border-rose-400/40 bg-rose-500/20 px-2.5 py-1 text-xs font-medium text-rose-100 hover:bg-rose-500/30"
                                                                >
                                                                    Delete
                                                                </button>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                ))}
                                                <tr className="border-t border-white/10">
                                                    <td className="px-3 py-2">
                                                        <input
                                                            value={draft.label}
                                                            onChange={(event) =>
                                                                setOptionDraft(
                                                                    configuration.id,
                                                                    {
                                                                        ...draft,
                                                                        label: event.target.value,
                                                                    },
                                                                )
                                                            }
                                                            placeholder="Label"
                                                            className="w-full rounded-md border border-white/20 bg-[var(--panel-surface)] px-2 py-1 text-sm"
                                                        />
                                                    </td>
                                                    <td className="px-3 py-2">
                                                        <input
                                                            value={draft.value}
                                                            onChange={(event) =>
                                                                setOptionDraft(
                                                                    configuration.id,
                                                                    {
                                                                        ...draft,
                                                                        value: event.target.value,
                                                                    },
                                                                )
                                                            }
                                                            placeholder="Value"
                                                            className="w-full rounded-md border border-white/20 bg-[var(--panel-surface)] px-2 py-1 text-sm"
                                                        />
                                                    </td>
                                                    <td className="px-3 py-2">
                                                        <input
                                                            type="number"
                                                            step="0.01"
                                                            value={draft.price_modifier}
                                                            onChange={(event) =>
                                                                setOptionDraft(
                                                                    configuration.id,
                                                                    {
                                                                        ...draft,
                                                                        price_modifier:
                                                                            event.target.value,
                                                                    },
                                                                )
                                                            }
                                                            className="w-full rounded-md border border-white/20 bg-[var(--panel-surface)] px-2 py-1 text-sm"
                                                        />
                                                    </td>
                                                    <td className="px-3 py-2">
                                                        <label className="flex items-center gap-2 text-xs">
                                                            <input
                                                                type="checkbox"
                                                                checked={draft.is_active}
                                                                onChange={(event) =>
                                                                    setOptionDraft(
                                                                        configuration.id,
                                                                        {
                                                                            ...draft,
                                                                            is_active:
                                                                                event.target.checked,
                                                                            is_default:
                                                                                event.target.checked
                                                                                    ? draft.is_default
                                                                                    : false,
                                                                        },
                                                                    )
                                                                }
                                                                className="size-4 rounded border-white/20"
                                                            />
                                                            Active
                                                        </label>
                                                        <label className="mt-2 flex items-center gap-2 text-xs">
                                                            <input
                                                                type="checkbox"
                                                                checked={draft.is_default}
                                                                onChange={(event) =>
                                                                    setOptionDraft(
                                                                        configuration.id,
                                                                        {
                                                                            ...draft,
                                                                            is_default:
                                                                                event.target.checked,
                                                                        },
                                                                    )
                                                                }
                                                                className="size-4 rounded border-white/20"
                                                            />
                                                            Default
                                                        </label>
                                                    </td>
                                                    <td className="px-3 py-2">
                                                        <button
                                                            type="button"
                                                            onClick={() =>
                                                                void handleCreateOption(
                                                                    configuration.id,
                                                                )
                                                            }
                                                            className="rounded-md bg-[var(--panel-primary)] px-2.5 py-1 text-xs font-semibold text-white hover:brightness-110"
                                                        >
                                                            Add Option
                                                        </button>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </article>
                            );
                        })
                    )}
                </div>
            )}
        </section>
    );
}
