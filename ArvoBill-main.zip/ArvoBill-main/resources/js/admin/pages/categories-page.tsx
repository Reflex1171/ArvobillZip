import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { deleteAdminCategory, listAdminCategories } from '@/lib/products-api';
import type { ProductCategory } from '@/types/category';

export function CategoriesPage() {
  const [categories, setCategories] = useState<ProductCategory[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [pendingId, setPendingId] = useState<number | null>(null);

  async function loadCategories() {
    try {
      const data = await listAdminCategories();
      setCategories(data);
      setError(null);
    } catch (loadError) {
      setError(
        loadError instanceof Error
          ? loadError.message
          : 'Failed to load categories.',
      );
    } finally {
      setIsLoading(false);
    }
  }

  useEffect(() => {
    void loadCategories();
  }, []);

  async function handleDelete(categoryId: number) {
    const confirmed = window.confirm(
      'Delete this category? Products will become unassigned.',
    );
    if (!confirmed) {
      return;
    }

    try {
      setPendingId(categoryId);
      await deleteAdminCategory(categoryId);
      setCategories((current) =>
        current.filter((category) => category.id !== categoryId),
      );
    } catch (deleteError) {
      setError(
        deleteError instanceof Error
          ? deleteError.message
          : 'Failed to delete category.',
      );
    } finally {
      setPendingId(null);
    }
  }

  return (
    <div className="space-y-6">
      <section className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">Categories</h2>
          <p className="mt-1 text-sm text-white/70 ">
            Categories control storefront navigation and product grouping.
          </p>
        </div>
        <Link
          to="/admin/categories/new"
          className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110"
        >
          New Category
        </Link>
      </section>

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      <section className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-white/5 text-white/70 ">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Slug</th>
              <th className="px-4 py-3 font-medium">Products</th>
              <th className="px-4 py-3 font-medium">Actions</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td
                  className="px-4 py-4 text-white/70 "
                  colSpan={4}
                >
                  Loading categories...
                </td>
              </tr>
            ) : categories.length === 0 ? (
              <tr>
                <td
                  className="px-4 py-4 text-white/70 "
                  colSpan={4}
                >
                  No categories yet.
                </td>
              </tr>
            ) : (
              categories.map((category) => (
                <tr
                  key={category.id}
                  className="border-t border-white/10 "
                >
                  <td className="px-4 py-3 font-medium">
                    {category.name}
                  </td>
                  <td className="px-4 py-3">{category.slug}</td>
                  <td className="px-4 py-3">
                    {category.products_count ?? 0}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex gap-2">
                      <Link
                        to={`/admin/categories/${category.id}/edit`}
                        className="rounded-md border border-white/20 px-2.5 py-1 text-xs font-medium hover:bg-white/10"
                      >
                        Edit
                      </Link>
                      <button
                        type="button"
                        disabled={pendingId === category.id}
                        onClick={() =>
                          void handleDelete(category.id)
                        }
                        className="rounded-md border border-rose-300 px-2.5 py-1 text-xs font-medium text-rose-700 hover:bg-rose-50 disabled:opacity-50 dark:border-rose-900/40 dark:text-rose-300 dark:hover:bg-rose-900/20"
                      >
                        Delete
                      </button>
                    </div>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}
