import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listAdminUsers } from '@/lib/products-api';

type AdminUser = {
  id: number;
  name: string;
  email: string;
  role: 'user' | 'staff' | 'admin' | 'superuser';
  created_at: string | null;
};

function formatDate(value: string | null): string {
  if (!value) {
    return '-';
  }

  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function UsersPage() {
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadUsers() {
      try {
        const data = await listAdminUsers();
        setUsers(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load users.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadUsers();
  }, []);

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-xl font-semibold">Users</h2>
        <p className="mt-1 text-sm text-white/70 ">
          View all registered users and their assigned roles.
        </p>
      </section>

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      <section className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-white/5 text-white/70 ">
            <tr>
              <th className="px-4 py-3 font-medium">Name</th>
              <th className="px-4 py-3 font-medium">Email</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Actions</th>
              <th className="px-4 py-3 font-medium">Created</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td
                  className="px-4 py-4 text-white/70 "
                  colSpan={5}
                >
                  Loading users...
                </td>
              </tr>
            ) : users.length === 0 ? (
              <tr>
                <td
                  className="px-4 py-4 text-white/70 "
                  colSpan={5}
                >
                  No users found.
                </td>
              </tr>
            ) : (
              users.map((user) => (
                <tr
                  key={user.id}
                  className="border-t border-white/10 "
                >
                  <td className="px-4 py-3 font-medium">{user.name}</td>
                  <td className="px-4 py-3">{user.email}</td>
                  <td className="px-4 py-3">
                    <span className="rounded-full bg-white/10 px-2.5 py-1 text-xs font-semibold uppercase text-white/80">
                      {user.role}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <Link
                      to={`/admin/users/${user.id}`}
                      className="text-[var(--panel-primary)] hover:underline"
                    >
                      View details
                    </Link>
                  </td>
                  <td className="px-4 py-3">
                    {formatDate(user.created_at)}
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </section>
    </div>
  );
}
