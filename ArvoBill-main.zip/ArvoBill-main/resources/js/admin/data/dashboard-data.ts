export type AdminStat = {
    label: string;
    value: string;
    detail: string;
};

export const adminStats: AdminStat[] = [
    {
        label: 'Total Users',
        value: '1,248',
        detail: '18 new users in the last 7 days',
    },
    {
        label: 'Active Services',
        value: '972',
        detail: '96.8% healthy service status',
    },
    {
        label: 'Monthly Revenue',
        value: '$84,320',
        detail: 'Placeholder KPI for billing reporting',
    },
    {
        label: 'Pending Orders',
        value: '43',
        detail: '11 require manual review',
    },
];
