import { Navigate, Route, Routes } from 'react-router-dom';
import { AdminLayout } from './layout/admin-layout';
import { CategoriesPage } from './pages/categories-page';
import { CategoryFormPage } from './pages/category-form-page';
import { DashboardPage } from './pages/dashboard-page';
import { InvoiceDetailPage } from './pages/invoice-detail-page';
import { InvoicesPage } from './pages/invoices-page';
import { InfrastructureEggsPage } from './pages/infrastructure-eggs-page';
import { InfrastructureNodesPage } from './pages/infrastructure-nodes-page';
import { InfrastructurePterodactylPage } from './pages/infrastructure-pterodactyl-page';
import { InfrastructureServersPage } from './pages/infrastructure-servers-page';
import { OrderDetailPage } from './pages/order-detail-page';
import { OrdersPage } from './pages/orders-page';
import { PaymentsPage } from './pages/payments-page';
import { PaymentProvidersPage } from './pages/payment-providers-page';
import { ProductFormPage } from './pages/product-form-page';
import { ProductConfigurationsPage } from './pages/product-configurations-page';
import { ProductsPage } from './pages/products-page';
import { ServiceDetailPage } from './pages/service-detail-page';
import { ServicesPage } from './pages/services-page';
import { TicketDetailPage } from './pages/ticket-detail-page';
import { TicketsPage } from './pages/tickets-page';
import { ThemePage } from './pages/theme-page';
import { UsersPage } from './pages/users-page';
import { UserDetailPage } from './pages/user-detail-page';

export function AdminApp() {
    return (
        <Routes>
            <Route element={<AdminLayout />}>
                <Route path="/admin/dashboard" element={<DashboardPage />} />
                <Route path="/admin/users" element={<UsersPage />} />
                <Route path="/admin/users/:id" element={<UserDetailPage />} />
                <Route path="/admin/theme" element={<ThemePage />} />
                <Route path="/admin/tickets" element={<TicketsPage />} />
                <Route path="/admin/tickets/:id" element={<TicketDetailPage />} />
                <Route path="/admin/services" element={<ServicesPage />} />
                <Route path="/admin/services/:id" element={<ServiceDetailPage />} />
                <Route
                    path="/admin/infrastructure/pterodactyl"
                    element={<InfrastructurePterodactylPage />}
                />
                <Route
                    path="/admin/infrastructure/nodes"
                    element={<InfrastructureNodesPage />}
                />
                <Route
                    path="/admin/infrastructure/eggs"
                    element={<InfrastructureEggsPage />}
                />
                <Route
                    path="/admin/infrastructure/servers"
                    element={<InfrastructureServersPage />}
                />
                <Route path="/admin/orders" element={<OrdersPage />} />
                <Route path="/admin/orders/:id" element={<OrderDetailPage />} />
                <Route path="/admin/invoices" element={<InvoicesPage />} />
                <Route
                    path="/admin/invoices/:id"
                    element={<InvoiceDetailPage />}
                />
                <Route path="/admin/payments" element={<PaymentsPage />} />
                <Route
                    path="/admin/payment-providers"
                    element={<PaymentProvidersPage />}
                />
                <Route path="/admin/products" element={<ProductsPage />} />
                <Route path="/admin/products/new" element={<ProductFormPage />} />
                <Route
                    path="/admin/products/:id/edit"
                    element={<ProductFormPage />}
                />
                <Route
                    path="/admin/products/:id/configurations"
                    element={<ProductConfigurationsPage />}
                />
                <Route path="/admin/categories" element={<CategoriesPage />} />
                <Route
                    path="/admin/categories/new"
                    element={<CategoryFormPage />}
                />
                <Route
                    path="/admin/categories/:id/edit"
                    element={<CategoryFormPage />}
                />
            </Route>
            <Route path="/admin" element={<Navigate to="/admin/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/admin/dashboard" replace />} />
        </Routes>
    );
}
