import {
    Boxes,
    CreditCard,
    FolderTree,
    Gauge,
    Headset,
    Network,
    Palette,
    PlugZap,
    Receipt,
    Server,
    ShieldCheck,
    ShoppingCart,
    SquareArrowOutUpRight,
    Users,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { NavLink, Navigate, Outlet, useLocation } from 'react-router-dom';
import { canAccessAdmin, hasPermission, useMe } from '@/hooks/use-me';
import { useTheme } from '@/contexts/theme-context';

type NavigationItem = {
    label: string;
    to: string;
    icon: LucideIcon;
    permission?: string;
};

const navigation: NavigationItem[] = [
    { label: 'Dashboard', to: '/admin/dashboard', icon: Gauge },
    { label: 'Products', to: '/admin/products', icon: Boxes, permission: 'manage_settings' },
    { label: 'Categories', to: '/admin/categories', icon: FolderTree, permission: 'manage_settings' },
    { label: 'Services', to: '/admin/services', icon: Server, permission: 'view_services' },
    { label: 'Pterodactyl', to: '/admin/infrastructure/pterodactyl', icon: Network, permission: 'manage_settings' },
    { label: 'Nodes', to: '/admin/infrastructure/nodes', icon: Server, permission: 'view_services' },
    { label: 'Eggs', to: '/admin/infrastructure/eggs', icon: Boxes, permission: 'view_services' },
    { label: 'Servers', to: '/admin/infrastructure/servers', icon: Server, permission: 'view_services' },
    { label: 'Users', to: '/admin/users', icon: Users, permission: 'view_users' },
    { label: 'Theme', to: '/admin/theme', icon: Palette, permission: 'manage_settings' },
    { label: 'Providers', to: '/admin/payment-providers', icon: PlugZap, permission: 'manage_settings' },
    { label: 'Tickets', to: '/admin/tickets', icon: Headset, permission: 'view_tickets' },
    { label: 'Orders', to: '/admin/orders', icon: ShoppingCart, permission: 'view_billing' },
    { label: 'Invoices', to: '/admin/invoices', icon: Receipt, permission: 'view_billing' },
    { label: 'Payments', to: '/admin/payments', icon: CreditCard, permission: 'view_billing' },
];

function getCsrfToken(): string {
    return (
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        ''
    );
}

export function AdminLayout() {
    const location = useLocation();
    const { me, isLoading } = useMe();
    const { theme } = useTheme();
    const isAdmin = canAccessAdmin(me?.role);
    const visibleNavigation = navigation.filter((item) =>
        !item.permission || hasPermission(me, item.permission),
    );

    if (!isLoading && !isAdmin) {
        return <Navigate to="/products" replace />;
    }

    const currentTitle =
        visibleNavigation.find((item) => location.pathname.startsWith(item.to))?.label ??
        'Dashboard';

    return (
        <div className="min-h-screen bg-[var(--panel-bg)] text-[var(--panel-text)]">
            <aside className="fixed inset-y-0 left-0 hidden w-72 border-r border-white/10 bg-[var(--panel-surface)] px-5 py-6 lg:block lg:overflow-y-auto">
                <div className="mb-8 px-2">
                    {theme.logo_url ? (
                        <img src={theme.logo_url} alt={`${theme.brand_name} logo`} className="h-14 w-auto object-contain object-left" />
                    ) : (
                        <div className="flex items-center gap-2 rounded-md bg-[var(--panel-primary)] p-2 text-white">
                            <ShieldCheck className="size-5" />
                            <span className="text-sm font-semibold">{theme.brand_name}</span>
                        </div>
                    )}
                </div>

                <nav className="space-y-1">
                    {visibleNavigation.map((item) => {
                        const Icon = item.icon;

                        return (
                            <NavLink
                                key={item.to}
                                to={item.to}
                                className={({ isActive }) =>
                                    [
                                        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                                        isActive
                                            ? 'bg-[var(--panel-primary)] text-white'
                                            : 'text-white/80 hover:bg-[var(--panel-secondary)] hover:text-white',
                                    ].join(' ')
                                }
                            >
                                <Icon className="size-4" />
                                <span>{item.label}</span>
                            </NavLink>
                        );
                    })}
                </nav>

                <div className="mt-6 border-t border-white/10 pt-4">
                    <a
                        href="/products"
                        className="flex items-center gap-3 rounded-lg bg-[var(--panel-secondary)] px-3 py-2 text-sm font-medium text-white hover:brightness-110"
                    >
                        <SquareArrowOutUpRight className="size-4" />
                        <span>Back to Client Area</span>
                    </a>
                </div>
            </aside>

            <div className="lg:pl-72">
                <header className="sticky top-0 z-20 border-b border-white/10 bg-[var(--panel-surface)]/90 backdrop-blur">
                    <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
                        <div>
                            <p className="text-xs uppercase tracking-[0.18em] text-white/60">
                                Admin Area
                            </p>
                            <h1 className="text-lg font-semibold">{currentTitle}</h1>
                        </div>

                        <div className="flex items-center gap-4">
                            <span className="rounded-full bg-[var(--panel-accent)] px-3 py-1 text-xs font-semibold uppercase tracking-wide text-white">
                                {me?.role ?? 'admin'}
                            </span>
                            <div className="text-right">
                                <p className="text-sm font-medium">{me?.name ?? 'Admin'}</p>
                                <p className="hidden text-xs text-white/70 sm:block">
                                    {me?.email ?? ''}
                                </p>
                            </div>
                            <form method="POST" action="/logout">
                                <input
                                    type="hidden"
                                    name="_token"
                                    value={getCsrfToken()}
                                />
                                <button
                                    type="submit"
                                    className="rounded-lg border border-white/25 px-3 py-2 text-sm font-medium transition hover:bg-white/10"
                                >
                                    Logout
                                </button>
                            </form>
                        </div>
                    </div>

                    <div className="border-t border-white/10 px-4 py-3 lg:hidden">
                        <div className="flex gap-2 overflow-x-auto pb-1">
                            {visibleNavigation.map((item) => (
                                <NavLink
                                    key={item.to}
                                    to={item.to}
                                    className={({ isActive }) =>
                                        [
                                            'whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold',
                                            isActive
                                                ? 'bg-[var(--panel-primary)] text-white'
                                                : 'bg-white/10 text-white/85',
                                        ].join(' ')
                                    }
                                >
                                    {item.label}
                                </NavLink>
                            ))}
                            <a
                                href="/products"
                                className="whitespace-nowrap rounded-full bg-[var(--panel-secondary)] px-3 py-1.5 text-xs font-semibold text-white"
                            >
                                Client Area
                            </a>
                        </div>
                    </div>
                </header>

                <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
