import { Component, type ErrorInfo, type ReactNode } from 'react';

type Props = {
    children: ReactNode;
};

type State = {
    hasError: boolean;
    message: string;
};

export class StorefrontErrorBoundary extends Component<Props, State> {
    public constructor(props: Props) {
        super(props);
        this.state = {
            hasError: false,
            message: '',
        };
    }

    public static getDerivedStateFromError(error: unknown): State {
        return {
            hasError: true,
            message: error instanceof Error ? error.message : 'Unexpected UI error.',
        };
    }

    public componentDidCatch(error: unknown, errorInfo: ErrorInfo): void {
        console.error('Storefront render error:', error, errorInfo);
    }

    public render() {
        if (!this.state.hasError) {
            return this.props.children;
        }

        return (
            <div className="min-h-screen bg-[var(--panel-bg)] px-4 py-10 text-[var(--panel-text)]">
                <div className="mx-auto max-w-3xl rounded-xl border border-rose-300/40 bg-rose-500/10 p-6">
                    <h1 className="text-xl font-semibold text-rose-100">Checkout failed to render</h1>
                    <p className="mt-2 text-sm text-rose-100/90">{this.state.message}</p>
                    <div className="mt-6 flex flex-wrap gap-3">
                        <a
                            href="/products"
                            className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10"
                        >
                            Back to Products
                        </a>
                        <button
                            type="button"
                            onClick={() => window.location.reload()}
                            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110"
                        >
                            Reload
                        </button>
                    </div>
                </div>
            </div>
        );
    }
}
