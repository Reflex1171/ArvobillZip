import { ShieldCheck } from 'lucide-react';
import { Link, Outlet } from 'react-router-dom';
import { canAccessAdmin, useMe } from '@/hooks/use-me';
import { useTheme } from '@/contexts/theme-context';
import { PanelFooter } from '@/components/panel-footer';

function getCsrfToken(): string {
    return (
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        ''
    );
}

export function StorefrontLayout() {
    const { me, isLoading } = useMe();
    const { theme } = useTheme();
    const showAdmin = canAccessAdmin(me?.role);

    return (
        <div className="flex min-h-screen flex-col bg-[var(--panel-bg)] text-[var(--panel-text)]">
            <header className="sticky top-0 z-20 border-b border-white/10 bg-[var(--panel-surface)]/90 backdrop-blur">
                <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4 sm:px-6 lg:px-8">
                    <Link to="/products" className="flex items-center gap-2">
                        {theme.logo_url ? (
                            <img src={theme.logo_url} alt={`${theme.brand_name} logo`} className="h-10 w-auto object-contain object-left" />
                        ) : (
                            <span className="rounded-md bg-[var(--panel-primary)] px-2 py-1 text-xs font-bold tracking-wide text-white">
                                ARVO
                            </span>
                        )}
                    </Link>
                    <div className="flex items-center gap-3">
                        <a
                            href="/client/dashboard"
                            className="rounded-lg border border-white/25 px-3 py-2 text-xs font-semibold hover:bg-white/10"
                        >
                            Client Area
                        </a>

                        {showAdmin ? (
                            <a
                                href="/admin/dashboard"
                                className="inline-flex items-center gap-1 rounded-lg bg-[var(--panel-accent)] px-3 py-2 text-xs font-semibold text-white hover:brightness-110"
                            >
                                <ShieldCheck className="size-4" />
                                Admin Area
                            </a>
                        ) : null}

                        {!isLoading && me ? (
                            <form method="POST" action="/logout">
                                <input
                                    type="hidden"
                                    name="_token"
                                    value={getCsrfToken()}
                                />
                                <button
                                    type="submit"
                                    className="rounded-lg border border-white/25 px-3 py-2 text-xs font-semibold hover:bg-white/10"
                                >
                                    Logout
                                </button>
                            </form>
                        ) : (
                            <a
                                href="/login"
                                className="rounded-lg border border-white/25 px-3 py-2 text-xs font-semibold hover:bg-white/10"
                            >
                                Login
                            </a>
                        )}
                    </div>
                </div>
            </header>

            <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 lg:px-8">
                <Outlet />
            </main>

            <PanelFooter brandName={theme.brand_name} logoUrl={theme.logo_url} />
        </div>
    );
}
