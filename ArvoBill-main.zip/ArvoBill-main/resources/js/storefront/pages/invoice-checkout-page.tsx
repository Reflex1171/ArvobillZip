import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
    applyAccountCreditToInvoice,
    createPayPalPaymentOrder,
    createStripePaymentSession,
    getClientBillingData,
    getClientInvoice,
    listCheckoutPaymentProviders,
} from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import { ArrowLeft, CreditCard, Sparkles, Wallet, ShieldCheck } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { InvoiceSummary } from '@/types/billing';
import type { CheckoutPaymentProvider } from '@/types/billing';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

function isUnauthenticatedError(error: unknown): boolean {
    if (!(error instanceof Error)) {
        return false;
    }

    const message = error.message.toLowerCase();
    return message.includes('unauthenticated') || message.includes('request failed: 401');
}

export function InvoiceCheckoutPage() {
    const { invoiceId } = useParams<{ invoiceId: string }>();
    const [invoice, setInvoice] = useState<InvoiceSummary | null>(null);
    const [providers, setProviders] = useState<CheckoutPaymentProvider[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isPaying, setIsPaying] = useState<'stripe' | 'paypal' | null>(null);
    const [isApplyingCredit, setIsApplyingCredit] = useState(false);
    const [autoCreditAttempted, setAutoCreditAttempted] = useState(false);
    const [availableCredit, setAvailableCredit] = useState(0);
    const [lastAppliedCredit, setLastAppliedCredit] = useState(0);
    const [notice, setNotice] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadInvoice() {
            if (!invoiceId) {
                setError('Missing invoice id.');
                setIsLoading(false);
                return;
            }

            try {
                const [invoiceData, providerData, billingData] = await Promise.all([
                    getClientInvoice(invoiceId),
                    listCheckoutPaymentProviders(),
                    getClientBillingData().catch(() => null),
                ]);
                setInvoice(invoiceData);
                setProviders(providerData);
                setAvailableCredit(billingData?.summary.current_balance ?? 0);
                setError(null);
            } catch (loadError) {
                if (isUnauthenticatedError(loadError)) {
                    const redirectTarget = window.location.pathname + window.location.search;
                    window.location.assign(`/register?redirect=${encodeURIComponent(redirectTarget)}`);
                    return;
                }

                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load invoice.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadInvoice();
    }, [invoiceId]);

    useEffect(() => {
        if (!invoice || autoCreditAttempted || invoice.status !== 'unpaid') {
            return;
        }

        if (availableCredit <= 0) {
            setAutoCreditAttempted(true);
            return;
        }

        setAutoCreditAttempted(true);
        void handleApplyCredit(true);
    }, [invoice, availableCredit, autoCreditAttempted]);

    async function refreshInvoiceAndCredit(currentInvoiceId: number) {
        const [invoiceData, billingData] = await Promise.all([
            getClientInvoice(String(currentInvoiceId)),
            getClientBillingData().catch(() => null),
        ]);

        setInvoice(invoiceData);
        setAvailableCredit(billingData?.summary.current_balance ?? 0);
    }

    async function handleApplyCredit(isAutomatic = false) {
        if (!invoice || invoice.status !== 'unpaid') return;

        try {
            setIsApplyingCredit(true);
            setError(null);
            setNotice(null);

            const result = await applyAccountCreditToInvoice(invoice.id);
            setLastAppliedCredit(result.applied_amount);
            await refreshInvoiceAndCredit(invoice.id);

            if (result.applied_amount > 0) {
                setNotice(
                    isAutomatic
                        ? 'Account credit was applied automatically first.'
                        : 'Account credit applied successfully.',
                );
            }
        } catch (applyError) {
            setError(
                applyError instanceof Error
                    ? applyError.message
                    : 'Failed to apply account credit.',
            );
        } finally {
            setIsApplyingCredit(false);
        }
    }

    async function handlePayWithStripe() {
        if (!invoice || invoice.status !== 'unpaid') return;

        try {
            setIsPaying('stripe');
            setError(null);
            const result = await createStripePaymentSession(invoice.id);
            if (result.checkout_url) {
                window.location.assign(result.checkout_url);
                return;
            }

            window.location.assign(`/client/invoices/${invoice.id}`);
        } catch (payError) {
            setError(
                payError instanceof Error
                    ? payError.message
                    : 'Failed to start Stripe checkout.',
            );
            setIsPaying(null);
        }
    }

    async function handlePayWithPayPal() {
        if (!invoice || invoice.status !== 'unpaid') return;

        try {
            setIsPaying('paypal');
            setError(null);
            const result = await createPayPalPaymentOrder(invoice.id);
            if (result.checkout_url) {
                window.location.assign(result.checkout_url);
                return;
            }

            window.location.assign(`/client/invoices/${invoice.id}`);
        } catch (payError) {
            setError(
                payError instanceof Error
                    ? payError.message
                    : 'Failed to start PayPal checkout.',
            );
            setIsPaying(null);
        }
    }

    if (isLoading) {
        return (
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                Loading invoice checkout...
            </div>
        );
    }

    if (error || !invoice) {
        return (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                {error ?? 'Invoice not found.'}
            </div>
        );
    }

    const canPay = invoice.status === 'unpaid';
    const hasStripe = providers.some((provider) => provider.provider === 'stripe');
    const hasPayPal = providers.some((provider) => provider.provider === 'paypal');

    return (
        <section className="max-w-5xl mx-auto space-y-12 py-4">
            <header className="flex flex-col gap-8 sm:flex-row sm:items-end sm:justify-between">
                <div className="space-y-4">
                    <Link
                        to={`/client/invoices/${invoice.id}`}
                        className="group inline-flex items-center gap-2 text-sm font-black uppercase tracking-widest text-accent-400 hover:text-accent-300 transition-colors"
                    >
                        <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                        Back to Invoice
                    </Link>
                    <div className="flex flex-col gap-2">
                        <div className="flex items-center gap-4">
                            <h1 className="text-4xl font-black tracking-tight text-warm-white sm:text-5xl">
                                Complete <span className="text-accent-500">Payment</span>
                            </h1>
                            <StatusBadge status={invoice.status} />
                        </div>
                        <p className="text-lg text-warm-muted leading-relaxed max-w-2xl">
                            You&apos;re almost there. Review your billing details below and choose a secure provider to activate your services.
                        </p>
                    </div>
                </div>
            </header>

            <div className="grid gap-10 lg:grid-cols-5">
                <div className="lg:col-span-3 space-y-10">
                    <article className="rounded-[2.5rem] border border-white/8 bg-[var(--color-card)] p-10 shadow-sm relative overflow-hidden group">
                        <div className="absolute top-0 left-0 w-1 h-full bg-accent-500/40 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <h3 className="text-xs font-black uppercase tracking-[0.2em] text-warm-muted/50 mb-8 flex items-center gap-3">
                            <CreditCard className="size-4 text-accent-400" />
                            Account Credits
                        </h3>

                        <div className="grid gap-4 sm:grid-cols-3">
                            {[
                                { label: 'Balance', value: availableCredit, icon: Wallet, color: 'text-emerald-400' },
                                { label: 'Applied', value: lastAppliedCredit, icon: Sparkles, color: 'text-accent-400' },
                                { label: 'Remainder', value: invoice.total, icon: CreditCard, color: 'text-warm-white' }
                            ].map((stat, i) => (
                                <div key={i} className="rounded-2xl border border-white/5 bg-white/[0.02] p-6 group/stat hover:border-white/10 transition-colors">
                                    <div className="flex items-center justify-between mb-4">
                                        <stat.icon className={cn("size-5", stat.color)} />
                                    </div>
                                    <p className="text-[10px] font-black uppercase tracking-widest text-warm-muted/40 mb-1">{stat.label}</p>
                                    <p className="text-lg font-black text-warm-white">{formatCurrency(stat.value)}</p>
                                </div>
                            ))}
                        </div>

                        <div className="mt-8 flex items-center justify-between pt-8 border-t border-white/5">
                            <p className="text-sm text-warm-muted max-w-[280px]">
                                We automatically apply project credits to your balance first.
                            </p>
                            <button
                                type="button"
                                onClick={() => void handleApplyCredit(false)}
                                disabled={isApplyingCredit || invoice.status !== 'unpaid' || availableCredit <= 0}
                                className="inline-flex h-12 items-center px-6 rounded-xl border border-white/10 text-xs font-black uppercase tracking-widest text-warm-white hover:bg-white/5 transition-colors disabled:opacity-30"
                            >
                                {isApplyingCredit ? 'Processing...' : 'Manual Apply'}
                            </button>
                        </div>
                    </article>

                    <article className="rounded-[2.5rem] border border-white/8 bg-[var(--color-card)] p-10 shadow-sm relative overflow-hidden">
                        <h3 className="text-xs font-black uppercase tracking-[0.2em] text-warm-muted/50 mb-8 flex items-center gap-3">
                            <Sparkles className="size-4 text-accent-400" />
                            Secure Pay
                        </h3>

                        <div className="grid gap-6 sm:grid-cols-2">
                            {hasStripe && (
                                <button
                                    onClick={() => void handlePayWithStripe()}
                                    disabled={!canPay || isPaying !== null}
                                    className="group relative flex flex-col items-start gap-4 rounded-3xl border border-white/5 bg-white/[0.02] p-8 text-left transition-all hover:border-accent-500/40 hover:bg-accent-500/[0.03] active:scale-[0.98] disabled:opacity-40"
                                >
                                    <div className="size-12 rounded-2xl bg-accent-500/10 flex items-center justify-center text-accent-400 group-hover:scale-110 transition-transform">
                                        <CreditCard className="size-6" />
                                    </div>
                                    <div>
                                        <h4 className="text-lg font-black text-warm-white">Stripe Checkout</h4>
                                        <p className="text-xs font-bold text-warm-muted group-hover:text-accent-400 transition-colors uppercase tracking-widest mt-1">Debit / Credit Card</p>
                                    </div>
                                    {isPaying === 'stripe' && (
                                        <div className="absolute inset-0 flex items-center justify-center rounded-3xl bg-black/40 backdrop-blur-sm">
                                            <div className="size-6 animate-spin rounded-full border-2 border-accent-400/20 border-t-accent-400" />
                                        </div>
                                    )}
                                </button>
                            )}
                            {hasPayPal && (
                                <button
                                    onClick={() => void handlePayWithPayPal()}
                                    disabled={!canPay || isPaying !== null}
                                    className="group relative flex flex-col items-start gap-4 rounded-3xl border border-white/5 bg-white/[0.02] p-8 text-left transition-all hover:border-indigo-500/40 hover:bg-indigo-500/[0.03] active:scale-[0.98] disabled:opacity-40"
                                >
                                    <div className="size-12 rounded-2xl bg-indigo-500/10 flex items-center justify-center text-indigo-400 group-hover:scale-110 transition-transform">
                                        <Wallet className="size-6" />
                                    </div>
                                    <div>
                                        <h4 className="text-lg font-black text-warm-white">PayPal</h4>
                                        <p className="text-xs font-bold text-warm-muted group-hover:text-indigo-400 transition-colors uppercase tracking-widest mt-1">Instant Balance Transfer</p>
                                    </div>
                                    {isPaying === 'paypal' && (
                                        <div className="absolute inset-0 flex items-center justify-center rounded-3xl bg-black/40 backdrop-blur-sm">
                                            <div className="size-6 animate-spin rounded-full border-2 border-indigo-400/20 border-t-indigo-400" />
                                        </div>
                                    )}
                                </button>
                            )}
                        </div>

                        {!hasStripe && !hasPayPal && (
                            <div className="rounded-2xl border border-rose-500/20 bg-rose-500/5 p-8 text-center text-rose-400">
                                No gateways currently online. Please contact technicians.
                            </div>
                        )}
                    </article>
                </div>

                <div className="lg:col-span-2 space-y-8">
                    <article className="rounded-[2.5rem] border border-accent-500/30 bg-primary/5 p-10 shadow-2xl backdrop-blur-sm relative overflow-hidden">
                        <div className="absolute -right-20 -top-20 size-64 rounded-full bg-accent-500/10 blur-3xl text-accent-500" />
                        <h3 className="text-[10px] font-black uppercase tracking-widest text-warm-muted/60 mb-8 flex items-center gap-2">
                            <Wallet className="size-4 text-accent-500" />
                            Final Calculation
                        </h3>

                        <div className="space-y-6">
                            <div className="flex items-center justify-between">
                                <span className="text-xs font-bold text-warm-muted uppercase tracking-widest">Reference</span>
                                <span className="text-sm font-black text-warm-white tracking-tight">
                                    INV-{invoice.id}
                                </span>
                            </div>
                            <div className="flex items-center justify-between border-b border-white/5 pb-6">
                                <span className="text-xs font-bold text-warm-muted uppercase tracking-widest">Product</span>
                                <span className="text-sm font-black text-warm-white tracking-tight">
                                    {invoice.order?.product?.name ?? 'Managed Asset'}
                                </span>
                            </div>
                            <div className="pt-2">
                                <p className="text-[10px] font-black uppercase tracking-widest text-accent-400 mb-1">Total Due Now</p>
                                <p className="text-5xl font-black text-warm-white tracking-tighter">
                                    {formatCurrency(invoice.total)}
                                </p>
                            </div>
                        </div>
                    </article>

                    <div className="space-y-4">
                        <div className="flex items-center gap-3 px-6 py-4 rounded-[1.5rem] bg-white/[0.03] border border-white/5">
                            <ShieldCheck className="size-5 text-emerald-500" />
                            <p className="text-[10px] font-black uppercase tracking-widest text-warm-muted/60">Level 4 Security Verified</p>
                        </div>
                        {notice && (
                            <div className="flex items-center gap-3 px-6 py-4 rounded-[1.5rem] bg-accent-500/10 border border-accent-500/20 text-accent-400">
                                <Sparkles className="size-5" />
                                <p className="text-xs font-bold leading-relaxed">{notice}</p>
                            </div>
                        )}
                        {error && (
                            <div className="flex items-center gap-3 px-6 py-4 rounded-[1.5rem] bg-rose-500/10 border border-rose-500/20 text-rose-400">
                                <div className="size-2 rounded-full bg-rose-500 animate-pulse" />
                                <p className="text-xs font-bold leading-relaxed">{error}</p>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </section>
    );
}
