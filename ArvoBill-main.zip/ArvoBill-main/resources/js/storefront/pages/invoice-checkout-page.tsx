import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
    applyAccountCreditToInvoice,
    createPayPalPaymentOrder,
    createStripePaymentSession,
    getClientBillingData,
    getClientInvoice,
    listCheckoutPaymentProviders,
} from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { InvoiceSummary } from '@/types/billing';
import type { CheckoutPaymentProvider } from '@/types/billing';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

function isUnauthenticatedError(error: unknown): boolean {
    if (!(error instanceof Error)) {
        return false;
    }

    const message = error.message.toLowerCase();
    return message.includes('unauthenticated') || message.includes('request failed: 401');
}

export function InvoiceCheckoutPage() {
    const { invoiceId } = useParams<{ invoiceId: string }>();
    const [invoice, setInvoice] = useState<InvoiceSummary | null>(null);
    const [providers, setProviders] = useState<CheckoutPaymentProvider[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [isPaying, setIsPaying] = useState<'stripe' | 'paypal' | null>(null);
    const [isApplyingCredit, setIsApplyingCredit] = useState(false);
    const [autoCreditAttempted, setAutoCreditAttempted] = useState(false);
    const [availableCredit, setAvailableCredit] = useState(0);
    const [lastAppliedCredit, setLastAppliedCredit] = useState(0);
    const [notice, setNotice] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadInvoice() {
            if (!invoiceId) {
                setError('Missing invoice id.');
                setIsLoading(false);
                return;
            }

            try {
                const [invoiceData, providerData, billingData] = await Promise.all([
                    getClientInvoice(invoiceId),
                    listCheckoutPaymentProviders(),
                    getClientBillingData().catch(() => null),
                ]);
                setInvoice(invoiceData);
                setProviders(providerData);
                setAvailableCredit(billingData?.summary.current_balance ?? 0);
                setError(null);
            } catch (loadError) {
                if (isUnauthenticatedError(loadError)) {
                    const redirectTarget = window.location.pathname + window.location.search;
                    window.location.assign(`/register?redirect=${encodeURIComponent(redirectTarget)}`);
                    return;
                }

                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load invoice.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadInvoice();
    }, [invoiceId]);

    useEffect(() => {
        if (!invoice || autoCreditAttempted || invoice.status !== 'unpaid') {
            return;
        }

        if (availableCredit <= 0) {
            setAutoCreditAttempted(true);
            return;
        }

        setAutoCreditAttempted(true);
        void handleApplyCredit(true);
    }, [invoice, availableCredit, autoCreditAttempted]);

    async function refreshInvoiceAndCredit(currentInvoiceId: number) {
        const [invoiceData, billingData] = await Promise.all([
            getClientInvoice(String(currentInvoiceId)),
            getClientBillingData().catch(() => null),
        ]);

        setInvoice(invoiceData);
        setAvailableCredit(billingData?.summary.current_balance ?? 0);
    }

    async function handleApplyCredit(isAutomatic = false) {
        if (!invoice || invoice.status !== 'unpaid') return;

        try {
            setIsApplyingCredit(true);
            setError(null);
            setNotice(null);

            const result = await applyAccountCreditToInvoice(invoice.id);
            setLastAppliedCredit(result.applied_amount);
            await refreshInvoiceAndCredit(invoice.id);

            if (result.applied_amount > 0) {
                setNotice(
                    isAutomatic
                        ? 'Account credit was applied automatically first.'
                        : 'Account credit applied successfully.',
                );
            }
        } catch (applyError) {
            setError(
                applyError instanceof Error
                    ? applyError.message
                    : 'Failed to apply account credit.',
            );
        } finally {
            setIsApplyingCredit(false);
        }
    }

    async function handlePayWithStripe() {
        if (!invoice || invoice.status !== 'unpaid') return;

        try {
            setIsPaying('stripe');
            setError(null);
            const result = await createStripePaymentSession(invoice.id);
            if (result.checkout_url) {
                window.location.assign(result.checkout_url);
                return;
            }

            window.location.assign(`/client/invoices/${invoice.id}`);
        } catch (payError) {
            setError(
                payError instanceof Error
                    ? payError.message
                    : 'Failed to start Stripe checkout.',
            );
            setIsPaying(null);
        }
    }

    async function handlePayWithPayPal() {
        if (!invoice || invoice.status !== 'unpaid') return;

        try {
            setIsPaying('paypal');
            setError(null);
            const result = await createPayPalPaymentOrder(invoice.id);
            if (result.checkout_url) {
                window.location.assign(result.checkout_url);
                return;
            }

            window.location.assign(`/client/invoices/${invoice.id}`);
        } catch (payError) {
            setError(
                payError instanceof Error
                    ? payError.message
                    : 'Failed to start PayPal checkout.',
            );
            setIsPaying(null);
        }
    }

    if (isLoading) {
        return (
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                Loading invoice checkout...
            </div>
        );
    }

    if (error || !invoice) {
        return (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                {error ?? 'Invoice not found.'}
            </div>
        );
    }

    const canPay = invoice.status === 'unpaid';
    const hasStripe = providers.some((provider) => provider.provider === 'stripe');
    const hasPayPal = providers.some((provider) => provider.provider === 'paypal');

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <div>
                    <h1 className="text-2xl font-semibold">Invoice Checkout</h1>
                    <p className="mt-1 text-sm text-white/70">
                        Confirm invoice details and continue with your payment provider.
                    </p>
                </div>
                <StatusBadge status={invoice.status} />
            </div>

            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <div className="space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span className="text-white/70">Invoice</span>
                        <span>#{invoice.id}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">Product</span>
                        <span>{invoice.order?.product?.name ?? '-'}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">Due date</span>
                        <span>{formatDate(invoice.due_date)}</span>
                    </div>
                    <div className="flex justify-between border-t border-white/10 pt-2 font-semibold">
                        <span>Total</span>
                        <span>{formatCurrency(invoice.total)}</span>
                    </div>
                </div>
            </div>

            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <h2 className="text-lg font-semibold">Account Credit</h2>
                <p className="mt-1 text-sm text-white/70">
                    Account credit is used first by default. Any remaining balance is paid by provider.
                </p>
                <div className="mt-4 grid gap-2 text-sm sm:grid-cols-3">
                    <div className="rounded-lg border border-white/10 bg-[var(--panel-bg)] p-3">
                        <p className="text-white/70">Available credit</p>
                        <p className="mt-1 font-semibold">{formatCurrency(availableCredit)}</p>
                    </div>
                    <div className="rounded-lg border border-white/10 bg-[var(--panel-bg)] p-3">
                        <p className="text-white/70">Last applied</p>
                        <p className="mt-1 font-semibold">{formatCurrency(lastAppliedCredit)}</p>
                    </div>
                    <div className="rounded-lg border border-white/10 bg-[var(--panel-bg)] p-3">
                        <p className="text-white/70">Remaining due</p>
                        <p className="mt-1 font-semibold">{formatCurrency(invoice.total)}</p>
                    </div>
                </div>
                <div className="mt-4">
                    <button
                        type="button"
                        onClick={() => void handleApplyCredit(false)}
                        disabled={isApplyingCredit || invoice.status !== 'unpaid' || availableCredit <= 0}
                        className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10 disabled:opacity-60"
                    >
                        {isApplyingCredit ? 'Applying Credit...' : 'Use Account Credit'}
                    </button>
                </div>
            </div>

            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <h2 className="text-lg font-semibold">Payment Provider</h2>
                <p className="mt-1 text-sm text-white/70">
                    Pay any remaining balance using your enabled payment providers.
                </p>

                <div className="mt-4 flex flex-wrap gap-3">
                    {hasStripe ? (
                        <button
                            type="button"
                            onClick={() => void handlePayWithStripe()}
                            disabled={!canPay || isPaying !== null}
                            className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                        >
                            {isPaying === 'stripe'
                                ? 'Redirecting...'
                                : `Pay Remaining with Card (Stripe)`}
                        </button>
                    ) : null}
                    {hasPayPal ? (
                        <button
                            type="button"
                            onClick={() => void handlePayWithPayPal()}
                            disabled={!canPay || isPaying !== null}
                            className="rounded-lg bg-[var(--panel-secondary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                        >
                            {isPaying === 'paypal'
                                ? 'Redirecting...'
                                : `Pay Remaining with PayPal`}
                        </button>
                    ) : null}
                    <Link
                        to={`/client/invoices/${invoice.id}`}
                        className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10"
                    >
                        Back to Invoice
                    </Link>
                </div>
            </div>

            {!canPay ? (
                <div className="rounded-lg border border-cyan-200 bg-cyan-50 p-4 text-sm text-cyan-800 dark:border-cyan-900/40 dark:bg-cyan-900/20 dark:text-cyan-300">
                    This invoice is already {invoice.status}. No additional payment is required.
                </div>
            ) : null}

            {notice ? (
                <div className="rounded-lg border border-emerald-300/40 bg-emerald-500/10 p-4 text-sm text-emerald-100">
                    {notice}
                </div>
            ) : null}

            {canPay && providers.length === 0 ? (
                <div className="rounded-lg border border-amber-200 bg-amber-50 p-4 text-sm text-amber-800 dark:border-amber-900/40 dark:bg-amber-900/20 dark:text-amber-300">
                    No payment providers are currently enabled. Please contact support.
                </div>
            ) : null}

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}
        </section>
    );
}
