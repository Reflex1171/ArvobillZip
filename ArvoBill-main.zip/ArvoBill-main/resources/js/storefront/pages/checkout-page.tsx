import { useEffect, useMemo, useState } from 'react';
import { createOrder, validatePromoCode, type PromoValidationResult } from '@/lib/billing-api';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import {
    formatCurrency,
    getClientProductBySlug,
    listProductConfigurationsBySlug,
} from '@/lib/products-api';
import type { ProductConfiguration } from '@/types/product-configuration';
import type { Product } from '@/types/product';
import {
    CreditCard,
    ShoppingCart,
    Settings,
    ArrowLeft,
    ChevronRight,
    ShieldCheck,
    Tag,
    CheckCircle2,
    Lock,
    Sparkles
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

function trialLabel(product: Product): string | null {
    if (!product.trial_enabled || !product.trial_interval || !product.trial_period) {
        return null;
    }

    const interval = product.trial_interval;
    const period = product.trial_period;
    const label = interval === 1 ? period : `${interval} ${period}s`;

    return `Free ${label} trial`;
}

const requiredPterodactylKeys = ['ram', 'disk', 'cpu'];

async function isAuthenticated(): Promise<boolean> {
    try {
        const response = await fetch('/api/me', {
            credentials: 'same-origin',
            headers: {
                Accept: 'application/json',
            },
        });

        if (!response.ok) {
            return false;
        }

        const payload = (await response.json()) as { data?: unknown };
        return Boolean(payload?.data);
    } catch {
        return false;
    }
}

export function ProductCheckoutPage() {
    const { slug } = useParams<{ slug: string }>();
    const [searchParams] = useSearchParams();
    const cfgFromQuery = searchParams.get('cfg');
    const autoCreateFromQuery = searchParams.get('auto_create') === '1';
    const [product, setProduct] = useState<Product | null>(null);
    const [configurations, setConfigurations] = useState<ProductConfiguration[]>([]);
    const [selectedConfigurations, setSelectedConfigurations] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [hasAutoCreateAttempted, setHasAutoCreateAttempted] = useState(false);
    const [promoInput, setPromoInput] = useState('');
    const [appliedPromo, setAppliedPromo] = useState<PromoValidationResult | null>(null);
    const [isApplyingPromo, setIsApplyingPromo] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadCheckoutProduct() {
            if (!slug) {
                setError('Missing product slug.');
                setIsLoading(false);

                return;
            }

            try {
                const [productData, configurationData] = await Promise.all([
                    getClientProductBySlug(slug),
                    listProductConfigurationsBySlug(slug),
                ]);
                setProduct(productData);
                setConfigurations(configurationData);
                let parsedSelections: Record<string, string> = {};

                if (cfgFromQuery) {
                    try {
                        parsedSelections = JSON.parse(cfgFromQuery) as Record<string, string>;
                    } catch {
                        parsedSelections = {};
                    }
                }

                const defaultSelections: Record<string, string> = {};
                configurationData.forEach((configuration) => {
                    const options = Array.isArray(configuration.options)
                        ? configuration.options
                        : [];
                    const defaultOption = options.find(
                        (option) => option.is_default,
                    );
                    if (defaultOption) {
                        defaultSelections[configuration.key] = defaultOption.value;
                    }
                });

                setSelectedConfigurations({
                    ...defaultSelections,
                    ...parsedSelections,
                });
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load checkout data.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadCheckoutProduct();
    }, [slug, cfgFromQuery]);

    const selectedSummary = useMemo(
        () =>
            configurations
                .map((configuration) => {
                    const selectedValue = selectedConfigurations[configuration.key];
                    if (!selectedValue) return null;

                    const options = Array.isArray(configuration.options)
                        ? configuration.options
                        : [];
                    const selectedOption = options.find(
                        (option) => option.value === selectedValue,
                    );

                    if (!selectedOption) return null;

                    return {
                        configurationName: configuration.name,
                        label: selectedOption.label,
                        priceModifier: selectedOption.price_modifier ?? 0,
                    };
                })
                .filter((item): item is NonNullable<typeof item> => item !== null),
        [configurations, selectedConfigurations],
    );

    const total = product ? product.price_monthly + (product.setup_fee ?? 0) : 0;
    const requiredKeys = configurations
        .filter((configuration) => configuration.required)
        .map((configuration) => configuration.key);
    const missingRequired = requiredKeys.filter(
        (key) => !selectedConfigurations[key],
    );
    const isPterodactylProduct = product?.infrastructure_type === 'pterodactyl';
    const missingPterodactylKeys = isPterodactylProduct
        ? requiredPterodactylKeys.filter(
            (key) => !configurations.some((configuration) => configuration.key === key),
        )
        : [];
    const missingPterodactylSelections = isPterodactylProduct
        ? requiredPterodactylKeys.filter((key) => !selectedConfigurations[key])
        : [];

    const selectedOptionPriceModifier = configurations.reduce((sum, configuration) => {
        const selectedValue = selectedConfigurations[configuration.key];
        if (!selectedValue) return sum;

        const options = Array.isArray(configuration.options)
            ? configuration.options
            : [];
        const selectedOption = options.find(
            (option) => option.value === selectedValue,
        );

        return sum + (selectedOption?.price_modifier ?? 0);
    }, 0);
    const adjustedTotal = total + selectedOptionPriceModifier;
    const finalTotal = appliedPromo ? appliedPromo.final_total : adjustedTotal;
    const trialAvailable = Boolean(
        product?.trial_enabled && product?.trial_interval && product?.trial_period,
    );
    const dueToday = trialAvailable ? 0 : finalTotal;

    useEffect(() => {
        setAppliedPromo(null);
    }, [slug, selectedConfigurations, adjustedTotal]);

    async function handleApplyPromoCode() {
        if (!product) {
            return;
        }

        const code = promoInput.trim();
        if (code === '') {
            setAppliedPromo(null);
            return;
        }

        try {
            setIsApplyingPromo(true);
            setError(null);
            const validatedPromo = await validatePromoCode({
                code,
                product_slug: product.slug,
                configurations: selectedConfigurations,
            });
            setAppliedPromo(validatedPromo);
            setPromoInput(validatedPromo.code ?? code.toUpperCase());
        } catch (promoError) {
            setAppliedPromo(null);
            setError(
                promoError instanceof Error
                    ? promoError.message
                    : 'Failed to apply promo code.',
            );
        } finally {
            setIsApplyingPromo(false);
        }
    }

    async function handleConfirmOrder() {
        if (!product) {
            return;
        }

        if (missingPterodactylKeys.length > 0) {
            setError('Product is missing required RAM/Disk/CPU configuration definitions.');
            return;
        }

        if (missingRequired.length > 0 || missingPterodactylSelections.length > 0) {
            setError('Please select all required configuration options.');
            return;
        }

        const authenticated = await isAuthenticated();
        if (!authenticated) {
            const params = new URLSearchParams({
                cfg: JSON.stringify(selectedConfigurations),
                auto_create: '1',
            });
            window.location.assign(
                `/register?redirect=${encodeURIComponent(`/checkout/product/${product.slug}?${params.toString()}`)}`,
            );
            return;
        }

        try {
            setIsSubmitting(true);
            setError(null);
            const order = await createOrder(
                product.slug,
                selectedConfigurations,
                appliedPromo?.code ?? null,
            );
            const invoiceId = order.invoice?.id;

            if (invoiceId) {
                window.location.assign(`/checkout/${invoiceId}`);
            } else {
                window.location.assign('/client/orders');
            }
        } catch (createError) {
            const message = createError instanceof Error
                ? createError.message
                : 'Failed to create order.';

            const lower = message.toLowerCase();
            if (lower.includes('unauthenticated') || lower.includes('request failed: 401')) {
                const params = new URLSearchParams({
                    cfg: JSON.stringify(selectedConfigurations),
                    auto_create: '1',
                });
                window.location.assign(
                    `/register?redirect=${encodeURIComponent(`/checkout/product/${product.slug}?${params.toString()}`)}`,
                );
                return;
            }

            setError(
                message,
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    useEffect(() => {
        if (
            !autoCreateFromQuery ||
            hasAutoCreateAttempted ||
            isLoading ||
            !product
        ) {
            return;
        }

        setHasAutoCreateAttempted(true);
        void handleConfirmOrder();
    }, [
        autoCreateFromQuery,
        hasAutoCreateAttempted,
        isLoading,
        product,
    ]);

    if (isLoading) {
        return (
            <div className="max-w-6xl mx-auto py-12 animate-pulse space-y-8">
                <div className="h-6 w-32 rounded bg-white/5" />
                <div className="h-48 rounded-3xl bg-white/5" />
            </div>
        );
    }

    if (error || !product) {
        return (
            <div className="max-w-xl mx-auto py-32 text-center">
                <div className="inline-flex size-20 items-center justify-center rounded-full bg-rose-500/10 text-rose-400 mb-6 font-bold text-3xl">!</div>
                <h3 className="text-2xl font-bold text-warm-white">Checkout Error</h3>
                <p className="mt-2 text-warm-muted">{error ?? 'This specific order session could not be established.'}</p>
                <Link to="/products" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 link-arrow">
                    Return to safety <span>&rarr;</span>
                </Link>
            </div>
        );
    }

    const trial = trialLabel(product);

    return (
        <div className="max-w-6xl mx-auto space-y-12 py-4">
            <header>
                <Link
                    to={`/products/${product.category?.slug ?? 'all'}/${product.slug}/configure`}
                    className="group mb-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 hover:text-accent-300 transition-colors"
                >
                    <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                    Review Configuration
                </Link>

                <div className="relative overflow-hidden rounded-[2.5rem] border border-white/8 bg-[var(--panel-surface)] p-12 shadow-2xl">
                    <div className="absolute right-0 top-0 h-full w-1/4 bg-gradient-to-l from-accent-500/10 to-transparent" />
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-4">
                            <ShoppingCart className="size-4 text-accent-400" />
                            <span className="text-[10px] font-black uppercase tracking-widest text-warm-muted/40">Secure Checkout</span>
                        </div>
                        <h2 className="text-4xl font-black tracking-tight text-warm-white sm:text-6xl">Finalize Order</h2>
                        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-warm-muted">
                            Complete your deployment of <span className="font-bold text-warm-white">{product.name}</span>. All instances are protected by our enterprise-grade security.
                        </p>
                    </div>
                </div>
            </header>

            <section className="grid gap-12 lg:grid-cols-5">
                <div className="lg:col-span-3 space-y-10">
                    <article className="rounded-3xl border border-white/8 bg-[var(--color-card)] p-8 shadow-sm">
                        <div className="flex items-center gap-3 mb-8">
                            <Sparkles className="size-5 text-accent-400" />
                            <h2 className="text-2xl font-bold text-warm-white">Human Checkout</h2>
                        </div>

                        <div className="grid gap-6">
                            {selectedSummary.length > 0 ? (
                                selectedSummary.map((item) => (
                                    <div key={item.configurationName} className="flex items-center justify-between p-4 rounded-2xl bg-white/2 border border-white/5">
                                        <div className="space-y-1">
                                            <p className="text-[10px] font-black uppercase tracking-widest text-warm-muted/40">{item.configurationName}</p>
                                            <p className="text-sm font-bold text-warm-white">{item.label}</p>
                                        </div>
                                        {item.priceModifier !== 0 && (
                                            <span className="text-xs font-black text-accent-500">
                                                {item.priceModifier > 0 ? '+' : ''}{formatCurrency(item.priceModifier)}
                                            </span>
                                        )}
                                    </div>
                                ))
                            ) : (
                                <div className="p-8 rounded-2xl bg-white/2 border border-dashed border-white/10 text-center">
                                    <Sparkles className="size-8 text-accent-400 mx-auto mb-3" />
                                    <p className="text-sm text-warm-muted">Base configuration selected. No modifications needed.</p>
                                </div>
                            )}
                        </div>
                    </article>

                    <article className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-10 shadow-sm relative overflow-hidden group">
                        <h3 className="text-lg font-black tracking-tight text-warm-white flex items-center gap-2 mb-8 uppercase">
                            <Tag className="size-5 text-accent-400" />
                            Promotional Code
                        </h3>
                        <p className="mb-6 text-sm text-warm-muted leading-relaxed">
                            Have a coupon for ArvoHost? Apply it below to see your adjusted total.
                        </p>

                        <div className="flex gap-4">
                            <input
                                type="text"
                                value={promoInput}
                                onChange={(e) => setPromoInput(e.target.value.toUpperCase())}
                                placeholder="PROMO_CODE"
                                className="flex-1 rounded-2xl border border-white/10 bg-white/5 p-4 text-sm font-bold text-warm-white focus:border-accent-500/50 focus:outline-none transition-all uppercase tracking-widest placeholder:text-warm-muted/20"
                            />
                            <button
                                type="button"
                                onClick={() => void handleApplyPromoCode()}
                                disabled={isApplyingPromo || promoInput.trim() === ''}
                                className="px-8 rounded-2xl bg-white/5 border border-white/10 text-sm font-black uppercase tracking-widest text-warm-white hover:bg-accent-500 hover:text-white transition-all disabled:opacity-50"
                            >
                                {isApplyingPromo ? '...' : 'Apply'}
                            </button>
                        </div>

                        {appliedPromo && (
                            <div className="mt-4 flex items-center gap-2 text-emerald-400 text-xs font-black uppercase tracking-widest animate-fade-in-up">
                                <CheckCircle2 className="size-4" />
                                Code {appliedPromo.code} Applied: Saved {formatCurrency(appliedPromo.discount_amount)}
                            </div>
                        )}
                    </article>
                </div>

                <div className="lg:col-span-2 space-y-8">
                    <article className="sticky top-8 rounded-[2.5rem] border border-accent-500/30 bg-accent-600/5 p-10 shadow-2xl backdrop-blur-sm relative overflow-hidden">
                        <div className="absolute -right-20 -top-20 size-64 rounded-full bg-accent-500/10 blur-3xl" />
                        <h3 className="text-lg font-bold text-warm-white tracking-tight flex items-center gap-2">
                            <CreditCard className="size-5 text-accent-400" />
                            Order Financials
                        </h3>

                        <div className="mt-8 space-y-4">
                            <div className="flex items-center justify-between text-xs font-bold uppercase tracking-widest text-warm-muted/40">
                                <span>Cycle</span>
                                <span className="text-warm-white">{product.billing_summary}</span>
                            </div>
                            {trial ? (
                                <div className="flex items-center justify-between text-xs font-bold uppercase tracking-widest">
                                    <span className="text-warm-muted/60">Trial</span>
                                    <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-emerald-300">
                                        {trial}
                                    </span>
                                </div>
                            ) : null}

                            <div className="space-y-3 py-6 border-y border-white/5">
                                <div className="flex justify-between text-sm">
                                    <span className="text-warm-muted">Base Recurring</span>
                                    <span className="font-bold text-warm-white">{formatCurrency(product.price_monthly)}</span>
                                </div>
                                {(product.setup_fee ?? 0) > 0 && (
                                    <div className="flex justify-between text-sm">
                                        <span className="text-warm-muted">Setup Fee</span>
                                        <span className="font-bold text-warm-white">{formatCurrency(product.setup_fee!)}</span>
                                    </div>
                                )}
                                {selectedOptionPriceModifier !== 0 && (
                                    <div className="flex justify-between text-sm">
                                        <span className="text-warm-muted">Config Modifiers</span>
                                        <span className="font-bold text-accent-500">+{formatCurrency(selectedOptionPriceModifier)}</span>
                                    </div>
                                )}
                                {appliedPromo && (
                                    <div className="flex justify-between text-sm">
                                        <span className="text-emerald-500 font-bold">Promo Discount</span>
                                        <span className="font-bold text-emerald-500">-{formatCurrency(appliedPromo.discount_amount)}</span>
                                    </div>
                                )}
                            </div>

                            <div className="flex items-center justify-between pt-2">
                                <div className="space-y-1">
                                    <p className="text-xs font-bold uppercase tracking-widest text-warm-muted/40">Total Due Now</p>
                                    <p className="text-3xl font-black text-warm-white">
                                        {formatCurrency(dueToday)}
                                    </p>
                                </div>
                            </div>

                            <div className="pt-8 space-y-4">
                                <button
                                    type="button"
                                    onClick={() => void handleConfirmOrder()}
                                    disabled={isSubmitting || missingRequired.length > 0 || missingPterodactylSelections.length > 0 || missingPterodactylKeys.length > 0}
                                    className="btn-glow flex w-full items-center justify-center gap-3 rounded-2xl bg-primary py-5 text-lg font-black uppercase tracking-widest text-white transition-all hover:bg-primary/90 active:scale-95 shadow-xl disabled:opacity-50"
                                >
                                    {isSubmitting ? 'Securing Spot...' : 'Activate Plan'}
                                    <ChevronRight className="size-5" />
                                </button>

                                <div className="flex flex-col items-center gap-3">
                                    <div className="flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-warm-muted/60">
                                        <Lock className="size-4 text-emerald-500" />
                                        End-to-End Encryption
                                    </div>
                                    <div className="flex gap-2">
                                        <ShieldCheck className="size-5 text-accent-500 opacity-50" />
                                        <CheckCircle2 className="size-5 text-emerald-500 opacity-50" />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            </section>
        </div>
    );
}
