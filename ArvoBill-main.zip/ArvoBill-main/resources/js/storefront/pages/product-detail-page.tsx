import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { formatCurrency, getClientProductBySlug } from '@/lib/products-api';
import type { Product } from '@/types/product';
import {
    ArrowLeft,
    ShieldCheck,
    Zap,
    Globe,
    Cpu,
    CheckCircle2,
    ChevronRight,
    CreditCard,
    Sparkles,
    Star
} from 'lucide-react';

function trialLabel(product: Product): string | null {
    if (!product.trial_enabled || !product.trial_interval || !product.trial_period) {
        return null;
    }

    const interval = product.trial_interval;
    const period = product.trial_period;
    const label = interval === 1 ? period : `${interval} ${period}s`;

    return `Free ${label} trial`;
}

export function ProductDetailPage() {
    const { category, slug } = useParams<{ category: string; slug: string }>();
    const [product, setProduct] = useState<Product | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadProduct() {
            if (!slug) {
                setError('Missing product slug.');
                setIsLoading(false);
                return;
            }

            try {
                const data = await getClientProductBySlug(slug);
                setProduct(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load product details.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadProduct();
    }, [slug]);

    if (isLoading) {
        return (
            <div className="max-w-5xl mx-auto py-12 animate-pulse space-y-8">
                <div className="h-6 w-32 rounded bg-white/5" />
                <div className="h-48 rounded-3xl bg-white/5" />
                <div className="grid gap-8 lg:grid-cols-2">
                    <div className="h-64 rounded-3xl bg-white/5" />
                    <div className="h-64 rounded-3xl bg-white/5" />
                </div>
            </div>
        );
    }

    if (error || !product) {
        return (
            <div className="max-w-xl mx-auto py-32 text-center">
                <div className="inline-flex size-20 items-center justify-center rounded-full bg-rose-500/10 text-rose-400 mb-6 font-bold text-3xl">!</div>
                <h3 className="text-2xl font-bold text-warm-white">Product Unavailable</h3>
                <p className="mt-2 text-warm-muted">{error ?? 'This plan could not be recovered from our database.'}</p>
                <Link to="/products" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 link-arrow">
                    Back to catalog <span>&rarr;</span>
                </Link>
            </div>
        );
    }

    const trial = trialLabel(product);

    return (
        <div className="max-w-6xl mx-auto space-y-12 py-4">
            <header>
                <Link
                    to={category ? `/products/${category}` : '/products'}
                    className="group mb-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 hover:text-accent-300 transition-colors"
                >
                    <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                    Back to {category ? 'Category' : 'Products'}
                </Link>

                <div className="relative overflow-hidden rounded-[2.5rem] border border-white/8 bg-[var(--panel-surface)] p-12 shadow-2xl">
                    <div className="absolute right-0 top-0 h-full w-1/4 bg-gradient-to-l from-accent-500/10 to-transparent" />
                    <div className="relative z-10">
                        {product.category && (
                            <div className="flex items-center gap-2 mb-4">
                                <Sparkles className="size-4 text-accent-400" />
                                <span className="rounded-full bg-accent-500/10 border border-accent-500/20 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-accent-400">
                                    {product.category.name}
                                </span>
                            </div>
                        )}
                        <h2 className="text-4xl font-black tracking-tight text-warm-white sm:text-6xl">{product.name}</h2>
                        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-warm-muted">
                            {product.description}
                        </p>

                        <div className="mt-10 flex flex-wrap gap-8">
                            <div className="flex items-center gap-3">
                                <div className="flex size-10 items-center justify-center rounded-xl bg-accent-500/10 text-accent-400">
                                    <Zap className="size-5" />
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50">Performance</p>
                                    <p className="text-sm font-bold text-warm-white tracking-tight">Enterprise NVMe</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="flex size-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400">
                                    <Globe className="size-5" />
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50">Network</p>
                                    <p className="text-sm font-bold text-warm-white tracking-tight">Global Edge Network</p>
                                </div>
                            </div>
                            <div className="flex items-center gap-3">
                                <div className="flex size-10 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
                                    <ShieldCheck className="size-5" />
                                </div>
                                <div>
                                    <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50">Security</p>
                                    <p className="text-sm font-bold text-warm-white tracking-tight">Advanced DDoS Shield</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <section className="grid gap-8 lg:grid-cols-5">
                <div className="lg:col-span-3 space-y-8">
                    <article className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-10 shadow-sm relative overflow-hidden group">
                        <div className="absolute top-0 left-0 w-1 h-full bg-accent-500/40 opacity-0 group-hover:opacity-100 transition-opacity" />
                        <h3 className="text-xl font-bold text-warm-white flex items-center gap-3">
                            <Cpu className="size-6 text-accent-400" />
                            Premium Hosting Features
                        </h3>
                        <div className="mt-8 grid gap-8 sm:grid-cols-2">
                            {[
                                { title: "Instant Setup", desc: "Get online immediately. Our automated provisioning system handles the heavy lifting." },
                                { title: "DDoS Protection", desc: "Battle-tested 12Tbps+ filtering capacity keeps your instances protected 24/7." },
                                { title: "NVMe Storage", desc: "Experience extreme I/O performance with data-center grade Gen4 NVMe drives." },
                                { title: "Expert Support", desc: "Direct access to technicians who understand your needs, not just a call center." }
                            ].map((feature, i) => (
                                <div key={i} className="space-y-2">
                                    <div className="flex items-center gap-2 text-accent-400">
                                        <CheckCircle2 className="size-4" />
                                        <span className="text-xs font-bold uppercase tracking-widest">{feature.title}</span>
                                    </div>
                                    <p className="text-sm text-warm-muted leading-relaxed">
                                        {feature.desc}
                                    </p>
                                </div>
                            ))}
                        </div>
                    </article>

                    <article className="rounded-3xl border border-white/8 bg-[var(--color-card)] p-10 text-center relative overflow-hidden">
                        <div className="absolute inset-0 opacity-5 pointer-events-none bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-accent-500 to-transparent" />
                        <div className="flex justify-center gap-1 text-amber-500 mb-6">
                            {[1, 2, 3, 4, 5].map(i => <Star key={i} className="size-5 fill-current" />)}
                        </div>
                        <blockquote className="text-2xl font-black text-warm-white leading-tight">
                            &ldquo;ArvoHost isn&apos;t just hosting. It&apos;s the unfair advantage my community needed to scale.&rdquo;
                        </blockquote>
                        <cite className="mt-4 block text-xs font-bold uppercase tracking-widest text-warm-muted not-italic">
                            — Verified Community Owner
                        </cite>
                    </article>
                </div>

                <div className="lg:col-span-2 space-y-8">
                    <article className="rounded-[2.5rem] border border-accent-500/30 bg-accent-600/5 p-10 shadow-2xl backdrop-blur-sm relative overflow-hidden">
                        <div className="absolute -right-20 -top-20 size-64 rounded-full bg-accent-500/10 blur-3xl text-accent-500" />
                        <h3 className="text-lg font-bold text-warm-white tracking-tight flex items-center gap-2">
                            <CreditCard className="size-5 text-accent-400" />
                            Pricing Overview
                        </h3>

                        <div className="mt-8 space-y-6">
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-warm-muted">Billing Cycle</span>
                                <span className="text-sm font-bold text-warm-white uppercase tracking-widest">
                                    {product.billing_summary}
                                </span>
                            </div>

                            {trial ? (
                                <div className="flex items-center justify-between">
                                    <span className="text-sm text-warm-muted">Trial</span>
                                    <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-emerald-300">
                                        {trial}
                                    </span>
                                </div>
                            ) : null}

                            <div className="flex items-center justify-between border-b border-white/5 pb-6">
                                <span className="text-sm text-warm-muted">Recurring Amount</span>
                                <div className="text-right">
                                    <span className="text-3xl font-black text-warm-white">
                                        {formatCurrency(product.price_monthly)}
                                    </span>
                                </div>
                            </div>

                            <div className="flex items-center justify-between pt-2">
                                <span className="text-sm text-warm-muted">Setup Fee</span>
                                <span className="text-sm font-bold text-warm-white">
                                    {(product.setup_fee ?? 0) > 0
                                        ? formatCurrency(product.setup_fee!)
                                        : 'Free Setup'}
                                </span>
                            </div>

                            <div className="pt-8">
                                <Link
                                    to={`/products/${product.category?.slug ?? 'all'}/${product.slug}/configure`}
                                    className="btn-glow flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-black uppercase tracking-widest text-white transition-all hover:bg-primary/90 shadow-xl shadow-accent-500/20 hover:shadow-accent-500/40"
                                >
                                    Configure Now <ChevronRight className="size-5" />
                                </Link>
                                <p className="mt-4 text-center text-[10px] font-bold uppercase tracking-widest text-warm-muted opacity-40">
                                    Instant Activation • Professional Hardware
                                </p>
                            </div>
                        </div>
                    </article>
                </div>
            </section>
        </div>
    );
}
