import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
    formatCurrency,
    getClientProductBySlug,
    listProductConfigurationsBySlug,
} from '@/lib/products-api';
import type { ProductConfiguration } from '@/types/product-configuration';
import type { Product } from '@/types/product';

function buildDefaultSelections(
    configurations: ProductConfiguration[],
): Record<string, string> {
    const selections: Record<string, string> = {};

    configurations.forEach((configuration) => {
        const defaultOption = configuration.options.find((option) => option.is_default);
        if (defaultOption) {
            selections[configuration.key] = defaultOption.value;
        }
    });

    return selections;
}

export function ProductConfigurePage() {
    const navigate = useNavigate();
    const { category = '', slug = '' } = useParams<{
        category: string;
        slug: string;
    }>();
    const [product, setProduct] = useState<Product | null>(null);
    const [configurations, setConfigurations] = useState<ProductConfiguration[]>([]);
    const [selections, setSelections] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadData() {
            if (!slug) {
                setError('Missing product slug.');
                setIsLoading(false);
                return;
            }

            try {
                const [productData, configurationData] = await Promise.all([
                    getClientProductBySlug(slug),
                    listProductConfigurationsBySlug(slug),
                ]);
                setProduct(productData);
                setConfigurations(configurationData);
                setSelections(buildDefaultSelections(configurationData));
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load configuration options.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadData();
    }, [slug]);

    const baseTotal = (product?.price_monthly ?? 0) + (product?.setup_fee ?? 0);
    const modifierTotal = useMemo(
        () =>
            configurations.reduce((sum, configuration) => {
                const selectedValue = selections[configuration.key];
                if (!selectedValue) return sum;

                const option = configuration.options.find(
                    (item) => item.value === selectedValue,
                );

                return sum + (option?.price_modifier ?? 0);
            }, 0),
        [configurations, selections],
    );
    const total = baseTotal + modifierTotal;

    const missingRequired = configurations
        .filter((configuration) => configuration.required && !selections[configuration.key])
        .map((configuration) => configuration.name);

    function updateSelection(configurationKey: string, value: string) {
        setSelections((current) => ({
            ...current,
            [configurationKey]: value,
        }));
    }

    function handleContinue() {
        if (!product) return;
        if (missingRequired.length > 0) {
            setError('Please select all required configuration options.');
            return;
        }

        const params = new URLSearchParams({
            cfg: JSON.stringify(selections),
        });
        navigate(`/checkout/product/${product.slug}?${params.toString()}`);
    }

    if (isLoading) {
        return (
            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                Loading configuration...
            </div>
        );
    }

    if (!product || error) {
        return (
            <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                {error ?? 'Product not found.'}
            </div>
        );
    }

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h1 className="text-2xl font-semibold">Configure {product.name}</h1>
                    <p className="mt-1 text-sm text-white/70">
                        Choose configuration options before checkout.
                    </p>
                </div>
                <Link
                    to={`/products/${category}/${slug}`}
                    className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
                >
                    Back to Product
                </Link>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                {configurations.length === 0 ? (
                    <p className="text-sm text-white/70">
                        No configurable options for this product.
                    </p>
                ) : (
                    configurations.map((configuration) => {
                        const selectedValue = selections[configuration.key] ?? '';

                        return (
                            <div key={configuration.id} className="space-y-2">
                                <label className="block text-sm font-medium">
                                    {configuration.name}{' '}
                                    {configuration.required ? (
                                        <span className="text-rose-300">*</span>
                                    ) : null}
                                </label>

                                {configuration.input_type === 'buttons' ? (
                                    <div className="flex flex-wrap gap-2">
                                        {configuration.options.map((option) => (
                                            <button
                                                key={option.id}
                                                type="button"
                                                onClick={() =>
                                                    updateSelection(
                                                        configuration.key,
                                                        option.value,
                                                    )
                                                }
                                                className={[
                                                    'rounded-lg border px-3 py-2 text-sm font-medium transition',
                                                    selectedValue === option.value
                                                        ? 'border-[var(--panel-primary)] bg-[var(--panel-primary)]/20 text-white'
                                                        : 'border-white/20 bg-transparent text-white/80 hover:bg-white/10',
                                                ].join(' ')}
                                            >
                                                {option.label}
                                                {option.price_modifier
                                                    ? ` (${option.price_modifier > 0 ? '+' : ''}${formatCurrency(option.price_modifier)})`
                                                    : ''}
                                            </button>
                                        ))}
                                    </div>
                                ) : (
                                    <select
                                        value={selectedValue}
                                        onChange={(event) =>
                                            updateSelection(
                                                configuration.key,
                                                event.target.value,
                                            )
                                        }
                                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                                    >
                                        <option value="">
                                            {configuration.required
                                                ? 'Select an option'
                                                : 'None'}
                                        </option>
                                        {configuration.options.map((option) => (
                                            <option key={option.id} value={option.value}>
                                                {option.label}
                                                {option.price_modifier
                                                    ? ` (${option.price_modifier > 0 ? '+' : ''}${formatCurrency(option.price_modifier)})`
                                                    : ''}
                                            </option>
                                        ))}
                                    </select>
                                )}
                            </div>
                        );
                    })
                )}
            </div>

            <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm">
                <h2 className="text-lg font-semibold">Price Preview</h2>
                <div className="mt-4 space-y-2 text-sm">
                    <div className="flex justify-between">
                        <span className="text-white/70">Monthly price</span>
                        <span>{formatCurrency(product.price_monthly)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">Setup fee</span>
                        <span>{formatCurrency(product.setup_fee ?? 0)}</span>
                    </div>
                    <div className="flex justify-between">
                        <span className="text-white/70">Configuration modifiers</span>
                        <span>{formatCurrency(modifierTotal)}</span>
                    </div>
                    <div className="flex justify-between border-t border-white/10 pt-2 font-semibold">
                        <span>First month total</span>
                        <span>{formatCurrency(total)}</span>
                    </div>
                </div>
            </div>

            <button
                type="button"
                onClick={handleContinue}
                disabled={missingRequired.length > 0}
                className="rounded-lg bg-[var(--panel-primary)] px-5 py-2.5 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
            >
                Continue to Checkout
            </button>
        </section>
    );
}
