import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import {
    formatCurrency,
    getClientProductBySlug,
    listProductConfigurationsBySlug,
} from '@/lib/products-api';
import type { ProductConfiguration } from '@/types/product-configuration';
import type { Product } from '@/types/product';
import {
    Settings,
    ChevronRight,
    ArrowLeft,
    CheckCircle2,
    CreditCard,
    Sparkles,
    Cpu,
    HardDrive,
    Zap,
    ShieldCheck
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

function trialLabel(product: Product): string | null {
    if (!product.trial_enabled || !product.trial_interval || !product.trial_period) {
        return null;
    }

    const interval = product.trial_interval;
    const period = product.trial_period;
    const label = interval === 1 ? period : `${interval} ${period}s`;

    return `Free ${label} trial`;
}

const requiredPterodactylConfigurations = {
    ram: { label: 'RAM' },
    disk: { label: 'Disk' },
    cpu: { label: 'CPU' },
    egg: { label: 'Egg' },
} as const;
const requiredPterodactylKeys = Object.keys(requiredPterodactylConfigurations);

function buildDefaultSelections(
    configurations: ProductConfiguration[],
): Record<string, string> {
    const selections: Record<string, string> = {};

    configurations.forEach((configuration) => {
        const options = Array.isArray(configuration.options) ? configuration.options : [];
        const defaultOption = options.find((option) => option.is_default);
        if (defaultOption) {
            selections[configuration.key] = defaultOption.value;
        }
    });

    return selections;
}

export function ProductConfigurePage() {
    const navigate = useNavigate();
    const { category = '', slug = '' } = useParams<{
        category: string;
        slug: string;
    }>();
    const [product, setProduct] = useState<Product | null>(null);
    const [configurations, setConfigurations] = useState<ProductConfiguration[]>([]);
    const [selections, setSelections] = useState<Record<string, string>>({});
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadData() {
            if (!slug) {
                setError('Missing product slug.');
                setIsLoading(false);
                return;
            }

            try {
                const [productData, configurationData] = await Promise.all([
                    getClientProductBySlug(slug),
                    listProductConfigurationsBySlug(slug),
                ]);
                setProduct(productData);
                setConfigurations(configurationData);
                setSelections(buildDefaultSelections(configurationData));
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load configuration options.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadData();
    }, [slug]);

    const baseTotal = (product?.price_monthly ?? 0) + (product?.setup_fee ?? 0);
    const modifierTotal = useMemo(
        () =>
            configurations.reduce((sum, configuration) => {
                const selectedValue = selections[configuration.key];
                if (!selectedValue) return sum;

                const options = Array.isArray(configuration.options)
                    ? configuration.options
                    : [];
                const option = options.find(
                    (item) => item.value === selectedValue,
                );

                return sum + (option?.price_modifier ?? 0);
            }, 0),
        [configurations, selections],
    );
    const total = baseTotal + modifierTotal;
    const trialAvailable = Boolean(
        product?.trial_enabled && product?.trial_interval && product?.trial_period,
    );
    const dueToday = trialAvailable ? 0 : total;
    const isPterodactylProduct = product?.infrastructure_type === 'pterodactyl';
    const missingPterodactylKeys = isPterodactylProduct
        ? requiredPterodactylKeys.filter(
            (key) => !configurations.some((configuration) => configuration.key === key),
        )
        : [];

    const missingRequired = configurations
        .filter((configuration) => configuration.required && !selections[configuration.key])
        .map((configuration) => configuration.name);
    const missingRequiredContractSelections = isPterodactylProduct
        ? requiredPterodactylKeys.filter((key) => !selections[key])
        : [];

    function updateSelection(configurationKey: string, value: string) {
        setSelections((current) => ({
            ...current,
            [configurationKey]: value,
        }));
    }

    function handleContinue() {
        if (!product) return;
        if (missingPterodactylKeys.length > 0) {
            setError('This Pterodactyl product is missing required RAM/Disk/CPU/Egg configurations. Please contact support.');
            return;
        }

        if (missingRequired.length > 0 || missingRequiredContractSelections.length > 0) {
            setError('Please select all required configuration options.');
            return;
        }

        const params = new URLSearchParams({
            cfg: JSON.stringify(selections),
        });
        navigate(`/checkout/product/${product.slug}?${params.toString()}`);
    }

    if (isLoading) {
        return (
            <div className="max-w-6xl mx-auto py-12 animate-pulse space-y-8">
                <div className="h-6 w-32 rounded bg-white/5" />
                <div className="h-48 rounded-3xl bg-white/5" />
            </div>
        );
    }

    if (!product || error) {
        return (
            <div className="max-w-xl mx-auto py-32 text-center">
                <div className="inline-flex size-20 items-center justify-center rounded-full bg-rose-500/10 text-rose-400 mb-6 font-bold text-3xl">!</div>
                <h3 className="text-2xl font-bold text-warm-white">Configuration Error</h3>
                <p className="mt-2 text-warm-muted">{error ?? 'This specific request could not be completed.'}</p>
                <Link to="/products" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 link-arrow">
                    Reset progress <span>&rarr;</span>
                </Link>
            </div>
        );
    }

    const trial = trialLabel(product);

    return (
        <div className="max-w-6xl mx-auto space-y-12 py-4">
            <header>
                <Link
                    to={`/products/${category}/${slug}`}
                    className="group mb-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 hover:text-accent-300 transition-colors"
                >
                    <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                    Back to Overview
                </Link>

                <div className="relative overflow-hidden rounded-[2.5rem] border border-white/8 bg-[var(--panel-surface)] p-12 shadow-2xl">
                    <div className="absolute right-0 top-0 h-full w-1/4 bg-gradient-to-l from-accent-500/10 to-transparent" />
                    <div className="relative z-10">
                        <div className="flex items-center gap-2 mb-4">
                            <Settings className="size-4 text-accent-400" />
                            <span className="text-[10px] font-black uppercase tracking-widest text-warm-muted/40">Configuration</span>
                        </div>
                        <h2 className="text-4xl font-black tracking-tight text-warm-white sm:text-6xl">Customize {product.name}</h2>
                        <p className="mt-6 max-w-2xl text-lg leading-relaxed text-warm-muted">
                            Fine-tune your hardware specifications and software environment to perfectly match your project requirements.
                        </p>
                    </div>
                </div>
            </header>

            <section className="grid gap-12 lg:grid-cols-5">
                <div className="lg:col-span-3 space-y-10">
                    <div className="space-y-10">
                        {configurations.length === 0 ? (
                            <div className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-12 text-center">
                                <Sparkles className="mx-auto mb-4 size-10 text-accent-400" />
                                <h3 className="text-lg font-bold text-warm-white">Perfectly Optimized</h3>
                                <p className="mt-2 text-warm-muted">This product comes pre-configured for maximum performance. No further steps required!</p>
                            </div>
                        ) : (
                            configurations.map((configuration) => {
                                const selectedValue = selections[configuration.key] ?? '';

                                return (
                                    <div key={configuration.id} className="space-y-6">
                                        <div className="flex items-center gap-3">
                                            <div className="flex size-8 items-center justify-center rounded-lg bg-accent-500/10 text-accent-400 font-black text-xs">
                                                {configuration.key === 'ram' ? <Zap className="size-4" /> : configuration.key === 'disk' ? <HardDrive className="size-4" /> : <Cpu className="size-4" />}
                                            </div>
                                            <label className="text-lg font-black tracking-tight text-warm-white flex items-center gap-2">
                                                {configuration.name}
                                                {configuration.required && <span className="text-accent-500">*</span>}
                                            </label>
                                        </div>

                                        {configuration.input_type === 'buttons' ? (
                                            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                                {(Array.isArray(configuration.options) ? configuration.options : []).map((option) => (
                                                    <button
                                                        key={option.id}
                                                        type="button"
                                                        onClick={() => updateSelection(configuration.key, option.value)}
                                                        className={cn(
                                                            "group relative p-4 rounded-2xl border transition-all text-left",
                                                            selectedValue === option.value
                                                                ? "bg-accent-500/10 border-accent-500/40 text-warm-white"
                                                                : "bg-white/2 border-white/5 text-warm-muted hover:border-white/20 hover:bg-white/5"
                                                        )}
                                                    >
                                                        <div className="flex items-center justify-between mb-1">
                                                            <span className="text-sm font-bold uppercase tracking-widest">{option.label}</span>
                                                            {selectedValue === option.value && <CheckCircle2 className="size-4 text-accent-400" />}
                                                        </div>
                                                        {(option.price_modifier ?? 0) !== 0 && (
                                                            <p className="text-[10px] font-black text-accent-500/80">
                                                                {(option.price_modifier ?? 0) > 0 ? '+' : ''}{formatCurrency(option.price_modifier ?? 0)}
                                                            </p>
                                                        )}
                                                    </button>
                                                ))}
                                            </div>
                                        ) : (
                                            <select
                                                value={selectedValue}
                                                onChange={(e) => updateSelection(configuration.key, e.target.value)}
                                                className="w-full rounded-2xl border border-white/10 bg-white/5 p-4 text-sm font-bold text-warm-white focus:border-accent-500/50 focus:outline-none transition-all"
                                            >
                                                <option value="" className="bg-[var(--panel-surface)] text-warm-muted">
                                                    {configuration.required ? 'Choose your option' : 'Skip configuration'}
                                                </option>
                                                {(Array.isArray(configuration.options) ? configuration.options : []).map((option) => (
                                                    <option key={option.id} value={option.value} className="bg-[var(--panel-surface)] text-warm-white">
                                                        {option.label} {option.price_modifier ? `(${option.price_modifier > 0 ? '+' : ''}${formatCurrency(option.price_modifier)})` : ''}
                                                    </option>
                                                ))}
                                            </select>
                                        )}
                                    </div>
                                );
                            })
                        )}
                    </div>
                </div>

                <div className="lg:col-span-2 space-y-8">
                    <article className="sticky top-8 rounded-[2.5rem] border border-accent-500/30 bg-accent-600/5 p-10 shadow-2xl backdrop-blur-sm relative overflow-hidden">
                        <div className="absolute -right-20 -top-20 size-64 rounded-full bg-accent-500/10 blur-3xl" />
                        <h3 className="text-lg font-bold text-warm-white tracking-tight flex items-center gap-2">
                            <CreditCard className="size-5 text-accent-400" />
                            Price Preview
                        </h3>

                        <div className="mt-8 space-y-6">
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-warm-muted">Billing Cycle</span>
                                <span className="text-sm font-bold text-warm-white uppercase tracking-widest">{product.billing_summary}</span>
                            </div>
                            {trial ? (
                                <div className="flex items-center justify-between">
                                    <span className="text-sm text-warm-muted">Trial</span>
                                    <span className="rounded-full bg-emerald-500/10 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-emerald-300">
                                        {trial}
                                    </span>
                                </div>
                            ) : null}
                            <div className="flex items-center justify-between">
                                <span className="text-sm text-warm-muted">Base Hardware</span>
                                <span className="text-sm font-bold text-warm-white">{formatCurrency(product.price_monthly)}</span>
                            </div>
                            {modifierTotal !== 0 && (
                                <div className="flex items-center justify-between">
                                    <span className="text-sm text-warm-muted">Addons</span>
                                    <span className="text-sm font-bold text-accent-500">+{formatCurrency(modifierTotal)}</span>
                                </div>
                            )}
                            <div className="flex items-center justify-between border-b border-white/5 pb-6">
                                <span className="text-sm text-warm-muted">Total Due Today</span>
                                <div className="text-right">
                                    <span className="text-3xl font-black text-warm-white">
                                        {formatCurrency(dueToday)}
                                    </span>
                                </div>
                            </div>

                            <div className="pt-8">
                                <button
                                    type="button"
                                    onClick={handleContinue}
                                    disabled={missingRequired.length > 0 || missingRequiredContractSelections.length > 0 || missingPterodactylKeys.length > 0}
                                    className="btn-glow flex w-full items-center justify-center gap-3 rounded-2xl bg-primary py-5 text-lg font-black uppercase tracking-widest text-white transition-all hover:bg-accent-500 active:scale-95 shadow-xl disabled:opacity-50 disabled:grayscale disabled:cursor-not-allowed"
                                >
                                    Proceed to Payment
                                    <ChevronRight className="size-5" />
                                </button>
                                <div className="mt-6 flex items-center gap-3 justify-center text-[10px] font-black uppercase tracking-widest text-warm-muted/60">
                                    <ShieldCheck className="size-4 text-emerald-500" />
                                    Secure Checkout
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            </section>
        </div>
    );
}
