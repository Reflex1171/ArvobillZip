import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
    formatCurrency,
    listCategories,
    listClientProducts,
    listClientProductsByCategory,
} from '@/lib/products-api';
import type { ProductCategory } from '@/types/category';
import type { Product } from '@/types/product';
import {
    Sparkles,
    Layers,
    Box,
    Zap,
    Globe,
    Server,
    Shield,
    Activity,
    ChevronRight,
    BoxSelect,
    Cpu,
    HardDrive,
    ArrowRight
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

function ProductCard({ product }: { product: Product }) {
    const categorySlug = product.category?.slug ?? 'category';

    return (
        <article className="card-lift group relative overflow-hidden rounded-[2rem] border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm transition-all hover:border-white/20">
            <div className="absolute -right-4 -top-4 size-32 rounded-full bg-accent-500/5 blur-3xl transition-colors group-hover:bg-accent-500/10" />

            <div className="relative mb-6 flex items-center justify-between">
                <div className="flex size-12 items-center justify-center rounded-2xl bg-white/5 text-warm-muted transition-colors group-hover:bg-accent-500/10 group-hover:text-accent-400">
                    <Box className="size-6" />
                </div>
                {product.category ? (
                    <span className="rounded-full bg-accent-500/10 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-accent-400">
                        {product.category.name}
                    </span>
                ) : null}
            </div>

            <h3 className="mb-2 text-xl font-black tracking-tight text-warm-white transition-colors group-hover:text-accent-400">
                {product.name}
            </h3>
            <p className="mb-8 line-clamp-3 text-sm leading-relaxed text-warm-muted/60">
                {product.description}
            </p>

            <div className="mb-8 flex items-end gap-1">
                <span className="text-3xl font-black tracking-tighter text-warm-white">
                    {formatCurrency(product.price_monthly)}
                </span>
                <span className="mb-1 text-sm font-bold text-warm-muted/40 italic">
                    / {product.billing_type === 'one_time'
                        ? 'forever'
                        : (product.billing_cycle || 'monthly').toLowerCase()}
                </span>
            </div>

            <Link
                to={`/products/${categorySlug}/${product.slug}`}
                className="btn-glow flex w-full items-center justify-center gap-2 rounded-2xl bg-white/5 py-4 text-sm font-black uppercase tracking-widest text-warm-white transition-all hover:bg-accent-500 hover:text-white"
            >
                Configure Spec
                <ArrowRight className="size-4" />
            </Link>
        </article>
    );
}

function CategorySkeleton() {
    return (
        <div className="space-y-2">
            {[1, 2, 3, 4, 5].map((i) => (
                <div key={i} className="h-10 w-full rounded-xl bg-white/5 animate-pulse" />
            ))}
        </div>
    );
}

export function ProductsPage() {
    const { category } = useParams<{ category: string }>();
    const [categories, setCategories] = useState<ProductCategory[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadData() {
            try {
                setIsLoading(true);
                const [categoriesData, productsData] = await Promise.all([
                    listCategories(),
                    category
                        ? listClientProductsByCategory(category)
                        : listClientProducts(),
                ]);
                setCategories(categoriesData);
                setProducts(productsData);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load product catalogue.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadData();
    }, [category]);

    const heading = useMemo(() => {
        if (!category) {
            return 'Every Resource.';
        }

        const currentCategory = categories.find((item) => item.slug === category);

        return currentCategory ? `${currentCategory.name}.` : 'Products.';
    }, [category, categories]);

    return (
        <div className="max-w-7xl mx-auto py-8">
            <header className="mb-16 space-y-4">
                <div className="flex items-center gap-3">
                    <Sparkles className="size-5 text-accent-400" />
                    <span className="text-sm font-bold uppercase tracking-widest text-warm-muted/40">Marketplace</span>
                </div>
                <h1 className="text-5xl font-black tracking-tighter text-warm-white sm:text-6xl">
                    {heading}
                    <span className="block text-accent-500">Unleashed.</span>
                </h1>
                <p className="max-w-2xl text-lg text-warm-muted leading-relaxed">
                    Deploy world-class infrastructure in seconds. From high-performance game servers to scalable cloud compute, choose the foundation for your next project.
                </p>
            </header>

            <div className="grid gap-12 lg:grid-cols-[280px_1fr]">
                <aside className="space-y-10">
                    <div className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-6 shadow-sm">
                        <h2 className="mb-6 flex items-center gap-2 text-[10px] font-black uppercase tracking-widest text-warm-muted/40">
                            <Layers className="size-4" />
                            Categories
                        </h2>
                        <nav className="space-y-2">
                            <Link
                                to="/products"
                                className={cn(
                                    'flex items-center justify-between rounded-xl px-4 py-3 text-sm font-bold transition-all group',
                                    !category
                                        ? 'bg-accent-500 text-white shadow-lg shadow-accent-500/20'
                                        : 'text-warm-muted hover:bg-white/5 hover:text-warm-white'
                                )}
                            >
                                <span>All Products</span>
                                {!category && <ChevronRight className="size-4" />}
                            </Link>
                            {isLoading && categories.length === 0 ? <CategorySkeleton /> : (
                                categories.map((item) => (
                                    <Link
                                        key={item.id}
                                        to={`/products/${item.slug}`}
                                        className={cn(
                                            'flex items-center justify-between rounded-xl px-4 py-3 text-sm font-bold transition-all group',
                                            category === item.slug
                                                ? 'bg-accent-500 text-white shadow-lg shadow-accent-500/20'
                                                : 'text-warm-muted hover:bg-white/5 hover:text-warm-white'
                                        )}
                                    >
                                        <span>{item.name}</span>
                                        {category === item.slug && <ChevronRight className="size-4" />}
                                    </Link>
                                ))
                            )}
                        </nav>
                    </div>

                    <div className="rounded-3xl border border-accent-500/10 bg-accent-500/5 p-6 text-center">
                        <div className="mx-auto mb-4 flex size-12 items-center justify-center rounded-2xl bg-accent-500/10 text-accent-400">
                            <Shield className="size-6" />
                        </div>
                        <h4 className="mb-2 text-sm font-black text-warm-white">Premium Support</h4>
                        <p className="text-xs text-warm-muted leading-relaxed">All products include our flagship 24/7 technical assistance.</p>
                    </div>
                </aside>

                <section className="space-y-8">
                    {error ? (
                        <div className="rounded-3xl border border-rose-500/20 bg-rose-500/5 p-8 flex items-center gap-4 text-rose-400">
                            <Activity className="size-6 shrink-0" />
                            <p className="text-sm font-bold">{error}</p>
                        </div>
                    ) : null}

                    {isLoading ? (
                        <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                            {[1, 2, 3, 4, 5, 6].map((i) => (
                                <div key={i} className="h-64 rounded-3xl bg-white/5 animate-pulse" />
                            ))}
                        </div>
                    ) : (
                        products.length > 0 ? (
                            <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
                                {products.map((product) => (
                                    <ProductCard key={product.id} product={product} />
                                ))}
                            </div>
                        ) : (
                            <div className="flex flex-col items-center justify-center rounded-[3rem] border border-dashed border-white/10 bg-white/2 p-20 text-center">
                                <div className="mb-6 flex size-20 items-center justify-center rounded-full bg-white/5 text-warm-muted">
                                    <BoxSelect className="size-10" />
                                </div>
                                <h3 className="text-xl font-bold text-warm-white">No Instances Found</h3>
                                <p className="mt-2 text-warm-muted">This category is currently being stocked. Check back soon!</p>
                            </div>
                        )
                    )}
                </section>
            </div>
        </div>
    );
}

