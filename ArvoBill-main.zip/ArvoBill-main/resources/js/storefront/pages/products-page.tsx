import { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
    formatCurrency,
    listCategories,
    listClientProducts,
    listClientProductsByCategory,
} from '@/lib/products-api';
import type { ProductCategory } from '@/types/category';
import type { Product } from '@/types/product';

function ProductCard({ product }: { product: Product }) {
    const categorySlug = product.category?.slug ?? 'category';

    return (
        <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
            <div className="mb-3 flex items-center justify-between gap-3">
                <h3 className="text-lg font-semibold">{product.name}</h3>
                {product.category ? (
                    <span className="rounded-full bg-cyan-100 px-2.5 py-1 text-xs font-semibold uppercase tracking-wide text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-300">
                        {product.category.name}
                    </span>
                ) : null}
            </div>
            <p className="mb-4 line-clamp-3 text-sm text-white/70">
                {product.description}
            </p>
            <p className="mb-4 text-2xl font-semibold">
                {formatCurrency(product.price_monthly)}
                <span className="text-sm font-medium text-white/70">
                    {' '}
                    {product.billing_type === 'one_time'
                        ? 'one-time'
                        : (product.billing_cycle || 'monthly').toLowerCase()}
                </span>
            </p>
            <Link
                to={`/products/${categorySlug}/${product.slug}`}
                className="inline-flex w-full justify-center rounded-lg bg-cyan-600 px-4 py-2.5 text-sm font-semibold text-white hover:bg-cyan-700"
            >
                Configure / Order
            </Link>
        </article>
    );
}

export function ProductsPage() {
    const { category } = useParams<{ category: string }>();
    const [categories, setCategories] = useState<ProductCategory[]>([]);
    const [products, setProducts] = useState<Product[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadData() {
            try {
                const [categoriesData, productsData] = await Promise.all([
                    listCategories(),
                    category
                        ? listClientProductsByCategory(category)
                        : listClientProducts(),
                ]);
                setCategories(categoriesData);
                setProducts(productsData);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load product catalogue.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadData();
    }, [category]);

    const heading = useMemo(() => {
        if (!category) {
            return 'All Products';
        }

        const currentCategory = categories.find((item) => item.slug === category);

        return currentCategory?.name ?? 'Products';
    }, [category, categories]);

    return (
        <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
            <aside className="h-fit rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4 shadow-sm">
                <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-white/70">
                    Categories
                </h2>
                <nav className="space-y-1">
                    <Link
                        to="/products"
                        className={[
                            'block rounded-lg px-3 py-2 text-sm font-medium',
                            !category
                                ? 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-200'
                                : 'text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800',
                        ].join(' ')}
                    >
                        All Products
                    </Link>
                    {categories.map((item) => (
                        <Link
                            key={item.id}
                            to={`/products/${item.slug}`}
                            className={[
                                'block rounded-lg px-3 py-2 text-sm font-medium',
                                category === item.slug
                                    ? 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900/40 dark:text-cyan-200'
                                    : 'text-white/80 hover:bg-white/10',
                            ].join(' ')}
                        >
                            {item.name}
                        </Link>
                    ))}
                </nav>
            </aside>

            <section className="space-y-5">
                <div>
                    <h1 className="text-2xl font-semibold">{heading}</h1>
                    <p className="mt-1 text-sm text-white/70">
                        Browse hosting products and continue to checkout when ready.
                    </p>
                </div>

                {isLoading ? (
                    <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                        Loading products...
                    </div>
                ) : null}

                {error ? (
                    <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                        {error}
                    </div>
                ) : null}

                {!isLoading && !error ? (
                    products.length > 0 ? (
                        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
                            {products.map((product) => (
                                <ProductCard key={product.id} product={product} />
                            ))}
                        </div>
                    ) : (
                        <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70">
                            No active products found in this category.
                        </div>
                    )
                ) : null}
            </section>
        </div>
    );
}
