export type DashboardStat = {
    label: string;
    value: string;
    detail: string;
};

export type ServiceRow = {
    name: string;
    status: 'Active' | 'Pending' | 'Suspended';
    nextDue: string;
    plan: string;
};

export type InvoiceRow = {
    invoiceNumber: string;
    date: string;
    amount: string;
    status: 'Paid' | 'Unpaid' | 'Overdue';
};

export type ActivityItem = {
    text: string;
    timestamp: string;
};

export const dashboardStats: DashboardStat[] = [
    {
        label: 'Active Services',
        value: '6',
        detail: '2 services renewed this month',
    },
    {
        label: 'Open Tickets',
        value: '3',
        detail: '1 awaiting your response',
    },
    {
        label: 'Outstanding Balance',
        value: '$124.00',
        detail: 'Due in the next 7 days',
    },
    {
        label: 'Next Invoice Due',
        value: 'Feb 18, 2026',
        detail: 'Invoice #INV-2026-0187',
    },
];

export const serviceRows: ServiceRow[] = [
    {
        name: 'Cloud VPS - us-east-1',
        status: 'Active',
        nextDue: 'Feb 18, 2026',
        plan: 'VPS Pro 4 GB',
    },
    {
        name: 'Shared Hosting - arvostudio.io',
        status: 'Active',
        nextDue: 'Mar 02, 2026',
        plan: 'Business Shared',
    },
    {
        name: 'Domain - arvostudio.io',
        status: 'Pending',
        nextDue: 'Aug 14, 2026',
        plan: 'Domain Registration',
    },
];

export const invoiceRows: InvoiceRow[] = [
    {
        invoiceNumber: 'INV-2026-0187',
        date: 'Feb 04, 2026',
        amount: '$64.00',
        status: 'Unpaid',
    },
    {
        invoiceNumber: 'INV-2026-0149',
        date: 'Jan 19, 2026',
        amount: '$29.00',
        status: 'Paid',
    },
    {
        invoiceNumber: 'INV-2026-0105',
        date: 'Jan 03, 2026',
        amount: '$31.00',
        status: 'Paid',
    },
];

export const recentActivity: ActivityItem[] = [
    {
        text: 'Support ticket #7012 was updated by Billing Team.',
        timestamp: '2 hours ago',
    },
    {
        text: 'Invoice INV-2026-0187 was generated.',
        timestamp: '1 day ago',
    },
    {
        text: 'Service Cloud VPS - us-east-1 was provisioned.',
        timestamp: '3 days ago',
    },
    {
        text: 'DNS records updated for arvostudio.io.',
        timestamp: '5 days ago',
    },
];
