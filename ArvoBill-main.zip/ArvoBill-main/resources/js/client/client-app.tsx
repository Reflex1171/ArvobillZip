import { useEffect } from 'react';
import { Navigate, Route, Routes } from 'react-router-dom';
import { ClientLayout } from './layout/client-layout';
import { CheckoutPlaceholderPage } from './pages/checkout-placeholder-page';
import { DashboardPage } from './pages/dashboard-page';
import { AccountPage } from './pages/account-page';
import { BillingPage } from './pages/billing-page';
import { InvoiceDetailPage } from './pages/invoice-detail-page';
import { InvoicesPage } from './pages/invoices-page';
import { NewTicketPage } from './pages/new-ticket-page';
import { OrdersPage } from './pages/orders-page';
import { ServiceDetailPage } from './pages/service-detail-page';
import { ServicesPage } from './pages/services-page';
import { SupportPage } from './pages/support-page';
import { TicketDetailPage } from './pages/ticket-detail-page';

function HardRedirect({ to }: { to: string }) {
    useEffect(() => {
        window.location.assign(to);
    }, [to]);

    return null;
}

export function ClientApp() {
    return (
        <Routes>
            <Route element={<ClientLayout />}>
                <Route path="/client/dashboard" element={<DashboardPage />} />
                <Route path="/client/products" element={<HardRedirect to="/products" />} />
                <Route path="/client/products/:slug" element={<HardRedirect to="/products" />} />
                <Route
                    path="/client/checkout/:slug"
                    element={<CheckoutPlaceholderPage />}
                />
                <Route
                    path="/client/services"
                    element={<ServicesPage />}
                />
                <Route path="/client/services/:id" element={<ServiceDetailPage />} />
                <Route
                    path="/client/orders"
                    element={<OrdersPage />}
                />
                <Route
                    path="/client/billing"
                    element={<BillingPage />}
                />
                <Route
                    path="/client/invoices"
                    element={<InvoicesPage />}
                />
                <Route path="/client/invoices/:id" element={<InvoiceDetailPage />} />
                <Route
                    path="/client/support"
                    element={<SupportPage />}
                />
                <Route path="/client/support/new" element={<NewTicketPage />} />
                <Route path="/client/support/:id" element={<TicketDetailPage />} />
                <Route path="/client/account" element={<AccountPage />} />
                <Route path="/client/settings" element={<Navigate to="/client/account" replace />} />
            </Route>
            <Route path="/client" element={<Navigate to="/client/dashboard" replace />} />
            <Route path="*" element={<Navigate to="/client/dashboard" replace />} />
        </Routes>
    );
}
