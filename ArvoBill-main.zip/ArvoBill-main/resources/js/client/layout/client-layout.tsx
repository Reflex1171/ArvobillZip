import {
    Boxes,
    CreditCard,
    FileText,
    Gauge,
    Headset,
    Receipt,
    Server,
    Settings,
    ShieldCheck,
    ShoppingCart,
} from 'lucide-react';
import type { LucideIcon } from 'lucide-react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { canAccessAdmin, useMe } from '@/hooks/use-me';
import { useTheme } from '@/contexts/theme-context';

type NavigationItem = {
    label: string;
    to: string;
    icon: LucideIcon;
};

const navigation: NavigationItem[] = [
    { label: 'Dashboard', to: '/client/dashboard', icon: Gauge },
    { label: 'Products', to: '/client/products', icon: Boxes },
    { label: 'Services', to: '/client/services', icon: Server },
    { label: 'Orders', to: '/client/orders', icon: ShoppingCart },
    { label: 'Billing', to: '/client/billing', icon: CreditCard },
    { label: 'Invoices', to: '/client/invoices', icon: Receipt },
    { label: 'Support', to: '/client/support', icon: Headset },
    { label: 'Account Settings', to: '/client/account', icon: Settings },
];

function getClientUser() {
    const mountNode = document.getElementById('client-app');

    return {
        name: mountNode?.dataset.userName ?? 'Client User',
        email: mountNode?.dataset.userEmail ?? 'client@example.com',
        csrfToken:
            document
                .querySelector('meta[name="csrf-token"]')
                ?.getAttribute('content') ?? '',
    };
}

export function ClientLayout() {
    const location = useLocation();
    const fallbackUser = getClientUser();
    const { me } = useMe();
    const { theme } = useTheme();
    const canViewAdmin = canAccessAdmin(me?.role);
    const user = {
        name: me?.name ?? fallbackUser.name,
        email: me?.email ?? fallbackUser.email,
        csrfToken: fallbackUser.csrfToken,
    };

    const currentTitle =
        navigation.find((item) => location.pathname.startsWith(item.to))?.label ??
        'Dashboard';

    return (
        <div className="min-h-screen bg-[var(--panel-bg)] text-[var(--panel-text)]">
            <aside className="fixed inset-y-0 left-0 hidden w-72 border-r border-white/10 bg-[var(--panel-surface)] px-5 py-6 backdrop-blur lg:block">
                <div className="mb-8 px-2">
                    {theme.logo_url ? (
                        <img src={theme.logo_url} alt={`${theme.brand_name} logo`} className="h-14 w-auto object-contain object-left" />
                    ) : (
                        <div className="flex items-center gap-2 rounded-md bg-[var(--panel-primary)] p-2 text-white">
                            <FileText className="size-5" />
                            <span className="text-sm font-semibold">{theme.brand_name}</span>
                        </div>
                    )}
                </div>

                <nav className="space-y-1">
                    {navigation.map((item) => {
                        const Icon = item.icon;

                        return (
                            <NavLink
                                key={item.to}
                                to={item.to}
                                className={({ isActive }) =>
                                    [
                                        'flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors',
                                        isActive
                                            ? 'bg-[var(--panel-primary)] text-white'
                                            : 'text-white/80 hover:bg-[var(--panel-secondary)] hover:text-white',
                                    ].join(' ')
                                }
                            >
                                <Icon className="size-4" />
                                <span>{item.label}</span>
                            </NavLink>
                        );
                    })}
                </nav>

                {canViewAdmin ? (
                    <div className="mt-6 border-t border-white/10 pt-4">
                        <a
                            href="/admin/dashboard"
                            className="flex items-center gap-3 rounded-lg bg-[var(--panel-accent)] px-3 py-2 text-sm font-medium text-white transition hover:brightness-110"
                        >
                            <ShieldCheck className="size-4" />
                            <span>Admin Area</span>
                        </a>
                    </div>
                ) : null}
            </aside>

            <div className="lg:pl-72">
                <header className="sticky top-0 z-20 border-b border-white/10 bg-[var(--panel-surface)]/90 backdrop-blur">
                    <div className="flex h-16 items-center justify-between px-4 sm:px-6 lg:px-8">
                        <div>
                            <p className="text-xs uppercase tracking-[0.18em] text-white/60">
                                Client Area
                            </p>
                            <h1 className="text-lg font-semibold">
                                {currentTitle}
                            </h1>
                        </div>

                        <div className="flex items-center gap-4">
                            <div className="text-right">
                                <p className="text-sm font-medium">
                                    {user.name}
                                </p>
                                <p className="hidden text-xs text-white/70 sm:block">
                                    {user.email}
                                </p>
                            </div>
                            <form method="POST" action="/logout">
                                <input
                                    type="hidden"
                                    name="_token"
                                    value={user.csrfToken}
                                />
                                <button
                                    type="submit"
                                    className="rounded-lg border border-white/25 px-3 py-2 text-sm font-medium transition hover:bg-white/10"
                                >
                                    Logout
                                </button>
                            </form>
                        </div>
                    </div>

                    <div className="border-t border-white/10 px-4 py-3 lg:hidden">
                        <div className="flex gap-2 overflow-x-auto pb-1">
                            {navigation.map((item) => (
                                <NavLink
                                    key={item.to}
                                    to={item.to}
                                    className={({ isActive }) =>
                                        [
                                            'whitespace-nowrap rounded-full px-3 py-1.5 text-xs font-semibold',
                                            isActive
                                                ? 'bg-[var(--panel-primary)] text-white'
                                                : 'bg-white/10 text-white/85',
                                        ].join(' ')
                                    }
                                >
                                    {item.label}
                                </NavLink>
                            ))}
                            {canViewAdmin ? (
                                <a
                                    href="/admin/dashboard"
                                    className="whitespace-nowrap rounded-full bg-[var(--panel-accent)] px-3 py-1.5 text-xs font-semibold text-white"
                                >
                                    Admin Area
                                </a>
                            ) : null}
                        </div>
                    </div>
                </header>

                <main className="px-4 py-6 sm:px-6 lg:px-8">
                    <Outlet />
                </main>
            </div>
        </div>
    );
}
