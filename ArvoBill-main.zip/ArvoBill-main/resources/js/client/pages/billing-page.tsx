import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { CreditCard, ReceiptText, Wallet } from 'lucide-react';
import {
    addFunds,
    createClientPaymentMethod,
    formatCurrency,
    getClientBillingData,
    removeClientPaymentMethod,
    setDefaultClientPaymentMethod,
} from '@/lib/billing-api';
import { StatusBadge } from '@/components/status-badge';
import type {
    ClientBillingPaymentMethod,
    ClientBillingPayload,
} from '@/types/client-billing';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function BillingPage() {
    const [data, setData] = useState<ClientBillingPayload | null>(null);
    const [paymentMethods, setPaymentMethods] = useState<ClientBillingPaymentMethod[]>(
        [],
    );
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isAddFundsOpen, setIsAddFundsOpen] = useState(false);
    const [isSubmittingAddFunds, setIsSubmittingAddFunds] = useState(false);
    const [addFundsAmount, setAddFundsAmount] = useState('10');
    const [addFundsProvider, setAddFundsProvider] = useState<'stripe' | 'paypal'>('stripe');
    const [isSavingMethod, setIsSavingMethod] = useState(false);

    useEffect(() => {
        async function loadBilling() {
            try {
                const billingData = await getClientBillingData();
                setData(billingData);
                setPaymentMethods(billingData.payment_methods);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load billing data.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadBilling();
    }, []);

    async function reloadBillingData() {
        const billingData = await getClientBillingData();
        setData(billingData);
        setPaymentMethods(billingData.payment_methods);
    }

    const currency = data?.summary.currency ?? 'USD';
    const hasOutstanding = (data?.outstanding_invoices.length ?? 0) > 0;
    const transactions = useMemo(
        () => (data?.recent_transactions ?? []).slice(0, 15),
        [data],
    );

    async function handleSetDefault(id: string) {
        try {
            await setDefaultClientPaymentMethod(id);
            await reloadBillingData();
            setError(null);
        } catch (setDefaultError) {
            setError(
                setDefaultError instanceof Error
                    ? setDefaultError.message
                    : 'Failed to update default payment method.',
            );
        }
    }

    async function handleRemoveMethod(id: string) {
        try {
            await removeClientPaymentMethod(id);
            await reloadBillingData();
            setError(null);
        } catch (removeError) {
            setError(
                removeError instanceof Error
                    ? removeError.message
                    : 'Failed to remove payment method.',
            );
        }
    }

    async function handleAddMethod() {
        if (isSavingMethod) return;

        try {
            setIsSavingMethod(true);
            await createClientPaymentMethod({
                provider: 'stripe',
                type: 'card',
                label: 'Card',
                masked_details: '**** 4242',
                provider_reference: null,
                is_default: paymentMethods.length === 0,
            });
            await reloadBillingData();
            setError(null);
        } catch (addMethodError) {
            setError(
                addMethodError instanceof Error
                    ? addMethodError.message
                    : 'Failed to add payment method.',
            );
        } finally {
            setIsSavingMethod(false);
        }
    }

    function handlePayNow(invoiceId: number) {
        window.location.assign(`/checkout/${invoiceId}`);
    }

    async function handleSubmitAddFunds() {
        const parsedAmount = Number(addFundsAmount);
        if (!Number.isFinite(parsedAmount)) {
            setError('Please enter a valid amount.');
            return;
        }

        try {
            setIsSubmittingAddFunds(true);
            setError(null);
            const result = await addFunds(parsedAmount, addFundsProvider);

            if (result.checkout_url) {
                window.location.assign(result.checkout_url);
                return;
            }

            setIsAddFundsOpen(false);
            await reloadBillingData();
        } catch (addFundsError) {
            setError(
                addFundsError instanceof Error
                    ? addFundsError.message
                    : 'Failed to start add-funds payment.',
            );
        } finally {
            setIsSubmittingAddFunds(false);
        }
    }

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Billing</h2>
                <p className="mt-1 text-sm text-white/70">
                    Review account balances, payment methods, and transactions.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <div className="mb-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                        <Wallet className="size-4 text-[var(--panel-primary)]" />
                        <h3 className="text-lg font-semibold">Account Balance</h3>
                    </div>
                    <button
                        type="button"
                        onClick={() => setIsAddFundsOpen(true)}
                        className="rounded-lg bg-[var(--panel-primary)] px-3 py-2 text-sm font-semibold text-white hover:brightness-110"
                    >
                        Add Funds
                    </button>
                </div>

                <div className="grid gap-4 sm:grid-cols-3">
                    <div className="rounded-lg border border-white/10 bg-[var(--panel-bg)] p-4">
                        <p className="text-xs uppercase tracking-wide text-white/60">
                            Current Balance
                        </p>
                        <p className="mt-2 text-2xl font-semibold">
                            {isLoading || !data
                                ? '-'
                                : formatCurrency(data.summary.current_balance, currency)}
                        </p>
                    </div>
                    <div className="rounded-lg border border-white/10 bg-[var(--panel-bg)] p-4">
                        <p className="text-xs uppercase tracking-wide text-white/60">
                            Credit Balance
                        </p>
                        <p className="mt-2 text-2xl font-semibold">
                            {isLoading || !data
                                ? '-'
                                : formatCurrency(data.summary.credit_balance, currency)}
                        </p>
                    </div>
                    <div className="rounded-lg border border-white/10 bg-[var(--panel-bg)] p-4">
                        <p className="text-xs uppercase tracking-wide text-white/60">
                            Outstanding
                        </p>
                        <p className="mt-2 text-2xl font-semibold">
                            {isLoading || !data
                                ? '-'
                                : formatCurrency(data.summary.outstanding_amount, currency)}
                        </p>
                    </div>
                </div>
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <div className="mb-4 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-2">
                        <CreditCard className="size-4 text-[var(--panel-primary)]" />
                        <h3 className="text-lg font-semibold">Payment Methods</h3>
                    </div>
                    <button
                        type="button"
                        onClick={handleAddMethod}
                        disabled={isSavingMethod}
                        className="rounded-lg border border-white/25 px-3 py-2 text-sm font-semibold hover:bg-white/10"
                    >
                        {isSavingMethod ? 'Adding...' : 'Add Payment Method'}
                    </button>
                </div>

                {isLoading ? (
                    <p className="text-sm text-white/70">Loading payment methods...</p>
                ) : paymentMethods.length === 0 ? (
                    <p className="text-sm text-white/70">
                        No payment methods saved yet.
                    </p>
                ) : (
                    <ul className="space-y-3">
                        {paymentMethods.map((method) => (
                            <li
                                key={method.id}
                                className="flex flex-col gap-3 rounded-lg border border-white/10 bg-[var(--panel-bg)] p-4 sm:flex-row sm:items-center sm:justify-between"
                            >
                                <div>
                                    <p className="font-medium">
                                        {method.label}{' '}
                                        <span className="text-white/70">
                                            ({method.masked_details})
                                        </span>
                                    </p>
                                    <p className="text-xs uppercase tracking-wide text-white/60">
                                        {method.provider}
                                        {method.is_default ? ' - Default' : ''}
                                    </p>
                                </div>
                                <div className="flex items-center gap-2">
                                    {!method.is_default ? (
                                        <button
                                            type="button"
                                            onClick={() => handleSetDefault(method.id)}
                                            className="rounded-md border border-white/25 px-2.5 py-1 text-xs font-semibold hover:bg-white/10"
                                        >
                                            Set Default
                                        </button>
                                    ) : null}
                                    <button
                                        type="button"
                                        onClick={() => handleRemoveMethod(method.id)}
                                        className="rounded-md border border-rose-400/40 bg-rose-500/20 px-2.5 py-1 text-xs font-semibold text-rose-100 hover:bg-rose-500/30"
                                    >
                                        Remove
                                    </button>
                                </div>
                            </li>
                        ))}
                    </ul>
                )}
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <div className="mb-4 flex items-center gap-2">
                    <ReceiptText className="size-4 text-[var(--panel-primary)]" />
                    <h3 className="text-lg font-semibold">Outstanding Invoices</h3>
                </div>
                <div className="overflow-x-auto rounded-lg border border-white/10">
                    <table className="min-w-full text-left text-sm">
                        <thead className="bg-white/5 text-white/70">
                            <tr>
                                <th className="px-4 py-3 font-medium">Invoice #</th>
                                <th className="px-4 py-3 font-medium">Date</th>
                                <th className="px-4 py-3 font-medium">Amount</th>
                                <th className="px-4 py-3 font-medium">Status</th>
                                <th className="px-4 py-3 font-medium">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            {isLoading ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={5}>
                                        Loading invoices...
                                    </td>
                                </tr>
                            ) : !hasOutstanding ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={5}>
                                        No outstanding invoices.
                                    </td>
                                </tr>
                            ) : (
                                data?.outstanding_invoices.map((invoice) => (
                                    <tr key={invoice.id} className="border-t border-white/10">
                                        <td className="px-4 py-3 font-medium">#{invoice.id}</td>
                                        <td className="px-4 py-3">
                                            {formatDate(invoice.created_at)}
                                        </td>
                                        <td className="px-4 py-3">
                                            {formatCurrency(invoice.amount, currency)}
                                        </td>
                                        <td className="px-4 py-3">
                                            <StatusBadge status={invoice.status} />
                                        </td>
                                        <td className="px-4 py-3">
                                            {invoice.status === 'unpaid' ? (
                                                <button
                                                    type="button"
                                                    onClick={() => handlePayNow(invoice.id)}
                                                    className="rounded-md bg-[var(--panel-primary)] px-3 py-1.5 text-xs font-semibold text-white hover:brightness-110"
                                                >
                                                    Pay Now
                                                </button>
                                            ) : (
                                                <Link
                                                    to={`/client/invoices/${invoice.id}`}
                                                    className="text-[var(--panel-primary)] hover:underline"
                                                >
                                                    View
                                                </Link>
                                            )}
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="mb-4 text-lg font-semibold">Recent Transactions</h3>
                <div className="overflow-x-auto rounded-lg border border-white/10">
                    <table className="min-w-full text-left text-sm">
                        <thead className="bg-white/5 text-white/70">
                            <tr>
                                <th className="px-4 py-3 font-medium">Date</th>
                                <th className="px-4 py-3 font-medium">Description</th>
                                <th className="px-4 py-3 font-medium">Amount</th>
                                <th className="px-4 py-3 font-medium">Payment Method</th>
                                <th className="px-4 py-3 font-medium">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {isLoading ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={5}>
                                        Loading transactions...
                                    </td>
                                </tr>
                            ) : transactions.length === 0 ? (
                                <tr>
                                    <td className="px-4 py-3 text-white/70" colSpan={5}>
                                        No recent transactions.
                                    </td>
                                </tr>
                            ) : (
                                transactions.map((transaction) => (
                                    <tr
                                        key={transaction.id}
                                        className="border-t border-white/10"
                                    >
                                        <td className="px-4 py-3">
                                            {formatDate(transaction.date)}
                                        </td>
                                        <td className="px-4 py-3">
                                            {transaction.description}
                                        </td>
                                        <td className="px-4 py-3">
                                            {formatCurrency(transaction.amount, currency)}
                                        </td>
                                        <td className="px-4 py-3">{transaction.method}</td>
                                        <td className="px-4 py-3">
                                            <StatusBadge status={transaction.status} />
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </article>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="mb-3 text-lg font-semibold">Quick Links</h3>
                <div className="flex flex-wrap gap-2">
                    <Link
                        to="/client/invoices"
                        className="rounded-lg border border-white/25 px-3 py-2 text-sm font-semibold hover:bg-white/10"
                    >
                        View All Invoices
                    </Link>
                    <Link
                        to="/client/orders"
                        className="rounded-lg border border-white/25 px-3 py-2 text-sm font-semibold hover:bg-white/10"
                    >
                        View Orders
                    </Link>
                    <Link
                        to="/client/support"
                        className="rounded-lg border border-white/25 px-3 py-2 text-sm font-semibold hover:bg-white/10"
                    >
                        Contact Support
                    </Link>
                </div>
            </article>

            {isAddFundsOpen ? (
                <div className="fixed inset-0 z-40 flex items-center justify-center bg-slate-950/70 px-4">
                    <div className="w-full max-w-md rounded-xl border border-white/15 bg-[var(--panel-surface)] p-5 shadow-lg">
                        <h4 className="text-lg font-semibold">Add Funds</h4>
                        <p className="mt-1 text-sm text-white/70">
                            Choose an amount and payment provider to top up your account balance.
                        </p>
                        <div className="mt-4 space-y-4">
                            <div className="grid grid-cols-5 gap-2">
                                {[5, 10, 25, 50, 100].map((preset) => (
                                    <button
                                        key={preset}
                                        type="button"
                                        onClick={() => setAddFundsAmount(String(preset))}
                                        className="rounded-lg border border-white/25 px-2 py-1.5 text-sm font-semibold hover:bg-white/10"
                                    >
                                        ${preset}
                                    </button>
                                ))}
                            </div>
                            <div>
                                <label className="mb-1 block text-sm font-medium">Amount</label>
                                <input
                                    type="number"
                                    min={5}
                                    max={500}
                                    step="0.01"
                                    value={addFundsAmount}
                                    onChange={(event) => setAddFundsAmount(event.target.value)}
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                                />
                            </div>
                            <div>
                                <label className="mb-1 block text-sm font-medium">Provider</label>
                                <select
                                    value={addFundsProvider}
                                    onChange={(event) =>
                                        setAddFundsProvider(event.target.value as 'stripe' | 'paypal')
                                    }
                                    className="w-full rounded-lg border border-white/20 bg-[var(--panel-bg)] px-3 py-2 text-sm"
                                >
                                    <option value="stripe">Stripe</option>
                                    <option value="paypal">PayPal</option>
                                </select>
                            </div>
                        </div>
                        <div className="mt-4 flex justify-end gap-2">
                            <button
                                type="button"
                                onClick={() => setIsAddFundsOpen(false)}
                                disabled={isSubmittingAddFunds}
                                className="rounded-lg border border-white/25 px-3 py-2 text-sm font-semibold hover:bg-white/10"
                            >
                                Close
                            </button>
                            <button
                                type="button"
                                onClick={() => void handleSubmitAddFunds()}
                                disabled={isSubmittingAddFunds}
                                className="rounded-lg bg-[var(--panel-primary)] px-3 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                            >
                                {isSubmittingAddFunds ? 'Processing...' : 'Continue'}
                            </button>
                        </div>
                    </div>
                </div>
            ) : null}
        </section>
    );
}
