import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { CreditCard, ReceiptText, Wallet, Plus, Trash2, CheckCircle2 } from 'lucide-react';
import {
    addFunds,
    createClientPaymentMethod,
    formatCurrency,
    getClientBillingData,
    removeClientPaymentMethod,
    setDefaultClientPaymentMethod,
} from '@/lib/billing-api';
import { StatusBadge } from '@/components/status-badge';
import type {
    ClientBillingPaymentMethod,
    ClientBillingPayload,
} from '@/types/client-billing';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function BillingPage() {
    const [data, setData] = useState<ClientBillingPayload | null>(null);
    const [paymentMethods, setPaymentMethods] = useState<ClientBillingPaymentMethod[]>(
        [],
    );
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isAddFundsOpen, setIsAddFundsOpen] = useState(false);
    const [isSubmittingAddFunds, setIsSubmittingAddFunds] = useState(false);
    const [addFundsAmount, setAddFundsAmount] = useState('10');
    const [addFundsProvider, setAddFundsProvider] = useState<'stripe' | 'paypal'>('stripe');
    const [isSavingMethod, setIsSavingMethod] = useState(false);

    useEffect(() => {
        async function loadBilling() {
            try {
                const billingData = await getClientBillingData();
                setData(billingData);
                setPaymentMethods(billingData.payment_methods);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load billing data.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadBilling();
    }, []);

    async function reloadBillingData() {
        const billingData = await getClientBillingData();
        setData(billingData);
        setPaymentMethods(billingData.payment_methods);
    }

    const currency = data?.summary.currency ?? 'USD';
    const hasOutstanding = (data?.outstanding_invoices.length ?? 0) > 0;
    const transactions = useMemo(
        () => (data?.recent_transactions ?? []).slice(0, 15),
        [data],
    );

    async function handleSetDefault(id: string) {
        try {
            await setDefaultClientPaymentMethod(id);
            await reloadBillingData();
            setError(null);
        } catch (setDefaultError) {
            setError(
                setDefaultError instanceof Error
                    ? setDefaultError.message
                    : 'Failed to update default payment method.',
            );
        }
    }

    async function handleRemoveMethod(id: string) {
        try {
            await removeClientPaymentMethod(id);
            await reloadBillingData();
            setError(null);
        } catch (removeError) {
            setError(
                removeError instanceof Error
                    ? removeError.message
                    : 'Failed to remove payment method.',
            );
        }
    }

    async function handleAddMethod() {
        if (isSavingMethod) return;

        try {
            setIsSavingMethod(true);
            await createClientPaymentMethod({
                provider: 'stripe',
                type: 'card',
                label: 'Card',
                masked_details: '**** 4242',
                provider_reference: null,
                is_default: paymentMethods.length === 0,
            });
            await reloadBillingData();
            setError(null);
        } catch (addMethodError) {
            setError(
                addMethodError instanceof Error
                    ? addMethodError.message
                    : 'Failed to add payment method.',
            );
        } finally {
            setIsSavingMethod(false);
        }
    }

    function handlePayNow(invoiceId: number) {
        window.location.assign(`/checkout/${invoiceId}`);
    }

    async function handleSubmitAddFunds() {
        const parsedAmount = Number(addFundsAmount);
        if (!Number.isFinite(parsedAmount)) {
            setError('Please enter a valid amount.');
            return;
        }

        try {
            setIsSubmittingAddFunds(true);
            setError(null);
            const result = await addFunds(parsedAmount, addFundsProvider);

            if (result.checkout_url) {
                window.location.assign(result.checkout_url);
                return;
            }

            setIsAddFundsOpen(false);
            await reloadBillingData();
        } catch (addFundsError) {
            setError(
                addFundsError instanceof Error
                    ? addFundsError.message
                    : 'Failed to start add-funds payment.',
            );
        } finally {
            setIsSubmittingAddFunds(false);
        }
    }

    return (
        <section className="space-y-8 fade-in-section">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight text-warm-white">Billing & Payments</h2>
                    <p className="mt-1 text-sm text-warm-muted leading-relaxed">
                        Review your account balances, saved cards, and transaction history.
                    </p>
                </div>
            </div>

            {error ? (
                <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-4 text-sm text-rose-400">
                    <span className="mr-2">⚠️</span> {error}
                </div>
            ) : null}

            <article className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm relative overflow-hidden">
                <div className="absolute top-0 right-0 w-64 h-64 bg-accent-50/2 rounded-full -mr-32 -mt-32 blur-3xl pointer-events-none" />

                <div className="relative z-10 mb-8 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3">
                        <div className="p-2.5 rounded-xl bg-accent-50/10 text-accent-50">
                            <Wallet className="size-5" />
                        </div>
                        <h3 className="text-lg font-bold text-warm-white tracking-tight">Account Overview</h3>
                    </div>
                    <button
                        type="button"
                        onClick={() => setIsAddFundsOpen(true)}
                        className="btn-glow inline-flex items-center gap-2 rounded-xl bg-accent-50 px-5 py-2.5 text-sm font-bold text-white transition-all shadow-lg shadow-accent-50/10"
                    >
                        <Plus className="size-4" /> Add Funds
                    </button>
                </div>

                <div className="relative z-10 grid gap-6 sm:grid-cols-3">
                    <div className="rounded-2xl border border-white/6 bg-white/2 p-6 transition-colors hover:border-white/10">
                        <p className="text-[10px] uppercase tracking-widest font-bold text-warm-muted/40 mb-2">
                            Current Balance
                        </p>
                        <p className="text-3xl font-bold text-warm-white tracking-tight">
                            {isLoading || !data
                                ? '-'
                                : formatCurrency(data.summary.current_balance, currency)}
                        </p>
                    </div>
                    <div className="rounded-2xl border border-white/6 bg-white/2 p-6 transition-colors hover:border-white/10">
                        <p className="text-[10px] uppercase tracking-widest font-bold text-warm-muted/40 mb-2">
                            Credit Balance
                        </p>
                        <p className="text-3xl font-bold text-emerald-400 tracking-tight">
                            {isLoading || !data
                                ? '-'
                                : formatCurrency(data.summary.credit_balance, currency)}
                        </p>
                    </div>
                    <div className="rounded-2xl border border-white/6 bg-white/2 p-6 transition-colors hover:border-white/10">
                        <p className="text-[10px] uppercase tracking-widest font-bold text-warm-muted/40 mb-2">
                            Outstanding
                        </p>
                        <p className={`text-3xl font-bold tracking-tight ${data?.summary.outstanding_amount && data.summary.outstanding_amount > 0 ? 'text-rose-400' : 'text-warm-white'}`}>
                            {isLoading || !data
                                ? '-'
                                : formatCurrency(data.summary.outstanding_amount, currency)}
                        </p>
                    </div>
                </div>
            </article>

            <div className="grid gap-8 xl:grid-cols-[1fr_0.8fr]">
                <div className="space-y-8">
                    <article className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm">
                        <div className="mb-6 flex items-center justify-between gap-4">
                            <div className="flex items-center gap-3">
                                <div className="p-2.5 rounded-xl bg-white/4 text-warm-muted/60">
                                    <CreditCard className="size-5" />
                                </div>
                                <h3 className="text-lg font-bold text-warm-white">Payment Methods</h3>
                            </div>
                            <button
                                type="button"
                                onClick={handleAddMethod}
                                disabled={isSavingMethod}
                                className="inline-flex items-center gap-2 rounded-xl border border-white/10 px-4 py-2 text-xs font-bold text-warm-muted hover:text-warm-white hover:bg-white/5 transition-all"
                            >
                                {isSavingMethod ? 'Saving...' : 'Add Method'}
                            </button>
                        </div>

                        {isLoading ? (
                            <div className="space-y-3">
                                {[1, 2].map((i) => <div key={i} className="h-16 rounded-xl bg-white/2 animate-pulse" />)}
                            </div>
                        ) : paymentMethods.length === 0 ? (
                            <p className="text-sm text-warm-muted/60 text-center py-4 bg-white/2 rounded-xl italic">
                                No payment methods saved yet. Add one for faster checkout.
                            </p>
                        ) : (
                            <ul className="space-y-3">
                                {paymentMethods.map((method) => (
                                    <li
                                        key={method.id}
                                        className="group flex flex-col gap-3 rounded-2xl border border-white/6 bg-white/2 p-5 sm:flex-row sm:items-center sm:justify-between transition-colors hover:border-white/10"
                                    >
                                        <div className="flex items-center gap-4">
                                            <div className="size-10 rounded-xl bg-white/5 flex items-center justify-center text-warm-muted/40">
                                                <CreditCard className="size-5" />
                                            </div>
                                            <div>
                                                <div className="flex items-center gap-2">
                                                    <p className="font-bold text-warm-white tracking-tight">
                                                        {method.label}
                                                    </p>
                                                    <span className="text-warm-muted/40 text-xs font-medium tracking-tighter">
                                                        ({method.masked_details})
                                                    </span>
                                                </div>
                                                <p className="text-[10px] uppercase tracking-widest font-bold text-warm-muted/30">
                                                    {method.provider} {method.is_default && '• Default'}
                                                </p>
                                            </div>
                                        </div>
                                        <div className="flex items-center gap-2 pl-14 sm:pl-0">
                                            {!method.is_default ? (
                                                <button
                                                    type="button"
                                                    onClick={() => handleSetDefault(method.id)}
                                                    className="inline-flex items-center gap-1.5 rounded-lg border border-white/5 bg-white/2 px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-warm-muted/60 hover:text-warm-white hover:bg-white/5 transition-all"
                                                >
                                                    <CheckCircle2 className="size-3" /> Set Default
                                                </button>
                                            ) : null}
                                            <button
                                                type="button"
                                                onClick={() => handleRemoveMethod(method.id)}
                                                className="group/trash inline-flex items-center gap-1.5 rounded-lg border border-rose-500/10 bg-rose-500/5 px-2.5 py-1.5 text-[10px] font-bold uppercase tracking-wider text-rose-400 hover:bg-rose-500/10 transition-all"
                                            >
                                                <Trash2 className="size-3 transition-transform group-hover/trash:scale-110" /> Remove
                                            </button>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        )}
                    </article>

                    <article className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] shadow-sm overflow-hidden">
                        <div className="border-b border-white/8 px-8 py-5 flex items-center gap-3">
                            <ReceiptText className="size-5 text-warm-muted/60" />
                            <h3 className="text-lg font-bold text-warm-white uppercase tracking-tight">Recent Transactions</h3>
                        </div>
                        <div className="overflow-x-auto">
                            <table className="min-w-full text-left text-sm">
                                <thead>
                                    <tr className="bg-white/2 text-[10px] uppercase tracking-widest font-bold text-warm-muted/40">
                                        <th className="px-8 py-4">Date</th>
                                        <th className="px-8 py-4">Description</th>
                                        <th className="px-8 py-4">Amount</th>
                                        <th className="px-8 py-4">Status</th>
                                    </tr>
                                </thead>
                                <tbody className="divide-y divide-white/4">
                                    {isLoading ? (
                                        <tr>
                                            <td className="px-8 py-8 text-center text-warm-muted/40" colSpan={4}>Loading history...</td>
                                        </tr>
                                    ) : transactions.length === 0 ? (
                                        <tr>
                                            <td className="px-8 py-8 text-center text-warm-muted/40" colSpan={4}>No recent transactions.</td>
                                        </tr>
                                    ) : (
                                        transactions.map((transaction) => (
                                            <tr key={transaction.id} className="group hover:bg-white/1 transition-colors">
                                                <td className="px-8 py-4 text-warm-muted/60 text-xs">{formatDate(transaction.date)}</td>
                                                <td className="px-8 py-4 font-medium text-warm-white">{transaction.description}</td>
                                                <td className="px-8 py-4 font-bold text-warm-white">{formatCurrency(transaction.amount, currency)}</td>
                                                <td className="px-8 py-4"><StatusBadge status={transaction.status} /></td>
                                            </tr>
                                        ))
                                    )}
                                </tbody>
                            </table>
                        </div>
                    </article>
                </div>

                <div className="space-y-8">
                    <article className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] shadow-sm overflow-hidden">
                        <div className="border-b border-white/8 px-8 py-5">
                            <h3 className="text-lg font-bold text-warm-white">Outstanding Invoices</h3>
                        </div>
                        <div className="divide-y divide-white/4">
                            {isLoading ? (
                                <div className="p-8 text-center text-warm-muted/40 italic">Loading invoices...</div>
                            ) : !hasOutstanding ? (
                                <div className="p-10 text-center space-y-2">
                                    <div className="text-2xl">✨</div>
                                    <p className="text-sm font-bold text-warm-white">You&apos;re all caught up!</p>
                                    <p className="text-xs text-warm-muted/40">No outstanding invoices found.</p>
                                </div>
                            ) : (
                                data?.outstanding_invoices.map((invoice) => (
                                    <div key={invoice.id} className="p-6 transition-colors hover:bg-white/2">
                                        <div className="flex items-center justify-between mb-4">
                                            <div>
                                                <p className="text-sm font-bold text-warm-white">Invoice #{invoice.id}</p>
                                                <p className="text-[10px] text-warm-muted/40 uppercase font-bold tracking-widest">{formatDate(invoice.created_at)}</p>
                                            </div>
                                            <StatusBadge status={invoice.status} />
                                        </div>
                                        <div className="flex items-center justify-between">
                                            <p className="text-xl font-bold text-warm-white">{formatCurrency(invoice.amount, currency)}</p>
                                            {invoice.status === 'unpaid' ? (
                                                <button
                                                    type="button"
                                                    onClick={() => handlePayNow(invoice.id)}
                                                    className="btn-glow rounded-xl bg-accent-50 px-4 py-2 text-xs font-bold text-white transition-all shadow-md shadow-accent-50/10"
                                                >
                                                    Pay Now
                                                </button>
                                            ) : (
                                                <Link
                                                    to={`/client/invoices/${invoice.id}`}
                                                    className="link-arrow text-xs font-bold text-accent-50"
                                                >
                                                    View Details <span>&rarr;</span>
                                                </Link>
                                            )}
                                        </div>
                                    </div>
                                ))
                            )}
                        </div>
                    </article>

                    <article className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm">
                        <h3 className="mb-6 text-sm font-bold uppercase tracking-widest text-warm-muted/40">Quick Links</h3>
                        <div className="flex flex-col gap-3">
                            <Link
                                to="/client/invoices"
                                className="link-arrow flex items-center justify-between rounded-xl bg-white/2 border border-white/5 p-4 text-sm font-bold text-warm-white hover:bg-white/5 transition-all"
                            >
                                Transaction History <span>&rarr;</span>
                            </Link>
                            <Link
                                to="/client/orders"
                                className="link-arrow flex items-center justify-between rounded-xl bg-white/2 border border-white/5 p-4 text-sm font-bold text-warm-white hover:bg-white/5 transition-all"
                            >
                                Your Orders <span>&rarr;</span>
                            </Link>
                            <Link
                                to="/client/support"
                                className="link-arrow flex items-center justify-between rounded-xl bg-white/2 border border-white/5 p-4 text-sm font-bold text-warm-white hover:bg-white/5 transition-all"
                            >
                                Support Tickets <span>&rarr;</span>
                            </Link>
                        </div>
                    </article>
                </div>
            </div>

            {isAddFundsOpen ? (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/80 backdrop-blur-sm px-4 fade-in-section">
                    <div className="w-full max-w-md rounded-2xl border border-white/10 bg-[var(--panel-surface)] p-8 shadow-2xl">
                        <h4 className="text-xl font-bold text-warm-white tracking-tight">Add Funds</h4>
                        <p className="mt-2 text-sm text-warm-muted leading-relaxed">
                            Top up your account balance for seamless hosting renewals.
                        </p>

                        <div className="mt-8 space-y-6">
                            <div className="grid grid-cols-5 gap-2">
                                {[5, 10, 25, 50, 100].map((preset) => (
                                    <button
                                        key={preset}
                                        type="button"
                                        onClick={() => setAddFundsAmount(String(preset))}
                                        className={`rounded-xl border px-2 py-2 text-xs font-bold transition-all ${addFundsAmount === String(preset) ? 'border-accent-50 bg-accent-50/10 text-accent-50 shadow-glow' : 'border-white/10 bg-white/4 text-warm-muted hover:border-white/20 hover:text-warm-white'}`}
                                    >
                                        ${preset}
                                    </button>
                                ))}
                            </div>

                            <div>
                                <label className="mb-2 block text-[10px] uppercase font-bold tracking-widest text-warm-muted/50">Custom Amount (USD)</label>
                                <div className="relative">
                                    <span className="absolute left-4 top-1/2 -translate-y-1/2 text-warm-muted/40 font-bold">$</span>
                                    <input
                                        type="number"
                                        min={5}
                                        max={500}
                                        step="0.01"
                                        value={addFundsAmount}
                                        onChange={(event) => setAddFundsAmount(event.target.value)}
                                        className="w-full rounded-xl border border-white/10 bg-white/4 pl-8 pr-4 py-3 text-sm font-bold text-warm-white focus:outline-none focus:border-accent-50 focus:bg-white/6 transition-all"
                                    />
                                </div>
                            </div>

                            <div>
                                <label className="mb-2 block text-[10px] uppercase font-bold tracking-widest text-warm-muted/50">Payment Provider</label>
                                <select
                                    value={addFundsProvider}
                                    onChange={(event) =>
                                        setAddFundsProvider(event.target.value as 'stripe' | 'paypal')
                                    }
                                    className="w-full rounded-xl border border-white/10 bg-white/4 px-4 py-3 text-sm font-bold text-warm-white focus:outline-none focus:border-accent-50 focus:bg-white/6 transition-all appearance-none"
                                >
                                    <option value="stripe">💳 Credit / Debit Card (Stripe)</option>
                                    <option value="paypal">🅿️ PayPal Account</option>
                                </select>
                            </div>
                        </div>

                        <div className="mt-8 flex gap-3">
                            <button
                                type="button"
                                onClick={() => setIsAddFundsOpen(false)}
                                disabled={isSubmittingAddFunds}
                                className="flex-1 rounded-xl border border-white/10 bg-white/4 py-3 text-xs font-bold text-warm-muted hover:text-warm-white hover:bg-white/6 transition-all"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={() => void handleSubmitAddFunds()}
                                disabled={isSubmittingAddFunds}
                                className="flex-[1.5] btn-glow rounded-xl bg-accent-50 py-3 text-xs font-bold text-white transition-all shadow-lg shadow-accent-50/10 disabled:opacity-50"
                            >
                                {isSubmittingAddFunds ? 'Connecting...' : 'Continue to Payment'}
                            </button>
                        </div>
                    </div>
                </div>
            ) : null}
        </section>
    );
}

