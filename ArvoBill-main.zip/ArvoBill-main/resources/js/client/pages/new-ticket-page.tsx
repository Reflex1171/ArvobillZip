import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createClientTicket } from '@/lib/support-api';
import type { TicketPriority } from '@/types/support';
import { ArrowLeft, Send, Sparkles, MessageSquare, LifeBuoy, BookOpen, Clock } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

const priorities: { value: TicketPriority; label: string; color: string }[] = [
    { value: 'low', label: 'Casual', color: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20' },
    { value: 'medium', label: 'Standard', color: 'bg-amber-500/10 text-amber-400 border-amber-500/20' },
    { value: 'high', label: 'Urgent', color: 'bg-rose-500/10 text-rose-400 border-rose-500/20' },
];

export function NewTicketPage() {
    const navigate = useNavigate();
    const [subject, setSubject] = useState('');
    const [priority, setPriority] = useState<TicketPriority>('medium');
    const [message, setMessage] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    async function handleSubmit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        try {
            setIsSubmitting(true);
            const ticket = await createClientTicket({
                subject,
                priority,
                message,
            });
            navigate(`/client/support/${ticket.id}`);
        } catch (submitError) {
            setError(
                submitError instanceof Error
                    ? submitError.message
                    : 'Failed to create ticket.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    return (
        <section className="max-w-6xl mx-auto space-y-10 py-4">
            <header className="flex flex-col gap-4">
                <Link
                    to="/client/support"
                    className="group mb-2 inline-flex items-center gap-2 text-sm font-bold text-accent-400 hover:text-accent-300 transition-colors"
                >
                    <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                    Support Center
                </Link>
                <div className="flex items-center gap-3">
                    <Sparkles className="size-6 text-accent-400" />
                    <h2 className="text-3xl font-bold tracking-tight text-warm-white">Start a new conversation</h2>
                </div>
                <p className="text-lg text-warm-muted leading-relaxed max-w-2xl">
                    Describe your issue or question below. The more detail you provide, the faster our team can help you out.
                </p>
            </header>

            {error ? (
                <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-6 text-rose-400">
                    <div className="flex items-center gap-3">
                        <MessageSquare className="size-5" />
                        <p className="font-bold">Failed to send message</p>
                    </div>
                    <p className="mt-2 text-sm opacity-80 ml-8">{error}</p>
                </div>
            ) : null}

            <div className="grid gap-8 lg:grid-cols-[1fr,320px]">
                <form
                    onSubmit={(event) => void handleSubmit(event)}
                    className="space-y-8 rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm"
                >
                    <div className="space-y-6">
                        <label className="block space-y-3">
                            <span className="text-sm font-bold uppercase tracking-wider text-warm-muted">What's the subject?</span>
                            <input
                                value={subject}
                                onChange={(event) => setSubject(event.target.value)}
                                required
                                placeholder="e.g., Server connection issue"
                                className="w-full rounded-2xl border border-white/10 bg-[var(--color-input)] px-6 py-4 text-warm-white placeholder:text-warm-muted transition-all focus:border-accent-500/50 focus:ring-4 focus:ring-accent-500/10"
                            />
                        </label>

                        <div className="space-y-3">
                            <span className="text-sm font-bold uppercase tracking-wider text-warm-muted">How urgent is this?</span>
                            <div className="grid grid-cols-3 gap-3">
                                {priorities.map((p) => (
                                    <button
                                        key={p.value}
                                        type="button"
                                        onClick={() => setPriority(p.value)}
                                        className={cn(
                                            "flex flex-col items-center gap-1 rounded-2xl border p-4 transition-all active:scale-95",
                                            p.color,
                                            priority === p.value
                                                ? "ring-2 ring-accent-500/40 border-accent-500/40 bg-accent-500/10 shadow-[0_0_20px_rgba(var(--accent-rgb),0.1)]"
                                                : "opacity-40 grayscale hover:opacity-100 hover:grayscale-0"
                                        )}
                                    >
                                        <span className="text-sm font-bold">{p.label}</span>
                                    </button>
                                ))}
                            </div>
                        </div>

                        <label className="block space-y-3">
                            <span className="text-sm font-bold uppercase tracking-wider text-warm-muted">Tell us more</span>
                            <textarea
                                value={message}
                                onChange={(event) => setMessage(event.target.value)}
                                required
                                rows={8}
                                placeholder="Describe your issue in detail. We're here to help!"
                                className="w-full rounded-2xl border border-white/10 bg-[var(--color-input)] px-6 py-4 text-warm-white placeholder:text-warm-muted transition-all focus:border-accent-500/50 focus:ring-4 focus:ring-accent-500/10"
                            />
                        </label>
                    </div>

                    <div className="flex flex-col items-center gap-4 pt-4 sm:flex-row sm:justify-between">
                        <p className="text-xs text-warm-muted max-w-[240px]">
                            By clicking send, your ticket will be added to our queue and a staff member will respond shortly.
                        </p>
                        <button
                            type="submit"
                            disabled={isSubmitting}
                            className="btn-glow flex w-full items-center justify-center gap-2 rounded-2xl bg-primary py-4 text-base font-bold text-white transition-all hover:bg-primary/90 disabled:opacity-60 active:scale-95 sm:w-auto sm:px-12"
                        >
                            {isSubmitting ? (
                                <div className="size-5 animate-spin rounded-full border-2 border-white/20 border-t-white" />
                            ) : (
                                <>
                                    <Send className="size-4" />
                                    Send Message
                                </>
                            )}
                        </button>
                    </div>
                </form>

                <aside className="space-y-6">
                    <div className="rounded-3xl border border-white/8 bg-[var(--color-card)] p-6">
                        <div className="mb-4 flex size-10 items-center justify-center rounded-xl bg-accent-500/10 text-accent-400">
                            <LifeBuoy className="size-5" />
                        </div>
                        <h4 className="text-lg font-bold text-warm-white">Need immediate help?</h4>
                        <p className="mt-2 text-sm text-warm-muted leading-relaxed">
                            Check our knowledgebase for quick answers to common questions.
                        </p>
                        <Link to="#" className="mt-4 inline-flex items-center gap-2 text-sm font-bold text-accent-400 link-arrow">
                            <BookOpen className="size-4" />
                            Knowledgebase <span>&rarr;</span>
                        </Link>
                    </div>

                    <div className="rounded-3xl border border-white/8 bg-white/2 p-6">
                        <div className="mb-4 flex size-10 items-center justify-center rounded-xl bg-amber-500/10 text-amber-400">
                            <Clock className="size-5" />
                        </div>
                        <h4 className="text-lg font-bold text-warm-white">Response Time</h4>
                        <p className="mt-2 text-sm text-warm-muted leading-relaxed">
                            Our team typically responds within <span className="text-amber-400 font-bold">1-2 hours</span> during business hours.
                        </p>
                    </div>
                </aside>
            </div>
        </section>
    );
}

