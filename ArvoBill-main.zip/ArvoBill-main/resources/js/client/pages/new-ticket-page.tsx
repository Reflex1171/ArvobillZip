import { FormEvent, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createClientTicket } from '@/lib/support-api';
import type { TicketPriority } from '@/types/support';

const priorities: TicketPriority[] = ['low', 'medium', 'high'];

export function NewTicketPage() {
    const navigate = useNavigate();
    const [subject, setSubject] = useState('');
    const [priority, setPriority] = useState<TicketPriority>('medium');
    const [message, setMessage] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    async function handleSubmit(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        try {
            setIsSubmitting(true);
            const ticket = await createClientTicket({
                subject,
                priority,
                message,
            });
            navigate(`/client/support/${ticket.id}`);
        } catch (submitError) {
            setError(
                submitError instanceof Error
                    ? submitError.message
                    : 'Failed to create ticket.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">Open New Ticket</h2>
                    <p className="mt-1 text-sm text-white/70">
                        Describe the issue and our team will respond in-thread.
                    </p>
                </div>
                <Link
                    to="/client/support"
                    className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
                >
                    Back to tickets
                </Link>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <form
                onSubmit={(event) => void handleSubmit(event)}
                className="space-y-4 rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6"
            >
                <label className="block space-y-2">
                    <span className="text-sm font-medium">Subject</span>
                    <input
                        value={subject}
                        onChange={(event) => setSubject(event.target.value)}
                        required
                        className="w-full rounded-lg border border-white/20 bg-transparent px-3 py-2 text-sm"
                    />
                </label>

                <label className="block space-y-2">
                    <span className="text-sm font-medium">Priority</span>
                    <select
                        value={priority}
                        onChange={(event) =>
                            setPriority(event.target.value as TicketPriority)
                        }
                        className="w-full rounded-lg border border-white/20 bg-[var(--panel-surface)] px-3 py-2 text-sm"
                    >
                        {priorities.map((item) => (
                            <option key={item} value={item}>
                                {item.charAt(0).toUpperCase() + item.slice(1)}
                            </option>
                        ))}
                    </select>
                </label>

                <label className="block space-y-2">
                    <span className="text-sm font-medium">Message</span>
                    <textarea
                        value={message}
                        onChange={(event) => setMessage(event.target.value)}
                        required
                        rows={8}
                        className="w-full rounded-lg border border-white/20 bg-transparent px-3 py-2 text-sm"
                    />
                </label>

                <button
                    type="submit"
                    disabled={isSubmitting}
                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
                >
                    {isSubmitting ? 'Submitting...' : 'Create Ticket'}
                </button>
            </form>
        </section>
    );
}
