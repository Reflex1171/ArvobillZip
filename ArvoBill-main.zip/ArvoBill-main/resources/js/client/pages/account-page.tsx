import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import {
    deleteAccount,
    getAccountProfile,
    updateAccountPassword,
    updateAccountProfile,
} from '@/lib/account-api';
import type { AccountProfile } from '@/types/account';
import { User, Shield, Lock, Calendar, CreditCard, Ticket, CheckCircle2, AlertCircle } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function AccountPage() {
    const [account, setAccount] = useState<AccountProfile | null>(null);
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [passwordConfirmation, setPasswordConfirmation] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSavingProfile, setIsSavingProfile] = useState(false);
    const [isSavingPassword, setIsSavingPassword] = useState(false);
    const [isDeletingAccount, setIsDeletingAccount] = useState(false);
    const [deletePassword, setDeletePassword] = useState('');
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadAccount() {
            try {
                const data = await getAccountProfile();
                setAccount(data);
                setName(data.name);
                setEmail(data.email);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load account settings.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadAccount();
    }, []);

    async function handleProfileSave(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        try {
            setIsSavingProfile(true);
            await updateAccountProfile({ name, email });
            const refreshed = await getAccountProfile();
            setAccount(refreshed);
            setMessage('Profile updated successfully.');
            setError(null);
        } catch (saveError) {
            setError(
                saveError instanceof Error
                    ? saveError.message
                    : 'Failed to update profile.',
            );
        } finally {
            setIsSavingProfile(false);
        }
    }

    async function handlePasswordSave(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();
        try {
            setIsSavingPassword(true);
            await updateAccountPassword({
                current_password: currentPassword,
                password: newPassword,
                password_confirmation: passwordConfirmation,
            });
            setCurrentPassword('');
            setNewPassword('');
            setPasswordConfirmation('');
            setMessage('Password updated successfully.');
            setError(null);
        } catch (saveError) {
            setError(
                saveError instanceof Error
                    ? saveError.message
                    : 'Failed to update password.',
            );
        } finally {
            setIsSavingPassword(false);
        }
    }

    async function handleDeleteAccount(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        const confirmed = window.confirm(
            'This will permanently delete your account and related data. Continue?',
        );

        if (!confirmed) {
            return;
        }

        try {
            setIsDeletingAccount(true);
            await deleteAccount({ current_password: deletePassword });
            window.location.href = '/';
        } catch (deleteError) {
            setError(
                deleteError instanceof Error
                    ? deleteError.message
                    : 'Failed to delete account.',
            );
        } finally {
            setIsDeletingAccount(false);
        }
    }

    if (isLoading) {
        return (
            <div className="max-w-7xl mx-auto py-12 animate-pulse space-y-8">
                <div className="h-6 w-32 rounded bg-white/5" />
                <div className="h-48 rounded-3xl bg-white/5" />
                <div className="grid gap-8 lg:grid-cols-3">
                    <div className="lg:col-span-2 h-96 rounded-3xl bg-white/5" />
                    <div className="h-96 rounded-3xl bg-white/5" />
                </div>
            </div>
        );
    }

    return (
        <section className="max-w-7xl mx-auto space-y-10 py-4">
            <header>
                <div className="flex items-center gap-3 mb-2">
                    <User className="size-5 text-accent-400" />
                    <span className="text-sm font-bold uppercase tracking-widest text-warm-muted/40">Profile Settings</span>
                </div>
                <h2 className="text-3xl font-black tracking-tight text-warm-white">
                    Manage your Digital Identity.
                </h2>
                <p className="mt-2 text-lg text-warm-muted leading-relaxed max-w-2xl">
                    Keep your profile information up to date to ensure seamless communication and account security.
                </p>
            </header>

            {message && (
                <div className="rounded-2xl border border-accent-500/20 bg-accent-500/10 p-4 text-sm text-accent-300 flex items-center gap-3">
                    <CheckCircle2 className="size-5" />
                    {message}
                </div>
            )}

            {error && (
                <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-sm text-rose-400 flex items-center gap-3">
                    <AlertCircle className="size-5" />
                    {error}
                </div>
            )}

            <div className="grid gap-10 lg:grid-cols-3">
                <div className="lg:col-span-2 space-y-10">
                    <form
                        onSubmit={(event) => void handleProfileSave(event)}
                        className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm space-y-8"
                    >
                        <h3 className="text-lg font-bold text-warm-white flex items-center gap-2">
                            <User className="size-5 text-accent-400" />
                            Personal Information
                        </h3>
                        <div className="grid gap-6 sm:grid-cols-2">
                            <label className="block space-y-2">
                                <span className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50 ml-1">Full Name</span>
                                <input
                                    value={name}
                                    onChange={(event) => setName(event.target.value)}
                                    className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-warm-white focus:border-accent-500/50 transition-colors"
                                    placeholder="Your Display Name"
                                />
                            </label>
                            <label className="block space-y-2">
                                <span className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50 ml-1">Email Address</span>
                                <input
                                    value={email}
                                    onChange={(event) => setEmail(event.target.value)}
                                    className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-warm-white focus:border-accent-500/50 transition-colors"
                                    placeholder="your@email.com"
                                />
                            </label>
                        </div>
                        <div className="flex flex-col sm:flex-row gap-4 pt-4">
                            <button
                                type="submit"
                                disabled={isSavingProfile}
                                className="btn-glow flex-1 rounded-xl bg-primary px-8 py-4 text-sm font-bold text-white shadow-lg shadow-accent-500/20 transition-all hover:bg-primary/90 hover:shadow-accent-500/40 disabled:opacity-50 disabled:cursor-not-allowed"
                            >
                                {isSavingProfile ? 'Saving Changes...' : 'Save Profile'}
                            </button>
                        </div>
                    </form>

                    <form
                        onSubmit={(event) => void handlePasswordSave(event)}
                        className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm space-y-8"
                    >
                        <h3 className="text-lg font-bold text-warm-white flex items-center gap-2">
                            <Shield className="size-5 text-accent-400" />
                            Security & Credentials
                        </h3>
                        <div className="space-y-6">
                            <label className="block space-y-2">
                                <span className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50 ml-1">Current Password</span>
                                <div className="relative">
                                    <Lock className="absolute left-4 top-1/2 -translate-y-1/2 size-4 text-warm-muted/30" />
                                    <input
                                        type="password"
                                        value={currentPassword}
                                        onChange={(event) => setCurrentPassword(event.target.value)}
                                        className="w-full rounded-2xl border border-white/10 bg-white/5 px-11 py-3 text-warm-white focus:border-accent-500/50 transition-colors"
                                        placeholder="••••••••"
                                    />
                                </div>
                            </label>
                            <div className="grid gap-6 sm:grid-cols-2">
                                <label className="block space-y-2">
                                    <span className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50 ml-1">New Password</span>
                                    <input
                                        type="password"
                                        value={newPassword}
                                        onChange={(event) => setNewPassword(event.target.value)}
                                        className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-warm-white focus:border-accent-500/50 transition-colors"
                                        placeholder="Min 8 characters"
                                    />
                                </label>
                                <label className="block space-y-2">
                                    <span className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50 ml-1">Confirm New Password</span>
                                    <input
                                        type="password"
                                        value={passwordConfirmation}
                                        onChange={(event) => setPasswordConfirmation(event.target.value)}
                                        className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-3 text-warm-white focus:border-accent-500/50 transition-colors"
                                        placeholder="Match new password"
                                    />
                                </label>
                            </div>
                        </div>
                        <div className="pt-4 border-t border-white/5">
                            <button
                                type="submit"
                                disabled={isSavingPassword}
                                className="btn-glow rounded-2xl bg-white/5 border border-white/10 px-8 py-4 text-sm font-bold text-warm-white transition-all hover:bg-white/10 active:scale-95 disabled:opacity-50"
                            >
                                {isSavingPassword ? 'Updating Password...' : 'Update Password'}
                            </button>
                        </div>
                    </form>

                    <form
                        onSubmit={(event) => void handleDeleteAccount(event)}
                        className="rounded-3xl border border-rose-400/20 bg-rose-500/5 p-8 shadow-sm space-y-6"
                    >
                        <h3 className="text-lg font-bold text-rose-200">Delete Account</h3>
                        <p className="text-sm text-rose-100/80">
                            Permanently delete your account and all associated data.
                        </p>
                        <label className="block space-y-2">
                            <span className="text-[10px] font-bold uppercase tracking-widest text-rose-100/70 ml-1">
                                Confirm Password
                            </span>
                            <input
                                type="password"
                                value={deletePassword}
                                onChange={(event) => setDeletePassword(event.target.value)}
                                className="w-full rounded-2xl border border-rose-300/30 bg-white/5 px-5 py-3 text-warm-white focus:border-rose-300/60 transition-colors"
                                placeholder="Enter your current password"
                                required
                            />
                        </label>
                        <button
                            type="submit"
                            disabled={isDeletingAccount}
                            className="rounded-2xl bg-rose-600 px-8 py-3 text-sm font-bold text-white transition-all hover:bg-rose-500 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isDeletingAccount ? 'Deleting Account...' : 'Delete Account'}
                        </button>
                    </form>
                </div>

                <aside className="space-y-10">
                    <article className="rounded-3xl border border-white/8 bg-white/2 p-8 space-y-8 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-4 opacity-10">
                            <Calendar className="size-20" />
                        </div>
                        <h3 className="text-lg font-bold text-warm-white tracking-tight">Account Overview</h3>
                        <div className="space-y-6">
                            <div className="flex justify-between items-center">
                                <span className="text-sm text-warm-muted">Join Date</span>
                                <span className="text-sm font-bold text-warm-white">{formatDate(account?.created_at ?? null)}</span>
                            </div>
                            <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                    <CreditCard className="size-4 text-accent-400" />
                                    <span className="text-sm text-warm-muted">Active Services</span>
                                </div>
                                <span className="inline-flex size-6 items-center justify-center rounded-full bg-accent-500/20 text-[10px] font-black text-accent-400">
                                    {account?.overview.active_services_count ?? 0}
                                </span>
                            </div>
                            <div className="flex justify-between items-center">
                                <div className="flex items-center gap-2">
                                    <Ticket className="size-4 text-emerald-400" />
                                    <span className="text-sm text-warm-muted">Open Tickets</span>
                                </div>
                                <span className="inline-flex size-6 items-center justify-center rounded-full bg-emerald-500/20 text-[10px] font-black text-emerald-400">
                                    {account?.overview.open_tickets_count ?? 0}
                                </span>
                            </div>
                        </div>
                    </article>

                    <article className="rounded-3xl border border-white/8 bg-accent-600/5 p-8 text-center relative overflow-hidden group">
                        <div className="absolute inset-0 bg-gradient-to-br from-accent-600/10 to-transparent pointer-events-none" />
                        <Shield className="size-12 text-accent-400 mx-auto mb-4 group-hover:scale-110 transition-transform" />
                        <h4 className="text-sm font-bold text-warm-white uppercase tracking-widest mb-2">Security Protocol</h4>
                        <p className="text-xs text-warm-muted leading-relaxed">Two-factor authentication and deep session monitoring are active for your account.</p>
                    </article>
                </aside>
            </div>
        </section>
    );
}
