import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { formatCurrency, listClientProducts } from '@/lib/products-api';
import type { Product } from '@/types/product';
import { ShoppingBag, Star, ArrowRight, Server, Shield, Zap } from 'lucide-react';

function ProductCard({ product }: { product: Product }) {
  return (
    <article className="card-lift group relative overflow-hidden rounded-[2rem] border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm transition-all hover:border-accent-500/30">
      <div className="absolute -right-12 -top-12 size-40 rounded-full bg-accent-500/5 blur-3xl transition-transform duration-700 group-hover:scale-150" />

      <div className="relative z-10">
        <div className="mb-6 flex items-center justify-between gap-4">
          <div className="flex size-14 items-center justify-center rounded-2xl border border-white/10 bg-white/5 text-accent-400 group-hover:scale-110 group-hover:text-accent-300 transition-all duration-500">
            <Server className="size-7" />
          </div>
          {product.category ? (
            <span className="rounded-full border border-accent-500/20 bg-accent-500/10 px-3 py-1 text-[10px] font-bold uppercase tracking-widest text-accent-400">
              {product.category.name}
            </span>
          ) : null}
        </div>

        <h3 className="text-2xl font-black tracking-tight text-warm-white group-hover:text-accent-400 transition-colors">
          {product.name}
        </h3>

        <p className="mt-4 text-sm leading-relaxed text-warm-muted line-clamp-2">
          {product.description}
        </p>

        <div className="mt-8 flex items-baseline gap-2">
          <p className="text-3xl font-black text-warm-white">
            {formatCurrency(product.price_monthly)}
          </p>
          <span className="text-xs font-bold uppercase tracking-widest text-warm-muted opacity-60">
            / {product.billing_type === 'one_time'
              ? 'one-time'
              : (product.billing_cycle || 'monthly').toLowerCase()}
          </span>
        </div>

        {product.setup_fee !== null && product.setup_fee > 0 ? (
          <p className="mt-1 text-[10px] font-bold uppercase tracking-widest text-warm-muted/50">
            +{formatCurrency(product.setup_fee)} Setup Fee
          </p>
        ) : (
          <div className="mt-1 flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-widest text-emerald-400/70">
            <Zap className="size-3" />
            Instant Deployment
          </div>
        )}

        <div className="mt-8 pt-6 border-t border-white/5">
          <a
            href={`/products/${product.category?.slug ?? 'all'}/${product.slug}/configure`}
            className="btn-glow flex w-full items-center justify-center gap-2 rounded-xl bg-primary py-3 text-sm font-bold text-white transition-all hover:bg-primary/90 active:scale-95"
          >
            Order Now
            <ArrowRight className="size-4" />
          </a>
        </div>
      </div>
    </article>
  );
}

export function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadProducts() {
      try {
        const data = await listClientProducts();
        setProducts(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load products.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadProducts();
  }, []);

  return (
    <div className="max-w-7xl mx-auto space-y-12 py-4">
      <header className="max-w-3xl">
        <div className="flex items-center gap-2 mb-3 text-accent-400">
          <ShoppingBag className="size-5" />
          <span className="text-sm font-bold uppercase tracking-wider">Product Catalog</span>
        </div>
        <h2 className="text-4xl font-black tracking-tight text-warm-white sm:text-5xl">
          Everything you need <br />
          <span className="text-accent-400">to scale your world.</span>
        </h2>
        <p className="mt-6 text-lg text-warm-muted leading-relaxed">
          Select from our high-performance infrastructure options. Each plan is optimized for gamers and developers who demand the absolute best.
        </p>
      </header>

      {error ? (
        <div className="rounded-3xl border border-rose-500/20 bg-rose-500/10 p-6 text-sm text-rose-400">
          <p className="font-bold">Catalog Error</p>
          <p className="mt-1">{error}</p>
        </div>
      ) : null}

      {!isLoading && !error ? (
        products.length > 0 ? (
          <section className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </section>
        ) : (
          <div className="rounded-[2.5rem] border border-dashed border-white/10 bg-white/2 p-24 text-center">
            <div className="mb-6 flex justify-center">
              <div className="size-20 rounded-full bg-white/5 flex items-center justify-center text-warm-muted">
                <ShoppingBag className="size-10" />
              </div>
            </div>
            <h3 className="text-xl font-bold text-warm-white">No active products</h3>
            <p className="mt-2 text-warm-muted">Our catalog is currently quiet. Check back soon for new drops!</p>
          </div>
        )
      ) : (
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <div key={i} className="animate-pulse rounded-[2rem] border border-white/5 bg-white/2 p-12 h-[420px]" />
          ))}
        </div>
      )}

      <footer className="rounded-3xl border border-white/8 bg-white/2 p-12 text-center">
        <h4 className="text-xl font-bold text-warm-white">Don&apos;t see what you&apos;re looking for?</h4>
        <p className="mt-2 text-warm-muted">Our team can build a custom solution tailored specifically to your project requirements.</p>
        <Link to="/client/support/new" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 link-arrow">
          Contact Enterprise Sales <span>&rarr;</span>
        </Link>
      </footer>
    </div>
  );
}

