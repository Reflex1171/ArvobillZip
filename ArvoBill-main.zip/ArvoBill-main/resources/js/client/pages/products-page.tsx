import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { formatCurrency, listClientProducts } from '@/lib/products-api';
import type { Product } from '@/types/product';

function ProductCard({ product }: { product: Product }) {
  return (
    <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm ">
      <div className="mb-3 flex items-center justify-between gap-3">
        <h3 className="text-lg font-semibold">{product.name}</h3>
        {product.category ? (
          <span className="rounded-full bg-[var(--panel-secondary)] px-2.5 py-1 text-xs font-semibold uppercase tracking-wide text-white">
            {product.category.name}
          </span>
        ) : null}
      </div>
      <p className="mb-4 text-sm text-white/70 ">
        {product.description}
      </p>
      <div className="mb-5">
        <p className="text-2xl font-semibold">
          {formatCurrency(product.price_monthly)}
          <span className="text-sm font-medium text-white/70 ">
            {' '}
            / month
          </span>
        </p>
        {product.setup_fee !== null ? (
          <p className="text-xs text-white/70 ">
            Setup fee: {formatCurrency(product.setup_fee)}
          </p>
        ) : (
          <p className="text-xs text-white/70 ">
            No setup fee
          </p>
        )}
      </div>
      <Link
        to={`/client/products/${product.slug}`}
        className="inline-flex w-full justify-center rounded-lg bg-[var(--panel-primary)] px-4 py-2.5 text-sm font-semibold text-white hover:brightness-110"
      >
        Configure / Order
      </Link>
    </article>
  );
}

export function ProductsPage() {
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadProducts() {
      try {
        const data = await listClientProducts();
        setProducts(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load products.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadProducts();
  }, []);

  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-xl font-semibold">Products</h2>
        <p className="mt-1 text-sm text-white/70 ">
          Choose from active hosting products and start checkout.
        </p>
      </section>

      {isLoading ? (
        <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70  ">
          Loading products...
        </div>
      ) : null}

      {error ? (
        <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      {!isLoading && !error ? (
        products.length > 0 ? (
          <section className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </section>
        ) : (
          <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70  ">
            No active products are available right now.
          </div>
        )
      ) : null}
    </div>
  );
}
