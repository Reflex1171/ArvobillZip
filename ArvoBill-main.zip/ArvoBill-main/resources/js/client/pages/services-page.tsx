import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { StatusBadge } from '@/components/status-badge';
import { listClientServices } from '@/lib/services-api';
import type { ServiceSummary } from '@/types/service';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function ServicesPage() {
    const [services, setServices] = useState<ServiceSummary[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadServices() {
            try {
                const data = await listClientServices();
                setServices(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load services.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadServices();
    }, []);

    return (
        <section className="space-y-6">
            <div>
                <h2 className="text-xl font-semibold">Services</h2>
                <p className="mt-1 text-sm text-white/70">
                    Manage your active products and service lifecycle actions.
                </p>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm">
                <table className="min-w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/70">
                        <tr>
                            <th className="px-4 py-3 font-medium">Service ID</th>
                            <th className="px-4 py-3 font-medium">Product</th>
                            <th className="px-4 py-3 font-medium">Status</th>
                            <th className="px-4 py-3 font-medium">Next Due Date</th>
                            <th className="px-4 py-3 font-medium">Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={5}>
                                    Loading services...
                                </td>
                            </tr>
                        ) : services.length === 0 ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={5}>
                                    No services found. Services are created when
                                    invoices are marked paid.
                                </td>
                            </tr>
                        ) : (
                            services.map((service) => (
                                <tr key={service.id} className="border-t border-white/10">
                                    <td className="px-4 py-3 font-medium">#{service.id}</td>
                                    <td className="px-4 py-3">
                                        {service.product?.name ?? '-'}
                                    </td>
                                    <td className="px-4 py-3">
                                        <StatusBadge status={service.status} />
                                    </td>
                                    <td className="px-4 py-3">
                                        {formatDate(service.next_due_at ?? service.next_due_date)}
                                    </td>
                                    <td className="px-4 py-3">
                                        <Link
                                            to={`/client/services/${service.id}`}
                                            className="text-[var(--panel-primary)] hover:underline"
                                        >
                                            Manage service
                                        </Link>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}
