import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { StatusBadge } from '@/components/status-badge';
import { listClientServices } from '@/lib/services-api';
import { cn } from '@/lib/utils';
import type { ServiceSummary } from '@/types/service';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function ServicesPage() {
    const [services, setServices] = useState<ServiceSummary[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [showCancelled, setShowCancelled] = useState(false);

    useEffect(() => {
        async function loadServices() {
            try {
                const data = await listClientServices();
                setServices(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load services.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadServices();
    }, []);

    const statusPriority = (status: string): number => {
        const normalized = status.toLowerCase();
        if (normalized === 'active') return 0;
        if (normalized === 'cancelled') return 99;
        return 10;
    };

    const visibleServices = services
        .filter((service) => showCancelled || service.status !== 'cancelled')
        .sort((a, b) => {
            const priorityDelta = statusPriority(a.status) - statusPriority(b.status);
            if (priorityDelta !== 0) {
                return priorityDelta;
            }

            const aTime = a.created_at ? new Date(a.created_at).getTime() : 0;
            const bTime = b.created_at ? new Date(b.created_at).getTime() : 0;
            return bTime - aTime;
        });

    return (
        <section className="space-y-8 fade-in-section">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                <div>
                    <h2 className="text-2xl font-bold tracking-tight text-warm-white">Your Game Servers</h2>
                    <p className="mt-1 text-sm text-warm-muted leading-relaxed">
                        Manage your active services and lifecycle actions.
                    </p>
                </div>
                <div className="flex items-center gap-6">
                    <label className="flex items-center gap-3 cursor-pointer group select-none">
                        <span className="text-sm font-bold text-warm-muted group-hover:text-warm-white transition-colors">Show Cancelled</span>
                        <div className="relative">
                            <input
                                type="checkbox"
                                className="sr-only"
                                checked={showCancelled}
                                onChange={(e) => setShowCancelled(e.target.checked)}
                            />
                            <div className={cn(
                                "block h-6 w-11 rounded-full transition-all",
                                showCancelled ? "bg-primary" : "bg-white/40"
                            )}></div>
                            <div className={cn(
                                "absolute left-1 top-1 h-4 w-4 rounded-full bg-white transition-all",
                                showCancelled ? "translate-x-5" : "translate-x-0"
                            )}></div>
                        </div>
                    </label>
                    <Link
                        to="/store/hosting"
                        className="btn-glow inline-flex items-center justify-center rounded-xl bg-accent-50 px-5 py-2.5 text-sm font-bold text-white transition-all shadow-lg shadow-accent-50/10"
                    >
                        Deploy New Server
                    </Link>
                </div>
            </div>

            {error ? (
                <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-4 text-sm text-rose-400">
                    <span className="mr-2">⚠️</span> {error}
                </div>
            ) : null}

            {isLoading ? (
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {[1, 2, 3].map((i) => (
                        <div key={i} className="h-48 rounded-2xl border border-white/5 bg-white/2 animate-pulse" />
                    ))}
                </div>
            ) : visibleServices.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 rounded-3xl border border-dashed border-white/8 bg-white/2 text-center">
                    <div className="text-4xl mb-4 opacity-20">🎮</div>
                    <h3 className="text-lg font-bold text-warm-white">No active services yet</h3>
                    <p className="mt-2 text-sm text-warm-muted max-w-xs mx-auto">
                        Once you deploy a server and pay the invoice, it will appear here ready for management.
                    </p>
                    <Link
                        to="/store/hosting"
                        className="mt-6 text-sm font-bold text-accent-50 hover:underline"
                    >
                        Browse plans &rarr;
                    </Link>
                </div>
            ) : (
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {visibleServices.map((service) => (
                        <article
                            key={service.id}
                            className="card-lift group relative overflow-hidden rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-6 shadow-sm"
                        >
                            {/* Accent glow on hover */}
                            <div className="absolute top-0 right-0 w-24 h-24 bg-accent-50/4 rounded-full -mr-12 -mt-12 blur-2xl opacity-0 group-hover:opacity-100 transition-opacity" />

                            <div className="flex items-start justify-between mb-6">
                                <div className="p-3 rounded-xl bg-white/4 group-hover:bg-accent-50/10 transition-colors">
                                    <span className="text-xl">🛠️</span>
                                </div>
                                <StatusBadge status={service.status} />
                            </div>

                            <div className="space-y-1">
                                <h3 className="font-bold text-lg">
                                    <Link
                                        to={`/client/services/${service.id}`}
                                        className="text-warm-white group-hover:text-accent-50 transition-colors hover:underline"
                                    >
                                        {service.product?.name ?? 'Unknown Service'}
                                    </Link>
                                </h3>
                                <p className="text-xs font-bold uppercase tracking-widest text-warm-muted/40">
                                    ID: #{service.id}
                                </p>
                            </div>

                            <div className="mt-6 pt-6 border-t border-white/4 grid grid-cols-2 gap-4">
                                <div>
                                    <p className="text-[10px] items-center gap-1 uppercase tracking-widest font-bold text-warm-muted/30 mb-1">
                                        Next Due
                                    </p>
                                    <p className="text-xs font-medium text-warm-muted/80">
                                        {formatDate(service.next_due_at ?? service.next_due_date)}
                                    </p>
                                </div>
                                <div className="text-right flex flex-col items-end justify-end">
                                    <Link
                                        to={`/client/services/${service.id}`}
                                        className="link-arrow text-sm font-bold text-accent-50 hover:text-accent-40 transition-colors"
                                    >
                                        Manage <span>&rarr;</span>
                                    </Link>
                                </div>
                            </div>
                        </article>
                    ))}
                </div>
            )}
        </section>
    );
}
