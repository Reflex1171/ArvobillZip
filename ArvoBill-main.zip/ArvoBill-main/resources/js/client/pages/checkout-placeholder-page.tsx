import { useEffect, useState } from 'react';
import { useParams } from 'react-router-dom';
import { formatCurrency, getClientProductBySlug } from '@/lib/products-api';
import type { Product } from '@/types/product';

export function CheckoutPlaceholderPage() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadProduct() {
      if (!slug) {
        setError('Missing product slug.');
        setIsLoading(false);

        return;
      }

      try {
        const data = await getClientProductBySlug(slug);
        setProduct(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load checkout summary.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadProduct();
  }, [slug]);

  if (isLoading) {
    return (
      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 text-sm text-white/70  ">
        Loading checkout summary...
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="rounded-xl border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
        {error ?? 'Product not found.'}
      </div>
    );
  }

  const firstMonthTotal =
    product.price_monthly + (product.setup_fee ?? 0);

  return (
    <section className="space-y-6">
      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm ">
        <h2 className="text-xl font-semibold">Checkout</h2>
        <p className="mt-1 text-sm text-white/70 ">
          Product: {product.name}
        </p>
      </div>

      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm ">
        <h3 className="text-lg font-semibold">Price Breakdown</h3>
        <div className="mt-4 space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-white/70 ">
              Monthly price
            </span>
            <span>{formatCurrency(product.price_monthly)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/70 ">
              Setup fee
            </span>
            <span>
              {formatCurrency(product.setup_fee ?? 0)}
            </span>
          </div>
          <div className="flex justify-between border-t border-white/10 pt-2 font-semibold ">
            <span>First month total</span>
            <span>{formatCurrency(firstMonthTotal)}</span>
          </div>
        </div>
      </div>

      <div className="rounded-xl border border-[var(--panel-primary)]/40 bg-[var(--panel-primary)]/15 p-4 text-sm text-[var(--panel-text)]">
        Checkout coming soon.
      </div>
    </section>
  );
}
