type PlaceholderPageProps = {
  title: string;
  description: string;
};

export function PlaceholderPage({ title, description }: PlaceholderPageProps) {
  return (
    <section className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-sm ">
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="mt-2 max-w-2xl text-sm text-white/70 ">
        {description}
      </p>
      <div className="mt-6 rounded-lg border border-dashed border-white/20 bg-white/5 p-8 text-sm text-white/70 ">
        Placeholder content. Connect this section to API resources when
        backend endpoints are ready.
      </div>
    </section>
  );
}
