import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusBadge } from '@/components/status-badge';
import { listClientTickets } from '@/lib/support-api';
import type { TicketSummary } from '@/types/support';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
}

export function SupportPage() {
    const [tickets, setTickets] = useState<TicketSummary[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadTickets() {
            try {
                const data = await listClientTickets();
                setTickets(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load tickets.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadTickets();
    }, []);

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">Support Tickets</h2>
                    <p className="mt-1 text-sm text-white/70">
                        Open and track support conversations with the admin team.
                    </p>
                </div>
                <Link
                    to="/client/support/new"
                    className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110"
                >
                    Open New Ticket
                </Link>
            </div>

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm">
                <table className="min-w-full text-left text-sm">
                    <thead className="bg-white/5 text-white/70">
                        <tr>
                            <th className="px-4 py-3 font-medium">Ticket ID</th>
                            <th className="px-4 py-3 font-medium">Subject</th>
                            <th className="px-4 py-3 font-medium">Status</th>
                            <th className="px-4 py-3 font-medium">Priority</th>
                            <th className="px-4 py-3 font-medium">Last Updated</th>
                            <th className="px-4 py-3 font-medium">View</th>
                        </tr>
                    </thead>
                    <tbody>
                        {isLoading ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={6}>
                                    Loading tickets...
                                </td>
                            </tr>
                        ) : tickets.length === 0 ? (
                            <tr>
                                <td className="px-4 py-4 text-white/70" colSpan={6}>
                                    No tickets found.
                                </td>
                            </tr>
                        ) : (
                            tickets.map((ticket) => (
                                <tr key={ticket.id} className="border-t border-white/10">
                                    <td className="px-4 py-3 font-medium">#{ticket.id}</td>
                                    <td className="px-4 py-3">{ticket.subject}</td>
                                    <td className="px-4 py-3">
                                        <StatusBadge status={ticket.status} />
                                    </td>
                                    <td className="px-4 py-3">
                                        <PriorityBadge priority={ticket.priority} />
                                    </td>
                                    <td className="px-4 py-3">
                                        {formatDate(ticket.updated_at)}
                                    </td>
                                    <td className="px-4 py-3">
                                        <Link
                                            to={`/client/support/${ticket.id}`}
                                            className="text-[var(--panel-primary)] hover:underline"
                                        >
                                            View ticket
                                        </Link>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </section>
    );
}

