import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusBadge } from '@/components/status-badge';
import { listClientTickets } from '@/lib/support-api';
import type { TicketSummary } from '@/types/support';
import { LifeBuoy, Plus, MessageSquare, Clock } from 'lucide-react';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
}

function TicketSkeleton() {
    return (
        <div className="animate-pulse rounded-2xl border border-white/5 bg-white/2 p-6">
            <div className="flex items-center justify-between mb-4">
                <div className="h-4 w-24 rounded bg-white/10" />
                <div className="h-5 w-16 rounded-full bg-white/10" />
            </div>
            <div className="h-6 w-3/4 rounded bg-white/10 mb-4" />
            <div className="flex items-center gap-4">
                <div className="h-4 w-20 rounded bg-white/10" />
                <div className="h-4 w-32 rounded bg-white/10" />
            </div>
        </div>
    );
}

export function SupportPage() {
    const [tickets, setTickets] = useState<TicketSummary[]>([]);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadTickets() {
            try {
                const data = await listClientTickets();
                setTickets(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load tickets.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadTickets();
    }, []);

    return (
        <section className="max-w-6xl mx-auto space-y-10 py-4">
            <header className="flex flex-col gap-6 sm:flex-row sm:items-end sm:justify-between">
                <div>
                    <div className="flex items-center gap-2 mb-2 text-accent-400">
                        <LifeBuoy className="size-5" />
                        <span className="text-sm font-bold uppercase tracking-wider">Support Center</span>
                    </div>
                    <h2 className="text-3xl font-bold tracking-tight text-warm-white">
                        Need a hand? We've got your back.
                    </h2>
                    <p className="mt-2 text-lg text-warm-muted leading-relaxed max-w-2xl">
                        Whether it's a technical glitch or a billing question, our team is here to help you get back to what matters most.
                    </p>
                </div>
                <Link
                    to="/client/support/new"
                    className="btn-glow inline-flex items-center justify-center gap-2 rounded-xl bg-accent-600 px-6 py-3 text-sm font-bold text-white transition-all hover:bg-accent-500 active:scale-95"
                >
                    <Plus className="size-4" />
                    Open New Ticket
                </Link>
            </header>

            {error ? (
                <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-sm text-rose-400">
                    <p className="font-bold mb-1">Oops! Something went wrong</p>
                    {error}
                </div>
            ) : null}

            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-1">
                {isLoading ? (
                    Array.from({ length: 3 }).map((_, i) => <TicketSkeleton key={i} />)
                ) : tickets.length === 0 ? (
                    <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-white/10 bg-white/2 p-16 text-center">
                        <div className="mb-6 flex size-20 items-center justify-center rounded-full bg-white/5 text-warm-muted">
                            <MessageSquare className="size-10" />
                        </div>
                        <h3 className="text-xl font-bold text-warm-white">No active tickets</h3>
                        <p className="mt-2 text-warm-muted">Everything looks clear! If you need anything, we're just a ticket away.</p>
                        <Link
                            to="/client/support/new"
                            className="mt-8 text-sm font-bold text-accent-400 hover:text-accent-300 link-arrow"
                        >
                            Start a conversation <span>&rarr;</span>
                        </Link>
                    </div>
                ) : (
                    tickets.map((ticket) => (
                        <Link
                            key={ticket.id}
                            to={`/client/support/${ticket.id}`}
                            className="card-lift group relative flex flex-col items-start justify-between gap-4 rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-6 shadow-sm transition-all hover:border-white/20 sm:flex-row sm:items-center"
                        >
                            <div className="flex-1 space-y-2">
                                <div className="flex items-center gap-3">
                                    <span className="text-xs font-bold text-accent-400/80 uppercase tracking-widest">#{ticket.id}</span>
                                    <StatusBadge status={ticket.status} />
                                    <PriorityBadge priority={ticket.priority} />
                                </div>
                                <h3 className="text-lg font-bold text-warm-white group-hover:text-accent-400 transition-colors">
                                    {ticket.subject}
                                </h3>
                                <div className="flex items-center gap-4 text-sm text-warm-muted">
                                    <div className="flex items-center gap-1.5">
                                        <Clock className="size-3.5" />
                                        <span>Last updated {formatDate(ticket.updated_at)}</span>
                                    </div>
                                </div>
                            </div>
                            <div className="flex items-center self-end sm:self-center">
                                <span className="text-sm font-bold text-accent-400 link-arrow">
                                    View Thread <span>&rarr;</span>
                                </span>
                            </div>
                        </Link>
                    ))
                )}
            </div>
        </section>
    );
}


