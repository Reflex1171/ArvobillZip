import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { formatCurrency, getClientProductBySlug } from '@/lib/products-api';
import type { Product } from '@/types/product';
import { ArrowLeft, ShieldCheck, Zap, Globe, Cpu, CheckCircle2, ChevronRight, CreditCard } from 'lucide-react';

export function ProductDetailPage() {
  const { slug } = useParams<{ slug: string }>();
  const [product, setProduct] = useState<Product | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadProduct() {
      if (!slug) {
        setError('Missing product slug.');
        setIsLoading(false);
        return;
      }

      try {
        const data = await getClientProductBySlug(slug);
        setProduct(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load product.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadProduct();
  }, [slug]);

  if (isLoading) {
    return (
      <div className="max-w-5xl mx-auto py-12 animate-pulse space-y-8">
        <div className="h-6 w-32 rounded bg-white/5" />
        <div className="h-48 rounded-3xl bg-white/5" />
        <div className="grid gap-8 lg:grid-cols-2">
          <div className="h-64 rounded-3xl bg-white/5" />
          <div className="h-64 rounded-3xl bg-white/5" />
        </div>
      </div>
    );
  }

  if (error || !product) {
    return (
      <div className="max-w-xl mx-auto py-32 text-center">
        <div className="inline-flex size-20 items-center justify-center rounded-full bg-rose-500/10 text-rose-400 mb-6 font-bold text-3xl">!</div>
        <h3 className="text-2xl font-bold text-warm-white">Product Unavailable</h3>
        <p className="mt-2 text-warm-muted">{error ?? 'This plan could not be recovered from our database.'}</p>
        <Link to="/client/products" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 link-arrow">
          Back to catalog <span>&rarr;</span>
        </Link>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto space-y-12 py-4">
      <header>
        <Link
          to="/client/products"
          className="group mb-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400 hover:text-accent-300 transition-colors"
        >
          <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
          Back to Products
        </Link>
        <div className="relative overflow-hidden rounded-[2.5rem] border border-white/8 bg-[var(--panel-surface)] p-12 shadow-2xl">
          <div className="absolute right-0 top-0 h-full w-1/3 bg-gradient-to-l from-accent-500/5 to-transparent" />
          <div className="relative z-10">
            {product.category && (
              <span className="mb-4 inline-block rounded-full bg-accent-500/10 border border-accent-500/20 px-4 py-1.5 text-[10px] font-bold uppercase tracking-widest text-accent-400">
                {product.category.name}
              </span>
            )}
            <h2 className="text-4xl font-black tracking-tight text-warm-white sm:text-5xl">{product.name}</h2>
            <p className="mt-6 max-w-2xl text-lg leading-relaxed text-warm-muted">
              {product.description}
            </p>
            <div className="mt-10 flex flex-wrap gap-8">
              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-xl bg-accent-500/10 text-accent-400">
                  <Zap className="size-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50">Performance</p>
                  <p className="text-sm font-bold text-warm-white tracking-tight">Enterprise NVMe</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-xl bg-emerald-500/10 text-emerald-400">
                  <Globe className="size-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50">Network</p>
                  <p className="text-sm font-bold text-warm-white tracking-tight">Global Edge Network</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex size-10 items-center justify-center rounded-xl bg-sky-500/10 text-sky-400">
                  <ShieldCheck className="size-5" />
                </div>
                <div>
                  <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/50">Security</p>
                  <p className="text-sm font-bold text-warm-white tracking-tight">Advanced DDoS Shield</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>

      <section className="grid gap-8 lg:grid-cols-5">
        <div className="lg:col-span-3 space-y-8">
          <article className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-10 shadow-sm relative overflow-hidden group">
            <div className="absolute top-0 left-0 w-1 h-full bg-accent-500/40 opacity-0 group-hover:opacity-100 transition-opacity" />
            <h3 className="text-xl font-bold text-warm-white flex items-center gap-3">
              <Cpu className="size-6 text-accent-400" />
              What&apos;s under the hood?
            </h3>
            <div className="mt-8 grid gap-6 sm:grid-cols-2">
              {[
                { title: "Instant Activation", desc: "Your server is deployed within seconds of payment confirmation." },
                { title: "24/7 Expert Support", desc: "Our staff is always awake and ready to help you solve issues." },
                { title: "DDoS Protection", desc: "Advanced filtering to keep your players online during attacks." },
                { title: "Global Latency", desc: "Optimized routing to ensure the best possible pings for everyone." }
              ].map((feature, i) => (
                <div key={i} className="space-y-2">
                  <div className="flex items-center gap-2 text-accent-400">
                    <CheckCircle2 className="size-4" />
                    <span className="text-xs font-bold uppercase tracking-widest">{feature.title}</span>
                  </div>
                  <p className="text-sm text-warm-muted leading-relaxed">
                    {feature.desc}
                  </p>
                </div>
              ))}
            </div>
          </article>

          <article className="rounded-3xl border border-white/8 bg-white/2 p-10 text-center">
            <p className="text-sm text-warm-muted mb-4 uppercase tracking-[0.2em] font-bold">Trusted by thousands of gamers</p>
            <div className="flex justify-center gap-1 text-amber-500">
              {[1, 2, 3, 4, 5].map(i => <div key={i} className="size-4 fill-current">★</div>)}
            </div>
            <blockquote className="mt-6 text-xl italic text-warm-white/90 font-serif">
              &ldquo;ArvoHost transformed our community server. The performance is rock solid and support is actually helpful.&rdquo;
            </blockquote>
          </article>
        </div>

        <div className="lg:col-span-2 space-y-8">
          <article className="rounded-[2.5rem] border border-accent-500/30 bg-accent-600/5 p-10 shadow-2xl backdrop-blur-sm relative overflow-hidden">
            <div className="absolute -right-20 -top-20 size-64 rounded-full bg-accent-500/10 blur-3xl" />
            <h3 className="text-lg font-bold text-warm-white tracking-tight flex items-center gap-2">
              <CreditCard className="size-5 text-accent-400" />
              Pricing Summary
            </h3>
            <div className="mt-8 space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-sm text-warm-muted">Billing Cycle</span>
                <span className="text-sm font-bold text-warm-white uppercase tracking-widest">
                  {product.billing_summary}
                </span>
              </div>
              <div className="flex items-center justify-between border-b border-white/5 pb-6">
                <span className="text-sm text-warm-muted">Recurring Amount</span>
                <span className="text-2xl font-black text-warm-white">
                  {formatCurrency(product.price_monthly)}
                </span>
              </div>
              <div className="flex items-center justify-between pt-2">
                <span className="text-sm text-warm-muted">Setup Fee</span>
                <span className="text-sm font-bold text-warm-white">
                  {product.setup_fee !== null && product.setup_fee > 0
                    ? formatCurrency(product.setup_fee)
                    : 'Free ($0.00)'}
                </span>
              </div>
              <div className="pt-8">
                <Link
                  to={`/client/checkout/${product.slug}`}
                  className="btn-glow flex w-full items-center justify-center gap-3 rounded-2xl bg-accent-600 py-5 text-lg font-bold text-white transition-all hover:bg-accent-500 active:scale-95 shadow-xl"
                >
                  Checkout Securely
                  <ChevronRight className="size-5" />
                </Link>
                <p className="mt-4 text-center text-[10px] font-bold uppercase tracking-widest text-warm-muted opacity-40">
                  No hidden fees • Cancel anytime
                </p>
              </div>
            </div>
          </article>
        </div>
      </section>
    </div>
  );
}

