import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { confirmStripePaymentSession, getClientInvoice } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { InvoiceSummary } from '@/types/billing';

function formatDate(value: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const [invoice, setInvoice] = useState<InvoiceSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isConfirmingPayment, setIsConfirmingPayment] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadInvoice() {
      if (!id) {
        setError('Missing invoice id.');
        setIsLoading(false);
        return;
      }

      try {
        const data = await getClientInvoice(id);
        setInvoice(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load invoice.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadInvoice();
  }, [id]);

  useEffect(() => {
    async function syncStripePayment() {
      if (!invoice || !id) return;
      if (invoice.status !== 'unpaid') return;

      const provider = searchParams.get('provider');
      const payment = searchParams.get('payment');
      const sessionId = searchParams.get('session_id');

      if (provider !== 'stripe' || payment !== 'success' || !sessionId) {
        return;
      }

      try {
        setIsConfirmingPayment(true);
        await confirmStripePaymentSession(invoice.id, sessionId);
        const refreshed = await getClientInvoice(id);
        setInvoice(refreshed);
        setError(null);
      } catch (syncError) {
        setError(
          syncError instanceof Error
            ? syncError.message
            : 'Payment was successful but invoice sync failed. Please refresh in a moment.',
        );
      } finally {
        setIsConfirmingPayment(false);
      }
    }

    void syncStripePayment();
  }, [invoice, id, searchParams]);

  if (isLoading) {
    return <div className="text-sm text-white/70 ">Loading invoice...</div>;
  }

  if (error || !invoice) {
    return (
      <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
        {error ?? 'Invoice not found.'}
      </div>
    );
  }

  return (
    <section className="space-y-6">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-xl font-semibold">Invoice #{invoice.id}</h2>
          <p className="mt-1 text-sm text-white/70 ">
            Due {formatDate(invoice.due_date)}
          </p>
        </div>
        <StatusBadge status={invoice.status} />
      </div>

      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
        <div className="border-b border-white/10 px-4 py-3 ">
          <h3 className="font-semibold">Items</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-white/5 text-white/70 ">
              <tr>
                <th className="px-4 py-3 font-medium">Description</th>
                <th className="px-4 py-3 font-medium">Amount</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.items ?? []).map((item) => (
                <tr key={item.id} className="border-t border-white/10 ">
                  <td className="px-4 py-3">{item.description}</td>
                  <td className="px-4 py-3">{formatCurrency(item.amount)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm ">
        <div className="space-y-2 text-sm">
          <div className="flex justify-between">
            <span className="text-white/70 ">Subtotal</span>
            <span>{formatCurrency(invoice.subtotal)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-white/70 ">Tax</span>
            <span>{formatCurrency(invoice.tax ?? 0)}</span>
          </div>
          <div className="flex justify-between border-t border-white/10 pt-2 font-semibold ">
            <span>Total</span>
            <span>{formatCurrency(invoice.total)}</span>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-4">
        <button
          type="button"
          onClick={() => window.location.assign(`/checkout/${invoice.id}`)}
          disabled={invoice.status !== 'unpaid'}
          className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:opacity-60"
        >
          Pay Invoice
        </button>
        <Link to="/client/invoices" className="text-sm text-[var(--panel-primary)] hover:underline">
          Back to invoices
        </Link>
      </div>

      {isConfirmingPayment ? (
        <div className="rounded-lg border border-cyan-200 bg-cyan-50 p-4 text-sm text-cyan-800 dark:border-cyan-900/40 dark:bg-cyan-900/20 dark:text-cyan-300">
          Confirming Stripe payment and updating invoice status...
        </div>
      ) : null}
    </section>
  );
}
