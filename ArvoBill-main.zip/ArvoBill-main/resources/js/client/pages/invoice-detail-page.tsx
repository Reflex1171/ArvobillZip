import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import {
  capturePayPalPaymentOrder,
  confirmStripePaymentSession,
  getClientInvoice,
} from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { InvoiceSummary } from '@/types/billing';
import { ArrowLeft, CreditCard, Receipt, FileText, Download, Wallet, ShieldCheck } from 'lucide-react';

function formatDate(value: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('en-US', {
    month: 'long',
    day: 'numeric',
    year: 'numeric',
  });
}

function InvoiceDetailSkeleton() {
  return (
    <div className="animate-pulse space-y-6">
      <div className="h-8 w-48 rounded bg-white/10" />
      <div className="h-64 rounded-3xl bg-white/5" />
      <div className="h-32 rounded-3xl bg-white/5" />
    </div>
  );
}

export function InvoiceDetailPage() {
  const { id } = useParams<{ id: string }>();
  const [searchParams] = useSearchParams();
  const [invoice, setInvoice] = useState<InvoiceSummary | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isConfirmingPayment, setIsConfirmingPayment] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadInvoice() {
      if (!id) {
        setError('Missing invoice id.');
        setIsLoading(false);
        return;
      }

      try {
        const data = await getClientInvoice(id);
        setInvoice(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load invoice.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadInvoice();
  }, [id]);

  useEffect(() => {
    async function syncStripePayment() {
      if (!invoice || !id) return;
      if (invoice.status !== 'unpaid') return;

      const provider = searchParams.get('provider');
      const payment = searchParams.get('payment');
      const sessionId = searchParams.get('session_id');

      if (provider !== 'stripe' || payment !== 'success' || !sessionId) {
        return;
      }

      try {
        setIsConfirmingPayment(true);
        await confirmStripePaymentSession(invoice.id, sessionId);
        const refreshed = await getClientInvoice(id);
        setInvoice(refreshed);
        setError(null);
      } catch (syncError) {
        setError(
          syncError instanceof Error
            ? syncError.message
            : 'Payment was successful but invoice sync failed. Please refresh in a moment.',
        );
      } finally {
        setIsConfirmingPayment(false);
      }
    }

    void syncStripePayment();
  }, [invoice, id, searchParams]);

  useEffect(() => {
    async function syncPayPalPayment() {
      if (!invoice || !id) return;
      if (invoice.status !== 'unpaid') return;

      const provider = searchParams.get('provider');
      const payment = searchParams.get('payment');
      const orderId = searchParams.get('token') ?? searchParams.get('order_id');

      if (provider !== 'paypal' || payment !== 'success' || !orderId) {
        return;
      }

      try {
        setIsConfirmingPayment(true);
        await capturePayPalPaymentOrder(invoice.id, orderId);
        const refreshed = await getClientInvoice(id);
        setInvoice(refreshed);
        setError(null);
      } catch (syncError) {
        setError(
          syncError instanceof Error
            ? syncError.message
            : 'Payment was successful but invoice sync failed. Please refresh in a moment.',
        );
      } finally {
        setIsConfirmingPayment(false);
      }
    }

    void syncPayPalPayment();
  }, [invoice, id, searchParams]);

  if (isLoading) {
    return (
      <div className="max-w-4xl mx-auto py-8">
        <InvoiceDetailSkeleton />
      </div>
    );
  }

  if (error || !invoice) {
    return (
      <div className="max-w-4xl mx-auto py-8">
        <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-6 text-rose-400">
          <p className="font-bold mb-2">Something went wrong</p>
          <p>{error ?? 'Invoice not found.'}</p>
          <Link to="/client/invoices" className="mt-4 inline-block text-sm font-bold link-arrow">
            Back to invoices <span>&rarr;</span>
          </Link>
        </div>
      </div>
    );
  }

  return (
    <section className="max-w-5xl mx-auto space-y-12 py-4">
      <header className="flex flex-col gap-8 sm:flex-row sm:items-end sm:justify-between">
        <div className="space-y-4">
          <Link
            to="/client/invoices"
            className="group inline-flex items-center gap-2 text-sm font-black uppercase tracking-widest text-accent-400 hover:text-accent-300 transition-colors"
          >
            <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
            Billing History
          </Link>
          <div className="flex flex-col gap-2">
            <div className="flex items-center gap-4">
              <h2 className="text-4xl font-black tracking-tight text-warm-white sm:text-5xl">
                Invoice <span className="text-accent-500">#{invoice.id}</span>
              </h2>
              <StatusBadge status={invoice.status} />
            </div>
            <p className="text-lg text-warm-muted leading-relaxed flex items-center gap-3">
              <Receipt className="size-5 text-accent-500/50" />
              Issued on <span className="text-warm-white font-bold">{formatDate(invoice.created_at)}</span>
            </p>
          </div>
        </div>
        <div className="flex items-center gap-3 pt-4 sm:pt-0">
          <button
            type="button"
            onClick={() => window.location.assign(`/api/invoices/${invoice.id}/pdf`)}
            className="btn-glow group relative flex h-14 items-center gap-3 rounded-2xl border border-white/10 bg-[var(--color-card)] px-8 text-sm font-black uppercase tracking-widest text-warm-white transition-all hover:bg-[var(--color-input)] hover:border-white/20 active:scale-95"
          >
            <Download className="size-5 text-accent-400 group-hover:scale-110 transition-transform" />
            Save PDF
          </button>
        </div>
      </header>

      {isConfirmingPayment && (
        <div className="rounded-[2rem] border border-accent-500/30 bg-accent-500/5 p-8 text-accent-400 backdrop-blur-xl animate-pulse">
          <div className="flex items-center gap-4">
            <div className="size-6 animate-spin rounded-full border-2 border-accent-400/20 border-t-accent-400" />
            <p className="text-lg font-bold tracking-tight">Securing payment status...</p>
          </div>
        </div>
      )}

      <div className="grid gap-10 lg:grid-cols-[1fr,380px]">
        <div className="space-y-10">
          <article className="overflow-hidden rounded-[2.5rem] border border-white/8 bg-[var(--color-card)] shadow-[0_20px_50px_rgba(0,0,0,0.3)] relative">
            <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-accent-600 via-accent-400 to-accent-600" />
            <div className="border-b border-white/6 px-10 py-8 bg-white/[0.02]">
              <h3 className="text-xs font-black uppercase tracking-[0.2em] text-warm-muted/50 flex items-center gap-3">
                <FileText className="size-4 text-accent-400" />
                Line Items
              </h3>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left">
                <thead>
                  <tr className="bg-white/[0.01]">
                    <th className="px-10 py-5 text-[10px] font-black uppercase tracking-widest text-warm-muted/40">Service Description</th>
                    <th className="px-10 py-5 text-right text-[10px] font-black uppercase tracking-widest text-warm-muted/40">Amount</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-white/5">
                  {(invoice.items ?? []).map((item) => (
                    <tr key={item.id} className="group transition-all hover:bg-white/[0.03]">
                      <td className="px-10 py-8">
                        <p className="text-lg font-black text-warm-white group-hover:text-accent-400 transition-colors leading-tight">{item.description}</p>
                        <div className="mt-2 flex items-center gap-2">
                          <span className="inline-block size-1.5 rounded-full bg-accent-500/30" />
                          <p className="text-[10px] font-bold text-warm-muted uppercase tracking-widest">Global Cloud Asset</p>
                        </div>
                      </td>
                      <td className="px-10 py-8 text-right">
                        <span className="text-xl font-black text-warm-white tracking-tight">
                          {formatCurrency(item.amount)}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </article>

          <footer className="grid gap-6 sm:grid-cols-2">
            <div className="rounded-[2rem] border border-white/8 bg-[var(--color-card)] p-8">
              <h4 className="text-[10px] font-black uppercase tracking-widest text-warm-muted/40 mb-4 flex items-center gap-2">
                <ShieldCheck className="size-4 text-emerald-500/50" />
                Trust Signals
              </h4>
              <p className="text-sm text-warm-muted leading-relaxed">
                This invoice is cryptographically signed and stored in our global billing vault. For reconciliation, use reference <span className="text-warm-white font-bold">INV-{invoice.id}</span>.
              </p>
            </div>
            <div className="rounded-[2rem] border border-white/8 bg-[var(--color-card)] p-8 flex items-center justify-between">
              <div>
                <h4 className="text-[10px] font-black uppercase tracking-widest text-warm-muted/40 mb-1">Status</h4>
                <p className="text-lg font-black text-warm-white uppercase tracking-tight">{invoice.status}</p>
              </div>
              <div className="size-12 rounded-2xl bg-white/5 flex items-center justify-center">
                <Receipt className="size-6 text-warm-muted/40" />
              </div>
            </div>
          </footer>
        </div>

        <aside className="space-y-8">
          <article className="rounded-[2.5rem] border border-accent-500/30 bg-accent-600/5 p-10 shadow-2xl backdrop-blur-sm relative overflow-hidden">
            <div className="absolute -right-20 -top-20 size-64 rounded-full bg-accent-500/10 blur-3xl text-accent-500" />
            <h3 className="text-[10px] font-black uppercase tracking-widest text-warm-muted/60 mb-8 flex items-center gap-2">
              <Wallet className="size-4 text-accent-500" />
              Financial Breakdown
            </h3>

            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-warm-muted">Subtotal</span>
                <span className="text-sm font-black text-warm-white tracking-tight">
                  {formatCurrency(invoice.subtotal)}
                </span>
              </div>
              <div className="flex items-center justify-between border-b border-white/5 pb-6">
                <span className="text-sm font-bold text-warm-muted">Taxes & Fees</span>
                <span className="text-sm font-black text-warm-white tracking-tight">
                  {formatCurrency(invoice.tax ?? 0)}
                </span>
              </div>
              <div className="pt-2">
                <p className="text-[10px] font-black uppercase tracking-widest text-accent-400 mb-1">Amount Due</p>
                <p className="text-5xl font-black text-warm-white tracking-tighter">
                  {formatCurrency(invoice.total)}
                </p>
              </div>

              <div className="pt-8">
                {invoice.status === 'unpaid' ? (
                  <div className="space-y-4">
                    <button
                      type="button"
                      onClick={() => window.location.assign(`/checkout/${invoice.id}`)}
                      className="btn-glow flex w-full items-center justify-center gap-3 rounded-[1.25rem] bg-accent-600 py-5 text-lg font-black uppercase tracking-widest text-white transition-all hover:bg-accent-500 active:scale-95 shadow-xl shadow-accent-600/20"
                    >
                      <CreditCard className="size-5" />
                      Settle Balance
                    </button>
                    <p className="text-center text-[10px] font-black uppercase tracking-widest text-warm-muted/40">
                      SSL Encrypted • Instant Activation
                    </p>
                  </div>
                ) : (
                  <div className="flex flex-col items-center gap-4 p-8 rounded-[2rem] border border-emerald-500/20 bg-emerald-500/5 text-center">
                    <div className="size-16 rounded-full bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
                      <ShieldCheck className="size-8" />
                    </div>
                    <div>
                      <h4 className="text-xl font-black text-warm-white tracking-tight">Fully Settled</h4>
                      <p className="text-sm font-bold text-emerald-500/60 uppercase tracking-widest mt-1">Transaction Verified</p>
                    </div>
                  </div>
                )}
              </div>
            </div>
          </article>

          <div className="rounded-[2.5rem] border border-white/8 bg-[var(--color-card)] p-10">
            <h4 className="text-lg font-black text-warm-white tracking-tight mb-4">Need a hand?</h4>
            <p className="text-sm text-warm-muted leading-relaxed mb-6">
              Our human support team is standing by to help with any billing inquiries or payment adjustments.
            </p>
            <Link to="/client/support" className="flex items-center gap-2 text-xs font-black uppercase tracking-widest text-accent-400 hover:text-accent-300 transition-colors">
              Talk to a person &rarr;
            </Link>
          </div>
        </aside>
      </div>
    </section>
  );
}
