import { useEffect, useState } from 'react';
import {
  formatCurrency,
  formatDashboardDate,
  getClientDashboardData,
} from '@/lib/dashboard-api';

function StatusBadge({ status }: { status: string }) {
  const normalized = status.toLowerCase();
  const statusClassName =
    normalized === 'completed' || normalized === 'paid' || normalized === 'active'
      ? 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300'
      : normalized === 'provisioning'
       ? 'bg-sky-100 text-sky-700 dark:bg-sky-900/30 dark:text-sky-300'
       : normalized === 'suspended'
        ? 'bg-orange-100 text-orange-800 dark:bg-orange-900/30 dark:text-orange-300'
      : normalized === 'pending' || normalized === 'unpaid'
       ? 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300'
       : 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300';

  return (
    <span
      className={`inline-flex rounded-full px-2 py-1 text-xs font-semibold capitalize ${statusClassName}`}
    >
      {status}
    </span>
  );
}

type DashboardData = Awaited<ReturnType<typeof getClientDashboardData>>;

export function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const response = await getClientDashboardData();
        setData(response);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load dashboard.',
        );
      }
    }

    void loadDashboard();
  }, []);

  const stats = [
    {
      label: 'Active Services',
      value: data ? String(data.stats.active_services) : '-',
      detail: 'Completed services in your account',
    },
    {
      label: 'Open Tickets',
      value: data ? String(data.stats.open_tickets) : '-',
      detail: 'Tickets currently awaiting closure',
    },
    {
      label: 'Outstanding Balance',
      value: data ? formatCurrency(data.stats.outstanding_balance) : '-',
      detail: 'Sum of your unpaid invoices',
    },
    {
      label: 'Next Invoice Due',
      value: data?.stats.next_invoice_due?.due_date
        ? formatDashboardDate(data.stats.next_invoice_due.due_date)
        : '-',
      detail: data?.stats.next_invoice_due
        ? `Invoice #${data.stats.next_invoice_due.invoice_id}`
        : 'No unpaid invoices',
    },
  ];

  return (
    <div className="space-y-6">
      <section>
        <h2 className="mb-1 text-xl font-semibold">Overview</h2>
        <p className="text-sm text-white/70 ">
          Infrastructure and billing at a glance.
        </p>
      </section>

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => (
          <article
            key={stat.label}
            className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-4 shadow-sm "
          >
            <p className="text-sm text-white/70 ">
              {stat.label}
            </p>
            <p className="mt-2 text-2xl font-semibold">{stat.value}</p>
            <p className="mt-2 text-xs text-white/70 ">
              {stat.detail}
            </p>
          </article>
        ))}
      </section>

      <section className="rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
        <div className="border-b border-white/10 px-4 py-3 ">
          <h3 className="font-semibold">Your Services</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead className="bg-white/5 text-white/70 ">
              <tr>
                <th className="px-4 py-3 font-medium">Service</th>
                <th className="px-4 py-3 font-medium">Plan</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Created</th>
              </tr>
            </thead>
            <tbody>
              {(data?.services ?? []).map((service) => (
                <tr
                  key={service.id}
                  className="border-t border-white/10 "
                >
                  <td className="px-4 py-3">{service.service}</td>
                  <td className="px-4 py-3 text-white/70 ">
                    {service.plan}
                  </td>
                  <td className="px-4 py-3">
                    <StatusBadge status={service.status} />
                  </td>
                  <td className="px-4 py-3 text-white/70 ">
                    {formatDashboardDate(service.created_at)}
                  </td>
                </tr>
              ))}
              {data && data.services.length === 0 ? (
                <tr className="border-t border-white/10 ">
                  <td
                    className="px-4 py-3 text-white/70 "
                    colSpan={4}
                  >
                    No services yet.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>

      <section className="grid gap-6 xl:grid-cols-2">
        <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
          <div className="border-b border-white/10 px-4 py-3 ">
            <h3 className="font-semibold">Recent Invoices</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead className="bg-white/5 text-white/70 ">
                <tr>
                  <th className="px-4 py-3 font-medium">Invoice</th>
                  <th className="px-4 py-3 font-medium">Date</th>
                  <th className="px-4 py-3 font-medium">Amount</th>
                  <th className="px-4 py-3 font-medium">Status</th>
                </tr>
              </thead>
              <tbody>
                {(data?.recent_invoices ?? []).map((invoice) => (
                  <tr
                    key={invoice.id}
                    className="border-t border-white/10 "
                  >
                    <td className="px-4 py-3">#{invoice.id}</td>
                    <td className="px-4 py-3 text-white/70 ">
                      {formatDashboardDate(invoice.date)}
                    </td>
                    <td className="px-4 py-3">
                      {formatCurrency(invoice.amount)}
                    </td>
                    <td className="px-4 py-3">
                      <StatusBadge status={invoice.status} />
                    </td>
                  </tr>
                ))}
                {data && data.recent_invoices.length === 0 ? (
                  <tr className="border-t border-white/10 ">
                    <td
                      className="px-4 py-3 text-white/70 "
                      colSpan={4}
                    >
                      No invoices yet.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
          <div className="border-b border-white/10 px-4 py-3 ">
            <h3 className="font-semibold">Recent Activity</h3>
          </div>
          <ul className="divide-y divide-slate-100 text-sm dark:divide-slate-800">
            {(data?.recent_activity ?? []).map((item, index) => (
              <li
                key={`${item.text}-${index}`}
                className="flex items-start justify-between gap-4 px-4 py-3"
              >
                <p className="text-[var(--panel-text)]">
                  {item.text}
                </p>
                <p className="whitespace-nowrap text-xs text-white/70 ">
                  {item.timestamp ?? '-'}
                </p>
              </li>
            ))}
            {data && data.recent_activity.length === 0 ? (
              <li className="px-4 py-3 text-white/70 ">
                No recent activity.
              </li>
            ) : null}
          </ul>
        </div>
      </section>
    </div>
  );
}
