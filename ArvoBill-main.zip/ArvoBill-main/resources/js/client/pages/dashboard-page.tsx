﻿import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  formatCurrency,
  formatDashboardDate,
  getClientDashboardData,
} from '@/lib/dashboard-api';

function StatusBadge({ status }: { status: string }) {
  const normalized = status.toLowerCase();

  // Warmer, softer status styling
  const statusClassName =
    normalized === 'completed' || normalized === 'paid' || normalized === 'active'
      ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
      : normalized === 'provisioning'
        ? 'bg-sky-500/10 text-sky-400 border-sky-500/20'
        : normalized === 'suspended'
          ? 'bg-orange-500/10 text-orange-400 border-orange-500/20'
          : normalized === 'pending' || normalized === 'unpaid'
            ? 'bg-amber-500/10 text-amber-400 border-amber-500/20'
            : 'bg-rose-500/10 text-rose-400 border-rose-500/20';

  return (
    <span
      className={`inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider border ${statusClassName}`}
    >
      {status}
    </span>
  );
}

type DashboardData = Awaited<ReturnType<typeof getClientDashboardData>>;

export function DashboardPage() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadDashboard() {
      try {
        const response = await getClientDashboardData();
        setData(response);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load dashboard.',
        );
      }
    }

    void loadDashboard();
  }, []);

  const stats = [
    {
      label: 'Active Services',
      value: data ? String(data.stats.active_services) : '-',
      detail: 'Servers running smoothly',
      emoji: '⚡',
      to: '/client/services',
    },
    {
      label: 'Open Tickets',
      value: data ? String(data.stats.open_tickets) : '-',
      detail: 'Questions needing answers',
      emoji: '💬',
      to: '/client/support',
    },
    {
      label: 'Outstanding Balance',
      value: data ? formatCurrency(data.stats.outstanding_balance) : '-',
      detail: 'Unpaid invoices',
      emoji: '💳',
      to: '/client/invoices',
    },
    {
      label: 'Next Deadline',
      value: data?.stats.next_invoice_due?.due_date
        ? formatDashboardDate(data.stats.next_invoice_due.due_date)
        : '-',
      detail: data?.stats.next_invoice_due
        ? `Invoice #${data.stats.next_invoice_due.invoice_id}`
        : 'No pending dues',
      emoji: '📅',
      to: data?.stats.next_invoice_due
        ? `/client/invoices/${data.stats.next_invoice_due.invoice_id}`
        : '/client/invoices',
    },
  ];

  return (
    <div className="space-y-8 fade-in-section">
      <section>
        <h2 className="mb-1 text-2xl font-bold tracking-tight">
          Hey there! Here&apos;s your overview.
        </h2>
        <p className="text-warm-muted leading-relaxed">
          Your infrastructure and billing, all in one place.
        </p>
      </section>

      {error ? (
        <div className="rounded-xl border border-rose-500/20 bg-rose-500/5 p-4 text-sm text-rose-400">
          <span className="mr-2">⚠️</span> {error}
        </div>
      ) : null}

      <section className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
        {stats.map((stat) => (
          <Link
            key={stat.label}
            to={stat.to}
            className="block"
            aria-label={`${stat.label}: open related page`}
          >
            <article className="card-lift rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-6 shadow-sm">
              <div className="flex items-center justify-between">
                <p className="text-xs font-bold uppercase tracking-widest text-warm-muted/50">
                  {stat.label}
                </p>
                <span className="text-lg opacity-50" aria-hidden="true">{stat.emoji}</span>
              </div>
              <p className="mt-3 text-3xl font-bold tracking-tight text-warm-white">{stat.value}</p>
              <p className="mt-2 text-xs text-warm-muted/60 leading-relaxed">
                {stat.detail}
              </p>
            </article>
          </Link>
        ))}
      </section>

      <section className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] shadow-sm overflow-hidden">
        <div className="border-b border-white/8 px-6 py-4 flex items-center justify-between">
          <h3 className="font-bold text-warm-white flex items-center gap-2">
            <span className="text-accent-50" aria-hidden="true">✦</span>
            Your Active Services
          </h3>
        </div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-left text-sm">
            <thead>
              <tr className="bg-white/2 text-xs uppercase tracking-widest font-bold text-warm-muted/40">
                <th className="px-6 py-4">Service</th>
                <th className="px-6 py-4">Plan</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4">Created</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/4">
              {(data?.services ?? []).map((service) => (
                <tr
                  key={service.id}
                  className="group hover:bg-white/1 transition-colors"
                >
                  <td className="px-6 py-4 font-medium text-warm-white">
                    <Link
                      to={`/client/services/${service.id}`}
                      className="hover:text-accent-50 hover:underline transition-colors"
                    >
                      {service.service}
                    </Link>
                  </td>
                  <td className="px-6 py-4 text-warm-muted/80">
                    {service.plan}
                  </td>
                  <td className="px-6 py-4">
                    <StatusBadge status={service.status} />
                  </td>
                  <td className="px-6 py-4 text-warm-muted/60">
                    {formatDashboardDate(service.created_at)}
                  </td>
                </tr>
              ))}
              {data && data.services.length === 0 ? (
                <tr>
                  <td
                    className="px-6 py-8 text-center text-warm-muted/60"
                    colSpan={4}
                  >
                    No services yet. Ready to start one?
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </section>

      <section className="grid gap-8 xl:grid-cols-[1.2fr_0.8fr]">
        <div className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] shadow-sm overflow-hidden">
          <div className="border-b border-white/8 px-6 py-4">
            <h3 className="font-bold text-warm-white">Recent Invoices</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full text-left text-sm">
              <thead>
                <tr className="bg-white/2 text-xs uppercase tracking-widest font-bold text-warm-muted/40">
                  <th className="px-6 py-4">Invoice</th>
                  <th className="px-6 py-4">Date</th>
                  <th className="px-6 py-4">Amount</th>
                  <th className="px-6 py-4">Status</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/4">
                {(data?.recent_invoices ?? []).map((invoice) => (
                  <tr
                    key={invoice.id}
                    className="group hover:bg-white/1 transition-colors"
                  >
                    <td className="px-6 py-4 font-medium text-warm-white">#{invoice.id}</td>
                    <td className="px-6 py-4 text-warm-muted/60">
                      {formatDashboardDate(invoice.date)}
                    </td>
                    <td className="px-6 py-4 font-semibold text-warm-white">
                      {formatCurrency(invoice.amount)}
                    </td>
                    <td className="px-6 py-4">
                      <StatusBadge status={invoice.status} />
                    </td>
                  </tr>
                ))}
                {data && data.recent_invoices.length === 0 ? (
                  <tr>
                    <td
                      className="px-6 py-8 text-center text-warm-muted/60"
                      colSpan={4}
                    >
                      All clear! No recent invoices.
                    </td>
                  </tr>
                ) : null}
              </tbody>
            </table>
          </div>
        </div>

        <div className="rounded-2xl border border-white/8 bg-[var(--panel-surface)] shadow-sm overflow-hidden">
          <div className="border-b border-white/8 px-6 py-4">
            <h3 className="font-bold text-warm-white">Activity Timeline</h3>
          </div>
          <ul className="divide-y divide-white/4">
            {(data?.recent_activity ?? []).map((item, index) => (
              <li
                key={`${item.text}-${index}`}
                className="flex items-start justify-between gap-4 px-6 py-4 group hover:bg-white/1 transition-colors"
              >
                <div className="flex gap-3">
                  <span className="mt-1 text-accent-50" aria-hidden="true">→</span>
                  <p className="text-warm-muted leading-relaxed">
                    {item.text}
                  </p>
                </div>
                <p className="whitespace-nowrap text-[10px] font-bold uppercase tracking-wider text-warm-muted/40 mt-1">
                  {item.timestamp ?? '-'}
                </p>
              </li>
            ))}
            {data && data.recent_activity.length === 0 ? (
              <li className="px-6 py-8 text-center text-warm-muted/60">
                Nothing to report yet.
              </li>
            ) : null}
          </ul>
        </div>
      </section>
    </div>
  );
}
