import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listClientOrders } from '@/lib/billing-api';
import { StatusBadge } from '@/components/status-badge';
import type { OrderSummary } from '@/types/billing';
import { ShoppingBag, Package, Calendar, Receipt, ChevronRight, AlertCircle, ArrowRight } from 'lucide-react';

function formatDate(value: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function OrdersPage() {
  const [orders, setOrders] = useState<OrderSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadOrders() {
      try {
        const data = await listClientOrders();
        setOrders(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load orders.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadOrders();
  }, []);

  return (
    <section className="max-w-6xl mx-auto space-y-10 py-4">
      <header className="flex flex-col gap-4">
        <div className="flex items-center gap-2 text-accent-400">
          <ShoppingBag className="size-5" />
          <span className="text-sm font-bold uppercase tracking-wider">Order Management</span>
        </div>
        <h2 className="text-3xl font-black tracking-tight text-warm-white">Your Acquisitions</h2>
        <p className="text-lg text-warm-muted leading-relaxed max-w-2xl">
          Track the status of your purchases and access deployment details for your infrastructure.
        </p>
      </header>

      {error && (
        <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-sm text-rose-400 flex items-center gap-3">
          <AlertCircle className="size-5" />
          {error}
        </div>
      )}

      <div className="grid gap-4">
        {isLoading ? (
          Array.from({ length: 3 }).map((_, i) => (
            <div key={i} className="h-24 rounded-2xl bg-white/5 animate-pulse" />
          ))
        ) : orders.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-white/10 bg-white/2 p-20 text-center">
            <div className="mb-6 flex size-20 items-center justify-center rounded-full bg-white/5 text-warm-muted">
              <Package className="size-10" />
            </div>
            <h3 className="text-xl font-bold text-warm-white">No orders yet</h3>
            <p className="mt-2 text-warm-muted">Start building your fleet to see your orders here.</p>
            <Link to="/client/products" className="mt-8 btn-glow rounded-2xl bg-primary px-6 py-3 text-sm font-bold text-white transition-all hover:bg-primary/90">
              Browse Products
            </Link>
          </div>
        ) : (
          orders.map((order) => (
            <article
              key={order.id}
              className="card-lift group rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-6 shadow-sm flex flex-col sm:flex-row sm:items-center justify-between gap-6"
            >
              <div className="flex items-center gap-6">
                <div className="flex size-14 items-center justify-center rounded-2xl bg-white/5 text-warm-muted transition-colors group-hover:bg-accent-500/10 group-hover:text-accent-400">
                  <Package className="size-7" />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <span className="text-lg font-bold text-warm-white">Order #{order.id}</span>
                    <StatusBadge status={order.status} />
                  </div>
                  <p className="text-sm font-medium text-warm-muted flex items-center gap-2">
                    {order.product?.name ?? 'Processing...'}
                  </p>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-8">
                <div className="flex items-center gap-2 text-warm-muted">
                  <Calendar className="size-4 opacity-40" />
                  <span className="text-sm">{formatDate(order.created_at)}</span>
                </div>

                {order.invoice && (
                  <>
                    <Link
                      to={`/client/invoices/${order.invoice.id}`}
                      className="flex items-center gap-2 px-4 py-2 rounded-xl bg-white/5 border border-white/5 text-xs font-bold text-warm-white hover:bg-white/10 transition-colors"
                    >
                      <Receipt className="size-4 text-accent-400" />
                      Invoice #{order.invoice.id}
                    </Link>
                    <Link
                      to={`/client/invoices/${order.invoice.id}/pay`}
                      className="btn-glow inline-flex items-center gap-2 rounded-lg bg-primary px-3 py-1.5 text-xs font-bold text-white transition-all hover:bg-primary/90"
                    >
                      Pay Now
                      <ArrowRight className="size-3" />
                    </Link>
                  </>
                )}

                <div className="hidden sm:flex size-10 items-center justify-center rounded-full bg-white/5 text-warm-muted transition-all group-hover:bg-accent-500 group-hover:text-white">
                  <ChevronRight className="size-6" />
                </div>
              </div>
            </article>
          ))
        )}
      </div>
    </section>
  );
}

