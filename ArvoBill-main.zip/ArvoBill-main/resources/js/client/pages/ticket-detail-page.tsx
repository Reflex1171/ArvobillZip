import { FormEvent, useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { PriorityBadge } from '@/components/priority-badge';
import { StatusBadge } from '@/components/status-badge';
import { getClientTicket, replyClientTicket } from '@/lib/support-api';
import type { TicketSummary } from '@/types/support';
import { ArrowLeft, Send, MessageSquare, ShieldCheck, User, Clock } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
        hour: 'numeric',
        minute: '2-digit',
    });
}

export function TicketDetailPage() {
    const { id = '' } = useParams();
    const [ticket, setTicket] = useState<TicketSummary | null>(null);
    const [reply, setReply] = useState('');
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadTicket() {
            try {
                setIsLoading(true);
                const data = await getClientTicket(id);
                setTicket(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load ticket.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadTicket();
    }, [id]);

    async function handleReply(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        try {
            setIsSubmitting(true);
            const updated = await replyClientTicket(id, reply);
            setTicket(updated);
            setReply('');
            setError(null);
        } catch (replyError) {
            setError(
                replyError instanceof Error
                    ? replyError.message
                    : 'Failed to submit reply.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    if (isLoading) {
        return (
            <div className="flex h-[400px] items-center justify-center">
                <div className="animate-pulse flex flex-col items-center gap-4 text-warm-muted">
                    <MessageSquare className="size-12 opacity-20" />
                    <span className="text-sm font-bold uppercase tracking-widest">Loading Conversation...</span>
                </div>
            </div>
        );
    }

    if (!ticket) {
        return (
            <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-white/10 bg-white/2 p-20 text-center">
                <h3 className="text-xl font-bold text-warm-white">Ticket not found</h3>
                <p className="mt-2 text-warm-muted">We couldn't find the ticket you're looking for.</p>
                <Link to="/client/support" className="mt-8 text-sm font-bold text-accent-400 link-arrow">
                    Back to all tickets <span>&rarr;</span>
                </Link>
            </div>
        );
    }

    return (
        <section className="max-w-5xl mx-auto space-y-10 py-4">
            <header className="flex flex-col gap-6 lg:flex-row lg:items-start lg:justify-between">
                <div>
                    <Link
                        to="/client/support"
                        className="group mb-2 inline-flex items-center gap-2 text-sm font-bold text-accent-400 hover:text-accent-300 transition-colors"
                    >
                        <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                        Back to Tickets
                    </Link>
                    <div className="flex flex-wrap items-center gap-3 mb-2">
                        <span className="text-xs font-bold text-accent-400/80 uppercase tracking-widest">Ticket #{ticket.id}</span>
                        <StatusBadge status={ticket.status} />
                        <PriorityBadge priority={ticket.priority} />
                    </div>
                    <h2 className="text-3xl font-bold tracking-tight text-warm-white">
                        {ticket.subject}
                    </h2>
                    <p className="mt-2 text-warm-muted flex items-center gap-2">
                        <Clock className="size-4" />
                        Opened on {formatDate(ticket.created_at)}
                    </p>
                </div>
                <div className="flex items-center gap-4 lg:self-center">
                    {/* Actions could go here */}
                </div>
            </header>

            {error ? (
                <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-sm text-rose-400">
                    <p className="font-bold mb-1">Reply failed</p>
                    {error}
                </div>
            ) : null}

            <div className="space-y-8">
                {(ticket.messages ?? []).map((message, index) => (
                    <div
                        key={message.id}
                        className={cn(
                            "flex w-full group",
                            message.is_admin ? "justify-start" : "justify-end"
                        )}
                    >
                        <div className={cn(
                            "flex max-w-[85%] items-start gap-4",
                            message.is_admin ? "flex-row" : "flex-row-reverse"
                        )}>
                            <div className={cn(
                                "mt-1 flex size-10 shrink-0 items-center justify-center rounded-2xl border transition-all duration-500 group-hover:scale-110",
                                message.is_admin
                                    ? "border-accent-500/20 bg-accent-500/10 text-accent-400"
                                    : "border-white/10 bg-white/5 text-warm-muted"
                            )}>
                                {message.is_admin ? <ShieldCheck className="size-5" /> : <User className="size-5" />}
                            </div>

                            <div className="space-y-2">
                                <div className={cn(
                                    "flex items-center gap-3 text-xs font-bold uppercase tracking-wider",
                                    message.is_admin ? "justify-start text-accent-400" : "justify-end text-warm-muted"
                                )}>
                                    <span>
                                        {message.is_admin
                                            ? message.user?.name ?? 'ArvoHost Support'
                                            : 'You'}
                                    </span>
                                    <span className="opacity-40">&bull;</span>
                                    <span className="opacity-60">{formatDate(message.created_at)}</span>
                                </div>

                                <div className={cn(
                                    "rounded-3xl border p-6 text-sm leading-relaxed shadow-sm transition-all duration-300",
                                    message.is_admin
                                        ? "rounded-tl-none border-accent-500/20 bg-[var(--panel-surface)] text-warm-white group-hover:border-accent-500/40"
                                        : "rounded-tr-none border-white/10 bg-white/5 text-warm-white group-hover:border-white/20"
                                )}>
                                    <p className="whitespace-pre-wrap">
                                        {message.message}
                                    </p>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="sticky bottom-8 z-10">
                <form
                    onSubmit={(event) => void handleReply(event)}
                    className="group relative rounded-[2.5rem] border border-white/10 bg-[var(--panel-surface)]/80 p-3 shadow-2xl backdrop-blur-xl transition-all focus-within:border-accent-500/40 focus-within:ring-4 focus-within:ring-accent-500/10"
                >
                    <textarea
                        value={reply}
                        onChange={(event) => setReply(event.target.value)}
                        required
                        placeholder={ticket.status === 'closed' ? "This ticket is closed." : "Write your reply here..."}
                        disabled={ticket.status === 'closed' || isSubmitting}
                        className="w-full resize-none rounded-[2rem] border-0 bg-transparent px-6 py-5 text-sm text-warm-white placeholder:text-warm-muted focus:ring-0"
                        rows={1}
                        onInput={(e) => {
                            const target = e.target as HTMLTextAreaElement;
                            target.style.height = 'auto';
                            target.style.height = `${Math.min(target.scrollHeight, 200)}px`;
                        }}
                    />
                    <div className="flex items-center justify-between px-4 pb-1">
                        <div className="text-[10px] font-bold uppercase tracking-widest text-warm-muted opacity-60">
                            Professional Support • Fast Response
                        </div>
                        <button
                            type="submit"
                            disabled={ticket.status === 'closed' || isSubmitting || !reply.trim()}
                            className="btn-glow flex items-center gap-2 rounded-xl bg-primary px-8 py-3 text-sm font-bold text-white transition-all hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            {isSubmitting ? (
                                <div className="size-4 animate-spin rounded-full border-2 border-white/20 border-t-white" />
                            ) : (
                                <Send className="size-5" />
                            )}
                        </button>
                    </div>
                </form>
                {ticket.status === 'closed' && (
                    <p className="mt-4 text-center text-sm font-bold text-rose-400">
                        This conversation has ended.
                    </p>
                )}
            </div>
        </section>
    );
}


