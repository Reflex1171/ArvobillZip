import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listClientInvoices } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { InvoiceSummary } from '@/types/billing';
import { Receipt, FileText, ChevronRight } from 'lucide-react';

function formatDate(value: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

function InvoiceSkeleton() {
  return (
    <div className="animate-pulse flex items-center justify-between rounded-2xl border border-white/5 bg-white/2 p-6">
      <div className="flex items-center gap-4">
        <div className="size-10 rounded-xl bg-white/10" />
        <div className="space-y-2">
          <div className="h-4 w-24 rounded bg-white/10" />
          <div className="h-3 w-16 rounded bg-white/10" />
        </div>
      </div>
      <div className="h-6 w-20 rounded bg-white/10" />
    </div>
  );
}

export function InvoicesPage() {
  const [invoices, setInvoices] = useState<InvoiceSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadInvoices() {
      try {
        const data = await listClientInvoices();
        setInvoices(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load invoices.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadInvoices();
  }, []);

  return (
    <section className="max-w-6xl mx-auto space-y-10 py-4">
      <header className="flex flex-col gap-4">
        <div className="flex items-center gap-2 text-accent-400">
          <Receipt className="size-5" />
          <span className="text-sm font-bold uppercase tracking-wider">Billing History</span>
        </div>
        <h2 className="text-3xl font-bold tracking-tight text-warm-white">Your Invoices</h2>
        <p className="text-lg text-warm-muted leading-relaxed max-w-2xl">
          Keep track of your spending and download PDF copies of your past transactions.
        </p>
      </header>

      {error ? (
        <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-sm text-rose-400">
          <p className="font-bold mb-1">Could not load invoices</p>
          {error}
        </div>
      ) : null}

      <div className="grid gap-4">
        {isLoading ? (
          Array.from({ length: 4 }).map((_, i) => <InvoiceSkeleton key={i} />)
        ) : invoices.length === 0 ? (
          <div className="flex flex-col items-center justify-center rounded-3xl border border-dashed border-white/10 bg-white/2 p-20 text-center">
            <div className="mb-6 flex size-20 items-center justify-center rounded-full bg-white/5 text-warm-muted">
              <FileText className="size-10" />
            </div>
            <h3 className="text-xl font-bold text-warm-white">All clear!</h3>
            <p className="mt-2 text-warm-muted">You don't have any invoices on your account yet.</p>
          </div>
        ) : (
          invoices.map((invoice) => (
            <Link
              key={invoice.id}
              to={`/client/invoices/${invoice.id}`}
              className="card-lift group flex items-center justify-between rounded-2xl border border-white/8 bg-[var(--panel-surface)] p-6 shadow-sm transition-all hover:border-white/20"
            >
              <div className="flex items-center gap-6">
                <div className="flex size-12 items-center justify-center rounded-2xl bg-white/5 text-warm-muted transition-colors group-hover:bg-accent-500/10 group-hover:text-accent-400">
                  <FileText className="size-6" />
                </div>
                <div>
                  <div className="flex items-center gap-3 mb-1">
                    <span className="text-sm font-bold text-warm-white">Invoice #{invoice.id}</span>
                    <StatusBadge status={invoice.status} />
                  </div>
                  <p className="text-xs font-medium text-warm-muted">
                    Due {formatDate(invoice.due_date)}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-6">
                <div className="text-right">
                  <p className="text-lg font-bold text-warm-white">{formatCurrency(invoice.total)}</p>
                </div>
                <div className="flex size-8 items-center justify-center rounded-full bg-white/5 text-warm-muted transition-all group-hover:bg-accent-500 group-hover:text-white">
                  <ChevronRight className="size-5" />
                </div>
              </div>
            </Link>
          ))
        )}
      </div>
    </section>
  );
}

