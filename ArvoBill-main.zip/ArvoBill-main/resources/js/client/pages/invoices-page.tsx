import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { listClientInvoices } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import { StatusBadge } from '@/components/status-badge';
import type { InvoiceSummary } from '@/types/billing';

function formatDate(value: string | null): string {
  if (!value) return '-';
  return new Date(value).toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'short',
    day: 'numeric',
  });
}

export function InvoicesPage() {
  const [invoices, setInvoices] = useState<InvoiceSummary[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    async function loadInvoices() {
      try {
        const data = await listClientInvoices();
        setInvoices(data);
        setError(null);
      } catch (loadError) {
        setError(
          loadError instanceof Error
            ? loadError.message
            : 'Failed to load invoices.',
        );
      } finally {
        setIsLoading(false);
      }
    }

    void loadInvoices();
  }, []);

  return (
    <section className="space-y-6">
      <div>
        <h2 className="text-xl font-semibold">Invoices</h2>
        <p className="mt-1 text-sm text-white/70 ">
          Review what is owed and inspect invoice details.
        </p>
      </div>

      {error ? (
        <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
          {error}
        </div>
      ) : null}

      <div className="overflow-x-auto rounded-xl border border-white/10 bg-[var(--panel-surface)] shadow-sm ">
        <table className="min-w-full text-left text-sm">
          <thead className="bg-white/5 text-white/70 ">
            <tr>
              <th className="px-4 py-3 font-medium">Invoice ID</th>
              <th className="px-4 py-3 font-medium">Total</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Due Date</th>
              <th className="px-4 py-3 font-medium">View</th>
            </tr>
          </thead>
          <tbody>
            {isLoading ? (
              <tr>
                <td className="px-4 py-4 text-white/70 " colSpan={5}>
                  Loading invoices...
                </td>
              </tr>
            ) : invoices.length === 0 ? (
              <tr>
                <td className="px-4 py-4 text-white/70 " colSpan={5}>
                  No invoices found.
                </td>
              </tr>
            ) : (
              invoices.map((invoice) => (
                <tr key={invoice.id} className="border-t border-white/10 ">
                  <td className="px-4 py-3 font-medium">#{invoice.id}</td>
                  <td className="px-4 py-3">{formatCurrency(invoice.total)}</td>
                  <td className="px-4 py-3">
                    <StatusBadge status={invoice.status} />
                  </td>
                  <td className="px-4 py-3">{formatDate(invoice.due_date)}</td>
                  <td className="px-4 py-3">
                    <Link
                      to={`/client/invoices/${invoice.id}`}
                      className="text-[var(--panel-primary)] hover:underline"
                    >
                      View invoice
                    </Link>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </section>
  );
}
