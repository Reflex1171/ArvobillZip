import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { StatusBadge } from '@/components/status-badge';
import {
    cancelClientService,
    getClientService,
    updateClientServiceAutoRenew,
    updateClientServiceDefaultPaymentMethod,
    upgradeClientService,
} from '@/lib/services-api';
import { getClientBillingData } from '@/lib/billing-api';
import { formatCurrency } from '@/lib/products-api';
import type { ServiceSummary } from '@/types/service';
import type { ClientBillingPaymentMethod } from '@/types/client-billing';
import {
    ArrowLeft,
    ExternalLink,
    Zap,
    RefreshCcw,
    ShieldAlert,
    Clock,
    CreditCard,
    Settings,
    Terminal,
    HardDrive,
    Cpu,
    Database,
    AlertCircle,
    XCircle,
    CheckCircle2
} from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function ServiceDetailPage() {
    const { id = '' } = useParams();
    const [service, setService] = useState<ServiceSummary | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [isUpdatingRenewal, setIsUpdatingRenewal] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);
    const [paymentMethods, setPaymentMethods] = useState<ClientBillingPaymentMethod[]>([]);
    const [selectedMethodId, setSelectedMethodId] = useState<string>('');
    const [showCancelModal, setShowCancelModal] = useState(false);
    const [cancelReason, setCancelReason] = useState('');
    const [cancelType, setCancelType] = useState<'immediate' | 'end_of_cycle'>('end_of_cycle');

    useEffect(() => {
        async function loadService() {
            try {
                const [data, billingData] = await Promise.all([
                    getClientService(id),
                    getClientBillingData().catch(() => null),
                ]);
                setService(data);
                const methods = billingData?.payment_methods ?? [];
                setPaymentMethods(methods);
                setSelectedMethodId(
                    data.default_payment_method
                        ? String(data.default_payment_method.id)
                        : '',
                );
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load service.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadService();
    }, [id]);

    async function handleUpgrade() {
        if (!service || service.status === 'cancelled') return;

        try {
            setIsSubmitting(true);
            const updated = await upgradeClientService(String(service.id));
            setService(updated);
            setMessage('Your upgrade request has been received. Our team will contact you shortly.');
            setError(null);
        } catch (upgradeError) {
            setError(
                upgradeError instanceof Error
                    ? upgradeError.message
                    : 'Failed to request upgrade.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleCancel() {
        if (!service || service.status === 'cancelled') return;

        try {
            setIsSubmitting(true);
            const updated = await cancelClientService(String(service.id), {
                reason: cancelReason.trim() || null,
                cancel_type: cancelType,
            });
            setService(updated);
            setMessage(
                cancelType === 'end_of_cycle'
                    ? 'Cancellation scheduled for the end of the billing cycle.'
                    : 'Service cancelled immediately.',
            );
            setError(null);
            setShowCancelModal(false);
            setCancelReason('');
            setCancelType('end_of_cycle');
        } catch (cancelError) {
            setError(
                cancelError instanceof Error
                    ? cancelError.message
                    : 'Failed to cancel service.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleToggleAutoRenew(nextValue: boolean) {
        if (!service) return;

        try {
            setIsUpdatingRenewal(true);
            const updated = await updateClientServiceAutoRenew(String(service.id), nextValue);
            setService(updated);
            setMessage(`Auto-renew ${nextValue ? 'enabled' : 'disabled'}.`);
            setError(null);
        } catch (renewError) {
            setError(
                renewError instanceof Error
                    ? renewError.message
                    : 'Failed to update auto-renew setting.',
            );
        } finally {
            setIsUpdatingRenewal(false);
        }
    }

    async function handleDefaultPaymentMethodSave() {
        if (!service) return;

        try {
            setIsUpdatingRenewal(true);
            const updated = await updateClientServiceDefaultPaymentMethod(
                String(service.id),
                selectedMethodId ? Number(selectedMethodId) : null,
            );
            setService(updated);
            setMessage('Default payment method updated.');
            setError(null);
        } catch (methodError) {
            setError(
                methodError instanceof Error
                    ? methodError.message
                    : 'Failed to update default payment method.',
            );
        } finally {
            setIsUpdatingRenewal(false);
        }
    }

    if (isLoading) {
        return (
            <div className="max-w-7xl mx-auto py-12 animate-pulse space-y-8">
                <div className="h-6 w-32 rounded bg-white/5" />
                <div className="h-32 rounded-3xl bg-white/5" />
                <div className="grid gap-8 lg:grid-cols-3">
                    <div className="lg:col-span-2 h-96 rounded-3xl bg-white/5" />
                    <div className="h-96 rounded-3xl bg-white/5" />
                </div>
            </div>
        );
    }

    if (!service) {
        return (
            <div className="max-w-xl mx-auto py-32 text-center">
                <AlertCircle className="size-16 text-rose-500 mx-auto mb-6" />
                <h3 className="text-2xl font-bold text-warm-white">Service Not Found</h3>
                <p className="mt-2 text-warm-muted">We couldn&apos;t find the service you&apos;re looking for.</p>
                <Link to="/client/services" className="mt-8 inline-flex items-center gap-2 text-sm font-bold text-accent-400">
                    <ArrowLeft className="size-4" />
                    Back to Services
                </Link>
            </div>
        );
    }

    const isCancelled = service.status === 'cancelled';
    const isProvisioned = Boolean(service.pterodactyl_server_id);
    const panelLink = service.pterodactyl_panel_url && service.pterodactyl_identifier
        ? `${service.pterodactyl_panel_url}/server/${service.pterodactyl_identifier}`
        : null;

    return (
        <section className="max-w-7xl mx-auto space-y-10 py-4">
            <header className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
                <div>
                    <Link
                        to="/client/services"
                        className="group mb-4 inline-flex items-center gap-2 text-sm font-bold text-accent-400 hover:text-accent-300 transition-colors"
                    >
                        <ArrowLeft className="size-4 transition-transform group-hover:-translate-x-1" />
                        Back to Fleet
                    </Link>
                    <div className="flex items-center gap-3 mb-2">
                        <Terminal className="size-5 text-accent-400" />
                        <span className="text-sm font-bold uppercase tracking-widest text-warm-muted/40">Resource ID #{service.id}</span>
                    </div>
                    <h2 className="text-3xl font-black tracking-tight text-warm-white">
                        {service.product?.name ?? 'Server Instance'}
                    </h2>
                </div>
                <div className="flex items-center gap-4">
                    <StatusBadge status={service.status} />
                    {isProvisioned && (
                        <a
                            href={panelLink ?? '#'}
                            target="_blank"
                            rel="noreferrer"
                            className="btn-glow flex items-center gap-2 rounded-2xl bg-primary px-6 py-3 text-sm font-bold text-white transition-all hover:bg-primary/90"
                        >
                            Open Game Panel
                            <ExternalLink className="size-4" />
                        </a>
                    )}
                </div>
            </header>

            {message && (
                <div className="rounded-2xl border border-accent-500/20 bg-accent-500/10 p-4 text-sm text-accent-300 flex items-center gap-3">
                    <CheckCircle2 className="size-5" />
                    {message}
                </div>
            )}

            {error && (
                <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-sm text-rose-400 flex items-center gap-3">
                    <AlertCircle className="size-5" />
                    {error}
                </div>
            )}

            {service.status === 'provisioning' && (
                <div className="rounded-[2.5rem] border border-sky-500/20 bg-sky-500/5 p-8 flex items-center gap-6 overflow-hidden relative">
                    <div className="absolute right-0 top-0 h-full w-32 bg-gradient-to-l from-sky-500/5 to-transparent animate-pulse" />
                    <div className="size-16 rounded-full bg-sky-500/10 flex items-center justify-center text-sky-400 animate-spin">
                        <RefreshCcw className="size-8" />
                    </div>
                    <div>
                        <h4 className="text-lg font-bold text-warm-white">Ignition protocol started...</h4>
                        <p className="text-sky-400/70 text-sm">Your new server environment is being constructed. This usually takes less than 60 seconds.</p>
                    </div>
                </div>
            )}

            <div className="grid gap-10 lg:grid-cols-3">
                <div className="lg:col-span-2 space-y-10">
                    <article className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm">
                        <div className="flex items-center justify-between mb-8">
                            <h3 className="text-lg font-bold text-warm-white flex items-center gap-2">
                                <Settings className="size-5 text-accent-400" />
                                Hardware Manifest
                            </h3>
                        </div>
                        <div className="grid gap-6 sm:grid-cols-3">
                            <div className="rounded-2xl border border-white/5 bg-white/2 p-5 text-center">
                                <Cpu className="size-6 text-accent-400 mx-auto mb-3" />
                                <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40 mb-1">Compute</p>
                                <p className="text-lg font-black text-warm-white">{service.provisioning_limits?.cpu ?? '--'}%</p>
                            </div>
                            <div className="rounded-2xl border border-white/5 bg-white/2 p-5 text-center">
                                <HardDrive className="size-6 text-emerald-400 mx-auto mb-3" />
                                <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40 mb-1">Memory</p>
                                <p className="text-lg font-black text-warm-white">{service.provisioning_limits?.memory ?? '--'} MB</p>
                            </div>
                            <div className="rounded-2xl border border-white/5 bg-white/2 p-5 text-center">
                                <Database className="size-6 text-sky-400 mx-auto mb-3" />
                                <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40 mb-1">Disk</p>
                                <p className="text-lg font-black text-warm-white">{service.provisioning_limits?.disk ?? '--'} MB</p>
                            </div>
                        </div>
                        <div className="mt-10 space-y-4">
                            <div className="flex justify-between items-center py-4 border-b border-white/5">
                                <span className="text-sm text-warm-muted">Physical Node</span>
                                <span className="text-sm font-bold text-warm-white">{service.pterodactyl_node_name ?? 'Allocating...'}</span>
                            </div>
                            <div className="flex justify-between items-center py-4 border-b border-white/5">
                                <span className="text-sm text-warm-muted">Instance Lifecycle</span>
                                <span className="text-sm font-bold text-warm-white capitalize">{service.status}</span>
                            </div>
                            <div className="flex justify-between items-center py-4">
                                <span className="text-sm text-warm-muted">Uptime Status</span>
                                <span className="text-sm font-bold text-warm-white capitalize">{service.pterodactyl_server_status ?? 'Idle'}</span>
                            </div>
                        </div>
                    </article>

                    <article className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-8 shadow-sm">
                        <h3 className="text-lg font-bold text-warm-white flex items-center gap-2 mb-8">
                            <Zap className="size-5 text-accent-400" />
                            Management Controls
                        </h3>
                        <div className="flex flex-wrap gap-4">
                            <button
                                type="button"
                                disabled={isCancelled || isSubmitting}
                                onClick={() => void handleUpgrade()}
                                className="btn-glow flex flex-1 items-center justify-center gap-2 rounded-2xl bg-white/5 border border-white/10 px-6 py-4 text-sm font-bold text-warm-white hover:bg-white/10 transition-all disabled:opacity-50"
                            >
                                <Zap className="size-4" />
                                Upgrade Resources
                            </button>
                            <button
                                type="button"
                                disabled={isCancelled || isSubmitting}
                                onClick={() => setShowCancelModal(true)}
                                className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-rose-500/5 border border-rose-500/20 px-6 py-4 text-sm font-bold text-rose-400 hover:bg-rose-500/10 transition-all disabled:opacity-50"
                            >
                                <XCircle className="size-4" />
                                Terminate Instance
                            </button>
                        </div>
                    </article>
                </div>

                <aside className="space-y-10">
                    <article className="rounded-3xl border border-white/8 bg-white/2 p-8 relative overflow-hidden">
                        <div className="absolute top-0 right-0 p-3 opacity-10">
                            <CreditCard className="size-24" />
                        </div>
                        <h4 className="text-lg font-bold text-warm-white flex items-center gap-2 mb-6">
                            <Clock className="size-5 text-accent-400" />
                            Billing Cycle
                        </h4>
                        <div className="space-y-6">
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40 mb-1">Next Payment</p>
                                <p className="text-xl font-black text-warm-white">{formatDate(service.next_due_at ?? service.next_due_date)}</p>
                            </div>
                            <div>
                                <p className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40 mb-1">Active Plan</p>
                                <p className="text-lg font-bold text-warm-white">{service.billing_summary}</p>
                            </div>

                            {service.billing_type === 'recurring' && (
                                <div className="pt-6 border-t border-white/5 space-y-6">
                                    <div className="flex items-center justify-between">
                                        <span className="text-sm text-warm-muted">Auto-Renew</span>
                                        <button
                                            onClick={() => void handleToggleAutoRenew(!service.auto_renew)}
                                            className={cn(
                                                "relative inline-flex h-6 w-11 items-center rounded-full transition-all focus:outline-none",
                                                service.auto_renew ? "bg-primary" : "bg-white/40"
                                            )}
                                        >
                                            <span className={cn(
                                                "inline-block h-4 w-4 transform rounded-full bg-white transition-transform",
                                                service.auto_renew ? "translate-x-6" : "translate-x-1"
                                            )} />
                                        </button>
                                    </div>

                                    <div className="space-y-3">
                                        <label className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40 block">Payment Method</label>
                                        <select
                                            value={selectedMethodId}
                                            onChange={(event) => setSelectedMethodId(event.target.value)}
                                            className="w-full rounded-xl border border-white/10 bg-white/5 px-4 py-3 text-sm text-warm-white"
                                            disabled={isUpdatingRenewal}
                                        >
                                            <option value="">None Selected</option>
                                            {paymentMethods.map((method) => (
                                                <option key={method.id} value={method.id}>
                                                    {method.label} (•{method.masked_details.slice(-4)})
                                                </option>
                                            ))}
                                        </select>
                                        <button
                                            type="button"
                                            onClick={() => void handleDefaultPaymentMethodSave()}
                                            disabled={isUpdatingRenewal || isCancelled}
                                            className="w-full rounded-xl bg-white/5 border border-white/10 py-3 text-xs font-black uppercase tracking-widest text-warm-white hover:bg-white/10 transition-colors disabled:opacity-50"
                                        >
                                            Update Method
                                        </button>
                                    </div>
                                </div>
                            )}
                        </div>
                    </article>

                    <article className="rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-8">
                        <h4 className="text-sm font-bold uppercase tracking-widest text-warm-muted/40 mb-6 underline decoration-accent-400/30">Reference Links</h4>
                        <div className="space-y-4">
                            <div className="flex justify-between py-2 items-center">
                                <span className="text-xs text-warm-muted">Service ID</span>
                                <span className="text-xs font-mono font-bold text-warm-white">#{service.id}</span>
                            </div>
                            <div className="flex justify-between py-2 items-center">
                                <span className="text-xs text-warm-muted">Parent Order</span>
                                <span className="text-xs font-mono font-bold text-warm-white">{service.order ? `#${service.order.id}` : '-'}</span>
                            </div>
                            <div className="flex justify-between py-2 items-center">
                                <span className="text-xs text-warm-muted">Latest Invoice</span>
                                {service.invoice ? (
                                    <Link
                                        to={`/client/invoices/${service.invoice.id}`}
                                        className="text-xs font-bold text-accent-400 hover:text-accent-300 transition-colors"
                                    >
                                        #{service.invoice.id}
                                    </Link>
                                ) : (
                                    <span className="text-xs font-bold text-warm-white">-</span>
                                )}
                            </div>
                        </div>
                    </article>
                </aside>
            </div>

            {showCancelModal && (
                <div
                    className="fixed inset-0 z-[100] flex items-center justify-center bg-black/80 backdrop-blur-sm p-4 overflow-y-auto"
                    onClick={() => {
                        setShowCancelModal(false);
                        setCancelReason('');
                        setCancelType('end_of_cycle');
                    }}
                >
                    <div
                        className="w-full max-w-lg rounded-[2.5rem] border border-white/10 bg-[var(--panel-surface)] p-10 shadow-2xl relative"
                        onClick={(event) => event.stopPropagation()}
                    >
                        <div className="absolute top-0 left-0 w-full h-2 bg-gradient-to-r from-rose-600 to-transparent rounded-t-[2.5rem]" />
                        <h3 className="text-2xl font-black tracking-tight text-warm-white flex items-center gap-3">
                            <ShieldAlert className="size-7 text-rose-500" />
                            Terminate Service
                        </h3>
                        <p className="mt-4 text-warm-muted leading-relaxed">
                            We&apos;re sorry to see you go. Terminating your service will permanently delete all associated data and configurations.
                        </p>

                        <div className="mt-8 space-y-8">
                            <div className="space-y-4">
                                <label className={cn(
                                    "flex items-center gap-4 p-4 rounded-2xl border transition-all cursor-pointer group",
                                    cancelType === 'end_of_cycle' ? "bg-white/5 border-white/20" : "bg-transparent border-white/5 hover:border-white/10"
                                )}>
                                    <input
                                        type="radio"
                                        name="cancel-type"
                                        value="end_of_cycle"
                                        checked={cancelType === 'end_of_cycle'}
                                        onChange={() => setCancelType('end_of_cycle')}
                                        className="size-4 accent-white"
                                    />
                                    <div>
                                        <p className="text-sm font-bold text-warm-white">Graceful Termination</p>
                                        <p className="text-xs text-warm-muted">Keep access until your current cycle ends.</p>
                                    </div>
                                </label>
                                <label className={cn(
                                    "flex items-center gap-4 p-4 rounded-2xl border transition-all cursor-pointer group",
                                    cancelType === 'immediate' ? "bg-rose-500/5 border-rose-500/20" : "bg-transparent border-white/5 hover:border-white/10"
                                )}>
                                    <input
                                        type="radio"
                                        name="cancel-type"
                                        value="immediate"
                                        checked={cancelType === 'immediate'}
                                        onChange={() => setCancelType('immediate')}
                                        className="size-4 accent-rose-500"
                                    />
                                    <div>
                                        <p className="text-sm font-bold text-warm-white">Immediate Wipe</p>
                                        <p className="text-xs text-warm-muted">All data will be destroyed right now.</p>
                                    </div>
                                </label>
                            </div>

                            <div className="space-y-3">
                                <label className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40 block">Reason for leaving (Optional)</label>
                                <textarea
                                    value={cancelReason}
                                    onChange={(event) => setCancelReason(event.target.value)}
                                    rows={3}
                                    className="w-full rounded-2xl border border-white/10 bg-white/5 px-5 py-4 text-sm text-warm-white placeholder:text-warm-muted/20"
                                    placeholder="Help us improve..."
                                />
                            </div>
                        </div>

                        <div className="mt-10 flex flex-col gap-3">
                            <button
                                type="button"
                                disabled={isSubmitting}
                                onClick={() => void handleCancel()}
                                className="w-full rounded-2xl bg-rose-600 py-5 text-sm font-black uppercase tracking-widest text-white hover:bg-rose-500 transition-colors shadow-lg active:scale-95 disabled:opacity-50"
                            >
                                {isSubmitting ? 'Processing...' : 'Confirm Termination'}
                            </button>
                            <button
                                type="button"
                                onClick={() => {
                                    setShowCancelModal(false);
                                    setCancelReason('');
                                    setCancelType('end_of_cycle');
                                }}
                                className="w-full py-4 text-xs font-bold text-warm-muted hover:text-warm-white transition-colors"
                            >
                                Nevermind, I&apos;ll keep it
                            </button>
                        </div>
                    </div>
                </div>
            )}
        </section>
    );
}

