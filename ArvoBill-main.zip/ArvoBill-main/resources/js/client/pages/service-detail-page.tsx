import { useEffect, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { StatusBadge } from '@/components/status-badge';
import {
    cancelClientService,
    getClientService,
    upgradeClientService,
} from '@/lib/services-api';
import { formatCurrency } from '@/lib/products-api';
import type { ServiceSummary } from '@/types/service';

function formatDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export function ServiceDetailPage() {
    const { id = '' } = useParams();
    const [service, setService] = useState<ServiceSummary | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [isSubmitting, setIsSubmitting] = useState(false);
    const [message, setMessage] = useState<string | null>(null);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        async function loadService() {
            try {
                const data = await getClientService(id);
                setService(data);
                setError(null);
            } catch (loadError) {
                setError(
                    loadError instanceof Error
                        ? loadError.message
                        : 'Failed to load service.',
                );
            } finally {
                setIsLoading(false);
            }
        }

        void loadService();
    }, [id]);

    async function handleUpgrade() {
        if (!service || service.status === 'cancelled') return;

        try {
            setIsSubmitting(true);
            const updated = await upgradeClientService(String(service.id));
            setService(updated);
            setMessage('Upgrade request placeholder triggered.');
            setError(null);
        } catch (upgradeError) {
            setError(
                upgradeError instanceof Error
                    ? upgradeError.message
                    : 'Failed to request upgrade.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    async function handleCancel() {
        if (!service || service.status === 'cancelled') return;

        const confirmed = window.confirm(
            'Are you sure you want to cancel this service?',
        );

        if (!confirmed) return;

        try {
            setIsSubmitting(true);
            const updated = await cancelClientService(String(service.id));
            setService(updated);
            setMessage('Service cancellation requested.');
            setError(null);
        } catch (cancelError) {
            setError(
                cancelError instanceof Error
                    ? cancelError.message
                    : 'Failed to cancel service.',
            );
        } finally {
            setIsSubmitting(false);
        }
    }

    if (isLoading) {
        return <div className="text-sm text-white/70">Loading service...</div>;
    }

    if (!service) {
        return <div className="text-sm text-white/70">Service not found.</div>;
    }

    const isCancelled = service.status === 'cancelled';
    const isProvisioned = Boolean(service.pterodactyl_server_id);
    const panelLink = service.pterodactyl_panel_url && service.pterodactyl_identifier
        ? `${service.pterodactyl_panel_url}/server/${service.pterodactyl_identifier}`
        : null;

    return (
        <section className="space-y-6">
            <div className="flex items-start justify-between gap-4">
                <div>
                    <h2 className="text-xl font-semibold">
                        Service #{service.id}
                    </h2>
                    <p className="mt-1 text-sm text-white/70">
                        Product: {service.product?.name ?? '-'}
                    </p>
                </div>
                <Link
                    to="/client/services"
                    className="rounded-lg border border-white/20 px-3 py-2 text-sm font-medium hover:bg-white/10"
                >
                    Back to services
                </Link>
            </div>

            {message ? (
                <div className="rounded-lg border border-[var(--panel-accent)]/40 bg-[var(--panel-accent)]/15 p-4 text-sm text-[var(--panel-text)]">
                    {message}
                </div>
            ) : null}

            {error ? (
                <div className="rounded-lg border border-rose-200 bg-rose-50 p-4 text-sm text-rose-700 dark:border-rose-900/40 dark:bg-rose-900/20 dark:text-rose-300">
                    {error}
                </div>
            ) : null}

            <div className="grid gap-4 md:grid-cols-2">
                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                    <h3 className="font-semibold">Service Details</h3>
                    <dl className="mt-4 space-y-3 text-sm">
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Status</dt>
                            <dd>
                                <StatusBadge status={service.status} />
                            </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Billing Cycle</dt>
                            <dd className="capitalize">{service.billing_cycle}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Next Due Date</dt>
                            <dd>{formatDate(service.next_due_date)}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Pterodactyl Server ID</dt>
                            <dd>{service.pterodactyl_server_id ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Node</dt>
                            <dd>{service.pterodactyl_node_name ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Server Status</dt>
                            <dd>{service.pterodactyl_server_status ?? '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Resource Limits</dt>
                            <dd>
                                {service.provisioning_limits
                                    ? `${service.provisioning_limits.memory}MB / ${service.provisioning_limits.cpu}% / ${service.provisioning_limits.disk}MB`
                                    : '-'}
                            </dd>
                        </div>
                    </dl>
                </article>

                <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                    <h3 className="font-semibold">Billing Links</h3>
                    <dl className="mt-4 space-y-3 text-sm">
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Order</dt>
                            <dd>{service.order ? `#${service.order.id}` : '-'}</dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Invoice</dt>
                            <dd>
                                {service.invoice ? (
                                    <Link
                                        to={`/client/invoices/${service.invoice.id}`}
                                        className="text-[var(--panel-primary)] hover:underline"
                                    >
                                        #{service.invoice.id}
                                    </Link>
                                ) : (
                                    '-'
                                )}
                            </dd>
                        </div>
                        <div className="flex items-center justify-between gap-4">
                            <dt className="text-white/70">Invoice Total</dt>
                            <dd>
                                {service.invoice
                                    ? formatCurrency(service.invoice.total)
                                    : '-'}
                            </dd>
                        </div>
                    </dl>
                </article>
            </div>

            <article className="rounded-xl border border-white/10 bg-[var(--panel-surface)] p-5 shadow-sm">
                <h3 className="font-semibold">Actions</h3>
                <div className="mt-4 flex flex-wrap gap-3">
                    {isProvisioned ? (
                        <a
                            href={panelLink ?? '#'}
                            target="_blank"
                            rel="noreferrer"
                            className={[
                                'rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold hover:bg-white/10',
                                panelLink ? '' : 'pointer-events-none cursor-not-allowed opacity-50',
                            ].join(' ')}
                        >
                            Go to Game Panel
                        </a>
                    ) : (
                        <button
                            type="button"
                            disabled
                            className="rounded-lg border border-white/20 px-4 py-2 text-sm font-semibold opacity-50"
                        >
                            Not Provisioned Yet
                        </button>
                    )}
                    <button
                        type="button"
                        disabled={isCancelled || isSubmitting}
                        onClick={() => void handleUpgrade()}
                        className="rounded-lg bg-[var(--panel-primary)] px-4 py-2 text-sm font-semibold text-white hover:brightness-110 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Upgrade Plan
                    </button>
                    <button
                        type="button"
                        disabled={isCancelled || isSubmitting}
                        onClick={() => void handleCancel()}
                        className="rounded-lg border border-rose-400/40 bg-rose-500/20 px-4 py-2 text-sm font-semibold text-rose-100 hover:bg-rose-500/30 disabled:cursor-not-allowed disabled:opacity-50"
                    >
                        Cancel Service
                    </button>
                </div>
            </article>
        </section>
    );
}
