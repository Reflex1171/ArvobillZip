import { useEffect, useState } from 'react';
import { getClientAffiliateData, requestAffiliatePayout } from '@/lib/affiliate-api';
import type { AffiliateClientPayload } from '@/types/affiliate';
import { formatCurrency } from '@/lib/billing-api';
import { Share2, Copy, TrendingUp, Users, Clock, Wallet, CheckCircle2, Trophy, Coins } from 'lucide-react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
    return twMerge(clsx(inputs));
}

function formatDate(value: string | null): string {
    if (!value) return '-';

    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

function StatCard({ label, value, detail, icon: Icon, colorClass, isLoading }: {
    label: string;
    value: string | number;
    detail: string;
    icon: any;
    colorClass: string;
    isLoading: boolean;
}) {
    return (
        <article className="card-lift relative overflow-hidden rounded-3xl border border-white/8 bg-[var(--panel-surface)] p-6 shadow-sm">
            <div className={cn("absolute -right-4 -top-4 size-24 rounded-full opacity-5 blur-2xl", colorClass)} />
            <div className="flex items-center justify-between mb-4">
                <div className={cn("flex size-10 items-center justify-center rounded-xl bg-white/5", colorClass.replace('bg-', 'text-'))}>
                    <Icon className="size-5" />
                </div>
                <span className="text-[10px] font-bold uppercase tracking-widest text-warm-muted/40">{label}</span>
            </div>
            <p className="text-3xl font-black tracking-tight text-warm-white">
                {isLoading ? <span className="opacity-20">---</span> : value}
            </p>
            <p className="mt-2 text-xs text-warm-muted leading-relaxed">
                {detail}
            </p>
        </article>
    );
}

export function AffiliatePage() {
    const [data, setData] = useState<AffiliateClientPayload | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [copied, setCopied] = useState(false);
    const [isPayoutModalOpen, setIsPayoutModalOpen] = useState(false);
    const [payoutAmount, setPayoutAmount] = useState<string>('');
    const [payoutMethod, setPayoutMethod] = useState<'bank_transfer' | 'paypal' | 'crypto' | 'other'>('paypal');
    const [payoutDetails, setPayoutDetails] = useState('');
    const [payoutError, setPayoutError] = useState<string | null>(null);
    const [isSubmittingPayout, setIsSubmittingPayout] = useState(false);

    async function loadAffiliateData() {
        try {
            setIsLoading(true);
            const payload = await getClientAffiliateData();
            setData(payload);
            setError(null);
        } catch (loadError) {
            setError(loadError instanceof Error ? loadError.message : 'Failed to load affiliate data.');
        } finally {
            setIsLoading(false);
        }
    }

    useEffect(() => {
        void loadAffiliateData();
    }, []);

    async function copyReferralLink() {
        if (!data?.referral_link) return;

        try {
            await navigator.clipboard.writeText(data.referral_link);
            setCopied(true);
            setTimeout(() => setCopied(false), 2000);
        } catch {
            // clipboard may be blocked
        }
    }

    function openPayoutModal() {
        const available = data?.stats.available_for_payout ?? 0;
        setPayoutAmount(available > 0 ? available.toFixed(2) : '');
        setPayoutMethod('paypal');
        setPayoutDetails('');
        setPayoutError(null);
        setIsPayoutModalOpen(true);
    }

    function closePayoutModal() {
        setIsPayoutModalOpen(false);
        setPayoutError(null);
        setIsSubmittingPayout(false);
    }

    async function submitPayoutRequest() {
        const amount = Number(payoutAmount);
        if (!Number.isFinite(amount) || amount <= 0) {
            setPayoutError('Enter a valid payout amount.');
            return;
        }

        try {
            setIsSubmittingPayout(true);
            setPayoutError(null);
            await requestAffiliatePayout({
                amount,
                payout_method: payoutMethod,
                payout_details: payoutDetails.trim() === '' ? null : payoutDetails.trim(),
            });

            await loadAffiliateData();
            closePayoutModal();
        } catch (submitError) {
            setPayoutError(
                submitError instanceof Error ? submitError.message : 'Failed to submit payout request.',
            );
        } finally {
            setIsSubmittingPayout(false);
        }
    }

    return (
        <section className="max-w-7xl mx-auto space-y-10 py-4">
            <header className="flex flex-col gap-6 lg:flex-row lg:items-end lg:justify-between">
                <div>
                    <div className="flex items-center gap-2 mb-2 text-accent-400">
                        <Trophy className="size-5" />
                        <span className="text-sm font-bold uppercase tracking-wider">Rewards Program</span>
                    </div>
                    <h2 className="text-3xl font-bold tracking-tight text-warm-white">
                        Grow with us, earn forever.
                    </h2>
                    <p className="mt-2 text-lg text-warm-muted leading-relaxed max-w-2xl">
                        Invite your friends to ArvoHost and earn <span className="text-accent-400 font-bold">recurring commissions</span> for every service they keep active.
                    </p>
                </div>
            </header>

            {error ? (
                <div className="rounded-2xl border border-rose-500/20 bg-rose-500/10 p-4 text-sm text-rose-400 text-center">
                    {error}
                </div>
            ) : null}

            <div className="grid gap-8 lg:grid-cols-[1fr,400px]">
                <div className="space-y-8">
                    <article className="relative overflow-hidden rounded-[2.5rem] border border-accent-500/20 bg-accent-600/5 p-8 shadow-2xl backdrop-blur-sm">
                        <div className="absolute -right-20 -top-20 size-64 rounded-full bg-accent-600/10 blur-3xl" />
                        <div className="relative z-10">
                            <h3 className="text-sm font-bold uppercase tracking-widest text-accent-400 flex items-center gap-2 mb-4">
                                <Share2 className="size-4" />
                                Your Unique Referral Link
                            </h3>
                            <div className="flex flex-col gap-4 sm:flex-row sm:items-center">
                                <div className="flex-1 rounded-2xl border border-white/10 bg-white/5 px-6 py-4 font-mono text-sm text-warm-white/80">
                                    {data?.referral_link ?? 'Loading your link...'}
                                </div>
                                <button
                                    type="button"
                                    onClick={() => void copyReferralLink()}
                                    disabled={!data?.referral_link}
                                    className="btn-glow flex items-center justify-center gap-2 rounded-2xl bg-primary px-8 py-4 text-sm font-bold text-white transition-all hover:bg-primary/90 active:scale-95 disabled:opacity-50"
                                >
                                    {copied ? <CheckCircle2 className="size-4" /> : <Copy className="size-4" />}
                                    {copied ? 'Copied!' : 'Copy Link'}
                                </button>
                            </div>
                            <p className="mt-4 text-xs text-warm-muted flex items-center gap-2">
                                <Clock className="size-3" />
                                Commissions are tracked instantly upon signup.
                            </p>
                        </div>
                    </article>

                    <div className="grid gap-4 grid-cols-2 md:grid-cols-3">
                        <StatCard
                            label="Total Clicks"
                            value={data?.stats.clicks ?? 0}
                            detail="Visits through your link"
                            icon={TrendingUp}
                            colorClass="bg-sky-500"
                            isLoading={isLoading}
                        />
                        <StatCard
                            label="Signups"
                            value={data?.stats.signups ?? 0}
                            detail="Members you've brought in"
                            icon={Users}
                            colorClass="bg-emerald-500"
                            isLoading={isLoading}
                        />
                        <StatCard
                            label="Current Balance"
                            value={formatCurrency(data?.stats.affiliate_balance ?? 0)}
                            detail="Ready for payout"
                            icon={Coins}
                            colorClass="bg-amber-500"
                            isLoading={isLoading}
                        />
                    </div>
                </div>

                <aside className="space-y-6">
                    <div className="rounded-3xl border border-white/8 bg-white/2 p-8">
                        <h4 className="text-lg font-bold text-warm-white flex items-center gap-2 mb-4">
                            <Wallet className="size-5 text-accent-400" />
                            Earnings Summary
                        </h4>
                        <div className="space-y-4">
                            <div className="flex justify-between items-center py-2">
                                <span className="text-sm text-warm-muted">Pending Commissions</span>
                                <span className="text-sm border border-white/5 bg-white/5 font-bold text-warm-white px-3 py-1 rounded-full">
                                    {isLoading ? '...' : formatCurrency(data?.stats.pending_earnings ?? 0)}
                                </span>
                            </div>
                            <div className="flex justify-between items-center py-2">
                                <span className="text-sm text-warm-muted">Lifetime Approved</span>
                                <span className="text-sm border border-white/5 bg-white/5 font-bold text-warm-white px-3 py-1 rounded-full">
                                    {isLoading ? '...' : formatCurrency(data?.stats.approved_earnings ?? 0)}
                                </span>
                            </div>
                            <div className="flex justify-between items-center py-2">
                                <span className="text-sm text-warm-muted">Pending Payouts</span>
                                <span className="text-sm border border-white/5 bg-white/5 font-bold text-warm-white px-3 py-1 rounded-full">
                                    {isLoading ? '...' : formatCurrency(data?.stats.pending_payouts ?? 0)}
                                </span>
                            </div>
                            <div className="flex justify-between items-center py-2">
                                <span className="text-sm text-warm-muted">Available for Payout</span>
                                <span className="text-sm border border-white/5 bg-white/5 font-bold text-emerald-300 px-3 py-1 rounded-full">
                                    {isLoading ? '...' : formatCurrency(data?.stats.available_for_payout ?? 0)}
                                </span>
                            </div>
                        </div>
                        <button
                            type="button"
                            onClick={openPayoutModal}
                            disabled={(data?.stats.available_for_payout ?? 0) <= 0}
                            className="w-full mt-6 py-3 rounded-2xl bg-white/5 border border-white/10 text-sm font-bold text-warm-white hover:bg-white/10 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                        >
                            Request Payout
                        </button>
                        {(data?.payout_requests.length ?? 0) > 0 ? (
                            <div className="mt-6 border-t border-white/8 pt-4 space-y-2">
                                <p className="text-xs font-bold uppercase tracking-wider text-warm-muted/60">Recent Payout Requests</p>
                                {data?.payout_requests.slice(0, 3).map((request) => (
                                    <div key={request.id} className="flex items-center justify-between text-xs">
                                        <span className="text-warm-muted/80">{formatCurrency(request.amount)}</span>
                                        <span className={cn(
                                            'rounded-full border px-2 py-0.5 font-bold uppercase tracking-wider',
                                            request.status === 'paid'
                                                ? 'border-emerald-500/20 bg-emerald-500/10 text-emerald-300'
                                                : request.status === 'rejected' || request.status === 'cancelled'
                                                    ? 'border-rose-500/20 bg-rose-500/10 text-rose-300'
                                                    : request.status === 'processing'
                                                        ? 'border-sky-500/20 bg-sky-500/10 text-sky-300'
                                                        : 'border-amber-500/20 bg-amber-500/10 text-amber-300'
                                        )}>
                                            {request.status}
                                        </span>
                                    </div>
                                ))}
                            </div>
                        ) : null}
                    </div>
                </aside>
            </div>

            <article className="overflow-hidden rounded-3xl border border-white/8 bg-[var(--panel-surface)] shadow-lg">
                <div className="border-b border-white/6 px-8 py-5">
                    <h3 className="text-sm font-bold uppercase tracking-widest text-warm-white/60">Commission Log</h3>
                </div>
                <div className="overflow-x-auto">
                    <table className="min-w-full text-left text-sm">
                        <thead>
                            <tr className="bg-white/2">
                                <th className="px-8 py-4 font-bold uppercase tracking-wider text-warm-muted/40">Invoice</th>
                                <th className="px-8 py-4 font-bold uppercase tracking-wider text-warm-muted/40">Amount</th>
                                <th className="px-8 py-4 font-bold uppercase tracking-wider text-warm-muted/40">Status</th>
                                <th className="px-8 py-4 font-bold uppercase tracking-wider text-warm-muted/40">Eligible On</th>
                                <th className="px-8 py-4 font-bold uppercase tracking-wider text-warm-muted/40">Earned</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-white/4">
                            {isLoading ? (
                                Array.from({ length: 3 }).map((_, i) => (
                                    <tr key={i} className="animate-pulse">
                                        <td className="px-8 py-5" colSpan={5}><div className="h-4 w-full rounded bg-white/5" /></td>
                                    </tr>
                                ))
                            ) : (data?.earnings.length ?? 0) === 0 ? (
                                <tr>
                                    <td className="px-8 py-12 text-center text-warm-muted/60" colSpan={5}>
                                        No commissions yet. Share your link to start earning!
                                    </td>
                                </tr>
                            ) : (
                                data?.earnings.map((earning) => (
                                    <tr key={earning.id} className="group hover:bg-white/1 transition-colors">
                                        <td className="px-8 py-5">
                                            <span className="font-bold text-warm-white">#{earning.invoice_id}</span>
                                        </td>
                                        <td className="px-8 py-5">
                                            <span className="font-bold text-accent-400">{formatCurrency(earning.amount)}</span>
                                        </td>
                                        <td className="px-8 py-5 capitalize">
                                            <span className={cn(
                                                "inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider border",
                                                earning.status === 'approved' ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                                            )}>
                                                {earning.status}
                                            </span>
                                        </td>
                                        <td className="px-8 py-5 text-warm-muted/80">{formatDate(earning.eligible_at)}</td>
                                        <td className="px-8 py-5 text-warm-muted/60">{formatDate(earning.created_at)}</td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </article>

            {isPayoutModalOpen ? (
                <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4">
                    <div className="w-full max-w-lg rounded-3xl border border-white/10 bg-[var(--panel-surface)] p-6 shadow-2xl">
                        <h3 className="text-lg font-bold text-warm-white">Request Affiliate Payout</h3>
                        <p className="mt-1 text-sm text-warm-muted">
                            Submit a payout request for admin review.
                        </p>

                        <div className="mt-5 space-y-4">
                            <div>
                                <label className="mb-1 block text-xs font-bold uppercase tracking-wider text-warm-muted/60">
                                    Available
                                </label>
                                <div className="rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-emerald-300">
                                    {formatCurrency(data?.stats.available_for_payout ?? 0)}
                                </div>
                            </div>

                            <div>
                                <label className="mb-1 block text-xs font-bold uppercase tracking-wider text-warm-muted/60">
                                    Amount
                                </label>
                                <input
                                    type="number"
                                    step="0.01"
                                    min="1"
                                    value={payoutAmount}
                                    onChange={(event) => setPayoutAmount(event.target.value)}
                                    className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-warm-white outline-none focus:border-accent-500/60"
                                />
                            </div>

                            <div>
                                <label className="mb-1 block text-xs font-bold uppercase tracking-wider text-warm-muted/60">
                                    Method
                                </label>
                                <select
                                    value={payoutMethod}
                                    onChange={(event) => setPayoutMethod(event.target.value as 'bank_transfer' | 'paypal' | 'crypto' | 'other')}
                                    className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-warm-white outline-none focus:border-accent-500/60"
                                >
                                    <option value="paypal">PayPal</option>
                                    <option value="bank_transfer">Bank Transfer</option>
                                    <option value="crypto">Crypto</option>
                                    <option value="other">Other</option>
                                </select>
                            </div>

                            <div>
                                <label className="mb-1 block text-xs font-bold uppercase tracking-wider text-warm-muted/60">
                                    Payout Details
                                </label>
                                <textarea
                                    value={payoutDetails}
                                    onChange={(event) => setPayoutDetails(event.target.value)}
                                    rows={3}
                                    placeholder="PayPal email, bank details, wallet address, or notes"
                                    className="w-full rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-sm text-warm-white outline-none focus:border-accent-500/60"
                                />
                            </div>
                        </div>

                        {payoutError ? (
                            <div className="mt-4 rounded-xl border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-300">
                                {payoutError}
                            </div>
                        ) : null}

                        <div className="mt-6 flex items-center justify-end gap-3">
                            <button
                                type="button"
                                onClick={closePayoutModal}
                                className="rounded-xl border border-white/15 px-4 py-2 text-sm font-semibold text-warm-white hover:bg-white/5"
                            >
                                Cancel
                            </button>
                            <button
                                type="button"
                                onClick={() => void submitPayoutRequest()}
                                disabled={isSubmittingPayout}
                                className="rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-white hover:bg-primary/90 disabled:opacity-50"
                            >
                                {isSubmittingPayout ? 'Submitting...' : 'Submit Request'}
                            </button>
                        </div>
                    </div>
                </div>
            ) : null}
        </section>
    );
}
