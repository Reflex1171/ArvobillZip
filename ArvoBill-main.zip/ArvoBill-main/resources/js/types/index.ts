export type * from './auth';
export type * from './navigation';
export type * from './ui';

import type { Auth } from './auth';

export type SharedData = {
    name: string;
    auth: Auth;
    sidebarOpen: boolean;
    socialProviders?: {
        google: boolean;
        apple: boolean;
    };
    theme?: {
        brand_name?: string | null;
        site_title?: string | null;
        logo_url?: string | null;
    };
    [key: string]: unknown;
};
