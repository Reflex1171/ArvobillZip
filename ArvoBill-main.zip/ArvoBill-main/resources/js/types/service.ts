export type ServiceStatus =
    | 'pending'
    | 'provisioning'
    | 'active'
    | 'suspended'
    | 'cancelled';

export type ServiceSummary = {
    id: number;
    status: ServiceStatus;
    billing_cycle: 'monthly' | string;
    next_due_date: string | null;
    pterodactyl_server_id: string | null;
    pterodactyl_node_id: number | null;
    pterodactyl_egg_id: number | null;
    pterodactyl_allocation_id: number | null;
    pterodactyl_identifier: string | null;
    pterodactyl_server_status: string | null;
    pterodactyl_node_name: string | null;
    pterodactyl_panel_url: string | null;
    provisioning_limits: {
        memory: number;
        cpu: number;
        disk: number;
    } | null;
    created_at: string | null;
    updated_at: string | null;
    product: {
        id: number;
        name: string;
        slug: string;
    } | null;
    user?: {
        id: number;
        name: string;
        email: string;
    } | null;
    order: {
        id: number;
        status: string;
    } | null;
    invoice: {
        id: number;
        status: string;
        total: number;
        due_date: string | null;
    } | null;
};
