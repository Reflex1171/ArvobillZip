export type ServiceStatus =
    | 'pending'
    | 'provisioning'
    | 'active'
    | 'suspended'
    | 'cancelled'
    | 'failed';

export type ServiceSummary = {
    id: number;
    status: ServiceStatus;
    billing_type: 'one_time' | 'recurring' | string;
    billing_interval: number | null;
    billing_period: 'day' | 'week' | 'month' | 'year' | null;
    billing_summary: string;
    billing_cycle: string;
    auto_renew: boolean;
    renewal_failure_count: number;
    next_due_at: string | null;
    next_due_date: string | null;
    cancel_at_period_end: boolean;
    cancellation_reason: string | null;
    cancel_requested_at: string | null;
    cancelled_at: string | null;
    pterodactyl_server_id: string | null;
    pterodactyl_node_id: number | null;
    pterodactyl_egg_id: number | null;
    pterodactyl_allocation_id: number | null;
    pterodactyl_identifier: string | null;
    pterodactyl_server_status: string | null;
    pterodactyl_node_name: string | null;
    pterodactyl_panel_url: string | null;
    provisioning_limits: {
        memory: number;
        cpu: number;
        disk: number;
    } | null;
    provisioning_error: string | null;
    created_at: string | null;
    updated_at: string | null;
    product: {
        id: number;
        name: string;
        slug: string;
    } | null;
    user?: {
        id: number;
        name: string;
        email: string;
    } | null;
    order: {
        id: number;
        status: string;
    } | null;
    invoice: {
        id: number;
        status: string;
        total: number;
        due_date: string | null;
    } | null;
    default_payment_method?: {
        id: number;
        provider: string;
        label: string;
        masked_details: string;
    } | null;
};
