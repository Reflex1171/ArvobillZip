export type OrderStatus = 'pending' | 'completed' | 'cancelled';
export type InvoiceStatus = 'unpaid' | 'paid' | 'cancelled';
export type PaymentStatus = 'pending' | 'paid' | 'failed';

export type OrderSummary = {
    id: number;
    status: OrderStatus;
    created_at: string | null;
    updated_at: string | null;
    product: {
        id: number;
        name: string;
        slug: string;
    } | null;
    configurations: Array<{
        id: number;
        configuration_key: string;
        selected_value: string;
        price_modifier: number;
    }> | null;
    invoice: {
        id: number;
        status: InvoiceStatus;
        subtotal: number;
        tax: number | null;
        total: number;
        due_date: string | null;
        items: InvoiceItem[] | null;
    } | null;
    user?: {
        id: number;
        name: string;
        email: string;
    } | null;
};

export type InvoiceItem = {
    id: number;
    description: string;
    amount: number;
};

export type InvoiceSummary = {
    id: number;
    status: InvoiceStatus;
    subtotal: number;
    tax: number | null;
    total: number;
    due_date: string | null;
    created_at: string | null;
    order: {
        id: number;
        status: OrderStatus;
        product: {
            id: number;
            name: string;
            slug: string;
        } | null;
    } | null;
    items: InvoiceItem[] | null;
    user?: {
        id: number;
        name: string;
        email: string;
    } | null;
};

export type PaymentSummary = {
    id: number;
    provider: 'stripe' | 'paypal' | string;
    provider_payment_id: string;
    amount: number;
    currency: string;
    status: PaymentStatus;
    created_at: string | null;
    invoice: {
        id: number;
        status: InvoiceStatus;
        user: {
            id: number;
            name: string;
            email: string;
        } | null;
    } | null;
};

export type CheckoutPaymentProvider = {
    provider: 'stripe' | 'paypal' | string;
    mode: 'test' | 'live' | string;
};

export type AdminPaymentProviderModeSettings = {
    public_key: string | null;
    secret_key_masked: string | null;
    webhook_secret_masked: string | null;
    has_secret_key: boolean;
    has_webhook_secret: boolean;
};

export type AdminPaymentProviderSettings = {
    provider: 'stripe' | 'paypal' | string;
    mode: 'test' | 'live';
    enabled: boolean;
    settings: Record<'test' | 'live', AdminPaymentProviderModeSettings>;
};
