export type ProductConfigurationInputType = 'buttons' | 'select' | 'dropdown';

export type ProductConfigurationOption = {
    id: number;
    product_configuration_id: number;
    label: string;
    value: string;
    price_modifier: number | null;
    is_active: boolean;
    is_default: boolean;
    created_at: string | null;
    updated_at: string | null;
};

export type ProductConfiguration = {
    id: number;
    product_id: number;
    name: string;
    key: string;
    input_type: ProductConfigurationInputType;
    required: boolean;
    sort_order: number;
    created_at: string | null;
    updated_at: string | null;
    options: ProductConfigurationOption[];
};

export type ProductConfigurationPayload = {
    name: string;
    key: string;
    input_type: ProductConfigurationInputType;
    required: boolean;
    sort_order: number;
};

export type ProductConfigurationOptionPayload = {
    label: string;
    value: string;
    price_modifier: number | null;
    is_active: boolean;
    is_default: boolean;
};
