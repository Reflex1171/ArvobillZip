import type { InvoiceStatus, PaymentStatus } from '@/types/billing';

export type ClientBillingPaymentMethod = {
    id: string;
    provider: 'stripe' | 'paypal' | string;
    type: 'card' | 'paypal' | string;
    label: string;
    masked_details: string;
    is_default: boolean;
};

export type ClientBillingOutstandingInvoice = {
    id: number;
    created_at: string | null;
    amount: number;
    status: InvoiceStatus;
};

export type ClientBillingTransaction = {
    id: string;
    date: string | null;
    description: string;
    amount: number;
    method: string;
    status: PaymentStatus | InvoiceStatus;
};

export type ClientBillingSummary = {
    currency: string;
    current_balance: number;
    credit_balance: number;
    outstanding_amount: number;
};

export type ClientBillingPayload = {
    summary: ClientBillingSummary;
    payment_methods: ClientBillingPaymentMethod[];
    outstanding_invoices: ClientBillingOutstandingInvoice[];
    recent_transactions: ClientBillingTransaction[];
};
