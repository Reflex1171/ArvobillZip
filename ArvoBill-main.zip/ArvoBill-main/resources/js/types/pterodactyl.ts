export type PterodactylSettings = {
    panel_url: string | null;
    enabled: boolean;
    api_key_masked: string | null;
    has_api_key: boolean;
};

export type PterodactylNode = {
    id: number;
    name: string | null;
    location_id: number | null;
    memory: number;
    disk: number;
    allocated_resources: {
        memory: number;
        disk: number;
    };
    server_count: number;
};

export type PterodactylEgg = {
    id: number;
    name: string | null;
    nest: string | null;
    docker_image: string | null;
    startup: string | null;
    nest_id: number;
};

export type PterodactylAllocation = {
    id: number;
    node_id: number;
    ip: string | null;
    port: number;
    assigned: boolean;
};

export type PterodactylServer = {
    id: number;
    identifier: string | null;
    name: string | null;
    node: string | null;
    status: string | null;
    uuid: string | null;
};
