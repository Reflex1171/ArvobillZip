import type { ProductCategory } from './category';

export type Product = {
    id: number;
    name: string;
    slug: string;
    description: string;
    category_id: number | null;
    category: ProductCategory | null;
    price_monthly: number;
    setup_fee: number | null;
    billing_type: 'one_time' | 'recurring';
    billing_interval: number | null;
    billing_period: 'day' | 'week' | 'month' | 'year' | null;
    billing_cycle: string;
    billing_summary: string;
    allow_auto_renew: boolean;
    infrastructure_type: 'none' | 'pterodactyl' | string;
    pterodactyl_egg_id: number | null;
    pterodactyl_location_id: number | null;
    pterodactyl_default_node_id: number | null;
    auto_provision: boolean;
    is_active: boolean;
    created_at: string | null;
    updated_at: string | null;
};

export type ProductPayload = {
    name: string;
    slug: string;
    description: string;
    category_id: number;
    price_monthly: number;
    setup_fee: number | null;
    billing_type: 'one_time' | 'recurring';
    billing_interval: number | null;
    billing_period: 'day' | 'week' | 'month' | 'year' | null;
    allow_auto_renew: boolean;
    infrastructure_type: 'none' | 'pterodactyl';
    pterodactyl_egg_id: number | null;
    pterodactyl_location_id: number | null;
    pterodactyl_default_node_id: number | null;
    auto_provision: boolean;
    is_active: boolean;
};
