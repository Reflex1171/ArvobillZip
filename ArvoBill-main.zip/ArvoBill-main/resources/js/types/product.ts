import type { ProductCategory } from './category';

export type Product = {
    id: number;
    name: string;
    slug: string;
    description: string;
    category_id: number | null;
    category: ProductCategory | null;
    price_monthly: number;
    setup_fee: number | null;
    is_active: boolean;
    created_at: string | null;
    updated_at: string | null;
};

export type ProductPayload = {
    name: string;
    slug: string;
    description: string;
    category_id: number;
    price_monthly: number;
    setup_fee: number | null;
    is_active: boolean;
};
