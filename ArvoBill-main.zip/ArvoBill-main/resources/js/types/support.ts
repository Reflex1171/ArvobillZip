export type TicketStatus = 'open' | 'answered' | 'closed';
export type TicketPriority = 'low' | 'medium' | 'high';

export type TicketMessage = {
    id: number;
    user_id: number | null;
    message: string;
    is_admin: boolean;
    created_at: string | null;
    user: {
        id: number;
        name: string;
        email: string;
    } | null;
};

export type TicketSummary = {
    id: number;
    subject: string;
    status: TicketStatus;
    priority: TicketPriority;
    created_at: string | null;
    updated_at: string | null;
    last_reply_at: string | null;
    user: {
        id: number;
        name?: string;
        email?: string;
    } | null;
    messages: TicketMessage[] | null;
};

