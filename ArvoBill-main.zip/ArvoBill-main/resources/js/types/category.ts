export type ProductCategory = {
    id: number;
    name: string;
    slug: string;
    description: string | null;
    active_products_count?: number | null;
    products_count?: number | null;
    created_at?: string | null;
    updated_at?: string | null;
};

export type CategoryPayload = {
    name: string;
    slug: string;
    description: string | null;
};
