export type ThemeSettings = {
    brand_name: string;
    site_title: string;
    logo_url: string | null;
    favicon_url: string | null;
    primary_color: string;
    secondary_color: string;
    accent_color: string;
    background_color: string;
    surface_color: string;
    text_color: string;
    warm_white_color: string;
    warm_muted_color: string;
    sidebar_color: string;
    card_color: string;
    input_color: string;
};
