export type AffiliateClientEarning = {
    id: number;
    invoice_id: number;
    amount: number;
    status: 'pending' | 'approved' | 'paid' | 'rejected';
    eligible_at: string | null;
    approved_at: string | null;
    paid_at: string | null;
    created_at: string | null;
};

export type AffiliateClientPayload = {
    referral_link: string;
    affiliate_code: string;
    stats: {
        clicks: number;
        signups: number;
        pending_earnings: number;
        approved_earnings: number;
        affiliate_balance: number;
    };
    earnings: AffiliateClientEarning[];
};

export type AffiliateAdminSettings = {
    enabled: boolean;
    commission_percent: number;
    commission_scope: 'first_invoice' | 'recurring';
    approval_delay_days: number;
    eligible_product_ids: number[];
};

export type AffiliateAdminSummary = {
    id: number;
    name: string;
    email: string;
    affiliate_code: string | null;
    affiliate_balance: number;
    referrals_count: number;
    pending_earnings: number;
    approved_earnings: number;
};

export type AffiliateAdminEarning = {
    id: number;
    affiliate_user: { id: number; name: string; email: string } | null;
    referred_user: { id: number; name: string; email: string } | null;
    invoice_id: number;
    amount: number;
    status: 'pending' | 'approved' | 'paid' | 'rejected';
    eligible_at: string | null;
    approved_at: string | null;
    paid_at: string | null;
    created_at: string | null;
};

export type AffiliateAdminPayload = {
    settings: AffiliateAdminSettings;
    affiliates: AffiliateAdminSummary[];
    earnings: AffiliateAdminEarning[];
};

export type EmailSettingsPayload = {
    host: string | null;
    port: number;
    username: string | null;
    password_masked: string | null;
    encryption: 'tls' | 'ssl' | 'starttls' | null;
    from_address: string | null;
    from_name: string | null;
    enabled: boolean;
};

export type SocialProviderSettingsPayload = {
    google: {
        enabled: boolean;
        client_id: string | null;
        client_secret_masked: string | null;
        redirect_uri: string | null;
        team_id: string | null;
        key_id: string | null;
        private_key_masked: string | null;
    };
    apple: {
        enabled: boolean;
        client_id: string | null;
        client_secret_masked: string | null;
        redirect_uri: string | null;
        team_id: string | null;
        key_id: string | null;
        private_key_masked: string | null;
    };
};
