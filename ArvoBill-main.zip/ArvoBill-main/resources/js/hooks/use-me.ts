import { useEffect, useState } from 'react';

export type UserRole = 'user' | 'staff' | 'admin' | 'superuser';

export type MeUser = {
    id: number;
    name: string;
    email: string;
    role: UserRole;
    permissions: string[];
};

type UseMeResult = {
    me: MeUser | null;
    isLoading: boolean;
    error: string | null;
};

type MeResponse = {
    data: MeUser | null;
};

export function canAccessAdmin(role: UserRole | undefined): boolean {
    return role === 'staff' || role === 'admin' || role === 'superuser';
}

export function hasPermission(
    user: MeUser | null,
    permission: string,
): boolean {
    if (!user) return false;
    if (user.role === 'superuser' || user.role === 'admin') return true;
    return user.permissions.includes(permission);
}

export function useMe(): UseMeResult {
    const [me, setMe] = useState<MeUser | null>(null);
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);

    useEffect(() => {
        const controller = new AbortController();

        async function loadMe() {
            try {
                setIsLoading(true);
                const response = await fetch('/api/me', {
                    method: 'GET',
                    credentials: 'same-origin',
                    headers: {
                        Accept: 'application/json',
                    },
                    signal: controller.signal,
                });

                if (!response.ok) {
                    throw new Error(`Failed to load /api/me (${response.status}).`);
                }

                const data = (await response.json()) as MeResponse;
                setMe(data.data);
                setError(null);
            } catch (loadError) {
                if (!controller.signal.aborted) {
                    setError(
                        loadError instanceof Error
                            ? loadError.message
                            : 'Failed to load user context.',
                    );
                }
            } finally {
                if (!controller.signal.aborted) {
                    setIsLoading(false);
                }
            }
        }

        void loadMe();

        return () => {
            controller.abort();
        };
    }, []);

    return { me, isLoading, error };
}
