import type { InvoiceStatus, OrderStatus, PaymentStatus } from '@/types/billing';
import type { ServiceStatus } from '@/types/service';
import type { TicketStatus } from '@/types/support';

type StatusValue = OrderStatus | InvoiceStatus | PaymentStatus | TicketStatus | ServiceStatus;

type StatusBadgeProps = {
    status: StatusValue;
};

const classMap: Record<StatusValue, string> = {
    pending: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    unpaid: 'bg-amber-500/10 text-amber-400 border-amber-500/20',
    provisioning: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
    active: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    suspended: 'bg-orange-500/10 text-orange-400 border-orange-500/20',
    completed: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    paid: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20',
    cancelled: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
    open: 'bg-sky-500/10 text-sky-400 border-sky-500/20',
    answered: 'bg-violet-500/10 text-violet-400 border-violet-500/20',
    closed: 'bg-zinc-500/10 text-zinc-400 border-zinc-500/20',
    failed: 'bg-rose-500/10 text-rose-400 border-rose-500/20',
};

export function StatusBadge({ status }: StatusBadgeProps) {
    return (
        <span
            className={`inline-flex rounded-full px-2.5 py-0.5 text-[10px] font-bold uppercase tracking-wider border transition-all ${classMap[status]}`}
        >
            {status}
        </span>
    );
}

