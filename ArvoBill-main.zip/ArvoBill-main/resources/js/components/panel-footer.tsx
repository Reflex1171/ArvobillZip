type PanelFooterProps = {
    brandName: string;
    logoUrl?: string | null;
};

const footerSections = [
    {
        title: 'Product',
        links: [
            { label: 'Products', href: '/products' },
            { label: 'Services', href: '/client/services' },
            { label: 'Control Panel', href: '/client/dashboard' },
        ],
    },
    {
        title: 'Company',
        links: [
            { label: 'About', href: '#' },
            { label: 'Status', href: '#' },
            { label: 'Contact', href: '#' },
        ],
    },
    {
        title: 'Support',
        links: [
            { label: 'Knowledgebase', href: '#' },
            { label: 'Tickets', href: '/client/support' },
            { label: 'Live Chat', href: '#' },
        ],
    },
    {
        title: 'Legal',
        links: [
            { label: 'Terms', href: '#' },
            { label: 'Privacy', href: '#' },
            { label: 'Acceptable Use', href: '#' },
        ],
    },
];

export function PanelFooter({ brandName, logoUrl }: PanelFooterProps) {
    const year = new Date().getFullYear();

    return (
        <footer className="mt-8 border-t border-white/10 bg-[var(--panel-bg)]">
            <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
                <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-6">
                    <div className="md:col-span-2 xl:col-span-2">
                        {logoUrl ? (
                            <img
                                src={logoUrl}
                                alt={`${brandName} logo`}
                                className="h-8 w-auto object-contain object-left"
                            />
                        ) : (
                            <p className="text-lg font-semibold text-[var(--panel-text)]">{brandName}</p>
                        )}
                        <p className="mt-2 max-w-xl text-xs leading-relaxed text-white/72">
                            Game hosting made simple with clear billing, stable infrastructure, and human support.
                        </p>
                    </div>

                    {footerSections.map((section) => (
                        <div key={section.title}>
                            <h3 className="text-sm font-semibold text-[var(--panel-text)]">{section.title}</h3>
                            <ul className="mt-2 space-y-1.5">
                                {section.links.map((link) => (
                                    <li key={link.label}>
                                        <a
                                            href={link.href}
                                            className="text-xs text-white/72 transition hover:text-[var(--panel-primary)]"
                                        >
                                            {link.label}
                                        </a>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    ))}
                </div>

                <div className="mt-6 border-t border-white/10 pt-4">
                    <p className="text-xs text-white/55">
                        &copy; {year} {brandName}. All rights reserved.
                    </p>
                </div>
            </div>
        </footer>
    );
}
