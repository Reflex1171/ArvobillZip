import type { TicketPriority } from '@/types/support';

type PriorityBadgeProps = {
    priority: TicketPriority;
};

const classMap: Record<TicketPriority, string> = {
    low: 'bg-emerald-100 text-emerald-700 dark:bg-emerald-900/30 dark:text-emerald-300',
    medium: 'bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300',
    high: 'bg-rose-100 text-rose-700 dark:bg-rose-900/30 dark:text-rose-300',
};

export function PriorityBadge({ priority }: PriorityBadgeProps) {
    return (
        <span
            className={`rounded-full px-2.5 py-1 text-xs font-semibold capitalize ${classMap[priority]}`}
        >
            {priority}
        </span>
    );
}

