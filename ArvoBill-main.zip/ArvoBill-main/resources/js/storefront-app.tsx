import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './storefront/styles.css';
import { ThemeProvider } from './contexts/theme-context';
import { StorefrontApp } from './storefront/storefront-app';
import { initializeTheme } from './hooks/use-appearance';

const mountNode = document.getElementById('storefront-app');

if (!mountNode) {
    throw new Error('Storefront app mount node not found.');
}

initializeTheme();

createRoot(mountNode).render(
    <StrictMode>
        <ThemeProvider>
            <BrowserRouter>
                <StorefrontApp />
            </BrowserRouter>
        </ThemeProvider>
    </StrictMode>,
);
