import type { ServiceStatus, ServiceSummary } from '@/types/service';

type JsonInit = {
    method?: 'GET' | 'POST' | 'PATCH' | 'DELETE';
    body?: unknown;
};

type SingleResponse<T> = {
    data: T;
};

type ListResponse<T> = {
    data: T[];
};

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined
                ? { 'Content-Type': 'application/json' }
                : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }

    return (await response.json()) as T;
}

export async function listClientServices(): Promise<ServiceSummary[]> {
    const response = await requestJson<ListResponse<ServiceSummary>>('/api/services');
    return response.data;
}

export async function getClientService(id: string): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/services/${id}`,
    );
    return response.data;
}

export async function cancelClientService(id: string): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/services/${id}/cancel`,
        { method: 'POST' },
    );
    return response.data;
}

export async function upgradeClientService(id: string): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/services/${id}/upgrade`,
        { method: 'POST' },
    );
    return response.data;
}

export async function listAdminServices(filters?: {
    status?: ServiceStatus | '';
    product_id?: string | '';
}): Promise<ServiceSummary[]> {
    const query = new URLSearchParams();

    if (filters?.status) {
        query.set('status', filters.status);
    }

    if (filters?.product_id) {
        query.set('product_id', filters.product_id);
    }

    const suffix = query.toString() ? `?${query.toString()}` : '';
    const response = await requestJson<ListResponse<ServiceSummary>>(
        `/api/admin/services${suffix}`,
    );
    return response.data;
}

export async function getAdminService(id: string): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/admin/services/${id}`,
    );
    return response.data;
}

export async function updateAdminServiceStatus(
    id: string,
    status: ServiceStatus,
): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/admin/services/${id}/status`,
        {
            method: 'PATCH',
            body: { status },
        },
    );
    return response.data;
}

export async function suspendAdminService(id: string): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/admin/services/${id}/suspend`,
        { method: 'POST' },
    );
    return response.data;
}

export async function unsuspendAdminService(id: string): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/admin/services/${id}/unsuspend`,
        { method: 'POST' },
    );
    return response.data;
}

export async function provisionAdminService(
    id: string,
    payload: {
        node_id: number;
        egg_id: number;
        nest_id: number;
        allocation_id: number;
        limits: {
            memory: number;
            cpu: number;
            disk: number;
        };
    },
): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/admin/services/${id}/provision`,
        {
            method: 'POST',
            body: payload,
        },
    );
    return response.data;
}

export async function deleteAdminPterodactylServer(id: string): Promise<ServiceSummary> {
    const response = await requestJson<SingleResponse<ServiceSummary>>(
        `/api/admin/services/${id}/pterodactyl`,
        {
            method: 'DELETE',
        },
    );
    return response.data;
}
