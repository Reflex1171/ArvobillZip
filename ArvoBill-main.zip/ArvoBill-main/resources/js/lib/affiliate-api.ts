import type {
    AffiliateAdminPayload,
    AffiliateAdminSettings,
    AffiliateClientPayload,
    EmailSettingsPayload,
    SocialProviderSettingsPayload,
} from '@/types/affiliate';

type JsonInit = {
    method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
    body?: unknown;
};

type SingleResponse<T> = { data: T };

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ?? '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        let message = `Request failed: ${response.status}`;
        try {
            const data = (await response.json()) as { message?: string };
            if (data.message) message = data.message;
        } catch {
            // ignore
        }

        throw new Error(message);
    }

    return (await response.json()) as T;
}

export async function getClientAffiliateData(): Promise<AffiliateClientPayload> {
    const response = await requestJson<SingleResponse<AffiliateClientPayload>>('/api/client/affiliate');
    return response.data;
}

export async function requestAffiliatePayout(payload: {
    amount: number;
    payout_method?: 'bank_transfer' | 'paypal' | 'crypto' | 'other' | null;
    payout_details?: string | null;
}): Promise<void> {
    await requestJson('/api/client/affiliate/payout-requests', {
        method: 'POST',
        body: payload,
    });
}

export async function getAdminAffiliateData(): Promise<AffiliateAdminPayload> {
    const response = await requestJson<SingleResponse<AffiliateAdminPayload>>('/api/admin/affiliates');
    return response.data;
}

export async function updateAffiliateSettings(payload: AffiliateAdminSettings): Promise<void> {
    await requestJson('/api/admin/affiliates/settings', {
        method: 'PUT',
        body: payload,
    });
}

export async function updateAffiliateEarningStatus(
    earningId: number,
    status: 'approved' | 'rejected' | 'paid',
): Promise<void> {
    await requestJson(`/api/admin/affiliates/earnings/${earningId}`, {
        method: 'PATCH',
        body: { status },
    });
}

export async function getEmailSettings(): Promise<EmailSettingsPayload> {
    const response = await requestJson<SingleResponse<EmailSettingsPayload>>('/api/admin/settings/email');
    return response.data;
}

export async function updateEmailSettings(payload: {
    host: string | null;
    port: number;
    username: string | null;
    password?: string | null;
    encryption: 'tls' | 'ssl' | 'starttls' | null;
    from_address: string | null;
    from_name: string | null;
    enabled: boolean;
}): Promise<void> {
    await requestJson('/api/admin/settings/email', {
        method: 'PUT',
        body: payload,
    });
}

export async function sendEmailTest(email: string): Promise<void> {
    await requestJson('/api/admin/settings/email/test', {
        method: 'POST',
        body: { email },
    });
}

export async function getSocialProviderSettings(): Promise<SocialProviderSettingsPayload> {
    const response = await requestJson<SingleResponse<SocialProviderSettingsPayload>>('/api/admin/settings/social');
    return response.data;
}

export async function updateSocialProviderSettings(
    provider: 'google' | 'apple',
    payload: {
        enabled: boolean;
        client_id: string | null;
        client_secret?: string | null;
        redirect_uri: string | null;
        team_id?: string | null;
        key_id?: string | null;
        private_key?: string | null;
    },
): Promise<void> {
    await requestJson(`/api/admin/settings/social/${provider}`, {
        method: 'PUT',
        body: payload,
    });
}

export async function testSocialProvider(provider: 'google' | 'apple'): Promise<{ auth_url: string }> {
    const response = await requestJson<{ data: { auth_url: string } }>(
        `/api/admin/settings/social/${provider}/test`,
        {
            method: 'POST',
        },
    );
    return response.data;
}
