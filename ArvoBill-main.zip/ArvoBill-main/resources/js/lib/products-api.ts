import type { CategoryPayload, ProductCategory } from '@/types/category';
import type {
    ProductConfiguration,
    ProductConfigurationOption,
    ProductConfigurationOptionPayload,
    ProductConfigurationPayload,
} from '@/types/product-configuration';
import type { Product, ProductPayload } from '@/types/product';
import type { MeUser } from '@/hooks/use-me';
import type { AdminUserDetail } from '@/types/account';

type ProductResponse = {
    data: Product;
};

type ProductListResponse = {
    data: Product[];
};

type CategoryResponse = {
    data: ProductCategory;
};

type CategoryListResponse = {
    data: ProductCategory[];
};

type CategoryProductsResponse = {
    category: ProductCategory;
    data: Product[];
};

type ConfigurationResponse = {
    data: ProductConfiguration;
};

type ConfigurationListResponse = {
    data: ProductConfiguration[];
};

type ConfigurationOptionResponse = {
    data: ProductConfigurationOption;
};

type UsersResponse = {
    data: Array<
        Pick<MeUser, 'id' | 'name' | 'email' | 'role'> & {
            created_at: string | null;
            permissions: string[];
        }
    >;
};

type AdminUserDetailResponse = {
    data: AdminUserDetail;
};

type JsonInit = {
    method?: 'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE';
    body?: unknown;
};

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined
                ? { 'Content-Type': 'application/json' }
                : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }

    return (await response.json()) as T;
}

export function formatCurrency(amount: number): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD',
    }).format(amount);
}

export async function listClientProducts(): Promise<Product[]> {
    const response = await requestJson<ProductListResponse>('/api/products');

    return response.data;
}

export async function listClientProductsByCategory(slug: string): Promise<Product[]> {
    const response = await requestJson<CategoryProductsResponse>(
        `/api/categories/${slug}/products`,
    );

    return response.data;
}

export async function getClientProductBySlug(slug: string): Promise<Product> {
    const response = await requestJson<ProductResponse>(`/api/products/${slug}`);

    return response.data;
}

export async function listProductConfigurationsBySlug(
    slug: string,
): Promise<ProductConfiguration[]> {
    const response = await requestJson<ConfigurationListResponse>(
        `/api/products/${slug}/configurations`,
    );

    return response.data;
}

export async function listCategories(): Promise<ProductCategory[]> {
    const response = await requestJson<CategoryListResponse>('/api/categories');

    return response.data;
}

export async function listAdminProducts(): Promise<Product[]> {
    const response = await requestJson<ProductListResponse>('/api/admin/products');

    return response.data;
}

export async function listAdminProductConfigurations(
    productId: string,
): Promise<ProductConfiguration[]> {
    const response = await requestJson<ConfigurationListResponse>(
        `/api/admin/products/${productId}/configurations`,
    );

    return response.data;
}

export async function createAdminProductConfiguration(
    productId: string,
    payload: ProductConfigurationPayload,
): Promise<ProductConfiguration> {
    const response = await requestJson<ConfigurationResponse>(
        `/api/admin/products/${productId}/configurations`,
        {
            method: 'POST',
            body: payload,
        },
    );

    return response.data;
}

export async function updateAdminProductConfiguration(
    configurationId: string,
    payload: ProductConfigurationPayload,
): Promise<ProductConfiguration> {
    const response = await requestJson<ConfigurationResponse>(
        `/api/admin/configurations/${configurationId}`,
        {
            method: 'PUT',
            body: payload,
        },
    );

    return response.data;
}

export async function deleteAdminProductConfiguration(
    configurationId: number,
): Promise<void> {
    await requestJson(`/api/admin/configurations/${configurationId}`, {
        method: 'DELETE',
    });
}

export async function createAdminConfigurationOption(
    configurationId: string,
    payload: ProductConfigurationOptionPayload,
): Promise<ProductConfigurationOption> {
    const response = await requestJson<ConfigurationOptionResponse>(
        `/api/admin/configurations/${configurationId}/options`,
        {
            method: 'POST',
            body: payload,
        },
    );

    return response.data;
}

export async function updateAdminConfigurationOption(
    optionId: string,
    payload: ProductConfigurationOptionPayload,
): Promise<ProductConfigurationOption> {
    const response = await requestJson<ConfigurationOptionResponse>(
        `/api/admin/options/${optionId}`,
        {
            method: 'PUT',
            body: payload,
        },
    );

    return response.data;
}

export async function deleteAdminConfigurationOption(optionId: number): Promise<void> {
    await requestJson(`/api/admin/options/${optionId}`, {
        method: 'DELETE',
    });
}

export async function getAdminProductById(id: string): Promise<Product> {
    const response = await requestJson<ProductResponse>(`/api/admin/products/${id}`);

    return response.data;
}

export async function createAdminProduct(payload: ProductPayload): Promise<Product> {
    const response = await requestJson<ProductResponse>('/api/admin/products', {
        method: 'POST',
        body: payload,
    });

    return response.data;
}

export async function updateAdminProduct(
    id: string,
    payload: ProductPayload,
): Promise<Product> {
    const response = await requestJson<ProductResponse>(`/api/admin/products/${id}`, {
        method: 'PUT',
        body: payload,
    });

    return response.data;
}

export async function toggleAdminProduct(id: number): Promise<Product> {
    const response = await requestJson<ProductResponse>(
        `/api/admin/products/${id}/toggle`,
        {
            method: 'PATCH',
        },
    );

    return response.data;
}

export async function duplicateAdminProduct(id: number): Promise<Product> {
    const response = await requestJson<ProductResponse>(
        `/api/admin/products/${id}/duplicate`,
        {
            method: 'POST',
        },
    );

    return response.data;
}

export async function listAdminCategories(): Promise<ProductCategory[]> {
    const response = await requestJson<CategoryListResponse>('/api/admin/categories');

    return response.data;
}

export async function getAdminCategoryById(id: string): Promise<ProductCategory> {
    const response = await requestJson<CategoryResponse>(`/api/admin/categories/${id}`);

    return response.data;
}

export async function createAdminCategory(
    payload: CategoryPayload,
): Promise<ProductCategory> {
    const response = await requestJson<CategoryResponse>('/api/admin/categories', {
        method: 'POST',
        body: payload,
    });

    return response.data;
}

export async function updateAdminCategory(
    id: string,
    payload: CategoryPayload,
): Promise<ProductCategory> {
    const response = await requestJson<CategoryResponse>(
        `/api/admin/categories/${id}`,
        {
            method: 'PUT',
            body: payload,
        },
    );

    return response.data;
}

export async function deleteAdminCategory(id: number): Promise<void> {
    await requestJson(`/api/admin/categories/${id}`, {
        method: 'DELETE',
    });
}

export async function listAdminUsers(): Promise<UsersResponse['data']> {
    const response = await requestJson<UsersResponse>('/api/admin/users');

    return response.data;
}

export async function getAdminUserById(id: string): Promise<AdminUserDetail> {
    const response = await requestJson<AdminUserDetailResponse>(`/api/admin/users/${id}`);
    return response.data;
}

export async function updateAdminUserRole(
    id: string,
    role: 'user' | 'staff' | 'admin' | 'superuser',
): Promise<AdminUserDetail> {
    const response = await requestJson<AdminUserDetailResponse>(
        `/api/admin/users/${id}/role`,
        {
            method: 'PUT',
            body: { role },
        },
    );

    return response.data;
}

export async function updateAdminUserPermissions(
    id: string,
    permissions: string[],
): Promise<AdminUserDetail> {
    const response = await requestJson<AdminUserDetailResponse>(
        `/api/admin/users/${id}/permissions`,
        {
            method: 'PUT',
            body: { permissions },
        },
    );

    return response.data;
}

export async function syncAdminUserPterodactylAccount(
    id: string,
): Promise<AdminUserDetail> {
    const response = await requestJson<AdminUserDetailResponse>(
        `/api/admin/users/${id}/sync-pterodactyl`,
        {
            method: 'POST',
        },
    );

    return response.data;
}

export async function deleteAdminUser(id: string): Promise<void> {
    await requestJson(`/api/admin/users/${id}`, {
        method: 'DELETE',
    });
}
