import type { AccountProfile } from '@/types/account';

type JsonInit = {
    method?: 'GET' | 'PUT' | 'DELETE';
    body?: unknown;
};

type SingleResponse<T> = {
    data: T;
};

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined
                ? { 'Content-Type': 'application/json' }
                : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        let message = `Request failed: ${response.status}`;
        try {
            const payload = (await response.json()) as { message?: string };
            if (payload.message) {
                message = payload.message;
            }
        } catch {
            // no-op
        }
        throw new Error(message);
    }

    return (await response.json()) as T;
}

export async function getAccountProfile(): Promise<AccountProfile> {
    const response = await requestJson<SingleResponse<AccountProfile>>('/api/account');
    return response.data;
}

export async function updateAccountProfile(payload: {
    name: string;
    email: string;
}): Promise<void> {
    await requestJson('/api/account/profile', {
        method: 'PUT',
        body: payload,
    });
}

export async function updateAccountPassword(payload: {
    current_password: string;
    password: string;
    password_confirmation: string;
}): Promise<void> {
    await requestJson('/api/account/password', {
        method: 'PUT',
        body: payload,
    });
}

export async function deleteAccount(payload: {
    current_password: string;
}): Promise<void> {
    await requestJson('/api/account', {
        method: 'DELETE',
        body: payload,
    });
}
