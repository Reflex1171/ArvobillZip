import type { ThemeSettings } from '@/types/theme';

type ThemeResponse = {
    data: ThemeSettings;
};

async function requestJson<T>(url: string, init?: RequestInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            ...(init?.method && init.method !== 'GET'
                ? {
                      'Content-Type': 'application/json',
                      'X-CSRF-TOKEN': csrfToken,
                  }
                : {}),
            ...(init?.headers ?? {}),
        },
        ...init,
    });

    if (!response.ok) {
        throw new Error(`Theme request failed (${response.status})`);
    }

    return (await response.json()) as T;
}

export async function getThemeSettings(): Promise<ThemeSettings> {
    const response = await requestJson<ThemeResponse>('/api/theme');
    return response.data;
}

export async function updateThemeSettings(
    payload: ThemeSettings,
): Promise<ThemeSettings> {
    const response = await requestJson<ThemeResponse>('/api/admin/theme', {
        method: 'PUT',
        body: JSON.stringify(payload),
    });
    return response.data;
}
