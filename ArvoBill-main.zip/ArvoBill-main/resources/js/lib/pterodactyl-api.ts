import type {
    PterodactylAllocation,
    PterodactylEgg,
    PterodactylNode,
    PterodactylServer,
    PterodactylSettings,
} from '@/types/pterodactyl';

type JsonInit = {
    method?: 'GET' | 'POST' | 'PUT';
    body?: unknown;
};

type SingleResponse<T> = {
    data: T;
};

type ListResponse<T> = {
    data: T[];
};

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined ? { 'Content-Type': 'application/json' } : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        let message = `Request failed: ${response.status}`;
        try {
            const data = (await response.json()) as { message?: string };
            if (data.message) {
                message = data.message;
            }
        } catch {
            // no-op
        }
        throw new Error(message);
    }

    return (await response.json()) as T;
}

export async function getPterodactylSettings(): Promise<PterodactylSettings> {
    const response = await requestJson<SingleResponse<PterodactylSettings>>(
        '/api/admin/infrastructure/pterodactyl',
    );
    return response.data;
}

export async function updatePterodactylSettings(payload: {
    panel_url: string | null;
    api_key?: string | null;
    enabled: boolean;
}): Promise<PterodactylSettings> {
    const response = await requestJson<SingleResponse<PterodactylSettings>>(
        '/api/admin/infrastructure/pterodactyl',
        {
            method: 'PUT',
            body: payload,
        },
    );
    return response.data;
}

export async function testPterodactylConnection(): Promise<void> {
    await requestJson('/api/admin/infrastructure/pterodactyl/test', {
        method: 'POST',
    });
}

export async function listPterodactylNodes(): Promise<PterodactylNode[]> {
    const response = await requestJson<ListResponse<PterodactylNode>>(
        '/api/admin/infrastructure/nodes',
    );
    return response.data;
}

export async function listPterodactylEggs(): Promise<PterodactylEgg[]> {
    const response = await requestJson<ListResponse<PterodactylEgg>>(
        '/api/admin/infrastructure/eggs',
    );
    return response.data;
}

export async function listPterodactylAllocations(nodeId?: number): Promise<PterodactylAllocation[]> {
    const query = nodeId ? `?node_id=${encodeURIComponent(String(nodeId))}` : '';
    const response = await requestJson<ListResponse<PterodactylAllocation>>(
        `/api/admin/infrastructure/allocations${query}`,
    );
    return response.data;
}

export async function listPterodactylServers(): Promise<PterodactylServer[]> {
    const response = await requestJson<ListResponse<PterodactylServer>>(
        '/api/admin/infrastructure/servers',
    );
    return response.data;
}
