import type {
    TicketPriority,
    TicketStatus,
    TicketSummary,
} from '@/types/support';

type JsonInit = {
    method?: 'GET' | 'POST' | 'PATCH';
    body?: unknown;
};

type TicketResponse = {
    data: TicketSummary;
};

type TicketsResponse = {
    data: TicketSummary[];
};

type TicketPayload = {
    subject: string;
    priority: TicketPriority;
    message: string;
};

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined
                ? { 'Content-Type': 'application/json' }
                : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }

    return (await response.json()) as T;
}

export async function listClientTickets(): Promise<TicketSummary[]> {
    const response = await requestJson<TicketsResponse>('/api/tickets');
    return response.data;
}

export async function createClientTicket(
    payload: TicketPayload,
): Promise<TicketSummary> {
    const response = await requestJson<TicketResponse>('/api/tickets', {
        method: 'POST',
        body: payload,
    });

    return response.data;
}

export async function getClientTicket(id: string): Promise<TicketSummary> {
    const response = await requestJson<TicketResponse>(`/api/tickets/${id}`);
    return response.data;
}

export async function replyClientTicket(
    id: string,
    message: string,
): Promise<TicketSummary> {
    const response = await requestJson<TicketResponse>(`/api/tickets/${id}/reply`, {
        method: 'POST',
        body: { message },
    });

    return response.data;
}

export async function listAdminTickets(filters?: {
    status?: TicketStatus | '';
    priority?: TicketPriority | '';
}): Promise<TicketSummary[]> {
    const params = new URLSearchParams();

    if (filters?.status) params.set('status', filters.status);
    if (filters?.priority) params.set('priority', filters.priority);

    const query = params.toString();
    const response = await requestJson<TicketsResponse>(
        `/api/admin/tickets${query ? `?${query}` : ''}`,
    );

    return response.data;
}

export async function getAdminTicket(id: string): Promise<TicketSummary> {
    const response = await requestJson<TicketResponse>(`/api/admin/tickets/${id}`);
    return response.data;
}

export async function replyAdminTicket(
    id: string,
    message: string,
): Promise<TicketSummary> {
    const response = await requestJson<TicketResponse>(
        `/api/admin/tickets/${id}/reply`,
        {
            method: 'POST',
            body: { message },
        },
    );

    return response.data;
}

export async function updateAdminTicketStatus(
    id: string,
    status: TicketStatus,
): Promise<TicketSummary> {
    const response = await requestJson<TicketResponse>(
        `/api/admin/tickets/${id}/status`,
        {
            method: 'PATCH',
            body: { status },
        },
    );

    return response.data;
}

