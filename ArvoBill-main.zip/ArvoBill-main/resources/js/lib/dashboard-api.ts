import { formatCurrency } from './products-api';

type ClientDashboardResponse = {
    data: {
        stats: {
            active_services: number;
            open_tickets: number;
            outstanding_balance: number;
            next_invoice_due: {
                invoice_id: number;
                due_date: string | null;
            } | null;
        };
        services: Array<{
            id: number;
            service: string;
            plan: string;
            status: string;
            created_at: string | null;
        }>;
        recent_invoices: Array<{
            id: number;
            date: string | null;
            amount: number;
            status: string;
        }>;
        recent_activity: Array<{
            text: string;
            timestamp: string | null;
            invoice_id: number | null;
        }>;
    };
};

type AdminDashboardResponse = {
    data: {
        total_users: number;
        active_services: number;
        monthly_revenue: number;
        pending_orders: number;
    };
};

async function requestJson<T>(url: string): Promise<T> {
    const response = await fetch(url, {
        method: 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
        },
    });

    if (!response.ok) {
        throw new Error(`Request failed: ${response.status}`);
    }

    return (await response.json()) as T;
}

export async function getClientDashboardData() {
    const response = await requestJson<ClientDashboardResponse>('/api/dashboard');
    return response.data;
}

export async function getAdminDashboardData() {
    const response = await requestJson<AdminDashboardResponse>(
        '/api/admin/dashboard',
    );
    return response.data;
}

export function formatDashboardDate(value: string | null): string {
    if (!value) return '-';
    return new Date(value).toLocaleDateString('en-US', {
        year: 'numeric',
        month: 'short',
        day: 'numeric',
    });
}

export { formatCurrency };
