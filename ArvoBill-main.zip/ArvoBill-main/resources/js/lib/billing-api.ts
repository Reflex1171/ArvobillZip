import type {
    InvoiceStatus,
    InvoiceSummary,
    OrderSummary,
    CheckoutPaymentProvider,
    PaymentSummary,
    AdminPaymentProviderSettings,
} from '@/types/billing';
import type {
    ClientBillingPayload,
    ClientBillingOutstandingInvoice,
    ClientBillingPaymentMethod,
    ClientBillingTransaction,
} from '@/types/client-billing';

type JsonInit = {
    method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
    body?: unknown;
};

type SingleResponse<T> = {
    data: T;
};

type ListResponse<T> = {
    data: T[];
};
type BillingResponse = {
    data: ClientBillingPayload;
};

export type PromoValidationResult = {
    code: string | null;
    discount_amount: number;
    subtotal: number;
    final_total: number;
    promo: {
        type: 'percentage' | 'fixed';
        value: number;
        affiliate_exclusive: boolean;
        disables_affiliate: boolean;
    } | null;
};

export type AdminPromoCode = {
    id: number;
    code: string;
    type: 'percentage' | 'fixed';
    value: number;
    max_uses: number | null;
    max_redemptions_per_user: number | null;
    duration_cycles: number | null;
    uses: number;
    expires_at: string | null;
    minimum_order_amount: number | null;
    applies_to: 'all' | 'products' | 'categories';
    eligible_product_ids: number[];
    eligible_category_ids: number[];
    affiliate_exclusive: boolean;
    disables_affiliate: boolean;
    once_per_user: boolean;
    is_active: boolean;
    created_at: string | null;
    redemptions?: Array<{
        id: number;
        discount_amount: number;
        created_at: string | null;
        user: { id: number; name: string; email: string } | null;
        order_id: number | null;
        invoice_id: number | null;
    }> | null;
};

export function formatCurrency(amount: number, currency = 'USD'): string {
    return new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency,
    }).format(amount);
}

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined
                ? { 'Content-Type': 'application/json' }
                : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        let message = `Request failed: ${response.status}`;
        try {
            const data = (await response.json()) as { message?: string };
            if (data.message) {
                message = data.message;
            }
        } catch {
            // Response may not be JSON.
        }
        throw new Error(message);
    }

    return (await response.json()) as T;
}

export async function createOrder(
    productSlug: string,
    configurations?: Record<string, string>,
    promoCode?: string | null,
): Promise<OrderSummary> {
    const response = await requestJson<SingleResponse<OrderSummary>>('/api/orders', {
        method: 'POST',
        body: {
            product_slug: productSlug,
            configurations: configurations ?? {},
            promo_code: promoCode ?? null,
        },
    });

    return response.data;
}

export async function validatePromoCode(payload: {
    code: string;
    product_slug: string;
    configurations?: Record<string, string>;
}): Promise<PromoValidationResult> {
    const response = await requestJson<SingleResponse<PromoValidationResult>>(
        '/api/promo-codes/validate',
        {
            method: 'POST',
            body: payload,
        },
    );

    return response.data;
}

export async function listClientOrders(): Promise<OrderSummary[]> {
    const response = await requestJson<ListResponse<OrderSummary>>('/api/orders');
    return response.data;
}

export async function getClientOrder(id: string): Promise<OrderSummary> {
    const response = await requestJson<SingleResponse<OrderSummary>>(`/api/orders/${id}`);
    return response.data;
}

export async function listClientInvoices(): Promise<InvoiceSummary[]> {
    const response = await requestJson<ListResponse<InvoiceSummary>>('/api/invoices');
    return response.data;
}

export async function getClientInvoice(id: string): Promise<InvoiceSummary> {
    const response = await requestJson<SingleResponse<InvoiceSummary>>(
        `/api/invoices/${id}`,
    );
    return response.data;
}

export async function listAdminOrders(status?: string): Promise<OrderSummary[]> {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    const response = await requestJson<ListResponse<OrderSummary>>(
        `/api/admin/orders${query}`,
    );
    return response.data;
}

export async function getAdminOrder(id: string): Promise<OrderSummary> {
    const response = await requestJson<SingleResponse<OrderSummary>>(
        `/api/admin/orders/${id}`,
    );
    return response.data;
}

export async function listAdminInvoices(status?: string): Promise<InvoiceSummary[]> {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    const response = await requestJson<ListResponse<InvoiceSummary>>(
        `/api/admin/invoices${query}`,
    );
    return response.data;
}

export async function getAdminInvoice(id: string): Promise<InvoiceSummary> {
    const response = await requestJson<SingleResponse<InvoiceSummary>>(
        `/api/admin/invoices/${id}`,
    );
    return response.data;
}

export async function updateAdminInvoiceStatus(
    id: string,
    status: InvoiceStatus,
): Promise<InvoiceSummary> {
    const response = await requestJson<SingleResponse<InvoiceSummary>>(
        `/api/admin/invoices/${id}/status`,
        {
            method: 'PATCH',
            body: { status },
        },
    );

    return response.data;
}

type PaymentRedirectResponse = {
    data: {
        provider: string;
        checkout_url: string | null;
        provider_payment_id: string;
        paid_with_balance?: boolean;
    };
};

export type CheckoutStartResult = {
    provider: string;
    checkout_url: string | null;
    provider_payment_id: string;
    paid_with_balance: boolean;
};

export async function createStripePaymentSession(
    invoiceId: number,
): Promise<CheckoutStartResult> {
    const response = await requestJson<PaymentRedirectResponse>(
        '/api/payments/stripe/create-session',
        {
            method: 'POST',
            body: {
                invoice_id: invoiceId,
            },
        },
    );

    return {
        provider: response.data.provider,
        checkout_url: response.data.checkout_url,
        provider_payment_id: response.data.provider_payment_id,
        paid_with_balance: Boolean(response.data.paid_with_balance),
    };
}

export async function createPayPalPaymentOrder(
    invoiceId: number,
): Promise<CheckoutStartResult> {
    const response = await requestJson<PaymentRedirectResponse>(
        '/api/payments/paypal/create-order',
        {
            method: 'POST',
            body: {
                invoice_id: invoiceId,
            },
        },
    );

    return {
        provider: response.data.provider,
        checkout_url: response.data.checkout_url,
        provider_payment_id: response.data.provider_payment_id,
        paid_with_balance: Boolean(response.data.paid_with_balance),
    };
}

export async function capturePayPalPaymentOrder(
    invoiceId: number,
    orderId: string,
): Promise<void> {
    await requestJson('/api/payments/paypal/capture-order', {
        method: 'POST',
        body: {
            invoice_id: invoiceId,
            order_id: orderId,
        },
    });
}

export async function addFunds(
    amount: number,
    provider: 'stripe' | 'paypal',
): Promise<CheckoutStartResult> {
    const response = await requestJson<PaymentRedirectResponse>('/api/billing/add-funds', {
        method: 'POST',
        body: {
            amount,
            provider,
        },
    });

    return {
        provider: response.data.provider,
        checkout_url: response.data.checkout_url,
        provider_payment_id: response.data.provider_payment_id,
        paid_with_balance: Boolean(response.data.paid_with_balance),
    };
}

export async function confirmStripePaymentSession(
    invoiceId: number,
    sessionId: string,
): Promise<void> {
    await requestJson('/api/payments/stripe/confirm-session', {
        method: 'POST',
        body: {
            invoice_id: invoiceId,
            session_id: sessionId,
        },
    });
}

type ApplyCreditResponse = {
    data: {
        invoice_id: number;
        status: 'unpaid' | 'paid' | 'cancelled';
        applied_amount: number;
        remaining_total: number;
    };
};

export async function applyAccountCreditToInvoice(invoiceId: number): Promise<{
    invoice_id: number;
    status: 'unpaid' | 'paid' | 'cancelled';
    applied_amount: number;
    remaining_total: number;
}> {
    const response = await requestJson<ApplyCreditResponse>('/api/payments/apply-credit', {
        method: 'POST',
        body: {
            invoice_id: invoiceId,
        },
    });

    return response.data;
}

export async function listAdminPayments(
    params?: { status?: string; provider?: string },
): Promise<PaymentSummary[]> {
    const search = new URLSearchParams();
    if (params?.status) {
        search.set('status', params.status);
    }
    if (params?.provider) {
        search.set('provider', params.provider);
    }

    const query = search.toString();
    const response = await requestJson<ListResponse<PaymentSummary>>(
        `/api/admin/payments${query ? `?${query}` : ''}`,
    );

    return response.data;
}

export async function listCheckoutPaymentProviders(): Promise<CheckoutPaymentProvider[]> {
    const response = await requestJson<ListResponse<CheckoutPaymentProvider>>(
        '/api/payment-providers',
    );

    return response.data;
}

export async function listAdminPaymentProviders(): Promise<AdminPaymentProviderSettings[]> {
    const response = await requestJson<ListResponse<AdminPaymentProviderSettings>>(
        '/api/admin/payment-providers',
    );

    return response.data;
}

export async function updateAdminPaymentProvider(
    provider: string,
    payload: {
        mode: 'test' | 'live';
        enabled: boolean;
        public_key?: string | null;
        secret_key?: string | null;
        webhook_secret?: string | null;
        confirm_overwrite?: boolean;
    },
): Promise<void> {
    await requestJson(`/api/admin/payment-providers/${provider}`, {
        method: 'PUT',
        body: payload,
    });
}

export async function listAdminPromoCodes(): Promise<AdminPromoCode[]> {
    const response = await requestJson<ListResponse<AdminPromoCode>>('/api/admin/discounts');
    return response.data;
}

type AdminPromoPayload = Omit<
    AdminPromoCode,
    'id' | 'uses' | 'created_at' | 'redemptions' | 'once_per_user'
>;

export async function createAdminPromoCode(payload: AdminPromoPayload): Promise<AdminPromoCode> {
    const response = await requestJson<SingleResponse<AdminPromoCode>>('/api/admin/discounts', {
        method: 'POST',
        body: payload,
    });

    return response.data;
}

export async function updateAdminPromoCode(
    id: number,
    payload: AdminPromoPayload,
): Promise<AdminPromoCode> {
    const response = await requestJson<SingleResponse<AdminPromoCode>>(`/api/admin/discounts/${id}`, {
        method: 'PUT',
        body: payload,
    });

    return response.data;
}

export async function toggleAdminPromoCode(id: number): Promise<AdminPromoCode> {
    const response = await requestJson<SingleResponse<AdminPromoCode>>(`/api/admin/discounts/${id}/toggle`, {
        method: 'PATCH',
    });

    return response.data;
}

function isNotFoundError(error: unknown): boolean {
    if (!(error instanceof Error)) {
        return false;
    }

    const message = error.message.toLowerCase();

    return (
        message.includes('request failed: 404') ||
        message.includes('could not be found') ||
        message.includes('not found')
    );
}

function buildFallbackPaymentMethods(
    providers: CheckoutPaymentProvider[],
): ClientBillingPaymentMethod[] {
    return providers.map((provider) => ({
        id: `provider-${provider.provider}`,
        provider: provider.provider,
        type: provider.provider === 'paypal' ? 'paypal' : 'card',
        label: provider.provider === 'paypal' ? 'PayPal' : 'Card',
        masked_details:
            provider.provider === 'paypal'
                ? 'Sandbox account'
                : 'No saved cards yet',
        is_default: provider.provider === 'stripe',
    }));
}

function buildFallbackTransactions(
    invoices: InvoiceSummary[],
): ClientBillingTransaction[] {
    return invoices.slice(0, 15).map((invoice) => ({
        id: `invoice-${invoice.id}`,
        date: invoice.created_at,
        description: `Invoice #${invoice.id}`,
        amount: invoice.total,
        method: invoice.status === 'paid' ? 'Provider payment' : 'Pending payment',
        status: invoice.status,
    }));
}

function buildFallbackOutstandingInvoices(
    invoices: InvoiceSummary[],
): ClientBillingOutstandingInvoice[] {
    return invoices
        .filter((invoice) => invoice.status === 'unpaid')
        .slice(0, 10)
        .map((invoice) => ({
            id: invoice.id,
            created_at: invoice.created_at,
            amount: invoice.total,
            status: invoice.status,
        }));
}

export async function getClientBillingData(): Promise<ClientBillingPayload> {
    try {
        const response = await requestJson<BillingResponse>('/api/client/billing');
        return response.data;
    } catch (error) {
        if (!isNotFoundError(error)) {
            throw error;
        }
    }

    const [invoices, providers] = await Promise.all([
        listClientInvoices(),
        listCheckoutPaymentProviders().catch(() => []),
    ]);

    const outstandingAmount = invoices
        .filter((invoice) => invoice.status === 'unpaid')
        .reduce((sum, invoice) => sum + invoice.total, 0);

    return {
        summary: {
            currency: 'USD',
            current_balance: 0,
            credit_balance: 0,
            outstanding_amount: outstandingAmount,
        },
        payment_methods: buildFallbackPaymentMethods(providers),
        outstanding_invoices: buildFallbackOutstandingInvoices(invoices),
        recent_transactions: buildFallbackTransactions(invoices),
    };
}

type PaymentMethodResponse = {
    data: ClientBillingPaymentMethod;
};

type MessageResponse = {
    message: string;
};

export async function createClientPaymentMethod(payload: {
    provider: 'stripe' | 'paypal';
    type: 'card' | 'paypal';
    label: string;
    masked_details: string;
    provider_reference?: string | null;
    is_default: boolean;
}): Promise<ClientBillingPaymentMethod> {
    const response = await requestJson<PaymentMethodResponse>(
        '/api/client/billing/payment-methods',
        {
            method: 'POST',
            body: payload,
        },
    );

    return response.data;
}

export async function removeClientPaymentMethod(id: string): Promise<void> {
    await requestJson<MessageResponse>(`/api/client/billing/payment-methods/${id}`, {
        method: 'DELETE',
    });
}

export async function setDefaultClientPaymentMethod(id: string): Promise<void> {
    await requestJson<MessageResponse>(
        `/api/client/billing/payment-methods/${id}/default`,
        {
            method: 'PATCH',
        },
    );
}
