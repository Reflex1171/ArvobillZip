import type {
    InvoiceStatus,
    InvoiceSummary,
    OrderSummary,
    CheckoutPaymentProvider,
    PaymentSummary,
    AdminPaymentProviderSettings,
} from '@/types/billing';

type JsonInit = {
    method?: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
    body?: unknown;
};

type SingleResponse<T> = {
    data: T;
};

type ListResponse<T> = {
    data: T[];
};

async function requestJson<T>(url: string, init?: JsonInit): Promise<T> {
    const csrfToken =
        document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') ??
        '';

    const response = await fetch(url, {
        method: init?.method ?? 'GET',
        credentials: 'same-origin',
        headers: {
            Accept: 'application/json',
            'X-CSRF-TOKEN': csrfToken,
            ...(init?.body !== undefined
                ? { 'Content-Type': 'application/json' }
                : {}),
        },
        body: init?.body !== undefined ? JSON.stringify(init.body) : undefined,
    });

    if (!response.ok) {
        let message = `Request failed: ${response.status}`;
        try {
            const data = (await response.json()) as { message?: string };
            if (data.message) {
                message = data.message;
            }
        } catch {
            // Response may not be JSON.
        }
        throw new Error(message);
    }

    return (await response.json()) as T;
}

export async function createOrder(
    productSlug: string,
    configurations?: Record<string, string>,
): Promise<OrderSummary> {
    const response = await requestJson<SingleResponse<OrderSummary>>('/api/orders', {
        method: 'POST',
        body: {
            product_slug: productSlug,
            configurations: configurations ?? {},
        },
    });

    return response.data;
}

export async function listClientOrders(): Promise<OrderSummary[]> {
    const response = await requestJson<ListResponse<OrderSummary>>('/api/orders');
    return response.data;
}

export async function getClientOrder(id: string): Promise<OrderSummary> {
    const response = await requestJson<SingleResponse<OrderSummary>>(`/api/orders/${id}`);
    return response.data;
}

export async function listClientInvoices(): Promise<InvoiceSummary[]> {
    const response = await requestJson<ListResponse<InvoiceSummary>>('/api/invoices');
    return response.data;
}

export async function getClientInvoice(id: string): Promise<InvoiceSummary> {
    const response = await requestJson<SingleResponse<InvoiceSummary>>(
        `/api/invoices/${id}`,
    );
    return response.data;
}

export async function listAdminOrders(status?: string): Promise<OrderSummary[]> {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    const response = await requestJson<ListResponse<OrderSummary>>(
        `/api/admin/orders${query}`,
    );
    return response.data;
}

export async function getAdminOrder(id: string): Promise<OrderSummary> {
    const response = await requestJson<SingleResponse<OrderSummary>>(
        `/api/admin/orders/${id}`,
    );
    return response.data;
}

export async function listAdminInvoices(status?: string): Promise<InvoiceSummary[]> {
    const query = status ? `?status=${encodeURIComponent(status)}` : '';
    const response = await requestJson<ListResponse<InvoiceSummary>>(
        `/api/admin/invoices${query}`,
    );
    return response.data;
}

export async function getAdminInvoice(id: string): Promise<InvoiceSummary> {
    const response = await requestJson<SingleResponse<InvoiceSummary>>(
        `/api/admin/invoices/${id}`,
    );
    return response.data;
}

export async function updateAdminInvoiceStatus(
    id: string,
    status: InvoiceStatus,
): Promise<InvoiceSummary> {
    const response = await requestJson<SingleResponse<InvoiceSummary>>(
        `/api/admin/invoices/${id}/status`,
        {
            method: 'PATCH',
            body: { status },
        },
    );

    return response.data;
}

type PaymentRedirectResponse = {
    data: {
        provider: string;
        checkout_url: string;
        provider_payment_id: string;
    };
};

export async function createStripePaymentSession(invoiceId: number): Promise<string> {
    const response = await requestJson<PaymentRedirectResponse>(
        '/api/payments/stripe/create-session',
        {
            method: 'POST',
            body: {
                invoice_id: invoiceId,
            },
        },
    );

    return response.data.checkout_url;
}

export async function createPayPalPaymentOrder(invoiceId: number): Promise<string> {
    const response = await requestJson<PaymentRedirectResponse>(
        '/api/payments/paypal/create-order',
        {
            method: 'POST',
            body: {
                invoice_id: invoiceId,
            },
        },
    );

    return response.data.checkout_url;
}

export async function confirmStripePaymentSession(
    invoiceId: number,
    sessionId: string,
): Promise<void> {
    await requestJson('/api/payments/stripe/confirm-session', {
        method: 'POST',
        body: {
            invoice_id: invoiceId,
            session_id: sessionId,
        },
    });
}

export async function listAdminPayments(
    params?: { status?: string; provider?: string },
): Promise<PaymentSummary[]> {
    const search = new URLSearchParams();
    if (params?.status) {
        search.set('status', params.status);
    }
    if (params?.provider) {
        search.set('provider', params.provider);
    }

    const query = search.toString();
    const response = await requestJson<ListResponse<PaymentSummary>>(
        `/api/admin/payments${query ? `?${query}` : ''}`,
    );

    return response.data;
}

export async function listCheckoutPaymentProviders(): Promise<CheckoutPaymentProvider[]> {
    const response = await requestJson<ListResponse<CheckoutPaymentProvider>>(
        '/api/payment-providers',
    );

    return response.data;
}

export async function listAdminPaymentProviders(): Promise<AdminPaymentProviderSettings[]> {
    const response = await requestJson<ListResponse<AdminPaymentProviderSettings>>(
        '/api/admin/payment-providers',
    );

    return response.data;
}

export async function updateAdminPaymentProvider(
    provider: string,
    payload: {
        mode: 'test' | 'live';
        enabled: boolean;
        public_key?: string | null;
        secret_key?: string | null;
        webhook_secret?: string | null;
        confirm_overwrite?: boolean;
    },
): Promise<void> {
    await requestJson(`/api/admin/payment-providers/${provider}`, {
        method: 'PUT',
        body: payload,
    });
}
