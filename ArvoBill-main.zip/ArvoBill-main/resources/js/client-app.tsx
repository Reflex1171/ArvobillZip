import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import './client/styles.css';
import { ClientApp } from './client/client-app';
import { ThemeProvider } from './contexts/theme-context';
import { initializeTheme } from './hooks/use-appearance';

const mountNode = document.getElementById('client-app');

if (!mountNode) {
    throw new Error('Client app mount node not found.');
}

initializeTheme();

createRoot(mountNode).render(
    <StrictMode>
        <ThemeProvider>
            <BrowserRouter>
                <ClientApp />
            </BrowserRouter>
        </ThemeProvider>
    </StrictMode>,
);
