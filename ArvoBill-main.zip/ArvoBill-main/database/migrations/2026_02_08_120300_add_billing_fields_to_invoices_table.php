<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table): void {
            $table->string('type')->default('service')->after('order_id');
            $table->foreignId('service_id')->nullable()->after('order_id')->constrained()->nullOnDelete();
            $table->decimal('balance_applied', 12, 2)->default(0)->after('total');
            $table->json('meta')->nullable()->after('status');
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('service_id');
            $table->dropColumn(['type', 'balance_applied', 'meta']);
        });
    }
};

