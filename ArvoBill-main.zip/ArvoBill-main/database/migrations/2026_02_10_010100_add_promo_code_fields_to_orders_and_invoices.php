<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('orders', function (Blueprint $table): void {
            $table->foreignId('promo_code_id')->nullable()->after('product_id')->constrained('promo_codes')->nullOnDelete();
            $table->string('promo_code_code')->nullable()->after('promo_code_id');
            $table->decimal('discount_amount', 12, 2)->default(0)->after('status');
        });

        Schema::table('invoices', function (Blueprint $table): void {
            $table->foreignId('promo_code_id')->nullable()->after('service_id')->constrained('promo_codes')->nullOnDelete();
            $table->string('promo_code_code')->nullable()->after('promo_code_id');
            $table->decimal('discount_amount', 12, 2)->default(0)->after('subtotal');
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('promo_code_id');
            $table->dropColumn(['promo_code_code', 'discount_amount']);
        });

        Schema::table('orders', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('promo_code_id');
            $table->dropColumn(['promo_code_code', 'discount_amount']);
        });
    }
};