<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('services', function (Blueprint $table): void {
            $table->boolean('cancel_at_period_end')->default(false)->after('auto_renew');
            $table->timestamp('cancel_requested_at')->nullable()->after('cancel_at_period_end');
            $table->timestamp('cancelled_at')->nullable()->after('cancel_requested_at');
            $table->text('cancellation_reason')->nullable()->after('cancelled_at');
        });
    }

    public function down(): void
    {
        Schema::table('services', function (Blueprint $table): void {
            $table->dropColumn([
                'cancel_at_period_end',
                'cancel_requested_at',
                'cancelled_at',
                'cancellation_reason',
            ]);
        });
    }
};
