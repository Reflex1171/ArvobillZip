<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('payment_provider_settings', function (Blueprint $table) {
            $table->id();
            $table->string('provider');
            $table->string('mode');
            $table->string('public_key')->nullable();
            $table->text('secret_key');
            $table->text('webhook_secret')->nullable();
            $table->boolean('enabled')->default(false);
            $table->timestamps();

            $table->unique(['provider', 'mode']);
            $table->index(['provider', 'enabled']);
        });

        $now = now();
        DB::table('payment_provider_settings')->insert([
            [
                'provider' => 'stripe',
                'mode' => 'test',
                'public_key' => null,
                'secret_key' => encrypt(''),
                'webhook_secret' => encrypt(''),
                'enabled' => false,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            [
                'provider' => 'stripe',
                'mode' => 'live',
                'public_key' => null,
                'secret_key' => encrypt(''),
                'webhook_secret' => encrypt(''),
                'enabled' => false,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            [
                'provider' => 'paypal',
                'mode' => 'test',
                'public_key' => null,
                'secret_key' => encrypt(''),
                'webhook_secret' => encrypt(''),
                'enabled' => false,
                'created_at' => $now,
                'updated_at' => $now,
            ],
            [
                'provider' => 'paypal',
                'mode' => 'live',
                'public_key' => null,
                'secret_key' => encrypt(''),
                'webhook_secret' => encrypt(''),
                'enabled' => false,
                'created_at' => $now,
                'updated_at' => $now,
            ],
        ]);
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('payment_provider_settings');
    }
};
