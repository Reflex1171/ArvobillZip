<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('services', function (Blueprint $table) {
            $table->json('provisioning_snapshot')
                ->nullable()
                ->after('pterodactyl_allocation_id');
            $table->text('provisioning_error')
                ->nullable()
                ->after('provisioning_snapshot');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('services', function (Blueprint $table) {
            $table->dropColumn([
                'provisioning_snapshot',
                'provisioning_error',
            ]);
        });
    }
};
