<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->boolean('trial_enabled')->default(false)->after('allow_auto_renew');
            $table->unsignedInteger('trial_interval')->nullable()->after('trial_enabled');
            $table->string('trial_period')->nullable()->after('trial_interval');
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->dropColumn(['trial_enabled', 'trial_interval', 'trial_period']);
        });
    }
};
