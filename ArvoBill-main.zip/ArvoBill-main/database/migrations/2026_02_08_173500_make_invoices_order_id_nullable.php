<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('invoices', function (Blueprint $table): void {
            $table->dropForeign(['order_id']);
        });

        Schema::table('invoices', function (Blueprint $table): void {
            $table->unsignedBigInteger('order_id')->nullable()->change();
        });

        Schema::table('invoices', function (Blueprint $table): void {
            $table->foreign('order_id')->references('id')->on('orders')->nullOnDelete();
        });
    }

    public function down(): void
    {
        Schema::table('invoices', function (Blueprint $table): void {
            $table->dropForeign(['order_id']);
        });

        Schema::table('invoices', function (Blueprint $table): void {
            $table->unsignedBigInteger('order_id')->nullable(false)->change();
        });

        Schema::table('invoices', function (Blueprint $table): void {
            $table->foreign('order_id')->references('id')->on('orders')->cascadeOnDelete();
        });
    }
};

