<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->string('billing_type')->default('monthly_subscription')->after('setup_fee');
            $table->string('billing_cycle')->default('monthly')->after('billing_type');
            $table->boolean('allow_auto_renew')->default(true)->after('billing_cycle');
        });
    }

    public function down(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->dropColumn(['billing_type', 'billing_cycle', 'allow_auto_renew']);
        });
    }
};

