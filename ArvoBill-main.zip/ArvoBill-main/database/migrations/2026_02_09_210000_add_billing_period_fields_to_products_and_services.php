<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('products', function (Blueprint $table): void {
            $table->unsignedInteger('billing_interval')->nullable()->after('billing_type');
            $table->string('billing_period')->nullable()->after('billing_interval');
        });

        Schema::table('services', function (Blueprint $table): void {
            $table->date('next_due_at')->nullable()->after('next_due_date');
            $table->json('billing_snapshot')->nullable()->after('next_due_at');
        });

        DB::table('products')
            ->where('billing_type', 'monthly_subscription')
            ->update(['billing_type' => 'recurring']);

        DB::table('products')
            ->where('billing_type', 'recurring')
            ->whereNull('billing_interval')
            ->update(['billing_interval' => 1]);

        DB::table('products')
            ->where('billing_type', 'recurring')
            ->where(function ($query): void {
                $query->whereNull('billing_period')
                    ->orWhere('billing_period', '')
                    ->orWhere('billing_period', 'monthly');
            })
            ->update(['billing_period' => 'month']);

        DB::table('products')
            ->where('billing_type', 'one_time')
            ->update([
                'billing_interval' => null,
                'billing_period' => null,
                'allow_auto_renew' => false,
            ]);

        DB::table('services')
            ->whereNull('next_due_at')
            ->update([
                'next_due_at' => DB::raw('next_due_date'),
            ]);

        DB::table('services')
            ->whereNull('billing_snapshot')
            ->orderBy('id')
            ->chunkById(200, function ($rows): void {
                foreach ($rows as $row) {
                    $product = DB::table('products')
                        ->select('billing_type', 'billing_interval', 'billing_period', 'price_monthly')
                        ->where('id', $row->product_id)
                        ->first();

                    $billingType = (string) ($product->billing_type ?? 'recurring');
                    $interval = max(1, (int) ($product->billing_interval ?? 1));
                    $period = (string) ($product->billing_period ?? 'month');

                    $snapshot = [
                        'billing_type' => $billingType,
                        'billing_interval' => $interval,
                        'billing_period' => $period,
                        'price' => (float) ($product->price_monthly ?? 0),
                        'currency' => 'USD',
                    ];

                    DB::table('services')
                        ->where('id', $row->id)
                        ->update(['billing_snapshot' => json_encode($snapshot)]);
                }
            });
    }

    public function down(): void
    {
        Schema::table('services', function (Blueprint $table): void {
            $table->dropColumn(['next_due_at', 'billing_snapshot']);
        });

        Schema::table('products', function (Blueprint $table): void {
            $table->dropColumn(['billing_interval', 'billing_period']);
        });
    }
};

