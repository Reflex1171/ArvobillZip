<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('theme_settings', function (Blueprint $blueprint) {
            $blueprint->string('sidebar_color')->default('#1a1c23')->after('warm_muted_color');
            $blueprint->string('card_color')->default('#24262d')->after('sidebar_color');
            $blueprint->string('input_color')->default('#2d2f36')->after('card_color');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('theme_settings', function (Blueprint $blueprint) {
            $blueprint->dropColumn(['sidebar_color', 'card_color', 'input_color']);
        });
    }
};
