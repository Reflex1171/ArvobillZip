<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        if (! Schema::hasTable('social_provider_settings')) {
            return;
        }

        $driver = DB::getDriverName();
        if ($driver === 'mysql') {
            DB::statement('ALTER TABLE social_provider_settings MODIFY client_secret TEXT NULL');
        } elseif ($driver === 'pgsql') {
            DB::statement('ALTER TABLE social_provider_settings ALTER COLUMN client_secret TYPE TEXT');
        }
    }

    public function down(): void
    {
        if (! Schema::hasTable('social_provider_settings')) {
            return;
        }

        $driver = DB::getDriverName();
        if ($driver === 'mysql') {
            DB::statement('ALTER TABLE social_provider_settings MODIFY client_secret VARCHAR(255) NULL');
        } elseif ($driver === 'pgsql') {
            DB::statement('ALTER TABLE social_provider_settings ALTER COLUMN client_secret TYPE VARCHAR(255)');
        }
    }
};
