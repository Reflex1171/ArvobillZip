<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('services', function (Blueprint $table): void {
            $table->boolean('auto_renew')->default(true)->after('billing_cycle');
            $table->foreignId('default_payment_method_id')
                ->nullable()
                ->after('auto_renew')
                ->constrained('user_payment_methods')
                ->nullOnDelete();
            $table->unsignedInteger('renewal_failure_count')->default(0)->after('default_payment_method_id');
            $table->timestamp('last_renewed_at')->nullable()->after('renewal_failure_count');
        });
    }

    public function down(): void
    {
        Schema::table('services', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('default_payment_method_id');
            $table->dropColumn(['auto_renew', 'renewal_failure_count', 'last_renewed_at']);
        });
    }
};

