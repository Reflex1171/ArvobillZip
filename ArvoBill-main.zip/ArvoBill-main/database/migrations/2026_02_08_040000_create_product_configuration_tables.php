<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('product_configurations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_id')->constrained()->cascadeOnDelete();
            $table->string('name');
            $table->string('key');
            $table->string('input_type');
            $table->boolean('required')->default(true);
            $table->unsignedInteger('sort_order')->default(0);
            $table->timestamps();

            $table->unique(['product_id', 'key']);
            $table->index(['product_id', 'sort_order']);
        });

        Schema::create('product_configuration_options', function (Blueprint $table) {
            $table->id();
            $table->foreignId('product_configuration_id')
                ->constrained()
                ->cascadeOnDelete();
            $table->string('label');
            $table->string('value');
            $table->decimal('price_modifier', 10, 2)->nullable();
            $table->boolean('is_active')->default(true);
            $table->timestamps();

            $table->index(['product_configuration_id', 'is_active']);
        });

        Schema::create('order_configurations', function (Blueprint $table) {
            $table->id();
            $table->foreignId('order_id')->constrained()->cascadeOnDelete();
            $table->string('configuration_key');
            $table->string('selected_value');
            $table->decimal('price_modifier', 10, 2)->default(0);
            $table->timestamp('created_at')->nullable();

            $table->index('order_id');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('order_configurations');
        Schema::dropIfExists('product_configuration_options');
        Schema::dropIfExists('product_configurations');
    }
};

