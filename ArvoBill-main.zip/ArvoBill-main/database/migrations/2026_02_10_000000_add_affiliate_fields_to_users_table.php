<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->string('affiliate_code', 32)->nullable()->unique()->after('balance');
            $table->foreignId('referred_by')->nullable()->after('affiliate_code')->constrained('users')->nullOnDelete();
            $table->decimal('affiliate_balance', 12, 2)->default(0)->after('referred_by');
        });
    }

    public function down(): void
    {
        Schema::table('users', function (Blueprint $table): void {
            $table->dropConstrainedForeignId('referred_by');
            $table->dropUnique('users_affiliate_code_unique');
            $table->dropColumn(['affiliate_code', 'affiliate_balance']);
        });
    }
};