<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('affiliate_settings', function (Blueprint $table): void {
            $table->id();
            $table->boolean('enabled')->default(true);
            $table->decimal('commission_percent', 5, 2)->default(10);
            $table->enum('commission_scope', ['first_invoice', 'recurring'])->default('first_invoice');
            $table->unsignedInteger('approval_delay_days')->default(30);
            $table->json('eligible_product_ids')->nullable();
            $table->timestamps();
        });

        Schema::create('affiliate_referral_visits', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('affiliate_user_id')->constrained('users')->cascadeOnDelete();
            $table->string('affiliate_code', 32);
            $table->string('ip_address', 45)->nullable();
            $table->text('user_agent')->nullable();
            $table->foreignId('referred_user_id')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('converted_at')->nullable();
            $table->timestamps();

            $table->index(['affiliate_user_id', 'created_at']);
            $table->index(['affiliate_code', 'created_at']);
        });

        Schema::create('affiliate_earnings', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('affiliate_user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('referred_user_id')->constrained('users')->cascadeOnDelete();
            $table->foreignId('invoice_id')->constrained('invoices')->cascadeOnDelete();
            $table->decimal('amount', 12, 2);
            $table->enum('status', ['pending', 'approved', 'paid', 'rejected'])->default('pending');
            $table->timestamp('eligible_at')->nullable();
            $table->timestamp('approved_at')->nullable();
            $table->timestamp('paid_at')->nullable();
            $table->foreignId('approved_by')->nullable()->constrained('users')->nullOnDelete();
            $table->json('meta')->nullable();
            $table->timestamps();

            $table->unique(['affiliate_user_id', 'invoice_id']);
            $table->index(['status', 'eligible_at']);
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('affiliate_earnings');
        Schema::dropIfExists('affiliate_referral_visits');
        Schema::dropIfExists('affiliate_settings');
    }
};