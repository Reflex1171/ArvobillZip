<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::table('affiliate_settings', function (Blueprint $table): void {
            $table->decimal('first_invoice_commission_percent', 5, 2)->default(15)->after('commission_percent');
            $table->decimal('recurring_commission_percent', 5, 2)->default(5)->after('first_invoice_commission_percent');
        });

        $driver = DB::getDriverName();
        if ($driver === 'mysql') {
            DB::statement(
                "ALTER TABLE affiliate_settings MODIFY commission_scope ENUM('first_invoice','recurring','tiered') DEFAULT 'first_invoice'"
            );
        }

        DB::table('affiliate_settings')
            ->whereNull('first_invoice_commission_percent')
            ->update(['first_invoice_commission_percent' => DB::raw('commission_percent')]);

        DB::table('affiliate_settings')
            ->whereNull('recurring_commission_percent')
            ->update(['recurring_commission_percent' => DB::raw('commission_percent')]);
    }

    public function down(): void
    {
        $driver = DB::getDriverName();
        if ($driver === 'mysql') {
            DB::statement(
                "ALTER TABLE affiliate_settings MODIFY commission_scope ENUM('first_invoice','recurring') DEFAULT 'first_invoice'"
            );
        }

        Schema::table('affiliate_settings', function (Blueprint $table): void {
            $table->dropColumn(['first_invoice_commission_percent', 'recurring_commission_percent']);
        });
    }
};
